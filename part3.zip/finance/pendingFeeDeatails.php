<?php
include_once './protectedAdmin.php';
//session_start();
include_once '../db.php';
include_once '../inc/conf.php';
ob_start();
?>
<script>
function modeOfPayment(mode)
    {
        var bank_name = document.getElementsByName("bank_name");
        var branch_name = document.getElementsByName("branch_add");
        var ref_no = document.getElementsByName("ref_no");
        //alert(bank_name[0].readOnly);
        //alert(mode);
        if (mode == 'cash') {
            bank_name[0].value = "Not Applicable";
            branch_name[0].innerHTML = "Not Applicable";
            ref_no[0].value = "Not Applicable";
            bank_name[0].readOnly = true;
            branch_name[0].readOnly = true;
            ref_no[0].readOnly = true;
        } else {
            bank_name[0].value = "";
            branch_name[0].innerHTML = "";
            ref_no[0].value = "";
            bank_name[0].readOnly = false;
            branch_name[0].readOnly = false;
            ref_no[0].readOnly = false;

        }
    }
</script>
<?php
if(isset($_POST['submit'])){
$receivedAmount=$_GET['paid'];
$pendingAmount=$_GET['pending'];
$oldMr=$_GET['mr'];
$mrNumber_part1 = substr($oldMr,0,7);
$mrNumber_part2 = substr($oldMr,7);
$newMrNumber=$mrNumber_part1."/IA".$mrNumber_part2;
$date=date('Y/m/d');
$pay_type=$_POST['pay_type'];
$bank_name=$_POST['bank_name'];
$branch_add=$_POST['branch_add'];
$ref_no=$_POST['ref_no'];

$sql = "INSERT INTO `tbl_update_amount` (`old_mrNumber`, `new_mrNumber`, `date`, `received_amount`, `again_pending`, `payment_type`, `bank_name`, `bank_addr`, `refNum`) VALUES ('$oldMr', '$newMrNumber', '$date', '$receivedAmount', '$pendingAmount', '$pay_type', '$bank_name' ,'$branch_add', '$ref_no');";
//echo $sql;
    $res = mysql_query($sql);
    if ($res) {
        //$id = mysql_insert_id();
        $mrNumberNew = $newMrNumber;
        //$mrNumberNew.=$id;
        $_SESSION['errMsg'] = "<script>alert('Data saved successfully')</script>";
        //$queryUpdate = "update tbl_finance set mr_number='$mrNumberNew' where finance_id=$id";
        //echo $queryUpdate."<br />";
        //var_dump($_SESSION['mrNumber']);
        //echo "<br />".$mrNumberNew;
        //$resUpdate = mysql_query($queryUpdate);
        ?>
        <script type="text/javascript">
            window.location="clearedFeesPrint.php?id=<?php echo $oldMr ?>&received=<?php echo $receivedAmount ?>";
        </script>
        <?php
    } else
        $_SESSION['errMsg'] = "<script>alert('Problem Occurred. Please try again')</script>";
}

?>
<form method="post">
<table border="0">
			<tr>
                <td class="alignRight">Select type of payment</td>
                <td><select name="pay_type" style="width: 250px;" onchange="modeOfPayment(this.value)" >
                        <option>Select</option>
                        <option value="cash">CASH</option>
                        <option value="dd">DEMAND DRAFT</option>
                        <option value="neft">NEFT TRANSFER</option>
                        <option value="rtgs">RTGS TRANSFER</option>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Name of the Bank</td>
                <td><input type="text" name="bank_name" value=""  style="width: 250px;" /></td>
            </tr>
            <tr>
                <td class="alignRight">Branch Address and Details</td>
                <td><textarea name="branch_add"  style="width: 250px;height: 100px;" ></textarea></td>
            </tr>
            <tr>
                <td class="alignRight">Payment reference Number<br />(DD Number/NEFT Number/RTGS Number)</td>
                <td><input type="text" name="ref_no" value=""  style="width: 250px;" /></td>
            </tr>
			<tr align="center">
                <td colspan="2"><input type="submit" name="submit" value="Print"  style="width: 250px;" /></td>
            </tr>
</table>
</form>
<?php
$content = ob_get_contents();
ob_end_clean();
include_once './template.php';
if (isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg'])) {
    echo $_SESSION['errMsg'];
    unset($_SESSION['errMsg']);
}
?>