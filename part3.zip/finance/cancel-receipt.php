<?php
include_once './protectedAdmin.php';
ob_start();
include_once '../db.php';
if(isset($_POST['btn_cancel']) && $_POST['btn_cancel']=="Submit"){
    $mrNumberNew=$_POST['mr_number'];
    $admin=$_SESSION['userName'];
    $refundAmount=$_POST['refund'];
    $comment=$_POST['comment'];
    $queryCancel="insert into tbl_finance_cancel values(NULL,'$mrNumberNew',curdate(),'$admin',$refundAmount,'$comment','Cancellation')";
    $resCancel=  mysql_query($queryCancel);
    if($resCancel){
        $_SESSION['errMsg']="<script>alert('This Money Receipt has been cancelled successfully.')</script>"; 
        ?>
            <script type="text/javascript">
                window.open("receiptPrint.php?type=ol&id=<?php echo $mrNumberNew?>","plain","");
            </script>
            <?php
    }
    else
        $_SESSION['errMsg']="<script>alert('Problem occurred. Please try again')</script>";  
}
if(isset($_POST['btn_mr']) && $_POST['btn_mr']=="Fetch"){
    $mrNumberNew=$_POST['id'];
    $queryVerify="SELECT * 
FROM tbl_finance tf
LEFT JOIN tbl_particular_sub tps ON tf.particular_sub_id = tps.particular_sub_id
LEFT JOIN tbl_particular tp ON tps.particular_id = tp.particular_id
LEFT JOIN tbl_admin ta ON tf.admin = ta.user_id
LEFT JOIN tbl_finance_cancel tfc ON tf.mr_number = tfc.mr_number
WHERE tf.mr_number =  '$mrNumberNew'";
    //echo $queryVerify;
    $resVerify=  mysql_query($queryVerify);
    if(mysql_num_rows($resVerify)==1){
        $rowVerify=  mysql_fetch_array($resVerify);
        if(empty($rowVerify['cancel_id'])){
            ?>
<script>
    function viewSelectedForm(c){
        var obj=document.getElementById("cancelForm");
        var obj1=document.getElementById("transferForm");
        if(c.value=='cancel'){
            obj.style.display="block";
            obj1.style.display="none";
        }else{
            obj1.style.display="block";
            obj.style.display="none";
        }
    }
    function confirmCancel(c){
        var option = confirm("Do you want to cancel the money receipt with number "+c.mr_number.value+"?");
        if(option==true)
            return true;
        else
            return false;
    }
</script>
<table align='center'>
    <tr>
        <td><input type="radio" value="cancel" name="task" onclick="viewSelectedForm(this)" />Cancel the Money Receipt</td>
        <td><input type="radio" value="transfer" name="task" onclick="viewSelectedForm(this)" />Transfer the Money Receipt</td>
    </tr>
    <tr>
        <td colspan="2">
            <form style="display:none" id='cancelForm' method="post" onsubmit="return confirmCancel(this)">
                <input type="hidden" value="<?php echo $mrNumberNew?>" name='mr_number' />
                <table>
                    <tr>
                        <td>Refund Amount : </td>
                        <td><input type="text" name="refund" /></td>
                    </tr>
                    <tr>
                        <td>Comments : </td>
                        <td><textarea name="comment" rows="10" cols="40"></textarea></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="submit" name='btn_cancel' value='Submit' /></td>
                    </tr>
                </table>
                
            </form>
            <form style="display:none" id='transferForm' method="post">
                <input type="hidden" value="<?php echo $mrNumberNew?>" name='mr_number' />
                Coming Up Soon
            </form>
        </td>
    </tr>
</table>
<?php
            
$receipt='
<table align="center" bgcolor="#DFDFDF" >
    <tr>
        <td align="left">
            <b>M.R. NO : '.$mrNumberNew.'</b>
        </td>
        <td align="right">
            <b>DATE : '.$rowVerify['date'].'</b>
        </td>
    </tr>
    <tr align="left">
        <td>
            Name
        </td>
        <td>
            '.$rowVerify[9].'
        </td>
    </tr>
    <tr align="left">
        <td>
            Roll no
        </td>
        <td>
            '.$rowVerify['roll_no'].'
        </td>
    </tr>
    <tr align="left">
        <td>
            Course
        </td>
        <td>
            '.$rowVerify['stream'].'
        </td>
    </tr>
    <tr align="left">
        <td>
            Branch
        </td>
        <td>
            '.$rowVerify['branch'].'
        </td>
    </tr>
    <tr align="left">
        <td>
            Year of Joining Batch
        </td>
        <td>
            '.$rowVerify['year_join'].'
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" style="border-style: solid">
                <tr>
                    <th width="100"><b>Sl. No.</b></th>
                    <th width="370"><b>Particulars</b></th>
                    <th width="180"><b>Amount(Rs)</b></th>
                </tr>
                <tr>
                    <td width="100">1</td>
                    <td>'.$rowVerify[24].' - '.$rowVerify[22].'</td>
                    <td>'.$rowVerify['amount'].'</td>
                </tr>
                <tr>
                    <th colspan="3" align="right">
                        <b>Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;'.$rowVerify['amount'].'&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
                    </th>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" align="left">
            Remarks : '.$rowVerify[16].'
        </td>
    </tr>
    <tr align="left">
        <td colspan="2">Received as per following details :</td>
    </tr>
    <tr>
        <td colspan="2">
            <table>
                <tr>
                    <th><b>Sl No</b></th>
                    <th><b>Mode</b></th>
                    <th><b>Instrument No</b></th>
                    <th><b>Date</b></th>
                    <th><b>Amount</b></th>
                    <th><b>Drawn On</b></th>
                </tr>
                <tr>
                    <td>1.</td>
                    <td>'.$rowVerify[4].'</td>
                    <td>'.$rowVerify['payment_ref_no'].'</td>
                    <td>'.$rowVerify[2].'</td>
                    <td>'.$rowVerify['amount'].'</td>
                    <td>'.$rowVerify['branch_detail'].'</td>
                </tr>
                <tr>
                    <td colspan="6">&nbsp;</td>
                </tr>
                <tr>
                    <td colspan="3"><b>Total</b></td>
                    <td colspan="3"><b>'.$rowVerify['amount'].'</b></td>
                </tr>
            </table>
        </td>
    </tr>
   
    <tr>
        <td align="left">Prepared by
        </td>
        <td align="right">
              '.$rowVerify[28].'
        </td>
    </tr>
    
</table>';
echo $receipt;

        }else{
            $_SESSION['errMsg']="<script>alert('This Money Receipt has already been cancelled. Please verify.')</script>";  
        }
    }else{
        $_SESSION['errMsg']="<script>alert('Money Receipt Number Not Found. Please re-enter')</script>";  
    }
}
?>
<form method="post" action="">
<table align='center'>
    <tr bgcolor="#000099">
        <td style="color: #FFFFFF" colspan="2">Cancel an Existing Money Receipt</td>
        
    </tr>
    <tr>
        <td>
            Select a Money Receipt
        </td>
        <td>

    <input type="text" name="id" style="width: 250px;" />
    

        </td>
    </tr>
    <tr align='center'>
        <td colspan="2"><input type="submit" value="Fetch" name="btn_mr" /></td>
    </tr>
</table>
</form>
<?php

$content=  ob_get_contents();
ob_end_clean();
include_once './template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>
