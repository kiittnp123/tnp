<?php
include_once './protectedAdmin.php';
ob_start();
//var_dump($_SESSION);
echo "Welcome";
$content=  ob_get_contents();
ob_end_clean();
include_once './template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>
