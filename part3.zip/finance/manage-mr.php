<?php
include_once './protectedAdmin.php';
include_once '../db.php';
ob_start();
if(isset($_POST['btn_part'])){
    $constant=$_POST['constant'];
    $queryUpdate="update tbl_setting set status='Active',value='$constant' where type='mr_number'";
    $resUpdate=  mysql_query($queryUpdate);
    $_SESSION['errMsg']="<script>alert('The constant part of the money receipt is changed')</script>";
    $_SESSION['mrNumber']=$constant;
}

?>
<form method="post" action="" id="part">
    <table align="center">
       
        <tbody>
            <tr>
                <td>Enter the Constant part to be displayed in the Money Receipt</td>
                <td><input type="text" name="constant" value="" /></td>
            </tr>
            <tr>
                <td><input type="submit" value="SAVE" name="btn_part" /></td>
                <td><input type="reset" value="CLEAR" /></td>
            </tr>
        </tbody>
    </table>
</form>

<?php
$content=  ob_get_contents();
ob_end_clean();
include_once './template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>