<?php
include_once './protectedAdmin.php';
//session_start();
include_once '../db.php';
include_once '../inc/conf.php';
ob_start();
if (isset($_POST['btn_save']) && !empty($_POST['btn_save']) && $_POST['btn_save'] == 'Save') {
    $admin = $_SESSION['userName'];
    $date = date("Y-m-d");
    $amount = $_POST['amount'];
    $paidForSub = $_POST['paid_for_sub'];
    $type = $_POST['pay_type'];
    $bankName = $_POST['bank_name'];
    $branchAdd = $_POST['branch_add'];
    $refNo = $_POST['ref_no'];
    $refDate = $_POST['ref_date'];
    $rollNo = $_POST['roll_no'];
    $name = $_POST['name'];
    $email = $_POST['email'];
    $mobile = $_POST['mobile'];
    $yoj = $_POST['yoj'];
    $stream = $_POST['stream'];
    $branch = $_POST['branch'];
    $semester = $_POST['semester'];
    $remarks = $_POST['remarks'];
	$sessionMonth=$_POST['sessionMonth'];
	$totalAmount=$_POST['totalAmount'];
	$pendingAmount=$_POST['pendingAmount'];

    $sql = "INSERT INTO `tbl_finance` (`finance_id`, `admin`, `date`,`session_month`,`total_amount`,`pending_amount`, `amount`, `type`, `bank_name`, `branch_detail`, `payment_ref_no`, `roll_no`, 
        `name`, `email`, `mobile`, `year_join`, `stream`, `branch`, `particular_sub_id`, `comment`, `semester`,`payment_ref_date`) 
        VALUES 
        (NULL, '$admin', '$date', '$sessionMonth', '$totalAmount', '$pendingAmount', '$amount', '$type', '$bankName', '$branchAdd', '$refNo', '$rollNo', '$name', '$email', '$mobile', '$yoj', '$stream', '$branch', '$paidForSub', '$remarks', '$semester','$refDate');";
//echo $sql;
    $res = mysql_query($sql);
    if ($res) {
        $id = mysql_insert_id();
        $mrNumberNew = $_SESSION['mrNumber'];
        $mrNumberNew.=$id;
        $_SESSION['errMsg'] = "<script>alert('Data saved successfully')</script>";
        $queryUpdate = "update tbl_finance set mr_number='$mrNumberNew' where finance_id=$id";
        //echo $queryUpdate."<br />";
        //var_dump($_SESSION['mrNumber']);
        //echo "<br />".$mrNumberNew;
        $resUpdate = mysql_query($queryUpdate);
        ?>
        <script type="text/javascript">
            window.open("receiptPrint.php?type=ol&id=<?php echo $mrNumberNew ?>", "plain", "");
        </script>
        <?php
    } else
        $_SESSION['errMsg'] = "<script>alert('Problem Occurred. Please try again')</script>";
}
$query = "select * from tbl_particular";
$res = mysql_query($query);
$particularList = "";
while ($row = mysql_fetch_array($res)) {
    $particularList.="<option value='" . $row[0] . "'>" . $row[1] . "</option>";
}
?>
<style type="text/css">
    .alignRight{
        text-align: right;
        padding-right: 20px;
    }
</style>
<script>
    function fetchSubParticular(particularSelect)
    {
        var particular = particularSelect.value;
        var xmlhttp;
        if (particular == 'NA')
        {
            document.getElementById("subParticular").innerHTML = "Please select a Particular";
            document.getElementsByName("remarks")[0].innerHTML = "";
            return;
        } else {
            document.getElementsByName("remarks")[0].innerHTML = particularSelect.options[particularSelect.selectedIndex].innerHTML;
        }
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                document.getElementById("subParticular").innerHTML = xmlhttp.responseText;
            }
        }
        xmlhttp.open("GET", "ajax_request.php?task=sub&id=" + particular, true);
        xmlhttp.send();
    }

    function modeOfPayment(mode)
    {
        var bank_name = document.getElementsByName("bank_name");
        var branch_name = document.getElementsByName("branch_add");
        var ref_no = document.getElementsByName("ref_no");
        //alert(bank_name[0].readOnly);
        //alert(mode);
        if (mode == 'cash') {
            bank_name[0].value = "Not Applicable";
            branch_name[0].innerHTML = "Not Applicable";
            ref_no[0].value = "Not Applicable";
            bank_name[0].readOnly = true;
            branch_name[0].readOnly = true;
            ref_no[0].readOnly = true;
        } else {
            bank_name[0].value = "";
            branch_name[0].innerHTML = "";
            ref_no[0].value = "";
            bank_name[0].readOnly = false;
            branch_name[0].readOnly = false;
            ref_no[0].readOnly = false;

        }
    }

    function formValidation(c) {
        //alert(c.paid_for.value);
        if (c.paid_for.value == 'NA') {
            alert("Please select a Particular");
            return false;
        }
		else if (c.sessionMonth.value == 'NA') {
            alert("Please select a Month For Session");
            return false;
        }
        else if (c.totalAmount.value == '') {
            alert("Please enter the Total Amount To Be Paid");
            return false;
        }
		else if (c.amount.value == '') {
            alert("Please enter the Amount Recieved");
            return false;
        }
		else if (c.pendingAmount.value == '') {
            alert("Please enter the Pending Amount");
            return false;
        }
        else if (c.pay_type.value == 'Select') {
            alert("Please select the payment mode");
            return false;
        }
        else if (c.bank_name.value == '') {
            alert("Please enter the name of the bank");
            return false;
        }
        else if (c.branch_add.value == '') {
            alert("Please enter the Address of the Bank");
            return false;
        }
        else if (c.ref_no.value == '') {
            alert("Please enter the corresponding Reference Number");
            return false;
        }
        else if (c.roll_no.value == '') {
            alert("Please enter the Roll Number of the student");
            return false;
        }
        else if (c.name.value == '') {
            alert("Please enter the name of the student");
            return false;
        }
        else if (c.email.value == '') {
            alert("Please enter the Email of the student");
            return false;
        }
        else if (c.mobile.value == '') {
            alert("Please enter the Mobile Number of the student");
            return false;
        }
        else if (c.yoj.value == 'Select') {
            alert("Please select the Year of Joining of the student");
            return false;
        }
        else if (c.stream.value == 'Select') {
            alert("Please select the Stream of the student");
            return false;
        }
        else if (c.branch.value == 'Select') {
            alert("Please select the Branch of the student");
            return false;
        }
        else if (c.semester.value == '') {
            alert("Please enter the current semester of the student");
            return false;
        }
        else if (c.remarks.value == '') {
            alert("Please enter some remarks for the corresponding Transaction");
            return false;
        }
        else {
            return true;
        }
    }
</script>
<form method="post" action="" onsubmit="return formValidation(this)">
<!--<form method="post" action="">-->
    <table border="0" style="">
        <tbody>
            <tr>
                <td class="alignRight">Date</td>
                <td><?php echo date("Y-m-d") ?></td>
            </tr>
            <tr>
                <td class="alignRight">Select Particulars</td>
                <td><select name="paid_for" style="width: 250px;" onchange="fetchSubParticular(this)">
                        <option value="NA">Select</option>
                        <?php echo $particularList; ?>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Session</td>
                <td><select name="sessionMonth">
                    <option value="NA">Select Month</option>
                    <option>Jan</option>
                    <option>Feb</option>
                    <option>Mar</option>
                    <option>Apr</option>
                    <option>May</option>
                    <option>Jun</option>
                    <option>Jul</option>
                    <option>Aug</option>
                    <option>Sept</option>
                    <option>Oct</option>
                    <option>Nov</option>
                    <option>Dec</option>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Select Sub Particulars</td>
                <td id="subParticular">Please select a Particular</td>
            </tr>
            <tr>
                <td class="alignRight">Total Amount</td>
                <td><input type="text" name="totalAmount" value=""  style="width: 250px;" /></td>
            </tr>
            <tr>
                <td class="alignRight">Enter the Amount Paid</td>
                <td><input type="text" name="amount" value=""  style="width: 250px;" /></td>
            </tr>
            <tr>
                <td class="alignRight">Pending Amount</td>
                <td><input type="text" name="pendingAmount" value=""  style="width: 250px;" /></td>
            </tr>
            <tr>
                <td class="alignRight">Select type of payment</td>
                <td><select name="pay_type" style="width: 250px;" onchange="modeOfPayment(this.value)" >
                        <option>Select</option>
                        <option value="cash">CASH</option>
                        <option value="dd">DEMAND DRAFT</option>
                        <option value="neft">NEFT TRANSFER</option>
                        <option value="rtgs">RTGS TRANSFER</option>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Name of the Bank</td>
                <td><input type="text" name="bank_name" value=""  style="width: 250px;" /></td>
            </tr>
            <tr>
                <td class="alignRight">Branch Address and Details</td>
                <td><textarea name="branch_add"  style="width: 250px;height: 100px;" ></textarea></td>
            </tr>
            <tr>
                <td class="alignRight">Payment reference Number<br />(DD Number/NEFT Number/RTGS Number)</td>
                <td><input type="text" name="ref_no" value=""  style="width: 250px;" /></td>
            </tr>
            <tr>
                <td class="alignRight">Payment reference Date<br />(DD Date/NEFT Date/RTGS Date)</td>
                <td><script>DateInput('ref_date', true, 'YYYY-MM-DD');</script></td>
            </tr>
            <tr>
                <td class="alignRight">Roll Number</td>
                <td><input type="text" name="roll_no" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Name</td>
                <td><input type="text" name="name" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Email</td>
                <td><input type="text" name="email" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Mobile</td>
                <td><input type="text" name="mobile" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Joining Batch</td>
                <td><select name="yoj" style="width: 250px;" >
                        <option>Select</option>
                        <?php include_once '../inc/yearList.php'; ?>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Stream</td>
                <td><select name="stream" id='streamId'  style="width: 250px;">
                        <option>Select</option>
                        <option>B.Tech</option>
                        <option>MCA</option>
                        <option>M.Tech</option>
                        <option>Dual Degree-B Tech + M Tech</option>
                        <option>Dual Degree-B Tech + MBA</option>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Branch</td>
                <td><select name="branch" style="width: 250px;">
                        <option>Select</option>
                        <option>Computer Science Engg.</option>
                        <option>Information Technology Engg.</option>
                        <option>Electrical Engg.</option>
                        <option>Electronics & Electrical Engg.</option>
                        <option>Electronics & Telecomm. Engg.</option>
                        <option>Electronics & Instrumentation Engg.</option>
                        <option>Mechanical Engg.</option>
                        <option>Civil Engg.</option>
                        <option>Automobile Engg.</option>
                        <option>MCA</option>
                    </select>
                </td>
            </tr>
            <tr>
                <td class="alignRight">Current Semester</td>
                <td><input type="text" name="semester" value="" style="width: 250px;"/></td>
            </tr>
            <tr>
                <td class="alignRight">Remarks</td>
                <td><textarea name="remarks"  style="width: 250px;height: 100px;" >
                    </textarea></td>
            </tr>
            <tr align='center'>
                <td><input type="submit" value="Save" name="btn_save" /></td>
                <td><input type="reset" value="Clear" name="btn_clear" /></td>
            </tr>
        </tbody>
    </table>
</form>
<?php
$content = ob_get_contents();
ob_end_clean();
include_once './template.php';
if (isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg'])) {
    echo $_SESSION['errMsg'];
    unset($_SESSION['errMsg']);
}
?>