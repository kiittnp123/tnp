<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>
<script src="../calendar/calendarDateInput.js"></script>
<body>
<?php
include_once '../db.php';
//echo $_GET['report'];
if($_GET['report']=='--Select One--'){
	?>
	<h1>Please Select A Report Type</h1>
	<?php
	}
	
	
elseif($_GET['report']=='All'){
	
	?>
	<form method="post">
           <input type="submit" name="submit_all" value="show">
    </form>
	<?php
	
	}
	
elseif($_GET['report']=='Bill Date Wise'){
	?>
    <form method="post">
	<table style="background-color:#CCC">
           <tr>
           <td>
           Select A Date Range
           </td>
           </tr>
           <tr>
           <td>
           <input type="date" name="from_date">
               TO
           </td>
           <td>
           <input type="date" name="to_date">
           </td>
           </tr>
           <tr align="center">
           <td colspan="2"><input type="submit" name="submit_date" value="Show"></td>
           </tr>
    </table>
    </form>
	<?php
	}
	
	
elseif($_GET['report']=='Office Type Wise'){
	$getQuery="SELECT DISTINCT `office_type` FROM `tbl_finance_expence`";
	
	$getRes=mysql_query($getQuery);

    ?>
    <form method="post">
    <table>
    <tr>
        <td>
        Select A Office
        </td>
        <td>
        <select name="office_type">
        <option>--Select One--</option>
        <?php
        while($getdata=mysql_fetch_array($getRes)){
            echo "<option>$getdata[office_type]</option>";
            }
        ?>
        </select>
        </td>
     </tr>
     <tr align="center">
         <td colspan="2">
         <input type="submit" name="submit_office" value="Show">
         </td>
     </tr>
     </table>
     </form>   
	<?php
	}
	
	
elseif($_GET['report']=='Guest Name Wise'){
	$getQuery="SELECT DISTINCT `guest_name` FROM `tbl_finance_expence`";
	
	$getRes=mysql_query($getQuery);

    ?>
    <form method="post">
    <table>
    <tr>
        <td>
        Select A Office
        </td>
        <td>
        <select name="guest_name">
        <option>--Select One--</option>
        <?php
        while($getdata=mysql_fetch_array($getRes)){
            echo "<option>$getdata[guest_name]</option>";
            }
        ?>
        </select>
        </td>
     </tr>
     <tr align="center">
         <td colspan="2">
         <input type="submit" name="submit_guest" value="Show">
         </td>
     </tr>
     </table>
     </form>
	
	<?php
	}
	
	
elseif($_GET['report']=='Company Wise'){
	$getQuery="SELECT DISTINCT `company_name` FROM `tbl_finance_expence`";
	
	$getRes=mysql_query($getQuery);

    ?>
    <form method="post">
    <table>
    <tr>
        <td>
        Select A Company Name
        </td>
        <td>
        <select name="company_name">
        <option>--Select One--</option>
        <?php
        while($getdata=mysql_fetch_array($getRes)){
            echo "<option>$getdata[company_name]</option>";
            }
        ?>
        </select>
        </td>
     </tr>
     <tr align="center">
         <td colspan="2">
         <input type="submit" name="submit_company" value="Show">
         </td>
     </tr>
     </table>
     </form>
	<?php
	?>
	
	<?php
	}
	
	
elseif($_GET['report']=='Expence Head Wise'){
	$getQuery="SELECT DISTINCT `expence_head` FROM `tbl_finance_expence`";
	
	$getRes=mysql_query($getQuery);

    ?>
    <form method="post">
    <table>
    <tr>
        <td>
        Select Expence Head
        </td>
        <td>
        <select name="expence_head">
        <option>--Select One--</option>
        <?php
        while($getdata=mysql_fetch_array($getRes)){
            echo "<option>$getdata[expence_head]</option>";
            }
        ?>
        </select>
        </td>
     </tr>
     <tr align="center">
         <td colspan="2">
         <input type="submit" name="submit_exphead" value="Show">
         </td>
     </tr>
     </table>
     </form>
	<?php
	
	}
	
	
elseif($_GET['report']=='Vendor Name Wise'){
	$getQuery="SELECT DISTINCT `vendor_name` FROM `tbl_finance_expence`";
	
	$getRes=mysql_query($getQuery);

    ?>
    <form method="post">
    <table>
    <tr>
        <td>
        Select A Vendor Name
        </td>
        <td>
        <select name="vendor_name">
        <option>--Select One--</option>
        <?php
        while($getdata=mysql_fetch_array($getRes)){
            echo "<option>$getdata[vendor_name]</option>";
            }
        ?>
        </select>
        </td>
     </tr>
     <tr align="center">
         <td colspan="2">
         <input type="submit" name="submit_vendor" value="Show">
         </td>
     </tr>
     </table>
	 </form>
	<?php
	}
	
	
elseif($_GET['report']=='Pending Amount Wise'){
	
	?>
	<form method="post">
           <input type="submit" name="submit_pendingAmount" value="show">
    </form>
	<?php
	}
?>
</body>
</html>