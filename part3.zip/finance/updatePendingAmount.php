<?php
ob_start();
include_once './protectedAdmin.php';
//session_start();
include_once '../db.php';
include_once '../inc/conf.php';
require_once("excelwriter.class.php");

?>
<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<?php
if(isset($_POST['submit'])){
	$reciveAmount = $_POST['amountRecived'];
	$pendingAmount = $_POST['amountPending'];
	$mrNumber = $_POST['mrNumber'];
	$amount = $_POST['amount'];
	$finalAmount = $amount+$reciveAmount;
	if($pendingAmount<'0' || $pendingAmount==''){
		?>
		    <script>
                    alert("Please Enter Valid Amount");
            </script>
		<?php
		}else{
		?>
        <?php
			$updateReciept="UPDATE `tbl_finance` SET `amount`='$finalAmount',`pending_amount`='$pendingAmount'  WHERE `mr_number`='$mrNumber'";
			$updateResult=mysql_query($updateReciept);
			if($updateResult){
				?>
				   <script>
						   //alert("<?php echo $oldMr;?>"); 
                           //alert("Rs.<?php echo $reciveAmount;?> Submitted For Reciept Number <?php echo $mrNumber?> and Rs.<?php echo $pendingAmount?> remain in Pending");
						   window.location="pendingFeeDeatails.php?paid="+<?php echo $reciveAmount;?>+"&pending="+<?php echo $pendingAmount;?>+"&mr=<?php echo $mrNumber;?>";
                   </script>
				<?php
				}
			}
	}


$query="SELECT `tbl_finance`.`finance_id`,`tbl_finance`.`date`,`tbl_finance`.`roll_no`,`tbl_finance`.`name`,`tbl_finance`.`total_amount`,`tbl_finance`.`amount`,`tbl_finance`.`pending_amount`,`tbl_particular_sub`.`name`,`tbl_particular`.`name`,`tbl_finance`.`mr_number`,`tbl_finance`.`mobile`,`tbl_finance`.`branch` FROM `tbl_finance`,`tbl_particular_sub`,`tbl_particular` WHERE tbl_finance.`particular_sub_id`=tbl_particular_sub.`particular_sub_id` and tbl_finance.`comment`=tbl_particular.`name` and tbl_finance.`pending_amount`>'0'";

$res=mysql_query($query);
?>
<table border="1" cellspacing="0">
<th>Reciept No.</th>
<th>Roll No.</th>
<th>Name</th>
<th>Branch</th>
<th>Contact No.</th>
<th>Total Amount</th>
<th>Amount Paid</th>
<th>Pending Amount</th>
<th>Amount Recived</th>
<th>Pending</th>
<th>Submit</th>
<?php
while($row=mysql_fetch_array($res)){
	
	?>
    <form method="post">
	<tr>       
        <td><?php echo $row[9];?><input type="hidden" name="mrNumber" value="<?php echo $row[9];?>"></td>
		<!--<td><?php echo $row[9];?><input type="text" name="mrNumber" value="<?php echo str_replace('/','o',$row[9]);?>"></td>-->
        <td><?php echo $row[2];?></td>
        <td><?php echo $row[3];?></td>
        <td><?php echo $row[11];?></td>
        <td><?php echo $row[10];?></td>
        <td><?php echo $row[4];?></td>
        <td><?php echo $row[5];?><input type="hidden" name="amount" value="<?php echo $row[5];?>"></td>
        <td><?php echo $row[6];?></td>
        <td><input type="text" name="amountRecived" placeholder="Enter Recived Amount" size="17"></td>
        <td><input type="text" name="amountPending" placeholder="Enter Pending Amount" size="17"></td>
        <td><input type="submit" name="submit" value="Update"></td>
    </tr>
    </form>
	<?php
	
	}
?>
</table>
<input type="button" id='download' value="download" onClick="javascript:download_report();">
<?php
$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Reciept No.","Roll No.","Name","Branch","Contact No.","Total Amount","Amount Paid","Pending Amount");

$excel->writeLine($myArr);

$query="SELECT `tbl_finance`.`finance_id`,`tbl_finance`.`date`,`tbl_finance`.`roll_no`,`tbl_finance`.`name`,`tbl_finance`.`total_amount`,`tbl_finance`.`amount`,`tbl_finance`.`pending_amount`,`tbl_particular_sub`.`name`,`tbl_particular`.`name`,`tbl_finance`.`mr_number`,`tbl_finance`.`mobile`,`tbl_finance`.`branch` FROM `tbl_finance`,`tbl_particular_sub`,`tbl_particular` WHERE tbl_finance.`particular_sub_id`=tbl_particular_sub.`particular_sub_id` and tbl_finance.`comment`=tbl_particular.`name` and tbl_finance.`pending_amount`>'0'";

$res=mysql_query($query);


while($row=mysql_fetch_array($res)){
	$myArr=array($row[9],$row[2],$row[3],$row[11],$row[10],$row[4],$row[5],$row[6]);
	$excel->writeLine($myArr);
	}
?>
<?php
$content = ob_get_contents();
ob_end_clean();
include_once './template.php';
if (isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg'])) {
    echo $_SESSION['errMsg'];
    unset($_SESSION['errMsg']);
}
?>