<?php
include_once '../db.php';
if(isset($_GET['task']) && !empty($_GET['task'])){
    $task=$_GET['task'];
    if($task=='sub'){
        $id=$_GET['id'];
        $query="select * from tbl_particular_sub where particular_id=$id";
        $res=  mysql_query($query);
        if(mysql_num_rows($res)>0){
            $subParticularList="<select name='paid_for_sub'>";
            while($row=  mysql_fetch_array($res)){
                $subParticularList.="<option value='".$row[0]."'>".$row[2]."</option>";
            }
        }else{
            $subParticularList="<input type='text' name='paid_for_sub' value='Not Applicable' readonly='readonly' />";
        }
        echo $subParticularList;
    }
}
?>
