<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
if($_GET['expence']=="Hotel"){
	?>
	     <table width="100%" id="hotelExp">
                <caption style="background-color:#CCCCCC;text-align:left">Hotel Expences :</caption>
                <tr>
                    <td>
                        Vendor Name
                    </td>
                    <td>
                        <input type="text" name="vendor_name[]">
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Voucher No.
                    </td>
                    <td>
                        <input type="text" name="voucher_no[]">
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Voucher Date
                    </td>
                    <td>
                        <input type="date" name="voucher_date[]">
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Voucher Amount
                    </td>
                    <td>
                        <input type="text" name="voucher_amount[]">
                    </td>
                </tr>
                
                <tr>
                    <td>
                         Transaction Head
                    </td>
                    <td>
                        <input type="text" name="transaction_head[]">
                    </td>
                </tr>
                
                <tr>
                    <td>
                        Transaction Date
                    </td>
                    <td>
                        <input type="date" name="transaction_date[]">
                    </td>
                </tr>
                
                <tr>
                    <td colspan="2">
                         <table id="gen_hotel_detail" width="100%">
                         
                         </table>
                    </td>
                </tr>
                
                <tr>
                    <td colspan="2">
                    <input type="button" value="+" id="btn_gen_hotel" onClick="genContent(this.id)">
                    <input type="button" value="-" id="btn_clr_hotel" onClick="genContent(this.id)">
                    </td>
                </tr>
         </table>
	<?php
	}
elseif($_GET['expence']=="Travel"){
	?>
	    <table width="100%" id="travelExp">
                <caption style="background-color:#CCCCCC;text-align:left">Travel Expences :</caption>
                <tr>
                    <td>
                        Travel By
                    </td>
                    <td>
                        <select name="travel_by" id="travelBy" onchange="toggleTravelExp(this.value)">
                                 <option>--Select One--</option>
                                 <option>Plain</option>
                                 <option>Train</option>
                                 <option>Cab</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="2" id="getTravelBy">
                        <!--travel by-->
                    </td>
                </tr>
         </table>
	<?php
	}
elseif($_GET['expence']=="Office"){
	?>
	   <table width="100%" id="officeExp">
               <caption style="background-color:#CCCCCC;text-align:left">Office Expences :</caption>
               <tr>
                  <td>
                      Vendor Name
                  </td>
                  <td>
                      <input type="text" name="vendor_name[]">
                  </td>
              </tr>
               
               <tr>
                   <td>
                       Transaction Head
                   </td>
                   <td>
                       <input type="text" name="transaction_head[]">
                   </td>
               </tr>
               
               <tr>
                   <td>
                       Transaction Date
                   </td>
                   <td>
                       <input type="date" name="transaction_date[]">
                   </td>
               </tr>
               
               <tr>
                  <td>
                      Transaction Amount
                  </td>
                  <td>
                      <input type="text" name="voucher_amount[]">
                  </td>
               </tr>
               
               <tr>
                  <td colspan="2">
                       <table id="gen_office_detail" width="100%">
                                
                       </table>
                  </td>
              </tr>
              
              <tr>
                  <td colspan="2">
                  <input type="button" value="+" id="btn_gen_office" onClick="genContent(this.id);">
                  <input type="button" value="-" id="btn_clr_office" onClick="genContent(this.id)">
                  </td>
              </tr>
       </table>
	<?php
	}
else{
	echo "";
	}
?>
</body>
</html>