<?php
include_once './protectedAdmin.php';
ob_start();
if(isset($_GET['btn_mr'])){
    $mrNumberNew=$_GET['id'];
	$date=$_GET['date'];
?>
<script type="text/javascript">
        window.location="instReceiptPrint.php?type=dt&id=<?php echo $mrNumberNew?>&date=<?php echo $date?>";
</script>
<?php } ?>
<form method="get" action="">
<table align='center'>
    <tr bgcolor="#000099">
        <td style="color: #FFFFFF" colspan="2">Regenerate an Existing Money Receipt</td>
        
    </tr>
    <tr>
        <td>
            Select a Money Receipt
        </td>
        <td>
    <input type="text" name="id" style="width: 250px;" />
        </td>
    </tr>
	<tr>
        <td>
            Select a Money Receipt Date
        </td>
        <td>
    <script>DateInput('date', true, 'YYYY-MM-DD');</script>
        </td>
    </tr>
    <tr align='center'>
        <td colspan="2"><input type="submit" value="Fetch" name="btn_mr" /></td>
    </tr>
</table>
</form>
<?php
$content=  ob_get_contents();
ob_end_clean();
include_once './template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>
