<?php
session_start();
unset($_SESSION['userName']);
unset($_SESSION['userType']);
session_destroy();
header("location:../admin/login.php");
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
