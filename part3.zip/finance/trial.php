<?php
$mrNumber="KSOT/13-14/2192";
$mrDate="28-05-13";
$mrType="ORIGINAL";
?>
<table align="center">
    <tr align="center">
        <td colspan="2"><img src="images/kiit.jpg" width="100"/></td>
    </tr>
    <tr align="center">
        <td colspan="2">
            KIIT SCHOOL OF TECHNOLOGY<br />
            KIIT UNIVERSITY<br />
            (Under the Management of Kalinga Institute of Industrial Technology)<br />
            AT/PO-KIIT, Bhubaneshwar - 751024, Odisha<br />
            Tel. 0674-2725272, 2712103, 2725347<br />
        </td>
    </tr>
    <tr align="center">
        <td colspan="2">
            <span style="background-color: black;color: white;">MONEY RECEIPT</span> - <span style="background-color: black;color: white;"><?php echo $mrType;?></span>
        </td>
    </tr>
    <tr>
        <td align="left">
            <b>M.R. NO : <?php echo $mrNumber;?></b>
        </td>
        <td align="right">
            <b>DATE : <?php echo $mrDate;?></b>
        </td>
    </tr>
    <tr>
        <td>
            Name
        </td>
        <td>
            <?php echo $studentName;?>
        </td>
    </tr>
    <tr>
        <td>
            Roll no
        </td>
        <td>
            <?php echo $studentRoll?>
        </td>
    </tr>
    <tr>
        <td>
            Course
        </td>
        <td>
            <?php echo $studentCourse?>
        </td>
    </tr>
    <tr>
        <td>
            Stream and Branch
        </td>
        <td>
            <?php echo $studentStream." , ".$studentBranch;?>
        </td>
    </tr>
    <tr>
        <td>
            Year of Joining Batch
        </td>
        <td>
            <?php echo $yearJoin?>
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" style="border-style: solid">
                <tr>
                    <th>Sl. No.</th>
                    <th>Particulars</th>
                    <th>Amount(Rs)</th>
                </tr>
                <tr>
                    <td>1</td>
                    <td><?php echo $mrItem;?></td>
                    <td><?php echo $mrAmount?></td>
                </tr>
                <tr>
                    <th colspan="3">
                        <span style="float: left;">Total</span>
                        <span style="float: right;"><?php echo $mrAmount?></span>
                    </th>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" align="left">
            Remarks : <?php echo $mrRemarks?>
        </td>
    </tr>
    <tr>
        <td colspan="2">Received as per following details :</td>
    </tr>
    <tr>
        <td colspan="2">
            <table>
                <tr>
                    <th>Sl No</th>
                    <th>Mode</th>
                    <th>Instrument No</th>
                    <th>Date</th>
                    <th>Amount</th>
                    <th>Drawn On</th>
                </tr>
                <tr>
                    <td>1.</td>
                    <td><?php echo $mrMode?></td>
                    <td><?php echo $mrRefNo?></td>
                    <td><?php echo $mrDate?></td>
                    <td><?php echo $mrAmount?></td>
                    <td><?php echo $mrBankDet?></td>
                </tr>
                <tr>
                    <td colspan="3">Total</td>
                    <td colspan="3"><?php echo $mrAmount?></td>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td align="left">
            Cheques / DDs are subject to realisation<br />
            Please check the Money Receipt before Leaving the Counter
        </td>
        <td align="right">
            Receiving Officer<br /><br /><br /><br />
            Prepared by <?php echo $mrOfficer ?>. Printed By <?php echo $_SESSION['userName']?> on <?php echo date("Y-m-d")?>
        </td>
    </tr>
</table>