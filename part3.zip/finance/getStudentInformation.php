<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
include_once '../db.php';
$roll=$_GET['info'];
if($roll==""){
	echo "Enter Valid ROll No.";
	}else{
		$query="SELECT * FROM `tbl_student` WHERE `roll_no`='$roll'";
		$res=mysql_query($query);
		
		if(mysql_num_rows($res)==0){
?>
	<table border="0" width="920">
         <tbody id="stud_info">
            <tr>
                <td style="width:280px" class="alignRight">Name</td>
                <td><input type="text" name="name" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Email</td>
                <td><input type="text" name="email" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Mobile</td>
                <td><input type="text" name="mobile" value="" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Joining Batch</td>
                <td><select name="yoj" style="width: 250px;" >
                        <option>Select</option>
                        <?php include_once '../inc/yearList.php'; ?>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Stream</td>
                <td><select name="stream" id='streamId'  style="width: 250px;">
                        <option>Select</option>
                        <option>B.Tech</option>
                        <option>MCA</option>
                        <option>M.Tech</option>
                        <option>Dual Degree-B Tech + M Tech</option>
                        <option>Dual Degree-B Tech + MBA</option>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Branch</td>
                <td><select name="branch" style="width: 250px;">
                        <option>Select</option>
                        <option>Computer Science Engg.</option>
                        <option>Information Technology Engg.</option>
                        <option>Electrical Engg.</option>
                        <option>Electronics & Electrical Engg.</option>
                        <option>Electronics & Telecomm. Engg.</option>
                        <option>Electronics & Instrumentation Engg.</option>
                        <option>Mechanical Engg.</option>
                        <option>Civil Engg.</option>
                        <option>Automobile Engg.</option>
                        <option>MCA</option>
                    </select>
                </td>
            </tr>
       </tbody>
    </table>
<?php
			}else{
		while($row=mysql_fetch_array($res)){
?>
     <table border="0" width="920">
         <tbody id="stud_info">
            <tr>
                <td style="width:280px" class="alignRight">Name</td>
                <td><input type="text" name="name" value="<?php echo $row['name'];?>" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Email</td>
                <td><input type="text" name="email" value="<?php echo $row['email'];?>" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Mobile</td>
                <td><input type="text" name="mobile" value="<?php echo $row['mobile'];?>" style="width: 250px;"  /></td>
            </tr>
            <tr>
                <td class="alignRight">Joining Batch</td>
                <td><select name="yoj" style="width: 250px;" >
                        <option><?php echo $row['year_join'];?></option>
                        <?php include_once '../inc/yearList.php'; ?>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Stream</td>
                <td><select name="stream" id='streamId'  style="width: 250px;">
                        <option><?php echo $row['stream'];?></option>
                        <option>B.Tech</option>
                        <option>MCA</option>
                        <option>M.Tech</option>
                        <option>Dual Degree-B Tech + M Tech</option>
                        <option>Dual Degree-B Tech + MBA</option>
                    </select></td>
            </tr>
            <tr>
                <td class="alignRight">Branch</td>
                <td><select name="branch" style="width: 250px;">
                        <option><?php echo $row['branch'];?></option>
                        <option>Computer Science Engg.</option>
                        <option>Information Technology Engg.</option>
                        <option>Electrical Engg.</option>
                        <option>Electronics & Electrical Engg.</option>
                        <option>Electronics & Telecomm. Engg.</option>
                        <option>Electronics & Instrumentation Engg.</option>
                        <option>Mechanical Engg.</option>
                        <option>Civil Engg.</option>
                        <option>Automobile Engg.</option>
                        <option>MCA</option>
                    </select>
                </td>
            </tr>
        </tbody>
    </table>
<?php
			}
		  }
		}
?>
</body>
</html>