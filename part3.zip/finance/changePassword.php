<?php
ob_start();
//session_start();
include 'protectedAdmin.php';
include '../db.php';

if(isset($_POST['btnsavepwd']) && !empty($_POST['btnsavepwd']) && $_POST['btnsavepwd']=='Reset Password')
{
	$current_pwd= mysql_real_escape_string($_POST['txtcurpwd']);
	$new_pwd=mysql_real_escape_string($_POST['txtnewpwd']);
	$re_pwd=mysql_real_escape_string($_POST['txtrepwd']);
	$sql="select password from tbl_admin where user_id='".$_SESSION['userName']."'";
	$result=mysql_query("$sql");
	$data=mysql_fetch_array($result);
	$pass=$data[0];
	if($current_pwd==$pass && ($new_pwd==$re_pwd))
	{
		$sqlupdate="update tbl_admin set password='$new_pwd' where user_id='".$_SESSION['userName']."'";
		$res=mysql_query("$sqlupdate");
		//echo $sqlupdate;
		if($res)
		{
			$_SESSION['ErrMsg']="<script>alert('your password has been changed !!!')</script>";

		}
	}
	else
	{
		$_SESSION['ErrMsg']="<script>alert('Please check your current and new password')</script>";

	}
}
?>
<form action="" method="post">
<table width="407" height="274" align="center" bgcolor="#E2E2E2" style="border-style:ridge">
<tr>
    <td>Enter Current Password<font color="#FF0000">*</font>:</td><td><input type="password" name="txtcurpwd" onblur="isEmpty(this)"/></td>
</tr>
<tr>
<td>New Password<font color="#FF0000">*</font>:</td><td><input type="password" name="txtnewpwd"  onblur="isEmpty(this)"/></td>
</tr>
<tr>
<td>Re-Enter Password<font color="#FF0000">*</font>:</td><td><input type="password" name="txtrepwd" onblur="isEmpty(this)" /></td>
</tr>
<tr>
<td align="center" colspan="2"><input type="submit" name="btnsavepwd" value="Reset Password" /><input type="reset" name="btnreset" value="Clear" /></td>
</tr>
</table>
</form>
<?php
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}

?>