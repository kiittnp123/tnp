<?php
ob_start();
include_once './protectedAdmin.php';
//session_start();
include_once '../db.php';
include_once '../inc/conf.php';
require_once("excelwriter.class.php");

?>
<script>
function changeReportType(str)
{
if (str.length==0)
  { 
  document.getElementById("getContent").innerHTML="";
  return;
  }
var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("getContent").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","getExpenceReport.php?report="+str,true);
xmlhttp.send();
}
</script>
<center>
        <table>
               <tr>
                   <td>
                       Slect Report Type
                   </td>
                   
                   <td>
                       <select name="reportType" id="reportType" onChange="changeReportType(this.value)">
                                <option>--Select One--</option>
                                <option>All</option>
                                <option>Bill Date Wise</option>
                                <option>Office Type Wise</option>
                                <option>Guest Name Wise</option>
                                <option>Company Wise</option>
                                <option>Expence Head Wise</option>
                                <option>Vendor Name Wise</option>
                                <option>Pending Amount Wise</option>
                       </select>
                   </td>
               </tr>
        </table>
        
        <div id="getContent"></div>
        
<?php
if(isset($_POST['submit_all'])){
	$query="SELECT * FROM `tbl_finance_expence`";
	
	$res=mysql_query($query);
	?>
	<table border="1" cellspacing="0">
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Invoice No.</th>
           <th>Invoice Date</th>
           <th>Invoice Amount</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['invoice_no'];?></td>
               <td><?php echo $row['invoice_date'];?></td>
               <td><?php echo $row['invoice_amount'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>
 
 
<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence`";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}
	

	}


if(isset($_POST['submit_pendingAmount'])){
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `amount_pending` !='0'";
	
	$res=mysql_query($query);
	?>
	<table border="1" cellspacing="0">
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Invoice No.</th>
           <th>Invoice Date</th>
           <th>Invoice Amount</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['invoice_no'];?></td>
               <td><?php echo $row['invoice_date'];?></td>
               <td><?php echo $row['invoice_amount'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>
 
 
<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `amount_pending` !='0'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}
	

	}


if(isset($_POST['submit_date'])){
	$fromDate=$_POST['from_date'];
	
	$toDate=$_POST['to_date'];
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `bill_date` BETWEEN '$fromDate' AND '$toDate'";
	
	$res=mysql_query($query);
	
	
	?>
	<table border="1" cellspacing="0">
    <caption><h3>Report Date Between <?php echo $fromDate." TO ".$toDate?></h3></caption>
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Guest Name</th>
           <th>Company Name</th>
           <th>Expence Head</th>
           <th>Vendor Name</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['guest_name'];?></td>
               <td><?php echo $row['company_name'];?></td>
               <td><?php echo $row['expence_head'];?></td>
               <td><?php echo $row['vendor_name'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>
 
 
<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `bill_date` BETWEEN '$fromDate' AND '$toDate'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}
	
	
}
if(isset($_POST['submit_office'])){
	$officeType=$_POST['office_type'];
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `office_type`='$officeType'";
	
	$res=mysql_query($query);
	?>
	<table border="1" cellspacing="0">
    <caption><h3>Report Of <?php echo $officeType;?> Office</h3></caption>
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Guest Name</th>
           <th>Company Name</th>
           <th>Expence Head</th>
           <th>Vendor Name</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['guest_name'];?></td>
               <td><?php echo $row['company_name'];?></td>
               <td><?php echo $row['expence_head'];?></td>
               <td><?php echo $row['vendor_name'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>


<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `office_type`='$officeType'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}

	
}
if(isset($_POST['submit_guest'])){
	$guestName=$_POST['guest_name'];
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `guest_name`='$guestName'";
	
	$res=mysql_query($query);
	
	
	?>
	<table border="1" cellspacing="0">
    <caption><h3>Report Of Mr.<?php echo $guestName;?></h3></caption>
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Guest Name</th>
           <th>Company Name</th>
           <th>Expence Head</th>
           <th>Vendor Name</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['guest_name'];?></td>
               <td><?php echo $row['company_name'];?></td>
               <td><?php echo $row['expence_head'];?></td>
               <td><?php echo $row['vendor_name'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>


<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `guest_name`='$guestName'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}

	
	
}
if(isset($_POST['submit_company'])){
	$companyName=$_POST['company_name'];
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `company_name`='$companyName'";
	
	$res=mysql_query($query);
	
	
	?>
	<table border="1" cellspacing="0">
    <caption><h3>Report Of <?php echo $companyName?></h3></caption>
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Guest Name</th>
           <th>Company Name</th>
           <th>Expence Head</th>
           <th>Vendor Name</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['guest_name'];?></td>
               <td><?php echo $row['company_name'];?></td>
               <td><?php echo $row['expence_head'];?></td>
               <td><?php echo $row['vendor_name'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>


<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `company_name`='$companyName'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}

	
	
	
}
if(isset($_POST['submit_exphead'])){
	$expenceHead=$_POST['expence_head'];
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `expence_head`='$expenceHead'";
	
	$res=mysql_query($query);
	
	
	?>
	<table border="1" cellspacing="0">
    <Caption><h3>Report On <?php echo $expenceHead;?> Expences</h3></Caption>
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Guest Name</th>
           <th>Company Name</th>
           <th>Expence Head</th>
           <th>Vendor Name</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['guest_name'];?></td>
               <td><?php echo $row['company_name'];?></td>
               <td><?php echo $row['expence_head'];?></td>
               <td><?php echo $row['vendor_name'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>



<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `expence_head`='$expenceHead'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}

		
}
if(isset($_POST['submit_vendor'])){
	$vendorName=$_POST['vendor_name'];
	
	$query="SELECT * FROM `tbl_finance_expence` WHERE `vendor_name`='$vendorName'";
	
	$res=mysql_query($query);
	
	
	?>
	<table border="1" cellspacing="0">
    <caption><h3>Expence Report Of <?php echo $vendorName;?></h3></caption>
           <th>SL.No</th>
           <th>Bill Date</th>
           <th>Office Type</th>
           <th>Guest Name</th>
           <th>Company Name</th>
           <th>Expence Head</th>
           <th>Vendor Name</th>
           <th>Amount Paid</th>
           <th>Amount Pending</th>
           <th>Payment Mode</th>
           <th>Bank Name</th>
           <th>Branch Name</th>
           <th>Ref No.</th>
           <?php
		   $i=1;
           while($row=mysql_fetch_array($res)){
		   ?>
           <tr>
               <td><?php echo $i++?></td>
               <td><?php echo $row['bill_date'];?></td>
               <td><?php echo $row['office_type'];?></td>
               <td><?php echo $row['guest_name'];?></td>
               <td><?php echo $row['company_name'];?></td>
               <td><?php echo $row['expence_head'];?></td>
               <td><?php echo $row['vendor_name'];?></td>
               <td><?php echo $row['amount_paid'];?></td>
               <td><?php echo $row['amount_pending'];?></td>
               <td><?php echo $row['payment_mode'];?></td>
               <td><?php echo $row['bank_name'];?></td>
               <td><?php echo $row['branch_name'];?></td>
               <td><?php if($row['ref_no']=='0'){
				             echo "NA";
				         }else{
							 echo $row['ref_no'];
						 }?></td>
           </tr>
           <?php
		   }
		   ?>
    </table>



<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<!--<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>-->
<input type="button" id='download' value="download" onClick="javascript:download_report();">
 
 
	<?php


$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("Bill Date","Office Type","Invoice No","Invoice Date","Invoice Amount","Guest Name","Company Name","Expence Head","vendor Name","Voucher No","Voucher Date","Voucher Amount","Ticket No","Transaction Head","Transaction Date","Travel By","Travel From","Travel To","Amount Paid","Amount Pending","Payment Mode","Bank Name","Branch Name","Reference No.");
$excel->writeLine($myArr);

$query="SELECT * FROM `tbl_finance_expence` WHERE `vendor_name`='$vendorName'";
	
$res=mysql_query($query);

if($res!=false)
{
	
	while($excelData=mysql_fetch_array($res)){
		if($excelData['voucher_no']=='0'){
			$voucher_data="NA";
			}else{
				$voucher_data=$excelData['voucher_no'];
				}
		if($excelData['travel_from']==''){
			$travel_from_data="NA";
			}else{
				$travel_from_data=$excelData['travel_from'];
			}
		if($excelData['travel_to']==''){
			$travel_to_data="NA";
			}else{
				$travel_to_data=$excelData['travel_to'];
				}
		if($excelData['ticket_no']==''){
			$ticket_no_data="NA";
			}else{
				$ticket_no_data=$excelData['ticket_no'];
				}
		if($excelData['voucher_date']==''){
			$voucher_date_data="NA";
			}else{
				$voucher_date_data=$excelData['voucher_date'];
				}
		if($excelData['ref_no']=='0'){
			$ref_no_data="NA";
			}else{
				$ref_no_data=$excelData['ref_no'];
				}
		$myArr=array($excelData['bill_date'],$excelData['office_type'],$excelData['invoice_no'],$excelData['invoice_date'],$excelData['invoice_amount'],$excelData['guest_name'],$excelData['company_name'],$excelData['expence_head'],$excelData['vendor_name'],$voucher_data,$voucher_date_data,$excelData['voucher_amount'],$ticket_no_data,$excelData['transaction_head'],$excelData['transaction_date'],$excelData['travel_by'],$travel_from_data,$travel_to_data,$excelData['amount_paid'],$excelData['amount_pending'],$excelData['payment_mode'],$excelData['bank_name'],$excelData['branch_name'],$ref_no_data);
		             
		$excel->writeLine($myArr);
		$i++;
	}
}

	

	}
	
	
?>
</center>

<?php
$content = ob_get_contents();
ob_end_clean();
include_once './template.php';
if (isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg'])) {
    echo $_SESSION['errMsg'];
    unset($_SESSION['errMsg']);
}
?>
