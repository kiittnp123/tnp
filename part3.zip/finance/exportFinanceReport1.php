<?php
//error_reporting(0);
//session_start();
include_once './protectedAdmin.php';
include '../db.php';
$condition=$_SESSION['query'];
$query="SELECT * 
FROM tbl_finance tf
LEFT JOIN tbl_particular_sub tps ON tf.particular_sub_id = tps.particular_sub_id
LEFT JOIN tbl_particular tp ON tps.particular_id = tp.particular_id
LEFT JOIN tbl_admin ta ON tf.admin = ta.user_id
LEFT JOIN tbl_finance_cancel tfc ON tf.mr_number = tfc.mr_number
WHERE (`date` between $condition)";
$queryCancel="SELECT * 
FROM tbl_finance tf
LEFT JOIN tbl_particular_sub tps ON tf.particular_sub_id = tps.particular_sub_id
LEFT JOIN tbl_particular tp ON tps.particular_id = tp.particular_id
LEFT JOIN tbl_admin ta ON tf.admin = ta.user_id
LEFT JOIN tbl_finance_cancel tfc ON tf.mr_number = tfc.mr_number
LEFT JOIN tbl_admin taa ON tfc.admin=taa.user_id
WHERE  (cancel_date  between $condition)";
$queryInstalment="SELECT * FROM `tbl_update_amount`,`tbl_finance` WHERE `tbl_update_amount`.`old_mrNumber`=`tbl_finance`.`mr_number`";
//echo $queryCancel;
//echo $query;

$res=mysql_query($query);
$resCancel=  mysql_query($queryCancel);
$resInstalment=  mysql_query($queryInstalment);
include_once '../excel/Classes/PHPExcel.php';
$phpExcel = new PHPExcel();
$phpExcel->createSheet();
$phpExcel->getActiveSheet()->mergeCells('A1:N1');
$phpExcel->getActiveSheet()->setCellValue("A1","RECIEVED AMOUNT");
$phpExcel->getActiveSheet()->setCellValue("A2","SL NO");
$phpExcel->getActiveSheet()->setCellValue("B2","ROLL NO");
$phpExcel->getActiveSheet()->setCellValue("C2","STUDENT NAME");
$phpExcel->getActiveSheet()->setCellValue("D2","MOBILE");
$phpExcel->getActiveSheet()->setCellValue("E2","STREAM");
$phpExcel->getActiveSheet()->setCellValue("F2","BRANCH");
$phpExcel->getActiveSheet()->setCellValue("G2","MODE OF PAYMENT");
$phpExcel->getActiveSheet()->setCellValue("H2","AMOUNT");
$phpExcel->getActiveSheet()->setCellValue("I2","DATE OF RECEIPT");
$phpExcel->getActiveSheet()->setCellValue("J2","ISSUING BANK NAME");
$phpExcel->getActiveSheet()->setCellValue("K2","DD ISSUING DATE");
$phpExcel->getActiveSheet()->setCellValue("L2","DRAFT NUMBER");
$phpExcel->getActiveSheet()->setCellValue("M2","MONEY RECEIPT NUMBER");
$phpExcel->getActiveSheet()->setCellValue("N2","PARTICULARS");
$phpExcel->getActiveSheet()->setCellValue("O2","SUB PARTICULARS");
$phpExcel->getActiveSheet()->setCellValue("P2","TRANSACTION DONE BY");
$phpExcel->getActiveSheet()->setCellValue("Q2","SESSION");
$phpExcel->getActiveSheet()->setCellValue("R2","TOTAL AMOUNT");
$phpExcel->getActiveSheet()->setCellValue("S2","PENDING AMOUNT");

$t=3;
$slno=1;
$totalAmountRecieved=0;
while ($row= mysql_fetch_array($res)){
    
    $phpExcel->getActiveSheet()->setCellValue("A".$t,"$slno");
    $phpExcel->getActiveSheet()->setCellValue("B".$t,$row['roll_no']);
    $phpExcel->getActiveSheet()->setCellValue("C".$t,$row[12]);
    $phpExcel->getActiveSheet()->setCellValue("D".$t,$row[14]);
    $phpExcel->getActiveSheet()->setCellValue("E".$t,$row['stream']);
    $phpExcel->getActiveSheet()->setCellValue("F".$t,$row['branch']);
    $phpExcel->getActiveSheet()->setCellValue("G".$t,$row['type']);
    $phpExcel->getActiveSheet()->setCellValue("H".$t,$row['amount']);
    $phpExcel->getActiveSheet()->setCellValue("I".$t,$row['date']);
    $phpExcel->getActiveSheet()->setCellValue("J".$t,$row['bank_name']."  Address:".$row['branch_detail']);
    $phpExcel->getActiveSheet()->setCellValue("K".$t,$row['payment_ref_date']);
    $phpExcel->getActiveSheet()->setCellValue("L".$t,$row['payment_ref_no']);
    $phpExcel->getActiveSheet()->setCellValue("M".$t,$row[22]);
    $phpExcel->getActiveSheet()->setCellValue("N".$t,$row[27]);
    $phpExcel->getActiveSheet()->setCellValue("O".$t,$row[25]);
    $phpExcel->getActiveSheet()->setCellValue("P".$t,$row[31]);
    $phpExcel->getActiveSheet()->setCellValue("Q".$t,$row['session_month']);
    $phpExcel->getActiveSheet()->setCellValue("R".$t,$row['total_amount']);
    $phpExcel->getActiveSheet()->setCellValue("S".$t,$row['pending_amount']);
    $totalAmountRecieved+=$row['amount'];
    $t++;
    $slno++;
    
}
$phpExcel->getActiveSheet()->setCellValue("G".$t,"TOTAL");
$phpExcel->getActiveSheet()->setCellValue("H".$t,$totalAmountRecieved);

$phpExcel->createSheet();
$phpExcel->setActiveSheetIndex(2);
$t=1;
$phpExcel->getActiveSheet()->mergeCells('A'.$t.':R'.$t);
$phpExcel->getActiveSheet()->setCellValue("A".$t,"INSTALMENT AMOUNT");
$t++;
$phpExcel->getActiveSheet()->setCellValue("A".$t,"SL NO");
$phpExcel->getActiveSheet()->setCellValue("B".$t,"ROLL NO");
$phpExcel->getActiveSheet()->setCellValue("C".$t,"STUDENT NAME");
$phpExcel->getActiveSheet()->setCellValue("D".$t,"MOBILE");
$phpExcel->getActiveSheet()->setCellValue("E".$t,"STREAM");
$phpExcel->getActiveSheet()->setCellValue("F".$t,"BRANCH");
$phpExcel->getActiveSheet()->setCellValue("G".$t,"MODE OF PAYMENT");
$phpExcel->getActiveSheet()->setCellValue("H".$t,"AMOUNT");
$phpExcel->getActiveSheet()->setCellValue("I".$t,"DATE OF RECEIPT");
$phpExcel->getActiveSheet()->setCellValue("J".$t,"ISSUING BANK NAME");
$phpExcel->getActiveSheet()->setCellValue("K".$t,"DRAFT NUMBER");
$phpExcel->getActiveSheet()->setCellValue("L".$t,"MONEY RECEIPT NUMBER");
$phpExcel->getActiveSheet()->setCellValue("M".$t,"PARTICULARS");
$phpExcel->getActiveSheet()->setCellValue("N".$t,"SUB PARTICULARS");

$t++;
$slno=1;
$totalAmountRefunded=0;
while ($row= mysql_fetch_array($resInstalment)){
    
    $phpExcel->getActiveSheet()->setCellValue("A".$t,"$slno");
    $phpExcel->getActiveSheet()->setCellValue("B".$t,$row['roll_no']);
    $phpExcel->getActiveSheet()->setCellValue("C".$t,$row['name']);
    $phpExcel->getActiveSheet()->setCellValue("D".$t,$row[14]);
    $phpExcel->getActiveSheet()->setCellValue("E".$t,$row['stream']);
    $phpExcel->getActiveSheet()->setCellValue("F".$t,$row['branch']);
    $phpExcel->getActiveSheet()->setCellValue("G".$t,$row['payment_type']);
    $phpExcel->getActiveSheet()->setCellValue("H".$t,$row['received_amount']);
    $phpExcel->getActiveSheet()->setCellValue("I".$t,$row['date']);
    $phpExcel->getActiveSheet()->setCellValue("J".$t,$row['bank_name']);
    $phpExcel->getActiveSheet()->setCellValue("K".$t,$row['refNum']);
    $phpExcel->getActiveSheet()->setCellValue("L".$t,$row['new_mrNumber']);
    $phpExcel->getActiveSheet()->setCellValue("M".$t,$row[27]);
	$phpExcel->getActiveSheet()->setCellValue("N".$t,$row[25]);
    //$totalAmountRefunded+=$row['refund_amount'];
    $t++;
    $slno++;
    
}
//$phpExcel->getActiveSheet()->setCellValue("Q".$t,"TOTAL");
//$phpExcel->getActiveSheet()->setCellValue("R".$t,$totalAmountRefunded);


$phpExcel->createSheet();
$phpExcel->setActiveSheetIndex(1);
$t=1;
$phpExcel->getActiveSheet()->mergeCells('A'.$t.':R'.$t);
$phpExcel->getActiveSheet()->setCellValue("A".$t,"REFUNDED AMOUNT");
$t++;
$phpExcel->getActiveSheet()->setCellValue("A".$t,"SL NO");
$phpExcel->getActiveSheet()->setCellValue("B".$t,"ROLL NO");
$phpExcel->getActiveSheet()->setCellValue("C".$t,"STUDENT NAME");
$phpExcel->getActiveSheet()->setCellValue("D".$t,"MOBILE");
$phpExcel->getActiveSheet()->setCellValue("E".$t,"STREAM");
$phpExcel->getActiveSheet()->setCellValue("F".$t,"BRANCH");
$phpExcel->getActiveSheet()->setCellValue("G".$t,"MODE OF PAYMENT");
$phpExcel->getActiveSheet()->setCellValue("H".$t,"AMOUNT");
$phpExcel->getActiveSheet()->setCellValue("I".$t,"DATE OF RECEIPT");
$phpExcel->getActiveSheet()->setCellValue("J".$t,"ISSUING BANK NAME");
$phpExcel->getActiveSheet()->setCellValue("K".$t,"DD ISSUING DATE");
$phpExcel->getActiveSheet()->setCellValue("L".$t,"DRAFT NUMBER");
$phpExcel->getActiveSheet()->setCellValue("M".$t,"MONEY RECEIPT NUMBER");
$phpExcel->getActiveSheet()->setCellValue("N".$t,"PARTICULARS");
$phpExcel->getActiveSheet()->setCellValue("O".$t,"SUB PARTICULARS");
$phpExcel->getActiveSheet()->setCellValue("P".$t,"TRANSACTION DONE BY");
$phpExcel->getActiveSheet()->setCellValue("Q".$t,"CANCELLATION DATE");
$phpExcel->getActiveSheet()->setCellValue("R".$t,"REFUNDED AMOUNT");
$phpExcel->getActiveSheet()->setCellValue("S".$t,"COMMENT");
$phpExcel->getActiveSheet()->setCellValue("T".$t,"CANCELLATION DONE BY");

$t++;
$slno=1;
$totalAmountRefunded=0;
while ($row= mysql_fetch_array($resCancel)){
    
    $phpExcel->getActiveSheet()->setCellValue("A".$t,"$slno");
    $phpExcel->getActiveSheet()->setCellValue("B".$t,$row['roll_no']);
    $phpExcel->getActiveSheet()->setCellValue("C".$t,$row[12]);
    $phpExcel->getActiveSheet()->setCellValue("D".$t,$row[14]);
    $phpExcel->getActiveSheet()->setCellValue("E".$t,$row['stream']);
    $phpExcel->getActiveSheet()->setCellValue("F".$t,$row['branch']);
    $phpExcel->getActiveSheet()->setCellValue("G".$t,$row['type']);
    $phpExcel->getActiveSheet()->setCellValue("H".$t,$row['amount']);
    $phpExcel->getActiveSheet()->setCellValue("I".$t,$row['date']);
    $phpExcel->getActiveSheet()->setCellValue("J".$t,$row['bank_name']."  Address:".$row['branch_detail']);
    $phpExcel->getActiveSheet()->setCellValue("K".$t,$row['payment_ref_date']);
    $phpExcel->getActiveSheet()->setCellValue("L".$t,$row['payment_ref_no']);
    $phpExcel->getActiveSheet()->setCellValue("M".$t,$row['mr_number']);
    $phpExcel->getActiveSheet()->setCellValue("N".$t,$row[27]);
	$phpExcel->getActiveSheet()->setCellValue("O".$t,$row[25]);
    $phpExcel->getActiveSheet()->setCellValue("P".$t,$row[31]);
    $phpExcel->getActiveSheet()->setCellValue("Q".$t,$row['cancel_date']);
    $phpExcel->getActiveSheet()->setCellValue("R".$t,$row['refund_amount']);
    $phpExcel->getActiveSheet()->setCellValue("S".$t,$row['comment']);
    $phpExcel->getActiveSheet()->setCellValue("T".$t,$row[44]);
    $totalAmountRefunded+=$row['refund_amount'];
    $t++;
    $slno++;
    
}
$phpExcel->getActiveSheet()->setCellValue("Q".$t,"TOTAL");
$phpExcel->getActiveSheet()->setCellValue("R".$t,$totalAmountRefunded);


$excelWriter = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
//$excelWriter->save("StudentData-UG.xls");
header('Content-type:application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="Finance-Report.xls"');
$excelWriter->save('php://output');

?>