<?php
include_once './protectedAdmin.php';
//session_start();
include_once '../db.php';
include_once '../inc/conf.php';
ob_start();
?>
<script>
function toggleExpenceHead(str){
if (str.length==0)
  { 
  document.getElementById("getContent").innerHTML="";
  return;
  }
var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("getContent").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","getExpenceDetail.php?expence="+str,true);
xmlhttp.send();

	}
	
function toggleTravelExp(str){
if (str.length==0)
  { 
  document.getElementById("getTravelBy").innerHTML="";
  return;
  }
var xmlhttp=new XMLHttpRequest();
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById("getTravelBy").innerHTML=xmlhttp.responseText;
    }
  }
xmlhttp.open("GET","getTravelDetail.php?travelBy="+str,true);
xmlhttp.send();
	}
	
function modeOfPayment(mode)
    {
        var bank_name = document.getElementsByName("bank_name");
        var branch_name = document.getElementsByName("branch_add");
        var ref_no = document.getElementsByName("ref_no");
        //alert(bank_name[0].readOnly);
        //alert(mode);
        if (mode == 'cash') {
            bank_name[0].value = "Not Applicable";
            branch_name[0].innerHTML = "Not Applicable";
            ref_no[0].value = "Not Applicable";
            bank_name[0].readOnly = true;
            branch_name[0].readOnly = true;
            ref_no[0].readOnly = true;
        } else {
            bank_name[0].value = "";
            branch_name[0].innerHTML = "";
            ref_no[0].value = "";
            bank_name[0].readOnly = false;
            branch_name[0].readOnly = false;
            ref_no[0].readOnly = false;

        }
    }

function genContent(id){
	if(document.getElementById(id).id=="btn_gen_hotel"){
	document.getElementById("gen_hotel_detail").innerHTML+='<tr><td colspan="2" style="color:red">Hotel Expences :</td></tr><tr><td>Vendor Name</td><td><input type="text" name="vendor_name[]"></td></tr><tr><td>Voucher No.</td><td><input type="text" name="voucher_no[]"></td></tr><tr><td>Voucher Date</td><td><input type="date" name="voucher_date[]"></td></tr><tr><td>Voucher Amount</td><td><input type="text" name="voucher_amount[]"></td></tr><tr><td>Transaction Head</td><td><input type="text" name="transaction_head[]"></td></tr><tr><td>Transaction Date</td><td><input type="date" name="transaction_date[]"></td></tr>';                              
	                                                   }
	else if(document.getElementById(id).id=="btn_clr_hotel"){
		document.getElementById("gen_hotel_detail").innerHTML='';
		}
	
else if(document.getElementById(id).id=="btn_gen_office"){
	//alert(id);
	document.getElementById("gen_office_detail").innerHTML+='<tr><td colspan="2" style="color:red">Office Expences :</td></tr><tr><td>Vendor Name</td><td><input type="text" name="vendor_name[]"></td></tr><tr><td>Transaction Head</td><td><input type="text" name="transaction_head[]"></td></tr><tr><td>Transaction Date</td><td><input type="date" name="transaction_date[]"></td></tr><tr><td>Transaction Amount</td><td><input type="text" name="voucher_amount[]"></td></tr>';                              
	}else if(document.getElementById(id).id=="btn_clr_office"){
		document.getElementById("gen_office_detail").innerHTML='';
		}
		
else if(document.getElementById(id).id=="btn_gen_plain"){
	document.getElementById("gen_plain_detail").innerHTML+='<tr><td colspan="2" style="color:red">Travel By Plain :</td></tr><tr><td>Transaction Date</td><td><input type="date" name="transaction_date[]"></td></tr><tr><td>Agency</td><td><input type="text" name="vendor_name[]"></td></tr><tr><td>Transaction Amount</td><td><input type="text" name="voucher_amount[]"></td></tr><tr><td>Ticket No.</td><td><input type="text" name="ticket_no[]"></td></tr><tr><td>Transaction Head</td><td><input type="text" name="transaction_head[]"></td></tr><tr><td>Travel Sector</td><td><input type="text" name="travel_from[]"> To <input type="text" name="travel_to[]"></td></tr>';
                                                                               
	}else if(document.getElementById(id).id=="btn_clr_plain"){
		document.getElementById("gen_plain_detail").innerHTML='';
		}
		
else if(document.getElementById(id).id=="btn_gen_train"){
	document.getElementById("gen_train_detail").innerHTML+='<tr><td colspan="2" style="color:red">Travel By train :</td></tr><tr><td>Transaction Date</td><td><input type="date" name="transaction_date[]"></td></tr><tr><td>Train Name</td><td><input type="text" name="vendor_name[]"></td></tr><tr><td>Transaction Amount</td><td><input type="text" name="voucher_amount[]"></td></tr><tr><td>Ticket No.</td><td><input type="text" name="ticket_no[]"></td></tr><tr><td>Transaction Head</td><td><input type="text" name="transaction_head[]"></td></tr><tr><td>Travel Sector</td><td><input type="text" name="travel_from[]"> To <input type="text" name="travel_to[]"></td></tr>';                              
	}else if(document.getElementById(id).id=="btn_clr_train"){
		document.getElementById("gen_train_detail").innerHTML='';
		}
		
else if(document.getElementById(id).id=="btn_gen_cab"){
	document.getElementById("gen_cab_detail").innerHTML+='<tr><td colspan="2" style="color:red">Travel By Cab :</td></tr><tr><td>Vendor Name</td><td><input type="text" name="vendor_name[]"></td></tr><tr><td>Voucher No.</td><td><input type="text" name="voucher_no[]"></td></tr><tr><td>Voucher Date</td><td><input type="date" name="voucher_date[]"></td></tr><tr><td>Voucher Amount</td><td><input type="text" name="voucher_amount[]"></td></tr><tr><td>Transaction Head</td><td><input type="text" name="transaction_head[]"></td></tr><tr><td>Transaction Date</td><td><input type="date" name="transaction_date[]"></td></tr>';                              
	}else if(document.getElementById(id).id=="btn_clr_cab"){
		document.getElementById("gen_cab_detail").innerHTML='';
		}
}

</script>
<?php
if(isset($_POST['submit'])){
$billDate=$_POST['bill_date'];
if($billDate==""){
	$billDate="NA";
	}else{
		$billDate;
		}

$officeType=$_POST['office_type'];
if($officeType==""){
	$officeType="NA";
	}else{
		$officeType;
		}

$invoiceNo=$_POST['invoiceNo'];
if($invoiceNo==""){
	$invoiceNo="NA";
	}else{
		$invoiceNo;
		}

$invoiceDate=$_POST['invoice_date'];
if($invoiceDate==""){
	$invoiceDate="NA";
	}else{
		$invoiceDate;
		}

$invoiceAmount=$_POST['invoice_amount'];
if($invoiceAmount==""){
	$invoiceAmount="NA";
	}else{
		$invoiceAmount;
		}

$guestName=$_POST['guest_name'];
if($guestName==""){
	$guestName="NA";
	}else{
		$guestName;
		}

$companyName=$_POST['company_name'];
if($companyName==""){
	$companyName="NA";
	}else{
		$companyName;
		}

$expenceHead=$_POST['expence_head'];
if($expenceHead==""){
	$expenceHead="NA";
	}else{
		$expenceHead;
		}

$ticket_no=$_POST['ticket_no'];

$vendor_name=$_POST['vendor_name'];

$voucher_no=$_POST['voucher_no'];

$voucher_date=$_POST['voucher_date'];

$voucher_amount=$_POST['voucher_amount'];

$transaction_head=$_POST['transaction_head'];

$transaction_date=$_POST['transaction_date'];

$travel_from=$_POST['travel_from'];

$travel_to=$_POST['travel_to'];

$amountPaid=$_POST['amount_paid'];
if($amountPaid==""){
	$amountPaid="NA";
	}else{
		$amountPaid;
		}

$travelBy=$_POST['travel_by'];
if($travelBy==""){
	$travelBy="NA";
	}else{
		$travelBy;
		}

$amountPending=$_POST['amount_pending'];
if($amountPending==""){
	$amountPending="NA";
	}else{
		$amountPending;
		}

$paymentMode=$_POST['payment_mode'];
if($paymentMode==""){
	$paymentMode="NA";
	}else{
		$paymentMode;
		}

$bankName=$_POST['bank_name'];
if($bankName==""){
	$bankName="NA";
	}else{
		$bankName;
		}

$branchAdd=$_POST['branch_add'];
if($branchAdd==""){
	$branchAdd="NA";
	}else{
		$branchAdd;
		}

$refNo=$_POST['ref_no'];
if($refNo==""){
	$refNo="NA";
	}else{
		$refNo;
		}

$count=count($vendor_name);

for($i=0;$i< sizeof($vendor_name);$i++){
		
	$query="INSERT INTO `tbl_finance_expence`(`bill_date`, `office_type`, `invoice_no`, `invoice_date`, `invoice_amount`, `guest_name`, `company_name`, `expence_head`, `vendor_name`, `voucher_no`, `voucher_date`, `voucher_amount`, `ticket_no`, `transaction_head`, `transaction_date`, `travel_by`, `travel_from`, `travel_to`, `amount_paid`, `amount_pending`, `payment_mode`, `bank_name`, `branch_name`, `ref_no`) 
	
	VALUES
	 ('$billDate','$officeType','$invoiceNo','$invoiceDate','$invoiceAmount','$guestName','$companyName','$expenceHead','$vendor_name[$i]','$voucher_no[$i]','$voucher_date[$i]','$voucher_amount[$i]','$ticket_no[$i]','$transaction_head[$i]','$transaction_date[$i]','$travelBy','$travel_from[$i]','$travel_to[$i]','$amountPaid','$amountPending','$paymentMode','$bankName','$branchAdd','$refNo')";
	
	$res=mysql_query($query);
	}
	if($res){
		?>
		<script>
                alert("Success Fully Added To Database");
        </script>
		<?php
		}else{
			?>
			<script>
                    alert("Operation Failed. Please Try Again !!!");
            </script>
			<?php
			}
		}
?>
<form method="post" action="">
       <table width="100%">
              <tr>
                   <td>
                            Bill Date
                   </td>
                   <td>
                            <script>DateInput('bill_date', true, 'YYYY-MM-DD');</script>
                   </td>
              </tr>
              
              <tr>
                   <td>
                            Office Type
                   </td>
                   <td>
                            <select name="office_type">
                                     <option>--Select One--</option>
                                     <option>TP</option>
                                     <option>CS</option>
                                     <option>CR</option>
                            </select>
                   </td>
              </tr>
              
              <tr>
                   <td>
                        Invoice No.
                   </td>
                   <td>
                        <input type="text" name="invoiceNo">
                   </td>
                   <td>
                       Invoice Date
                   </td>
                   <td>
                       <script>DateInput('invoice_date', true, 'YYYY-MM-DD');</script>
                   </td>
                   <td>
                       Invoice Amount
                   </td>
                   <td>
                       <input type="text" name="invoice_amount">
                   </td>
              </tr>
              <tr>
                   <td>
                       Guest Name
                   </td>
                   <td>
                       <input type="text" name="guest_name">
                   </td>
                   <td>
                       Company Name
                   </td>
                   <td>
                       <input type="text" name="company_name">
                   </td>
              </tr>
              
              <tr>
                   <td>
                       Expence Head
                   </td>
                   <td>
                            <select name="expence_head" id="expHead" onchange="toggleExpenceHead(this.value)">
                                     <option>--Select One--</option>
                                     <option>Hotel</option>
                                     <option>Travel</option>
                                     <option>Office</option>
                            </select>
                   </td>
              </tr>
              
              <tr>
                   <td colspan="6" id="getContent">
                       <!--hotel-->
                       
                       
                       <!--Travel-->
                       
                       
                       <!--office-->
                   </td>
              </tr>
              
              <tr>
                  <td colspan="6" style="background-color:#CCCCCC;text-align:left">Payment Details:</td>
              </tr>
              <tr>
                 <td>Amount Paid</td>
                 <td><input type="text" name="amount_paid"></td>
             </tr>
             <tr>
                 <td>Amount Pending</td>
                 <td><input type="text" name="amount_pending"></td>
             </tr>
             <tr>
                  <td>
                      Mode Of Payment
                  </td>
                  <td>
                      <select name="payment_mode" onchange="modeOfPayment(this.value)">
                                <option>--Select One--</option>
                                <option value="cash">CASH</option>
                                <option value="cheque">CHEQUE</option>
                                <option value="dd">DEMAND DRAFT</option>
                                <option value="neft">NEFT TRANSFER</option>
                                <option value="rtgs">RTGS TRANSFER</option>
                      </select>
                  </td>
              </tr>
              <tr>
                  <td>
                      Name of the Bank
                  </td>
                  <td>
                      <input type="text" name="bank_name">
                  </td>
              </tr>
              <tr>
                  <td>
                      Branch Address and Details
                  </td>
                  <td>
                      <textarea name="branch_add"></textarea>
                  </td>
              </tr>
              <tr>
                  <td>
                      Payment reference Number<br />(DD Number/NEFT Number/RTGS Number)
                  </td>
                  <td>
                      <input type="text" name="ref_no">
                  </td>
              </tr>
              <tr align="center">
                  <td colspan="3"><input type="submit" name="submit" value="submit"></td>
              </tr>
       </table>
</form>
<?php
$content = ob_get_contents();
ob_end_clean();
include_once './template.php';
if (isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg'])) {
    echo $_SESSION['errMsg'];
    unset($_SESSION['errMsg']);
}
?>