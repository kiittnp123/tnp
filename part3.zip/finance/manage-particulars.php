<?php
include_once './protectedAdmin.php';
include_once '../db.php';
ob_start();
if(isset($_POST['btn_part'])){
    $partName=$_POST['part_name'];
    $query="insert into tbl_particular values(NULL,'$partName')";
    $res=  mysql_query($query);
    $particularId=  mysql_insert_id();
    $querySub="insert into tbl_particular_sub values(NULL,$particularId,'Not Applicable')";
    $resSub=  mysql_query($querySub);
    $_SESSION['errMsg']="<script>alert('Particular Added to the database')</script>";
}
if(isset($_POST['btn_subpart'])){
    $partName=$_POST['part_name'];
    $particularId=$_POST['particular'];
    $query="insert into tbl_particular_sub values(NULL,$particularId,'$partName')";
    $res=  mysql_query($query);
    $_SESSION['errMsg']="<script>alert('Sub Particular Added to the database')</script>";
}
?>
<script>
    function displayForm(c){
        //alert(c);
            c=c.split(",");
          //  alert(c);
            document.getElementById(c[0]).style.display="block";
            document.getElementById(c[1]).style.display="none";
    }
</script>
<input type="radio" name="type" value="part,subpart" onclick="displayForm(this.value)" />Particular Form
<input type="radio" name="type" value="subpart,part" onclick="displayForm(this.value)" />Sub Particular For
<form method="post" action="" id="part" style="display:none">
    <table align="center">
       
        <tbody>
            <tr>
                <td>Enter the name of the Particular</td>
                <td><input type="text" name="part_name" value="" /></td>
            </tr>
            <tr>
                <td><input type="submit" value="SAVE" name="btn_part" /></td>
                <td><input type="reset" value="CLEAR" /></td>
            </tr>
        </tbody>
    </table>
</form>
<?php

$query="select * from tbl_particular";
$res=  mysql_query($query);
$particularList="";
while ($row = mysql_fetch_array($res)) {
    $particularList.="<option value='".$row[0]."'>".$row[1]."</option>";
}
?>
<form method="post" action="" id="subpart" style="display:none">
    <table align="center">
       
        <tbody>
            <tr>
                <td>Enter the name of the Sub Particular</td>
                <td><input type="text" name="part_name" value="" /></td>
            </tr>
            <tr>
                <td>Select the corresponding Particular</td>
                <td><select name="particular"><?php echo $particularList; ?></select></td>
            </tr>
            <tr>
                <td><input type="submit" value="SAVE" name="btn_subpart" /></td>
                <td><input type="reset" value="CLEAR" /></td>
            </tr>
        </tbody>
    </table>
</form>
<?php
$content=  ob_get_contents();
ob_end_clean();
include_once './template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>
