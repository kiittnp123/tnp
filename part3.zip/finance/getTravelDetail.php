<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
if($_GET['travelBy']=="Plain"){
	?>
	                   <table width="100%" id="plainExp">
                               <caption style="background-color:#CCCCCC;text-align:left">Travel By Plain :</caption>
                               <tr>
                                   <td>
                                       Transaction Date
                                   </td>
                                   <td>
                                       <input type="date" name="transaction_date[]">
                                   </td>
                               </tr>
                               
                               <tr>
                                  <td>
                                      Transaction Amount
                                  </td>
                                  <td>
                                      <input type="text" name="voucher_amount[]">
                                  </td>
                               </tr>
                               
                               <tr>
                                  <td>
                                      Ticket No.
                                  </td>
                                  <td>
                                      <input type="text" name="ticket_no[]">
                                  </td>
                               </tr>
                              
                               <tr>
                                  <td>
                                       Transaction Head
                                  </td>
                                  <td>
                                      <input type="text" name="transaction_head[]">
                                  </td>
                               </tr>
                               
                               <tr>
                                   <td>
                                       Agency
                                   </td>
                                   <td>
                                       <input type="text" name="vendor_name[]">
                                   </td>
                               </tr>
                               
                               <tr>
                                   <td>
                                       Travel Sector
                                   </td>
                                   <td>
                                       <input type="text" name="travel_from[]"> To <input type="text" name="travel_to[]">
                                   </td>
                               </tr>
                               
                               <tr>
                                  <td colspan="2">
                                       <table id="gen_plain_detail" width="100%">
                                       
                                       </table>
                                  </td>
                              </tr>
                              
                              <tr>
                                  <td colspan="2">
                                  <input type="button" value="+" id="btn_gen_plain" onClick="genContent(this.id)">
                                  <input type="button" value="-" id="btn_clr_plain" onClick="genContent(this.id)">
                                  </td>
                              </tr>
                        </table>
	<?php
	}
	
elseif($_GET['travelBy']=="Train"){
	?>
	                    <table width="100%" id="trainExp">
                               <caption style="background-color:#CCCCCC;text-align:left">Travel By Train :</caption>
                               <tr>
                                   <td>
                                       Transaction Date
                                   </td>
                                   <td>
                                       <input type="date" name="transaction_date[]">
                                   </td>
                                </tr>
                               
                                <tr>
                                  <td>
                                      Transaction Amount
                                  </td>
                                  <td>
                                      <input type="text" name="voucher_amount[]">
                                  </td>
                               </tr>
                               
                               <tr>
                                  <td>
                                      Ticket No.
                                  </td>
                                  <td>
                                      <input type="text" name="ticket_no[]">
                                  </td>
                               </tr>
                               
                               <tr>
                                  <td>
                                       Transaction Head
                                  </td>
                                  <td>
                                      <input type="text" name="transaction_head[]">
                                  </td>
                               </tr>
                
                               <tr>
                                   <td>
                                       Train Name
                                   </td>
                                   <td>
                                       <input type="text" name="vendor_name[]">
                                   </td>
                               </tr>
                               
                               <tr>
                                   <td>
                                       Travel Sector
                                   </td>
                                   <td>
                                       <input type="text" name="travel_from[]"> To <input type="text" name="travel_to[]">
                                   </td>
                               </tr>
                               
                               <tr>
                                  <td colspan="2">
                                       <table id="gen_train_detail" width="100%">
                                       
                                       </table>
                                  </td>
                              </tr>
                              
                              <tr>
                                  <td colspan="2">
                                  <input type="button" value="+" id="btn_gen_train" onClick="genContent(this.id)">
                                  <input type="button" value="-" id="btn_clr_train" onClick="genContent(this.id)">
                                  </td>
                              </tr>
                               
                        </table>
	<?php
	}
	
elseif($_GET['travelBy']=="Cab"){
	?>
	                   <table width="100%" id="cabExp">
                                <caption style="background-color:#CCCCCC;text-align:left">Travel By Cab  :</caption>
                                <tr>
                                    <td>
                                        Vendor Name
                                    </td>
                                    <td>
                                        <input type="text" name="vendor_name[]">
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>
                                        Voucher No.
                                    </td>
                                    <td>
                                        <input type="text" name="voucher_no[]">
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>
                                        Voucher Date
                                    </td>
                                    <td>
                                        <input type="date" name="voucher_date[]">
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>
                                        Voucher Amount
                                    </td>
                                    <td>
                                        <input type="text" name="voucher_amount[]">
                                    </td>
                                </tr>
                
                                <tr>
                                    <td>
                                         Transaction Head
                                    </td>
                                    <td>
                                        <input type="text" name="transaction_head[]">
                                    </td>
                                </tr>
                                
                                <tr>
                                    <td>
                                        Transaction Date
                                    </td>
                                    <td>
                                        <input type="date" name="transaction_date[]">
                                    </td>
                                </tr>
                                
                                <tr>
                                  <td colspan="2">
                                       <table id="gen_cab_detail" width="100%">
                                       
                                       </table>
                                  </td>
                              </tr>
                              
                              <tr>
                                  <td colspan="2">
                                  <input type="button" value="+" id="btn_gen_cab" onClick="genContent(this.id)">
                                  <input type="button" value="-" id="btn_clr_cab" onClick="genContent(this.id)">
                                  </td>
                              </tr>
                                
                         </table>
	<?php
	}
?>
</body>
</html>