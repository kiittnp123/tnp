<?php
include_once './protectedAdmin.php';
include_once '../db.php';
ob_start();
if(isset($_POST['btn_request']) && !empty($_POST['btn_request']) && $_POST['btn_request']=='DOWNLOAD' ){
    $startDate=$_POST['start_date'];
    $endDate=$_POST['end_date'];
    $query="select count(*) as total from tbl_finance tf LEFT JOIN tbl_finance_cancel tfc on tf.mr_number=tfc.mr_number where (`date` between '$startDate' and '$endDate') or (cancel_date  between '$startDate' and '$endDate')";
    //echo $query;
    $res=mysql_query($query);
    $row=  mysql_fetch_array($res);
    if($row['total']>0){
        $_SESSION['query']="'$startDate' and '$endDate'";
        header("Location:exportFinanceReport1.php");
    }else{
        $_SESSION['errMsg']="<script>alert('No Transaction exists for the selected period')</script>";
    } 
}
?>
<form method="post" action="">
<table align="center">
    <tr>
        <td>Select the Start Date</td>
        <td><script>DateInput('start_date', true, 'YYYY-MM-DD')</script></td>
    </tr>
    <tr align="center">
        <td colspan="2">TO</td>
    </tr>
    <tr>
        <td>Select the End Date</td>
        <td><script>DateInput('end_date', true, 'YYYY-MM-DD')</script></td>
    </tr>
    <tr align="center">
        <td colspan="2"><input type="submit" value="DOWNLOAD" name="btn_request" /></td>
    </tr>
</table>
</form>
<?php
$content=  ob_get_contents();
ob_end_clean();
include_once './template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>
