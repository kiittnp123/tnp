<?php

session_start();
//error_reporting(0);
include_once '../db.php';
include_once '../inc/conf.php';
require_once('../conf/config/lang/eng.php');
require_once('../conf/tcpdf.php');

if (isset($_GET['id']) && !empty($_GET['id'])) {
    $id = $_GET['id'];
	$mrNumber_part1 = substr($id,0,7);
	$mrNumber_part2 = substr($id,7);
	$newMrNumber=$mrNumber_part1."/IA".$mrNumber_part2;
	$received=$_GET['received'];
    /*$type = $_GET['type'];
    if ($type == 'ol')
        $typeReceipt = "ORIGINAL";
    if ($type == 'dt')
        $typeReceipt = "DUPLICATE";*/
    $query = "SELECT * 
FROM tbl_finance tf
LEFT JOIN tbl_particular_sub tps ON tf.particular_sub_id = tps.particular_sub_id
LEFT JOIN tbl_particular tp ON tps.particular_id = tp.particular_id
LEFT JOIN tbl_admin ta ON tf.admin = ta.user_id
LEFT JOIN tbl_finance_cancel tfc ON tf.mr_number = tfc.mr_number
WHERE tf.mr_number =  '$id'";
    //echo $query;
    $res = mysql_query($query);
    if (mysql_num_rows($res) == 1) {
        $row = mysql_fetch_array($res);
        $bgImage = "";
        $paymentInfo = '<tr>
                            <td>1.</td>
                            <td>' . $row['type'] . '</td>
                            <td>' . $row['payment_ref_no'] . '</td>
                            <td>' . date("Y-m-d") . '</td>
                            <td>' . $received . '</td>
                            <td>' . $row['bank_name'] . ' - ' . $row['branch_detail'] . '</td>
                        </tr>';
        if (!empty($row['cancel_id'])) {
            $bgImage = '<tr><td colspan="2"><br>&nbsp;<br><img src="images/cancel.jpg" width="100" height="50"/></td></tr>';
            $paymentInfo = '<tr>
                                <td>1.</td>
                                <td>Cash</td>
                                <td>Not Applicable</td>
                                <td>' . $row['cancel_date'] . '</td>
                                <td>' . $row['refund_amount'] . '</td>
                                <td>Not Applicable</td>
                            </tr>';
            $typeReceipt = "CANCELLED";
        }
        $receipt = '
<table align="center" border="2">
    <tr>    
        <td align="center" style="width:20%"><br />&nbsp;<br /><img src="images/kiit.jpg" width="100"/></td>
        <td style="width:80%" align="left">
            <br />&nbsp;<br />
            &nbsp;KIIT SCHOOL OF TECHNOLOGY<br />
            &nbsp;KIIT UNIVERSITY<br />
            &nbsp;(Under the Management of Kalinga Institute of Industrial Technology)<br />
            &nbsp;AT/PO-KIIT, Bhubaneshwar - 751024, Odisha<br />
            &nbsp;Tel. 0674-2725272, 2712103, 2725347
        </td>
    </tr>
    <tr align="center">
        <td colspan="2">
            <span style="background-color: black;color: white;">MONEY RECEIPT</span> - <span style="background-color: black;color: white;">' . $typeReceipt . '</span>
        </td>
    </tr>    
    <tr>
        <td align="left" style="width:50%">
            <b>M.R. NO : ' . $newMrNumber . '</b>
        </td>
        <td align="right" style="width:50%">
            <b>DATE : ' . date('Y/m/d') . '</b>
        </td>
    </tr>    
    <tr align="left">
        <td style="width:30%">
            Name
        </td>
        <td style="width:70%">
            ' . $row[12] . '
        </td>
    </tr>    
    <tr align="left">
        <td style="width:30%">
            Roll no
        </td>
        <td style="width:70%">
            ' . $row['roll_no'] . '
        </td>
    </tr>
    <tr align="left">
        <td style="width:30%">
            Course
        </td>
        <td style="width:70%">
            ' . $row['stream'] . '
        </td>
    </tr>
    <tr align="left">
        <td style="width:30%">
            Branch
        </td>
        <td style="width:70%">
            ' . $row['branch'] . '
        </td>
    </tr>
    <tr align="left">
        <td style="width:30%">
            Year of Joining Batch
        </td>
        <td style="width:70%">
            ' . $row['year_join'] . '
        </td>
    </tr>
    <tr>
        <td colspan="2">
            <table border="1" style="border-style: solid" style="width: 100%;">
                <tr>
                    <th width="100"><b>Sl. No.</b></th>
                    <th width="370"><b>Particulars</b></th>
                    <th width="180"><b>Amount(Rs)</b></th>
                </tr>
                <tr>
                    <td width="100">1</td>
                    <td>' . $row[27] . ' - ' . $row[25] . '</td>
                    <td>' . $row['total_amount'] . '</td>
                </tr>
                <tr>
                    <th colspan="3" align="right">
                        <b>Total&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                        &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;' . $row['total_amount'] . '&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</b>
                    </th>
                </tr>
            </table>
        </td>
    </tr>
    <tr>
        <td colspan="2" align="left">
            Remarks : ' . $row[19] . '
        </td>
    </tr>    
    <tr align="left">
        <td colspan="2"> &nbsp;Received / Refunded as per following details :</td>
    </tr>    
    <tr>
        <td colspan="2">
            <table border="1" style="width: 100%;">
                <tr>
                    <th><b>Sl No</b></th>
                    <th><b>Mode</b></th>
                    <th><b>Instrument No</b></th>
                    <th><b>Date</b></th>
                    <th><b>Amount</b></th>
                    <th><b>Drawn On</b></th>
                </tr>
                    ' . $paymentInfo . '                
                <tr>
                    <td colspan="4" align="right"><b>Total</b>&nbsp;&nbsp;</td>
                    <td><b>' . $received . '</b></td>
                    <td></td>
                </tr>
            </table>
        </td>
    </tr>    
            ' . $bgImage . '        
    <tr>
        <td align="left" style="font-size:25px;"><br /><br /><br /><br /><br /><br />Cheques / DDs are subject to realisation<br />
            Please check the Money Receipt before Leaving the Counter
        </td>
        <td align="right">
            Receiving Officer<br /><br /><br /><br />
           <span style="font-size:25px;"> Prepared by ' . $row[31] . '. Printed By ' . $_SESSION['userFullName'] . ' on ' . date("Y-m-d") . '</span>
        </td>
    </tr>
</table>';
        //echo $receipt;
        /*
          echo "<pre>";
          var_dump($row);
          echo "</pre>";
         */
// create new PDF document

        $pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

// set document information
        $pdf->SetCreator(PDF_CREATOR);
        $pdf->SetAuthor('TNP - KIIT UNIVERSITY');
        $pdf->SetTitle('');
        $pdf->SetSubject('');
        $pdf->SetKeywords('');

// set default header data
//$pdf->SetHeaderData(PDF_HEADER_LOGO, PDF_HEADER_LOGO_WIDTH, ''.'','');
// set header and footer fonts
        $pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
        $pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));

// set default monospaced font
        $pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);

//set margins
//$pdf->SetMargins(PDF_MARGIN_LEFT, PDF_MARGIN_TOP, PDF_MARGIN_RIGHT);
//$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
//$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
//set auto page breaks
        $pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);

//set image scale factor
        $pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);

//set some language-dependent strings
        $pdf->setLanguageArray($l);

// ---------------------------------------------------------
// set font
        $pdf->SetFont('dejavusans', '', 10);

// add a page
        $pdf->AddPage();

// create some HTML content
//echo $html;
// output the HTML content
        $pdf->writeHTML($receipt, true, false, true, false, '');
// reset pointer to the last page
        $pdf->lastPage();

// ---------------------------------------------------------
//Close and output PDF document
//header("Content-Type: application/octet-stream");
//header("Content-Disposition: attachment; filename=somefile.pdf;");

        $fileName = str_replace("/", "~", $row[22]);
//var_dump($fileName);
        $pdf->Output($fileName . '-' . $typeReceipt . '.pdf');

//============================================================+
// END OF FILE                                                
//============================================================+
         
    } else {
        echo "<h1>Money Receipt Id Not Found</h1>";
    }
} else {
    echo "<h1>Unauthorized Access</h1>";
}
?>
