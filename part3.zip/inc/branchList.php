<?php
if(isset($_GET['id']) && !empty($_GET['id']))
    $selectStream=$_GET['id'];
if($selectStream=="M.Tech"){
  ?>
<option>Construction Engg. & Management</option>
<option>Structural Engg.</option>
<option>Computer Science</option>
<option>Computer Science & Information Security</option>
<option>Database Engg.</option>
<option>Software Engg.</option>
<option>Communication System Engg.</option>
<option>VLSI Design & Embedded System</option>
<option>Power Electronics and Drives</option>
<option>Power Engg. & Energy System</option>
<option>Thermal Engg.</option>
<option>Manufacturing Process & Systems</option>
<option>RF & Microwave Engg.</option>
<?php
}  elseif ($selectStream=="MCA") {
    ?>
<option>MCA</option>
<?php
}elseif ($selectStream=="Dual Digree B.Tech and M.Tech") {
    ?>
<option>Computer Science Engg.</option>
<option>Information Technology Engg.</option>
<option>Electrical Engg.</option>
<option>Electronics & Electrical Engg.</option>
<option>Electronics & Telecomm. Engg.</option>
<option>Electronics & Instrumentation Engg.</option>
<option>Mechanical Engg.</option>
<option>Civil Engg.</option>
<option>Automobile Engg.</option>
<option>Construction Engg. & Management</option>
<option>Structural Engg.</option>
<option>Computer Science</option>
<option>Computer Science & Information Security</option>
<option>Database Engg.</option>
<option>Software Engg.</option>
<option>Communication System Engg.</option>
<option>VLSI Design & Embedded System</option>
<option>Power Electronics and Drives</option>
<option>Power Engg. & Energy System</option>
<option>Thermal Engg.</option>
<option>Manufacturing Process & Systems</option>
<option>RF & Microwave Engg.</option>
<?php
}else{
    ?>
<option>Computer Science Engg.</option>
<option>Information Technology Engg.</option>
<option>Electrical Engg.</option>
<option>Electronics & Electrical Engg.</option>
<option>Electronics & Telecomm. Engg.</option>
<option>Electronics & Instrumentation Engg.</option>
<option>Mechanical Engg.</option>
<option>Civil Engg.</option>
<option>Automobile Engg.</option>
<?php
}
?>