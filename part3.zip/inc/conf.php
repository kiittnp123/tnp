<?php
// Setting the default time zone for all the php scripts

date_default_timezone_set("Asia/Kolkata");
?>