<?php
ob_start();
include '../db.php';
include 'protectedStudent.php';
$username=$_SESSION['userName'];
$sqlstd="select * from tbl_student where email='$username'";
$resstd=mysql_query($sqlstd);
$row=mysql_fetch_array($resstd);
?>
<script type="text/javascript">
function infoDisplay(c){
    if(c.value=='Other Information'){
        document.getElementById("otherInfo").style.display='block';
        document.getElementById("personalInfo").style.display='none';
        document.getElementById("academicInfo").style.display='none';
        document.getElementById("placementInfo").style.display='none';
    }
    else if(c.value=='Placement Information'){
        document.getElementById("otherInfo").style.display='none';
        document.getElementById("personalInfo").style.display='none';
        document.getElementById("academicInfo").style.display='none';
        document.getElementById("placementInfo").style.display='block';
    }
    else if(c.value=='Personal Information'){
        document.getElementById("otherInfo").style.display='none';
        document.getElementById("personalInfo").style.display='block';
        document.getElementById("academicInfo").style.display='none';
        document.getElementById("placementInfo").style.display='none';
    }
    else if(c.value=='Academic Information'){
        document.getElementById("otherInfo").style.display='none';
        document.getElementById("personalInfo").style.display='none';
        document.getElementById("academicInfo").style.display='block';
        document.getElementById("placementInfo").style.display='none';
    }
        
}
</script>

View <select name="info_type" id="infoType" onchange="return infoDisplay(this)">
    <option>Personal Information</option>
    <option>Academic Information</option>
    <option>Other Information</option>
    <!--option>Placement Information</option-->
</select>

      <table align="center" width="1000" border="0" id="personalInfo" style="display: block">
        <tr>
        <td colspan="2" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Personal Detail</font></td>
        </tr>
         <tr>
            <td>Rollno:</td>
           <td  align="left"><input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td>Status:</td>
           <td  align="left"><input type="text" name="txtstatus" value="<?php echo $row['status'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td>Name:</td>
                <td><input type="text" name="name" size="25" value="<?php echo $row['name'] ?>" style="width:500px" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <input type="text" name="year_join" size="25" value="<?php echo $row['year_join'] ?>" style="width:500px" readonly="readonly" />
            </td>    
        </tr>
        <tr>
            <td>
                Year of Passing
            </td>
            <td>
                <input type="text" name="year_pass" size="25" value="<?php echo $row['year_passout'] ?>" style="width:500px" readonly="readonly" />
            </td>
        </tr>
        <tr>
            <td>Boarding:</td>
            <td><input type="text" name="boarding" value="<?php echo $row['boarding'] ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>Category</td>
            <td><input type="text" name="category" value="<?php echo $row['category'] ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td><input type="text" name="gender" value="<?php echo $row['gender'] ?>" readonly="readonly" /></td>           
        </tr>
        <tr>
            <td>DoB</td>
            <td><input type="text" name="dob" value="<?php echo date("d-M-y",strtotime($row['dob'])) ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>Permanent Contact Number</td>
            <td><input type="text" name="permanent_contact" size="25" value="<?php echo $row['mobile_perm'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Photo</td>
            <td><img src="<?php echo $row['image']; ?>" height="90" width="110" /></td>
        </tr>
        <tr>
            <td align="left">Mobile Number(Self)</td>
            <td><input type="text" name="txtmobile" size="25" value="<?php echo $row['mobile'] ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>e-Mail ID (Self)</td>
            <td><input type="text" name="txtaltemail" size="25" value="<?php echo $row['alt_email'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td align="left">Father's Name:</td>
            <td><input type="text" name="txtfhname" size="50" value="<?php echo $row['father_name'] ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td align="left">Father's Mobile Number</td>
            <td><input type="text" name="txtmobile" size="25" value="<?php echo $row['father_mobile'] ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>Father's e-Mail ID</td>
            <td><input type="text" name="txtaltemail" size="25" value="<?php echo $row['father_email'] ?>" readonly="readonly"/></td>
        </tr>
        <tr valign="middle">
            <td align="left" valign="top">Occupation with:</td>
            <td><input type="text" name="father_industry" size="25" value="<?php echo $row['father_org'] ?>" readonly="readonly"/></td>
        </tr>
        <?php
            if($row['father_add']==""){
		?>
        <tr>
            <td valign="top">Designation & Address</td>
            <td>
                <!--<textarea name="father_post" rows="5" cols="50" readonly="readonly"><?php /*echo $row['father_add']*/ ?></textarea>-->
                <input type="text" readonly="readonly" size="50" value="<?php echo $row['father_add_1'];?>"><br/>
                <input type="text" readonly="readonly" size="50" value="<?php echo $row['father_add_2'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['father_add_city'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['father_add_state'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['father_add_pin'];?>">          
            </td>
        </tr>
        <?php
			}else{
		?>
		<tr>
            <td valign="top">Designation & Address</td>
            <td>
                <textarea name="father_post" rows="5" cols="50" readonly="readonly"><?php echo $row['father_add'] ?></textarea>
            </td>
        </tr>          
		<?php
				}
		?>
        <?php
            if($row['permanent_address']==""){
		?>
        <tr>
            <td align="left" valign="top">Permanent Address</td>
            <td>
                <!--<textarea name="txtpermadd" rows="5" cols="50" readonly="readonly"><?php //echo $row['permanent_address'] ?></textarea>-->
                <input type="text" readonly="readonly" size="50" value="<?php echo $row['permanent_add_1'];?>"><br/>
                <input type="text" readonly="readonly" size="50" value="<?php echo $row['permanent_add_2'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['permanent_add_city'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['permanent_add_state'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['permanent_add_pin'];?>">
            </td>
        </tr>
        <?php
			}else{
		?>
        <tr>
            <td align="left" valign="top">Permanent Address</td>
            <td>
                <textarea name="txtpermadd" rows="5" cols="50" readonly="readonly"><?php echo $row['permanent_address'] ?></textarea>
            </td>
        </tr>          
		<?php
				}
		?>
        <?php
            if($row['permanent_address']==""){
		?>
        <tr>
            <td align="left" valign="top">Correspondence Address</td>
            <td>
                <!--<textarea name="txtcorresadd" rows="5" cols="50" readonly="readonly"><?php //echo $row['corres_address'] ?></textarea>-->
                <input type="text" readonly="readonly" size="50" value="<?php echo $row['corres_add_1'];?>"><br/>
                <input type="text" readonly="readonly" size="50" value="<?php echo $row['corres_add_2'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['corres_add_city'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['corres_add_state'];?>"><br/>
                <input type="text" readonly="readonly" size="25" value="<?php echo $row['corres_add_pin'];?>">
            </td>
        </tr>
        <?php
			}else{
		?>
        <tr>
            <td align="left" valign="top">Correspondence Address</td>
            <td>
                <textarea name="txtcorresadd" rows="5" cols="50" readonly="readonly"><?php echo $row['corres_address'] ?></textarea>
            </td>
        </tr>          
		<?php
				}
		?>
        </table>
        <table align="center" width="1000" border="0" id="academicInfo"  style="display: none">
        <tr>
        <td colspan="2" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Academic Detail</font></td>
        </tr>
        <?php
        if($row['ssc_board']!='NA'){
        ?>
        <tr>
        <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">10<sup>th</sup> (SSC)</font></td>
        </tr>
        <tr>
            <td>School</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['ssc_school'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['ssc_board'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>State</td>
            <td><input type="text" name="ssc_state" value="<?php echo $row['ssc_state'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><input type="text" name="yrpass" value="<?php echo $row['ssc_yop'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><input type="text" name="ssc_distance" value="<?php echo $row['ssc_distance'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td colspan="2">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text" name="ssc_board_total" value="<?php if($row['ssc_board_total']!=0) echo round(($row['ssc_board_secure']/$row['ssc_board_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td colspan="2">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text" name="ssc_total" value="<?php if($row['ssc_total']!=0) echo round(($row['ssc_secure']/$row['ssc_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <?php
        }
        ?>
        <?php
        if($row['hsc_board']!='NA'){
        ?>
        <tr>
        <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">12<sup>th</sup> (HSC)</font></td>
        </tr>
        <tr>
            <td>School/College</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['hsc_school'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['hsc_board'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>State</td>
            <td><input type="text" name="ssc_state" value="<?php echo $row['hsc_state'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><input type="text" name="year_join" value="<?php echo $row['hsc_yoj'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><input type="text" name="" value="<?php echo $row['hsc_yop'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><input type="text" name="" value="<?php echo $row['hsc_distance'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td colspan="2">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text"  value="<?php if($row['hsc_board_total']!=0) echo round(($row['hsc_board_secure']/$row['hsc_board_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td colspan="2">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text" name="ssc_total" value="<?php if($row['hsc_total']!=0) echo round(($row['hsc_secure']/$row['hsc_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <?php
        }
        ?>
        <?php
        if($row['dip_board']!='NA'){
        ?>
        <tr>
        <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Diploma</font></td>
        </tr>
        <tr>
            <td>School/College</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['dip_school'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['dip_board'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>State</td>
            <td><input type="text" name="ssc_state" value="<?php echo $row['dip_state'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><input type="text" name="year_join" value="<?php echo $row['dip_yoj'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><input type="text" name="" value="<?php echo $row['dip_yop'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><input type="text" name="" value="<?php echo $row['dip_distance'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td colspan="2">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text"  value="<?php if($row['dip_board_total']!=0) echo round(($row['dip_board_secure']/$row['dip_board_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td colspan="2">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text" name="ssc_total" value="<?php if($row['dip_board_total']!=0) echo round(($row['dip_board_secure']/$row['dip_board_total'])*100,2); else echo '0'; ?>" readonly="readOnly" /></td>
        </tr>
        <?php
        }
        ?>
        <?php
        if($row['gra_board']!='NA'){
        ?>
        <tr>
        <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Graduation</font></td>
        </tr>
        <tr>
            <td>Scool/College</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['gra_school'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><input type="text" name="ssc_board" value="<?php echo $row['gra_board'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>State</td>
            <td><input type="text" name="ssc_state" value="<?php echo $row['gra_state'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><input type="text" name="year_join" value="<?php echo $row['gra_yoj'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><input type="text" name="" value="<?php echo $row['gra_yop'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><input type="text" name="" value="<?php echo $row['gra_distance'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td>Stream:</td>
            <td><input type="text" name="gra_stream" value="<?php echo $row['gra_stream'] ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td>Honours:</td>
            <td><input type="text" name="gra_honours" value="<?php echo $row['gra_honors'] ?>" readonly="readonly"/></td>
        </tr>
        <tr>
            <td colspan="2">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text"  value="<?php if($row['gra_board_total']!=0) echo round(($row['gra_board_secure']/$row['gra_board_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <tr>
            <td colspan="2">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><input type="text" name="ssc_total" value="<?php if($row['gra_total']!=0) echo round(($row['gra_secure']/$row['gra_total'])*100,2); else echo '0'; ?>" readonly="readonly" /></td>
        </tr>
        <?php
        }
        ?>
        <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Current Course(B.Tech / MCA / M.Tech)</font></td>
        </tr>
        <tr>
            <td colspan="2">
                <table>
                    <tr>
                        <td>Semester</td>
                        <td>1<sup>st</sup></td>
                        <td>2<sup>nd</sup></td>
                        <td>3<sup>rd</sup></td>
                        <td>4<sup>th</sup></td>
                        <td>5<sup>th</sup></td>
                        <td>6<sup>th</sup></td>
                        <td>7<sup>th</sup></td>
                        <td>8<sup>th</sup></td>
                        <td>9<sup>th</sup></td>
                        <td>10<sup>th</sup></td>
                    </tr>
                    <tr>
                        <td>SGPA</td>
                        <td><input type="text" name="sgpa_1" value="<?php echo $row['sgpa_1'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_2" value="<?php echo $row['sgpa_2'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_3" value="<?php echo $row['sgpa_3'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_4" value="<?php echo $row['sgpa_4'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_5" value="<?php echo $row['sgpa_5'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_6" value="<?php echo $row['sgpa_6'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_7" value="<?php echo $row['sgpa_7'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_8" value="<?php echo $row['sgpa_8'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_9" value="<?php echo $row['sgpa_9'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="sgpa_10" value="<?php echo $row['sgpa_10'] ?>" size="5" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>CGPA</td>
                        <td><input type="text" name="cgpa_1" value="<?php echo $row['cgpa_1'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_2" value="<?php echo $row['cgpa_2'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_3" value="<?php echo $row['cgpa_3'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_4" value="<?php echo $row['cgpa_4'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_5" value="<?php echo $row['cgpa_5'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_6" value="<?php echo $row['cgpa_6'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_7" value="<?php echo $row['cgpa_7'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_8" value="<?php echo $row['cgpa_8'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_9" value="<?php echo $row['cgpa_9'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="cgpa_10" value="<?php echo $row['cgpa_10'] ?>" size="5" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>No. Of Backlogs</td>
                        <td><input type="text" name="backlog_1" value="<?php echo $row['back_1'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_2" value="<?php echo $row['back_2'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_3" value="<?php echo $row['back_3'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_4" value="<?php echo $row['back_4'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_5" value="<?php echo $row['back_5'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_6" value="<?php echo $row['back_6'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_7" value="<?php echo $row['back_7'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_8" value="<?php echo $row['back_8'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_9" value="<?php echo $row['back_9'] ?>" size="5" readonly="readonly" /></td>
                        <td><input type="text" name="backlog_10" value="<?php echo $row['back_10'] ?>" size="5" readonly="readonly" /></td>
                    </tr>      
                </table>
                </td>
         </tr>
         <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Year Gap</font></td>
        </tr>
        <tr>
            <td colspan="2">
                <table>
                     <tr>
                        <td> No. of year gaps between 10<sup>th</sup> and 12<sup>th</sup>:</td>
                        <td><input type="text" name="gap_10_12" value="<?php echo $row['gap_10_12'] ?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between 10<sup>th</sup> and Diploma:</td>
                        <td><input type="text" name="gap_10_dip" value="<?php echo $row['gap_10_dip'] ?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between 12<sup>th</sup> and Graduation:</td>
                        <td><input type="text" name="gap_12_gra" value="<?php echo $row['gap_12_gra'] ?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between Diploma and Graduation:</td>
                        <td><input type="text" name="gap_dip_gra" value="<?php echo $row['gap_dip_gra'] ?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between Graduation and PG(MCA & M.Tech):</td>
                        <td><input type="text" name="gap_gra_pg" value="<?php echo $row['gap_gra_pg'] ?>"  readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>Reason</td>
                        <td><textarea name="gap_reason" rows="4" cols="40" readonly="readonly"><?php echo $row['gap_reason']; ?></textarea></td>
                    </tr>
                </table>
              </td>
        </tr>
        </table>
        <table align="center" border="0" id="otherInfo" style="display: none;">
            <tr>
        <td colspan="2" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Other Detail</font></td>
        </tr>
        <tr>
           <td colspan="2" align="left" bgcolor="#237648" width="1000"><font color="#FFFFFF">Hobby</font></td>
        </tr>
        <tr>
            <td>Hobbies</td>
            <td><textarea name="hobby" rows="4" cols="40" readonly="readonly"><?php echo $row['hobby'];  ?></textarea></td>
        </tr>
        <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Project / Summer Training(Please mention all informal & formal Projects)</font></td>
        </tr>
        
                    <tr>
                        <td>Project Name</td>
                        <td><input type="text" name="pro1_name" value="<?php echo $row['pro_name']?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>Institution / Organization</td>
                        <td><input type="text" name="pro1_org" value="<?php echo $row['pro_org']?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>Duration of the Project</td>
                        <td><input type="text" name="pro1_dur" value="<?php echo $row['pro_duration']?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>Project Guide(s)</td>
                        <td><input type="text" name="pro1_guide" value="<?php echo $row['pro_guide']?>" readonly="readonly" /></td>
                    </tr>
                    <tr>
                        <td>Project Summary</td>
                        <td><textarea name="pro1_sum" rows="4" cols="40" readonly="readonly"><?php echo $row['pro_summary']?></textarea></td>
                    </tr>
                    
        <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Order of Preference</font></td>
        </tr>
        <tr>
            <td>You would give higher preference to</td>
            <td><input type="text" readonly="readonly" name="pref" value="<?php echo $row['preference']; ?>"></td>
        </tr>
       </table>
       <table align="center" width="1000" border="0" id="placementInfo"  style="display: none">
           <tr>
        <td colspan="2" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Placement Detail</font></td>
        </tr>
       </table>
 <?php
  
$content=ob_get_contents();
ob_clean();
include'template1.php';
?>