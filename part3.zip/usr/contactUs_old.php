<?php
include_once '../db.php';
session_start();
ob_start();
?>
<style>
    .record {
        background: #0F4988;
        color: #FFFFFF;
        font-size: 14px;
        -moz-box-shadow: 0 0 5px #888;
        -webkit-box-shadow: 0 0 5px#888;
        box-shadow: 0 0 5px #888;
        font-family: 'Open Sans', sans-serif;
    }
    table.zebra {
        font-size:12px;
        line-height: 16px;
        border: 1px solid #EEE;
        border-width: 1px 1px 0 0;
    }
    .zebra tr td, .zebra tr th {
        border: 1px solid #EEE;
        border-width: 0 0 1px 1px;
    }
    .zebra tr.even td, .zebra tr.even th, .zebra tr:nth-child(odd) td {
        background-color: #eee;
    }
    h1 {  text-align: center; margin:0;}
    h1 a:link,h1 a:visited {font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold;color:#fff; text-decoration:none; }
    table.placement {
        background:#DFE6F0;
        font-family: 'Open Sans', sans-serif;
        font-size:12px;
        margin-top: 20px;
    }
    table.placement ul {
        list-style:none;
        margin:0;
        padding:0;
    }
    table.placement a:link, table.placement a:visited {
        text-decoration: none;
        color:#476389;
    }
    table.placement a:hover {
        color:#514789
    }
    table.placement ul li {
        padding: 5px 0;
        border-bottom: 1px dotted #974F4F; 
    }
    table.placement .record {
        background:#0F4988;
        color:#FFFFFF;
        font-size:14px;
        -moz-box-shadow: 0 0 5px #888;
        -webkit-box-shadow: 0 0 5px#888;
        box-shadow: 0 0 5px #888;
    }
    table.placement .record2 {background:#208B0F;}
    table.placement .record2 h3 { margin-top:0; font-size:14px; line-height:20px;}
    table.placement .record2 h3 big { font-size:18px; line-height:25px;}
    table.placement .record2 div {text-align:left; }
    table.placement .record a:link, table.placement .record a:visited, table.placement .record a:hover {
        color:#FFFFFF;
        font-weight: bold;
        font-size: 16px;
        display:block;
        padding:8px;
        text-align:center;
    }
</style>
<?php
if (isset($_POST['btn_send']) && !empty($_POST['btn_send']) && $_POST['btn_send'] == 'SEND') {
    if ($_POST['security_code'] == $_SESSION['captcha']) {
        unset($_SESSION['captcha']);
        if (!empty($_POST['name']) && !empty($_POST['mobile']) && !empty($_POST['email']) && !empty($_POST['message'])) {
            $query = "insert into tbl_feedback values (NULL,'" . mysql_real_escape_string($_POST['name']) . "','" . mysql_real_escape_string($_POST['mobile']) . "','" . mysql_real_escape_string($_POST['email']) . "','" . mysql_real_escape_string($_POST['message']) . "', curdate())";
            //echo $query;
            $res = mysql_query($query);
            if ($res) {
                $to = mysql_real_escape_string($_POST['email']);
                $subject = 'Feedback / Query Recieved -- KIIT TNP';
                $body = "Dear " . $_POST['name'] . ", \r\n\r\nThanks a lot for contacting Training and Placement, KIIT-University. Your Query has been duly recieved by KIIT-TNP. We would get back to you soon with the updates on your feedback.\r\n\r\n Best Regards,\r\n Training and Placement Officer, \r\n KIIT-University ";
                $body.="\r\nYour message is:\r\n\r\n\r\n";
                $body.=$_POST['message'];
                $body.="\r\n\r\n\r\n\r\nNote: Please do not reply back to this mail. Replies to this mail goes to an unmonitored mail box. For any further communication, please feel free to drop a mail at placement@kiit.ac.in and training@kiit.ac.in";
                //$body=  wordwrap($body, 70, "\r\n");
                //$header = 'From: tnphelpdesk@kiittnp.in';
                $header = 'From: contact@kiittnp.in' . "\r\n" . 'Cc: tnphelpdesk@kiit.ac.in';
                mail($to, $subject, $body, $header);
                $_SESSION['errMsg'] = "<script>alert('Your feedback has been sent to the TNP Admin')</script>";
            } else
                $_SESSION['errMsg'] = "<script>alert('Some error has occurred. Please try again later')</script>";
        }else {
            $_SESSION['errMsg'] = "<script>alert('All the fields are compulsory tp be filled')</script>";
        }
    } else {
        $_SESSION['errMsg'] = "<script>alert('You have entered the wrong security code. Please try Again')</script>";
    }
}
unset($_SESSION['captcha']);
?>
<form method="post" action="contactUs.php">
    <table border="0">
        <tr>
            <td width="50%">
                <table border="0" width="100%" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
                    <tr>
                        <td colspan="2"><h1>Feedback / Query Form</h1></td>
                    </tr>
                    <tr class="light">
                        <td>Name</td>
                        <td><input type="text" name="name" value="" /></td>
                    </tr>
                    <tr class="dark">
                        <td>Mobile:</td>
                        <td><input type="text" name="mobile" value="" /></td>

                    </tr>
                    <tr class="light">
                        <td>E-mail</td>
                        <td><input type="text" name="email" value="" /></td>
                    </tr>
                    <tr class="dark">
                        <td>Message</td>
                        <td><textarea name="message" rows="10" cols="40"></textarea></td>  
                    </tr>
                    <tr>
                        <td>
                            <img src="CaptchaSecurityImages.php?width=100&height=40&characters=5" /><br>
                        </td>
                        <td>
                            <label for="security_code"><b>Security Code:</b> </label><br/>
                            <input id="security_code" name="security_code" type="text" /><br />
                        </td>
                    </tr>
                    <tr class="light">
                        <td><input type="submit" value="SEND" name="btn_send" /></td>
                        <td><input type="reset" value="RESET" name="btn_reset" /></td>
                    </tr>
                </table>
            </td>
            <!-- <td>
                <table border="0" width="100%" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
                    <tr>
                        <td>For any placement related queries, please contact the below mentioned address:</td>
                    </tr>
                    <tr>
                        <td>Email: placement@kiit.ac.in</td>
                    </tr>
                                    <tr>
                                            <td>&nbsp;</td>
                                    </tr>
                    <tr>
                        <td>For all the queries related to Certification School, please contact at the below mentioned address:</td>
                    </tr>
                    <tr>
                        <td>Email: nilay.das@kiit.ac.in, &nbsp;&nbsp;training@kiit.ac.in</td>
                    </tr>
                </table>
            </td> -->
            <td width="50%">
                <table width="95%" border="0" align="right" cellpadding="5" cellspacing="0" style="padding-right: 40px;">
                    <tbody>
                        <tr>                    
                            <td align="center" class="record">
                                <h3>
                                    <big><strong>Training &amp; Placement Help Desk</strong></big>
                                    <br>
                                    <big>Ph: 0674 - 2725 419 <br></big>Email: tnphelpdesk@kiit.ac.in
                                </h3>
                                <div style="text-align: left;">
                                    <p>Present and past students may contact the Help Desk for issues relating to Training &amp; Placement.</p>
                                    <p>The Help Desk In-charge will resolve the issues on the spot as far as possible. If the issue deserves detailed attention, he / she will intimate the same and request an E-mail to be sent.</p>
                                    <p>Students can send an E-mail to <span style="font-weight: bold;font-size: larger;">tnphelpdesk@kiit.ac.in</span> directly.<br> 
                                        Such queries shall be resolved within 48 hours. </p>
                                </div>
                            </td>
                        </tr>
                    </tbody>
                </table>
                <br>
            </td>
        </tr>
    </table>
</form>
<table border="0" align="center" cellpadding="0" cellspacing="0" class="placement">

<!--<tr>
<td width="29%" rowspan="11" align="center" valign="middle"><img src="d1.jpg" width="235" height="453" /></td>
</tr>-->
    <tbody>
        <tr>
            <td height="0" colspan="2" valign="top"><div align="center">
                    <h2>IMPORTANT CONTACT PERSONS</h2>
                </div></td>
            <td height="0" valign="top">&nbsp;</td>
        </tr>
        <tr>
            <td height="0" colspan="2" valign="top"><table width="100%" cellpadding="5" cellspacing="0" class="zebra">
                    <tbody><tr>
                            <td width="28%" valign="top"><strong>Dr. Saranjit Singh</strong>
                                <div></div>
                                <div></div></td>
                            <td width="38%" valign="top">Dean (T&amp;P)</td>
                            <td width="20%" valign="top">placement@kiit.ac.in<br>
                                ssingh@kiit.ac.in</td>
                            <td width="14%" valign="top">9437020233</td>
                        </tr>
                        <tr>
                            <td valign="top"><strong>Prof. Kumar Mohanty</strong></td>
                            <td valign="top">Dean, Career Advisory &amp; Augmentation Services (CAAS)</td>
                            <td valign="top">m.kumar@kiit.ac.in</td>
                            <td valign="top">9937220236</td>
                        </tr>
                        <tr>
                            <td valign="top"><strong>Mr Venkat Sastry </strong></td>
                            <td valign="top">Head - Corporate Relations</td>
                            <td valign="top">venkats@kiit.ac.in</td>
                            <td valign="top">7200478002&nbsp;</td>
                        </tr>
                        <tr>
                            <td valign="top"><strong>Mr. Debraj Mitra</strong></td>
                            <td valign="top">Placement Officer </td>
                            <td valign="top">kiitcr.dm@kiit.ac.in</td>
                            <td valign="top">07894427740</td>
                        </tr>
                        <tr>
                            <td valign="top"><strong>Ms. Krithika Kaul</strong></td>
                            <td valign="top">Mumbai</td>
                            <td valign="top">kiitcr.kk@kiit.ac.in</td>
                            <td valign="top">9004693905</td>
                        </tr>
                        <tr>
                            <td valign="top"><strong>Mr. Navendu Kar</strong></td>
                            <td valign="top">Orissa/West Bengal</td>
                            <td valign="top">kiitcr.nk@kiit.ac.in</td>
                            <td valign="top">9238314802</td>
                        </tr>                        
                        <tr>
                            <td valign="top"><strong>Mr. Lenka Bikram</strong></td>
                            <td valign="top">North&nbsp;</td>
                            <td valign="top">l.bikram@kiit.ac.in&nbsp;</td>
                            <td valign="top">9937937595&nbsp;</td>
                        </tr>
                        <tr>
                            <td valign="top"><strong>Mr. R Siva Prasad</strong></td>
                            <td valign="top">South&nbsp;</td>
                            <td valign="top">kiitcr.sp@kiit.ac.in</td>
                            <td valign="top">9841474312&nbsp;</td>
                        </tr>
                    </tbody>
                </table>                    
            </td>
            <td height="0" valign="top">&nbsp;</td>
        </tr>
        <tr>
            <td height="0" colspan="2" valign="top">&nbsp;</td>
            <td height="0" valign="top">&nbsp;</td>
        </tr>        
    </tbody></table>
<?php
        $pageContent = ob_get_contents();
        $pageType = "Contact";
                ob_end_clean();
        include_once 'template2.php';
                if (isset($_SESSION['errMsg']) &&!empty($_SESSION['errMsg'])) {
        echo $_SESSION['errMsg'];
    unset($_SESSION['errMsg']);
}
?>