<?php
include_once 'protectedStudent.php';
include'../db.php';
ob_start();
$username=$_SESSION['userName'];
$sqlstd="select name,roll_no,stream,branch,mobile,alt_email from tbl_student where email='$username'";
$resstd=mysql_query($sqlstd);
$row=mysql_fetch_array($resstd);
 if(isset($_POST['btnsave']) && !empty($_POST['btnsave']) && $_POST['btnsave'] == 'Save')
{	
  $train_name=mysql_real_escape_string($_POST['tname']);
  $org_name=mysql_real_escape_string($_POST['txtorgname']);
  $contact_name=mysql_real_escape_string($_POST['txtname']);
  $contact_desig=mysql_real_escape_string($_POST['txtdesig']);
  $org_address=mysql_real_escape_string($_POST['txtaddress']);
  $ref_name=mysql_real_escape_string($_POST['txtref']);
  $ref_contact=mysql_real_escape_string($_POST['txtmob']);
  $ref_email=mysql_real_escape_string($_POST['txtemail']);
  $from_date=mysql_real_escape_string($_POST['start_date']);
  $to_date=mysql_real_escape_string($_POST['end_date']);
  $stu_sem=mysql_real_escape_string($_POST['stusem']);
  $queryNocCount="select count(*) as total from tbl_training_noc where student_id=$_SESSION[userId] and stu_sem='$stu_sem'";
  $resNocCount=  mysql_query($queryNocCount);
  $nocCount=  mysql_fetch_array($resNocCount);
  if($nocCount['total']<4){
  $sql="insert into tbl_training_noc(train_name,indus_name,contact_name,contact_desig,indus_addr,ref_name,ref_mobile,ref_email,start_date,end_date,
        student_id,stu_sem,status) 
        values
        ('$train_name','$org_name','$contact_name','$contact_desig','$org_address','$ref_name','$ref_contact','$ref_email','$from_date','$to_date',
         $_SESSION[userId],'$stu_sem','Pending')";
  $res=mysql_query("$sql");
  //echo "data saved..";
  if($res)
	   {
	  $_SESSION['errMsg']="<script>alert('Data Saved Successfully !!!')</script>";
	  	
	   }
   else {
          $_SESSION['errMsg']="<script>alert('Some problem with the database has occurred. Please try again !!!')</script>";    
        }
  }else{
      $_SESSION['errMsg']="<script>alert('You have already reached the limit for this semester. Please contact TNP Cell for further information')</script>";    
  }
        
}
//-----------------
?>
<script type="text/javascript">
    function validNoc(c){
        if(c.txtorgname.value=='') { 
            alert('Organization Field is a compulsory Field');
            return false;
            }else{
            return true;
            }
    }
</script>

<form method="post" action="trainApplStu.php" name="trainoc" onsubmit="return validNoc(this) " >

<table align="center" bgcolor="#E2E2E2" style="border-style:ridge" width="800">
<tr>
<td colspan="4" align="center"><font><b><h2>Industrial Training Application Form</h2></b></font></td>
</tr>
<tr>
    <td colspan="2">Training Name:</td>
    <td colspan="2"><input type="radio" name="tname" value="Winter Training" checked="checked"/>Winter Training <br/>
                           <input type="radio" name="tname" value="Summer Training " />Summer Training</td>
</tr>
<tr bgcolor="#FFFFFF">
<td colspan="4" align="center"><font size="+1"><b>Organisation Details</b></font></td>
</tr>
<tr>
<td colspan="2">Name of the Industry/Organisation Name:</td>
<td colspan="2"><input type="text" name="txtorgname" id="txtorgname" style="width:200px" /></td>
</tr>
<tr>
<td colspan="2">Name of the concerned Person:<br/>(To whom Letter shall be issued)</td>
<td colspan="2"><input type="text" name="txtname" style="width:200px" /></td>
</tr>
<tr>
<td colspan="2">Designation of the concerned Person:<br/>(To whom Letter shall be issued)</td>
<td colspan="2"><input type="text" name="txtdesig" style="width:200px" /></td>
</tr>
<tr>
<td colspan="2">Industry/Organisation Address:</td>
<td colspan="2"><textarea name="txtaddress" rows="3" cols="18"></textarea></td>
</tr>
<tr>
<td colspan="2">Industry/Organisation Ref. Person Name:</td>
<td colspan="2"><input type="text" name="txtref" style="width:200px" /></td>
</tr>
<tr>
<td>Ref. person Contact No:</td>
<td><input type="text" name="txtmob" /></td>
<td align="right">Email Id:</td>
<td><input type="text" name="txtemail" /></td>
</tr>
<tr>
<td>Training Period:</td>
<td style="text-align: center" align="center"><script type="text/javascript">DateInput('start_date', true, 'YYYY-MM-DD')</script></td>
<td>to</td>
<td><script type="text/javascript">DateInput('end_date', true, 'YYYY-MM-DD')</script></td>
</tr>
<tr bgcolor="#FFFFFF">
<td colspan="4" align="center"><font size="+1"><b>Student Details</b></font></td>
</tr>
<tr>
<td colspan="2">Name:</td>
<td colspan="2"><input type="text" name="stuname" value="<?php echo $row['name']?>" readonly="readonly" size="50"/></td>
</tr>
<tr>
<td colspan="2">College Roll No:</td>
<td colspan="2"><input type="text" name="sturoll" value="<?php echo $row['roll_no']?>" readonly="readonly" /></td>
</tr>
<tr>
<td colspan="2">Stream:</td>
<td colspan="2"><input type="text" name="stustream"  value="<?php echo $row['stream']?>" readonly="readonly"  size="50"/></td>
</tr>
<tr>
<td colspan="2">Branch:</td>
<td colspan="2"><input type="text" name="stubranch"  value="<?php echo $row['branch']?>" readonly="readonly" size="50" /></td>
</tr>
<tr>
<td colspan="2">Select Semester:</td>
<td colspan="2"><select name="stusem">
     <option selected="selected">1st Semester</option>
     <option>2nd Semester</option>
     <option>3rd Semester</option>
     <option>4th Semester</option>
     <option>5th Semester</option>
     <option>6th Semester</option>
     <option>7th Semester</option>
     <option>8th Semester</option>
</select></td>
</tr>
<tr>
<td colspan="2">Contact No:</td>
<td colspan="2"><input type="text" name="stucon"  value="<?php echo $row['mobile']?>" readonly="readonly" /></td>
</tr>
<tr>
<td colspan="2">Email Id:</td>
<td colspan="2"><input type="text" name="stuemail"  value="<?php echo $row['alt_email']?>" readonly="readonly" size="50" /></td>
</tr>
<tr>
<td colspan="4" align="center"><input type="submit" name="btnsave" value="Save" />
                               <input type="reset" name="btnreset" value="NEW" /></td>
</tr>
</table>
</form>
<?php 
$content=ob_get_contents();
ob_clean();
include_once 'template1.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>