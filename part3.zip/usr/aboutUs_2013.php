<?php
include_once '../db.php';
$sql = "select * from tbl_homepage order by home_id desc limit 1";
$res = mysql_query($sql);
$data = mysql_fetch_array($res);
ob_start();
?>
<style type="text/css">
    @media print { body { display:none }}
    #content_holder p{ font-family:"Arial Narrow",Arial, Helvetica, sans-serif; line-height:24px; margin-top:0; margin-bottom: 24px; color:#444444;}
    h1 { font-family:Georgia, "Times New Roman", Times, serif; }
    .highlight {
        padding: 0 10px 10px;
        margin: 0 0 24px;
    }
    .highlight h5 { color:#CC0033; font-size:18px; margin:0;}
    .highlight table { border: 2px solid #FFA610;}
    .highlight table th { background-color: #FFA610; }
    .highlight table tr:nth-child(2n) td { background-color:#FFE9C3;}
    .highlight p {margin-bottom:0 !important; clear:both; font-size:14px;}
    .leftfloat { float: left; padding: 0 10px 0 0; text-align:center; margin-bottom:16px;}
    .rightfloat { float:right; padding: 0 0 0 10px; text-align:center; margin-bottom:16px;  }
    a:link img { outline:none; border:0;}
    .leftfloat a:link, .rightfloat a:link { text-decoration:none; line-height: 15px;}
    .leftfloat p, .rightfloat p { margin-bottom: 0 !important;}

    .small_red {
        font-size: 11px;
        font-weight: normal;
        color: #990000;

    }
    .center_text {text-align:center}
    .clear_both { clear:both}
    h1 { font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold; text-align: center; color:#fff; margin:0;}
</style>
<table width="100%" cellspacing="10" style="font-family: trebuchet MS; text-align: justify;line-height: 1.5;">
    <!-- <tr>
        <td><h1>About Training and Placement Cell</h1></td>
    </tr>    
    <tr>
        <td><?php echo $data['content']; ?></td>
    </tr>
    -->
    <tr id="placement2013Heading" style="text-align: center;background-color: #C30000;color: white;font-size: 25px;font-weight: bold;">
        <td>KIIT Yet Again Achieves Record Placement in All Streams  in 2013</td>
    </tr>
    <tr id="placement2013">
        <td width="73%" valign="top"><div id="content_holder">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td width="66%" rowspan="2" valign="top"><p><strong>KIIT University has been achieving record cent percent campus placements since 2001, when the first batch of engineering students graduated. The spell continues for 2013 graduating batch despite the tough market condition with respect to recruitment of freshers. Though unfavorable market condition led to poor placements in some of the most reputed institutions of the country, KIIT University achieved 89% placement averaging across all courses of study.</strong></p>
                                <p><strong>Out of 1,848 students eligible and interested for campus placements in six streams of KIIT University - Schools of Engineering, School of Computer Application, School of Biotechnology, School of Management, School of Rural Management, and School of Law and  - 1,651 students bagged job offers. </strong>Many students - 57 from Schools of Engineering - were pampered with two or even three job offers. <strong>These jobs were offered by 174 companies that participated in the campus placement programme for 2013 passing out batch students.</strong></p>
                                <p>
                                    <strong>Schools of Engineering and School of Computer Application, which have the highest number of students among all schools of KIIT University, recorded 90% placement. More than 65 companies – core as well as IT - visited these two School for placements,
                                    </strong> since the campus was opened for Shapoorji &amp; Pallonji in the month of July 2012. Top corporate houses and multinational companies participated, including Microsoft, Intel, SAP, Tata Steel, Tata Power, MuSigma, Aricent, TCS, Accenture, CapGemini, SISL, TIL, Genpact, Bergen Solar Power &amp; Energy and Windworld Energy (Enercon). <strong>For the sixth year in a row, TCS had  the distinction of being the top recruiter at Schools of Engineering. The highest salary package in Schools of Engineering was Rs. 16.25 lacs p.a. offered by Microsoft and the average salary package was Rs. 3.15 lacs p.a. Visits by many more companies are in the pipeline.</strong></p>
                                <p>
                                    <strong>School of Management had more than 45 corporate houses visiting for the campus placement, in which about 90% of the students got job offers. The highest salary package was Rs. 16.13 lacs p.a. (offered by Metafrique), while the average was Rs. 3.90 lacs p.a.</strong>
                                </p>
                                <p><strong>School of Rural Management recorded 100% placement with all 50 students of 2013 passing out batch placed in 20 organisations - both from development and corporate sectors.</strong> Prominent development sector organizations which visited KSRM for placement include Gramin Vikas Trust (GVT), Bihar Rural Livelihoods Promotion Society (BRLPS) and Access Livelihood Consulting. Students also joined corporate sector organizations such as HDFC Bank, Development Credit Bank (DCB), NCML and GCMMF. <strong>For the first time, KSRM students got placement in an overseas company Sagrocod India Private Ltd, a part of Tanmondial Pte Ltd, Singapore. Compared to previous year, there was a sharp increase in compensation package - the highest salary offered being Rs. 9.2 lacs.</strong></p>
                                <p>As many as 23 students from School of Biotechnology got selected for reputed national and international universities and research organizations. <strong>Taking together 42 students who preferred to join industries, School of Biotechnology has recorded 93% placement for its 2013 passing out batch.</strong> Total 19 companies visited KSBT for campus placement including B. Braun, Dabur, Nestle, Cadila, Glenmark, RPG Life Sciences, SRL, Bayer Pharma, Nuzivedu Seeds Ltd and St. Martha Hospitals. </p>
                                <p><strong>Total 20 recruiters visited School of Law and offered jobs to 74 BA.LL.B, BBA.LL.B and BSc.LL.B graduates. </strong>The recruiters include legal firms like Quislex, Zenith Lex and S. Jalan &amp; Co. as well as corporate like Bajaj Allianz, Kotak Mahindra and ICICI Lombard. <strong>Taking into account another four students who were academically placed, the School has so far recorded 73% placement.</strong> With more visits by recruiters scheduled in coming weeks, School of Law is all set to achieve cent percent placement second time in a row. It had achieved this remarkable feat for its very first batch students who passed out last year. </p>
                                <p>Excellent placement for the current batch students once again proves that KIIT is one of the most favored talent hunting ground for the corporate world. This is because of rigorous training of students, which helps develop strong foundation for core academic competencies along with high quality IT skills. Students get wide professional exposure due to a vibrant schedule of academic conferences and seminars which are attended by top academicians, scientists and industry leaders. Excellent performance of past batch students also motivates companies for repeat visit.</p></td>
                            <td valign="top"><div style="margin-left:5px" class="highlight">
                                    <h5>Campus Placement 2013:<br>
                                        Performance Across Schools </h5>
                                    <table width="100%" border="0" cellpadding="5" cellspacing="0">
                                        <tbody><tr>
                                                <th width="30%" align="left"><p>School</p></th>
                                        <th width="22%" align="center"><p>Students</p></th>
                                        <th width="23%" align="center"><p>Placed </p></th>
                                        <th width="25%" align="center"><p>Placed %</p></th>
                                        </tr>
                                        <tr>
                                            <td><p>SOE &amp; SCA</p></td>
                                            <td><p>1406</p></td>
                                            <td><p>1264</p></td>
                                            <td><p>89.90</p></td>
                                        </tr>
                                        <tr>
                                            <td><p>SRM</p></td>
                                            <td><p>50</p></td>
                                            <td><p>50</p></td>
                                            <td><p>100.00</p></td>
                                        </tr>
                                        <tr>
                                            <td><p>SBT</p></td>
                                            <td><p>70</p></td>
                                            <td><p>65</p></td>
                                            <td><p>92.86</p></td>
                                        </tr>
                                        <tr>
                                            <td><p>SOM</p></td>
                                            <td><p>220</p></td>
                                            <td><p>198</p></td>
                                            <td><p>90.00</p></td>
                                        </tr>
                                        <tr>
                                            <td><p>SOL</p></td>
                                            <td><p>102</p></td>
                                            <td><p>74</p></td>
                                            <td><p>72.55</p></td>
                                        </tr>
                                        <tr>
                                            <th><p>Total</p></th>
                                        <th><p>1848</p></th>
                                        <th><p>1651</p></th>
                                        <th><p>89.34</p></th>
                                        </tr>
                                        <tr>
                                            <td colspan="4"><p style="text-align:left; font-size:13px"><strong>Abbreviation: SOE </strong>- Schools of  Engineering, <strong>SCA -</strong> School of Computer Application, <strong>SRM</strong> - School of Rural Management, <strong>SBT</strong> - School of Biotechnology, <strong>SOM</strong> - School of Management, <strong>SOL - </strong> School of Law.</p></td>
                                        </tr>
                                        </tbody></table>
                                </div></td>
                        </tr>
                        <tr>
                            <td width="34%" valign="top"><div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013-2/full/1.jpg" rel="slides-gallery"><img src="images/plac_assets/2013-2/1.jpg" width="320" height="268"><br>
                                            <span class="small_red" style="text-align:center"> Placement - 2013: No. of Companies in Different Schools</span></a></p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013-2/full/2.jpg" rel="slides-gallery"><img src="images/plac_assets/2013-2/2.jpg" width="320" height="230"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                                Placement 2013: Top 5 Companies by No. of Offers</span></a><br>
                                    </p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013-2/full/3.jpg" rel="slides-gallery"><img src="images/plac_assets/2013-2/3.jpg" width="320" height="271"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                                Campus Placement 2013: Top 10 Companies by CTC (in Rs. Lakh P.A.)</span></a><br>
                                    </p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013-2/full/4.jpg" rel="slides-gallery"><img src="images/plac_assets/2013-2/4.jpg" width="320" height="245"><br>
                                            <span class="small_red" style="text-align:center">
                                                Campus Placement 2013: School of Management</span></a><br>
                                    </p>
                                </div></td>
                        </tr>
                        <tr>
                            <td colspan="2" valign="top"><table border="0" align="center" cellpadding="0" cellspacing="0">
                                    <tbody><tr>
                                            <td><div class="leftfloat">
                                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013-2/full/5.jpg" rel="slides-gallery"><img src="images/plac_assets/2013-2/5.jpg" width="320" height="194"><br>
                                                            <span class="small_red" style="text-align:center"> KIIT School of Rural Management<br>
                                                                % od Students joining Development Sector &amp; Corporate Sector <br>
                                                                (Placement 2013)</span></a><br>
                                                    </p>
                                                </div></td>
                                            <td><div class="rightfloat">
                                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013-2/full/6.jpg" rel="slides-gallery"><img src="images/plac_assets/2013-2/6.jpg" width="320" height="229"><br>
                                                            <span class="small_red" style="text-align:center"> KIIT School of Biotechnology<br>
                                                                Placement 2013 Corporate Placement &amp; Academic Placement<br>
                                                                (Total No. of Students Placed = 65)</span></a><br>
                                                    </p>
                                                </div></td>
                                        </tr>
                                    </tbody></table></td>
                        </tr>
                    </tbody></table>
                <h2>Academic Placement - 2013</h2>
                <p><strong>KIIT University uniquely places equal emphasis on academic placement, meticulously grooming interested students for higher studies and actively supporting their efforts to secure admission in reputed institutions. Whether it is success in the prestigious Indian Institute of Management (IIM) or offer from top foreign universities, students of 2013 batch have performed exceedingly well.</strong></p>
                <p><strong>Dushyant Panda, Govinda, Mohit Dayal and Somaditya Roy are notable among scores of B.Tech students of 2013 passing out batch who have bagged call letters from IIMs,</strong> admissions to which are done through Common Admission Test (CAT), one of the most competitive entrance examinations of the country. While Dushyant was pampered with choice with admission offers from as many as 7 IIMs, Govinda received call letters from 6 IIMs. Mohit and Somaditya managed admission offers from 5 IIMs each.</p>
                <p>Similarly, <strong>Saurav Singh Thakur (B.Tech) secured 4th position in the prestigious Graduate Aptitude Test in Engineering (GATE).</strong> While 250 students from KIIT University were successful in GATE – 2013, they also achieved the commendable feat of bagging three ranks in top 100. The other two high rank holders are Prikshit Prasad (Rank – 21) and Bhwan Singh (Rank – 23). </p>
                <p><strong>With many others securing admission in reputed foreign universities, more than 300 students of Schools of Engineering have been academically placed. Some of the prominent foreign universities in which they have been selected are University College, Dublin, Ireland; San Jose State University, California, USA; University of South California, USA and University of Pennsylvania, USA.</strong></p>
                <p><strong>Continuing with its strong track record in academic placement, School of Biotechnology has been able to place 23 students in reputed national and international universities and research organizations. Seven students have been selected to for Ph.D. programme in reputed European and South Korean universities.</strong> Seven others will be joining national research institutions having cleared CSIR, DBT fellowship programs. Another nine students have been offered research positions at ZSI, JNCASR, IARI, IGIB, KIIT University and NIPGR. </p>
                <p><strong>Six students of School of Law preferred to opt for higher studies securing admission into leading Indian and foreign universities, including University of London, U.K., Oxford University, U.K. and Cambridge University, U. K. </strong></p>
                <h2>Success Stories</h2>
                <p>                <strong>Sarbajit Paul</strong> (B.Tech - Electrical) is among many students of Schools of Engineering who have won scholarship for higher education in a foreign university. He has been selected by the Korean Government Scholarship Program (KGSP), which is designed to provide higher education opportunities for international students in South Korea. The award, instituted and managed by the National Institute for International Education (NIIED), a division of the Ministry of Education , South Korea, is very competitive. This year students from India were kept in a category which was shared by 11 other countries - Brazil, Cambodia, Ethiopia, Japan, Kazakhstan, Kyrgyzstan, Myanmar, Russia, The United States, Turkey and Uzbekistan.</p>
                <p><strong>Farakh Abbas</strong> (B.Tech – Electronics) was one among 100 from the country to receive the Young India Fellowship, a programme launched by the International Federation for Research and Education (IFRE) in collaboration with the University of Pennsylvania's School of Engineering and Applied Sciences. There were 15,000 applications for this highly competitive fellowship. The YIF brings together 100 emerging leaders from around India in a one-year residential post-graduate programme. The fellows are launched on their leadership journey by opening their mind to a rich and diverse set of subjects and perspectives, delivered by some of the finest teachers of the generation from around the world.<br>
                </p>
            </div>
        </td>
    </tr>
    <tr id="placementLink2013">
        <td valign="top">
            <h4>&lt;&lt; PREVIOUS YEAR: <a href="#placement2012Heading" onclick="displayContent('placement2012');">RECORD  PLACEMENT IN ALL SCHOOLS OF KIIT UNIVERSITY IN 2012</a></h4>
        </td>
    </tr>
    <tr id="placement2012Heading" style="text-align: center;display: none;background-color: #C30000;color: white;font-size: 25px;font-weight: bold;">        
        <td>RECORD PLACEMENT IN ALL SCHOOLS OF KIIT UNIVERSITY IN 2012</td>
    </tr>
    <tr style="display:none;" id="placement2012">
        <td width="73%" valign="top" bgcolor="#F7F7F7" style="background-color:#F7F7F7;">
            <div id="content_holder">
                <table width="100%" border="0" cellspacing="0" cellpadding="0">
                    <tbody>
                        <tr>
                            <td width="66%" rowspan="2" valign="top"><p><strong>It is raining jobs at KIIT University campus with 1,920 offers in campus placement for 1,625 eligible students of 2012 passing out batch of various streams. With job offers outstripping eligible students in almost all streams, the University has yet again achieved a record placement. </strong>All students of KIIT School of Biotechnology and KIIT School of Rural Management were placed, while <strong>KIIT School of Law created history by achieving cent percent placement for its very first passing out batch.</strong> Total 96% students of Schools of Engineering and School of Computer Application were placed. Similarly, all the students of KIIT School of Management were offered jobs by reputed companies. </p>
                                <p><strong>As many as 380 students bagged multiple job offers. These job offers were made by 185 companies</strong> which visited six schools of KIIT University – Schools of Engineering, School of Computer Application, School of Biotechnology, School of Law, School of Management and School of Rural Management - for campus placement.</p>
                                <p><strong>In an encouraging trend, 159 students from these schools were academically placed, securing admission in leading institutions of higher education  abroad.</strong></p>
                                <p><strong>All 41 eligible and interested students of the very first passing out batch of KIIT School of Law were absorbed by 16 companies that visited the campus.</strong> Legal process outsourcing firms such as Quislex and OSC Global participated, so did law firms like Corporate Lexport and S. Basu &amp; Associates. Corporate houses like Tata Motors Finance and Damodar Valley Corporation also picked up students. Some students also joined Chambers of senior advocates, Mr. Ram Jetmalani, Mr. Fali. S. Nariman and Ms. Pinky Anand.</p>
                                <p>Ankita Bafna, was one among 22 extraordinary students from  the globe to be selected for European Master in Law &amp; Economics after  completing B.A. LL.B. Four other students of the school have secured admission  in illustrious institutions like University Law College, University of London;  Oxford University, U.K.; and Cambridge University, U.K.</p>
                                <p> Technology streams have been a traditional stronghold of  KIIT University. <strong>This year, 74 recruiters – including 43 core and 28 IT  companies - visited for 2012 passing out batch of B.Tech, M.Tech and MCA  students, generating 1428 job offers for 1219 eligible students.</strong> While 103  students secured admission in reputed institutions for higher studies abroad, a  whopping 352 students bagged multiple job offers. At the very beginning of  placement season for 2012 batch students, three top recruiters TCS, Accenture  and Wipro gave job offers to 1128 students. Campus placement of 708 KIIT  students by TCS in a single day is a record for highest placement conversion in  Eastern India. <strong>Besides, multinational companies like Deloitte US, Siemens,  SAP and Atkins picked up more than 100 graduates. Fortune 500 companies like  Accenture, Microsoft, Intel, Deloitte, SAP, etc visit only KIIT University in Odisha  for campus placement, which is a key indicator of strong institute-industry  linkage KIIT possesses.</strong> KIIT is also  favorite talent hunting ground for many multinational companies operating in  core sectors. </p>
                                <p><strong>Among all companies, Microsoft offered the highest pay  package of Rs. 16 lakh, followed by Intel India at Rs. 8.50 lakh and Tata Steel  at Rs. 8 lakh. </strong>Placement in KIIT School of Biotechnology has been equally  impressive for 2012 batch.<strong> It is leading among all schools of KIIT  University in academic placement with 42 out of 75 students joining reputed  national and international institutions for higher studies.</strong></p>
                                <p><strong>Most notable selections are Abhijeet Nayak in ETH, Zurich  (Switzerland), Dibya Bhol in EAWAG, Dubendorf (Switzerland), Ipshita Mukherjee  in University of Lyon (France) and Nikita Chandel in Texas A&amp;M University  (USA).</strong> Notably, two students have been selected to receive DST Inspire  Fellowship for five years to pursue their Ph.D. in national laboratories of  their choice. In terms of job offers, all the 33 eligible and interested  students of KIIT School of Biotechnology have already bagged jobs in leading  organizations having diverse interests like biotech R&amp;D, cancer diagnostic,  pharmaceutical, bio-analytical concept marketing, bioinformatics, etc.</p>
                                <p><strong>In KIIT School of Management, 208 out of 214 eligible  students are already placed in 61 companies that visited the campus. Six  students opted for higher studies. The highest salary offered was Rs. 9.00  lakh, while average salary was Rs. 4.25 lakh.</strong></p>
                                <div class="leftfloat">
                                    <p align="center" style="text-align:center; padding:8px 0;"><a href="images/plac_assets/2013/graph6.jpg"><img src="images/plac_assets/2013/graph6.jpg" width="320" height="211"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                                Top 10 Core Companies by No. Of Offers <br>
                                            </span></a></p>
                                </div>
                                <p><strong>Similarly, 20 recruiters broadly from Development and  Corporate Sectors visited KIIT School of Rural Management for campus placement,  resulting in 62 job offers for 59 students.</strong> Some of the prominent  recruiters are Reliance Foundation, Gramin Vikas Trust, Development  Alternatives, Minda NexGen Tech Limited and Adani Wilmar. <strong>The highest package  offered was 6.5 lakh, while the average was Rs. 4.1 lakh.</strong> Placement in  Kalinga Polytechnic, Diploma Engineering wing, and KIIT Industrial Training  Centre (KIIT-ITC) was also good.</p>
                                <div class="leftfloat">
                                    <p style="text-align:center; padding:8px 0;"><a href="images/plac_assets/2013/graph5.jpg"><img src="images/plac_assets/2013/graph5.jpg" width="320" height="221" border="0"><br></a><a href="images/plac_assets/2013/graph5.jpg"><span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application</span></a><br>
                                        <a href="images/plac_assets/2013/graph6.jpg"><span class="small_red" style="text-align:center">Top Five IT Companies by No. Of Offers </span></a>                        </p>
                                </div>
                                <p>KIIT University has been achieving record cent percent  placements since 2001, when the first batch of B.Tech graduates passed out.  This is because of rigorous training of students, which helps develop strong  foundation for core academic competencies along with high quality IT skills.  Students get wide professional exposure due to a vibrant schedule of academic  conferences and seminars which are attended by top academicians, scientists and  industry leaders. Excellent performance of past batch students also motivates  companies for repeat visit. <strong>Congratulating successful students, Dr. A.  Samanta, Founder, KIIT &amp; KISS said that excellent placement record of KIIT  University is due to high quality of teaching and students, and combined effort  of one and all, including the Training &amp; Placement Cell.</strong></p></td>
                            <td valign="top"><div style="margin-left:5px" class="highlight"><table border="0" cellspacing="0" cellpadding="0">
                                        <tbody><tr>
                                                <td width="657" colspan="2"><h2 class="title-top" style="font-weight:normal; margin-top:0">Placement 2013</h2>
                                                    <h2 style="font-weight:normal; margin-top:0"><strong>Microsoft </strong> Picks Up Two Students</h2>
                                                    <p> Two B.Tech students of 2013 passing out batch have been  selected by Microsoft in campus placement with a high pay package of Rs. 16  lakh per annum. Both students - Aashish Kumar and Abhinav Priyadarshi &nbsp;– are from Computer Science stream.</p></td>
                                            </tr>
                                            <tr>
                                                <td width="50%" align="center"><img src="images/plac_assets/2013/aashish.jpg" width="100" height="115"></td>
                                                <td width="50%" align="center"><img src="images/plac_assets/2013/abhinabh.jpg" width="100" height="113"></td>
                                            </tr>
                                            <tr>
                                                <td><p align="center" class="center_text">Aashish Kumar</p></td>
                                                <td><p align="center" class="center_text">Abhinav Priyadarshi</p></td>
                                            </tr>
                                        </tbody></table></div></td>
                        </tr>
                        <tr>
                            <td width="34%" valign="top"><div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013/graph7.jpg"><img src="images/plac_assets/2013/graph7.jpg" width="320" height="281"><br>
                                            <span class="small_red" style="text-align:center"> Placement - 2012: No. of Companies in Different Schools</span></a></p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013/graph8.jpg"><img src="images/plac_assets/2013/graph8.jpg" width="320" height="228"><br>
                                            <span class="small_red" style="text-align:center"> Placement - 2012: All Schools Taken Together</span></a></p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding-bottom:16px;"><a href="images/plac_assets/2013/graph1.jpg"><img src="images/plac_assets/2013/graph1.jpg" width="320" height="209"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                                Sector-wise Companies for Campus Placement - 2012</span></a></p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding:8px 0;"><a href="images/plac_assets/2013/graph2.jpg"><img src="images/plac_assets/2013/graph2.jpg" width="320" height="228"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                                IT &amp; Core Companies in Campus Placement - 2012</span></a></p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding:8px 0;"><a href="images/plac_assets/2013/graph3.jpg"><img src="images/plac_assets/2013/graph3.jpg" width="320" height="236"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                                Top 10 IT Companies by CTC (In Rs. Lakh, Per Annum)
                                                <br>
                                            </span></a></p>
                                </div>
                                <div class="rightfloat">
                                    <p align="center" style="text-align:center; padding:8px 0;"><a href="images/plac_assets/2013/graph4.jpg"><img src="images/plac_assets/2013/graph4.jpg" width="320" height="231"><br>
                                            <span class="small_red" style="text-align:center">School of Engineering &amp; School of Computer Application<br>
                                            </span></a><a href="images/plac_assets/2013/graph3.jpg"><span class="small_red" style="text-align:center">Top 10 Core Companies by CTC (In Rs. Lakh, Per Annum) </span></a>
                                        <a href="images/plac_assets/2013/graph4.jpg"><span class="small_red" style="text-align:center"><br>
                                            </span>
                                        </a>
                                    </p>
                                </div>
                            </td>
                        </tr>
                    </tbody></table>
                <h2>Academic Placement - 2012</h2>
                <p>KIIT University uniquely places equal emphasis on academic  placement, meticulously grooming interested students for higher studies and  actively supporting their efforts to secure admission in reputed institutions  in India and abroad. From Schools of Engineering, 103 B.Tech students secured  admission in reputed foreign institutions. Some of the prominent foreign  universities where KIIT students joined are listed below</p>
                <table width="100%" border="0" cellspacing="0" cellpadding="5">
                    <tbody><tr>
                            <td width="50%" valign="top"><p><strong>SIX</strong> students each in<br>
                                    University  of Pennsylvania, USA<br>
                                    National University of Singapore, Singapore</p>
                                <p><strong>FIVE </strong>students  in<br>
                                    King's College London, UK</p>
                                <p><strong>FOUR</strong> students each in<br>
                                    LSAC  University, USA<br>
                                    New Jersey  Institute of Technology, USA<br>
                                    University of Texas at Austin, USA</p>
                                <p><strong>THREE</strong> students each in<br>
                                    Northeastern  University College of Computer and Information Science, USA<br>
                                    Oklahoma  State University, USA<br>
                                    Penn State  University, USA</p>
                                <p><strong>TWO</strong> students each in<br>
                                    Arizona  State University, USA<br>
                                    Columbia  University, USA<br>
                                    Edinburgh  Napier University, UK<br>
                                    McGill  University, Canada<br>
                                    Nanyang  University, Singapore<br>
                                    New York  University, USA<br>
                                    State  University of New York, USA<br>
                                    Stony Brook  University, USA<br>
                                    Technische  Universität Darmstadt, Germany<br>
                                    Texas A  &amp;M University, USA<br>
                                    University  of Florida, USA<br>
                                    University  of Oklahoma, USA<br>
                                    University  Of Oxford, UK<br>
                                    University  of Pittsburgh, USA<br>
                                    University  of Southern California, USA<br>
                                    University  of Toronto, Canada<br>
                                    University of Technology, Sydney, Australia</p></td>
                            <td valign="top"><p><strong>ONE</strong> student each in<br>
                                    Cambridge  University, UK<br>
                                    Cardiff  University, UK<br>
                                    Carnegie  Mellon University, USA<br>
                                    College of  Business, University of Cincinnati, USA<br>
                                    Cornell  University, USA<br>
                                    Delft  University of Technology, The Netherlands<br>
                                    EAWAG,  Dubendorf, Switzerland<br>
                                    Erasmus  University, The Netherlands<br>
                                    ETH, Zurich,  Switzerland<br>
                                    Florida  International University, USA<br>
                                    Georgia  Institute of Technology, USA<br>
                                    Graduate  College, USA<br>
                                    Graduate  Institute of International and<br>
                                    Development  Studies, Geneva<br>
                                    Imperial  College London, UK<br>
                                    Indiana  University Bloomington, USA<br>
                                    Iowa State  University, USA<br>
                                    Karlsruhe  Institute of Technology, Germany<br>
                                    Lakehead  University, Canada<br>
                                    Liverpool  John Moores University, Ireland<br>
                                    LSSC,  University, USA<br>
                                    MBA, UK<br>
                                    Michigan  State University, USA<br>
                                    Missouri  University of Science and Technology, USA<br>
                                    Munchen  University, USA<br>
                                    Northwestern  University, USA<br>
                                    Queen Mary,  University of London, UK<br>
                                    Queensland  University of Technology, Australia<br>
                                    RMIT  University, Australia<br>
                                    Rutgers, The  State University of New Jersey, USA<br>
                                    San Jose  State University, USA<br>
                                    William E.  Simon Graduate School of Business Administration,
                                    University  of Rochester, USA<br>
                                    Syracuse  University, USA<br>
                                    The Fletcher  School, Tufts University, USA<br>
                                    Trinity  College, Dublin, Ireland<br>
                                    University  of Adelaide, Australia<br>
                                    University  of Bergen, Norway<br>
                                    University  of California, Santa Barbara, USA<br>
                                    University  of Central Florida, USA<br>
                                    University  of Connecticut, USA<br>
                                    University  of Heidelberg, USA<br>
                                    University  of Illinois at Chicago, USA<br>
                                    University  of Lyon, France<br>
                                    University  of Melbourne, Australia<br>
                                    University  of Memphis, USA<br>
                                    University  of Missouri-Columbia, USA<br>
                                    University  of Ottawa, Canada<br>
                                    University  of Paderdorn, USA<br>
                                    University  of South Florida, USA<br>
                                    University  Of Strathclyde, UK<br>
                                    Virginia  Polytechnic Institute and State University, USA</p></td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </td>
    </tr>
    <tr id="placementLink2012" style="display:none">
        <td align="right" valign="top" bgcolor="#F7F7F7" style="background-color:#F7F7F7;">
            <h4>NEXT YEAR: <a href="#placement2013Heading" onclick="displayContent('placement2013');">KIIT Yet Again Achieves Record Placement in All Streams  in 2013 &gt;&gt;</a></h4>
        </td>
    </tr>
</table> 
<script>
    function displayContent(section) {
        if (section === "placement2013") {
            document.getElementById("placementLink2012").style.display = "none";
            document.getElementById("placement2012").style.display = "none";
            document.getElementById("placementLink2013").style.display = "block";
            document.getElementById("placement2013").style.display = "block";
            document.getElementById("placement2012Heading").style.display = "none";
            document.getElementById("placement2013Heading").style.display = "";
        }
        else {
            document.getElementById("placementLink2012").style.display = "block";
            document.getElementById("placement2012").style.display = "block";
            document.getElementById("placementLink2013").style.display = "none";
            document.getElementById("placement2013").style.display = "none";
            document.getElementById("placement2012Heading").style.display = "";
            document.getElementById("placement2013Heading").style.display = "none";
        }
    }
</script>
<?php
$pageContent = ob_get_contents();
$pageType = 'Home';
ob_end_clean();
include_once 'template2.php';
?>