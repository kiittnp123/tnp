<?php
session_start();
ob_start();
?>
<table class="table" style="font: 16px Arial,Verdana;">
    <caption><h3>Industry Engagement Cell (IEC) Members</h3> </caption>
    <thead>
    <tr>
    <th>School</th>
    <th>Name Of IEC Member</th>
    <th>Designation</th>
    <th>Contact No.</th>
    <th>E-Mail Id</th>
    </tr>
    </thead>
    <tr style="background:  #dcdcf0;">
        <td rowspan="2">Civil Engineering</td>
        <td>Prof. D.K.Bera</td>
        <td>Associate Dean (T&P)</td>
        <td>7894470698</td>
        <td><u>dberafce@kiit.ac.in</u></td>
    </tr>
    <tr style="background:  #dcdcf0;">
        <td>Prof. Nihar Ranjan Panda</td>
        <td>Faculty Associate (T&P)</td>
        <td>9178091991</td>
        <td><u>nihar.iitb@gmail.com </u></td>
    </tr>
    <tr style="background: White;">
        <td rowspan="2">Computer Engineering</td>
        <td>Prof. Prachet Bhuyan</td>
        <td>Associate Dean (T&P)</td>
        <td>7894427738</td>
        <td><u>pbhuyanfcs@kiit.ac.in</u></td>
    </tr>
    <tr style="background: White;">
        <td>Prof. Abhishek Ray</td>
        <td>Faculty Associate (T&P)</td>
        <td>7894427741</td>
        <td><u>arayfcs@kiit.ac.in</u></td>
    </tr>
    <tr style="background:  #dcdcf0;">
        <td rowspan="3">Electrical Engineering</td>
        <td>Prof Subrat Behera</td>
        <td>Associate Dean (T&P)</td>
        <td>9556271032</td>
        <td><u>subrat.sb@gmail.com</u></td>
    </tr>
    <tr style="background:  #dcdcf0;">
        <td>Prof T.R.Choudhuri</td>
        <td>Faculty Associate (T&P)</td>
        <td>9776432644</td>
        <td><u>trcfel@kiit.ac.in</u></td>
    </tr>
    <tr style="background:  #dcdcf0;">
        <td>Prof. Soubhagya Prusty</td>
        <td>Faculty Associate (T&P)</td>
        <td>9853561355</td>
        <td><u>Soubhagya503095@gmail.com</u></td>
    </tr>
    <tr style="background: White;">
        <td rowspan="5">Electronics Engineering</td>
        <td>Prof. Col. S. Pany </td>
        <td>Associate Dean (T&P)</td>
        <td>9937289194</td>
        <td><u>spanyfet@kiit.ac.in</u></td>
    </tr>
    <tr style="background: White;">
        <td>Prof. Rahul Yadav</td>
        <td>Faculty Associate (T&P)</td>
        <td>9778263836</td>
        <td><u>rahulyadav0409@gmail.com</u></td>
    </tr>
    <tr style="background: White;">
        <td>Prof . Arindam Basak </td>
        <td>Faculty Associate (T&P)</td>
        <td>9938557233</td>
        <td><u>arindambasak2007@gmail.com</u></td>
    </tr>
    <tr style="background: White;">
        <td>Prof. Tushar Singh</td>
        <td>Faculty Associate (T&P)</td>
        <td>8594967390</td>
        <td><u>tushar8990@gmail.com</u></td>
    </tr>
    <tr style="background: White;">
        <td>Prof. Selvin Furtado</td>
        <td>Faculty Associate (T&P)</td>
        <td>7064093910</td>
        <td><u>selvin.furtado@gmail.com</u></td>
    </tr>
    
    <tr style="background: #dcdcf0;">
        <td rowspan="2">Mechanical Engineering </td>
        <td>Pof. Isham Panigrahi</td>
        <td>Associate Dean (T&P)</td>
        <td>9437162857</td>
        <td><u>ipanigrahifme@kiit.ac.in </u></td>
    </tr>
    <tr style="background: #dcdcf0;">
        <td>Prof. Lalit Pothal </td>
        <td>Faculty Associate (T&P)</td>
        <td>9176611155</td>
        <td><u>lalit_pothal@yahoo.com</u></td>
    </tr>
    <tr style="background: White;">
    	<td>Computer Application </td>
        <td>Prof.Manas Mukul</td>
        <td>Faculty Associate (T&P)</td>
        <td>9124999460</td>
        <td><u>mmukulfca@kiit.ac.in</u></td>
    </tr>
</table>
<?php
$pageContent = ob_get_contents();
$pageType = 'IEC Members';
ob_end_clean();
include_once 'template2.php';
?>