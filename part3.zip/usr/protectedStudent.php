<?php
session_start();
if(!isset($_SESSION['userName']) || empty($_SESSION['userName']) || !isset($_SESSION['userType']) || empty($_SESSION['userType']) || ($_SESSION['userType']!='Student' && $_SESSION['userType']!='Faculty'))
{ 
    header("location:index.php");
}
?>

