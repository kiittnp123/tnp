<?php
session_start();
include_once '../db.php';
include_once '../inc/conf.php';
if (isset($_POST['btn_stu_login']) && !empty($_POST['btn_stu_login'])) {
    $uid = mysql_real_escape_string($_POST['user_name']);
    $password = mysql_real_escape_string($_POST['password']);
    $type = mysql_real_escape_string($_POST['user_type']);
    if ($type == "Student")
        $query = "select email,student_id from tbl_student where email='$uid' and password='$password'";
    else
        $query = "select email,faculty_name from tbl_faculty where email='$uid' and password='$password'";
    $res = mysql_query($query);
    if (mysql_num_rows($res) == 1) {
        $settingQuery = "select * from tbl_setting where type='registration' and status='Active'";
        $resSetting = mysql_query($settingQuery);
        $rowSetting = mysql_fetch_array($resSetting);
        $_SESSION['regdSetting'] = $rowSetting['value'];
        $data = mysql_fetch_array($res);
        $_SESSION['userName'] = $data[0];
        $_SESSION['userId'] = $data[1];
        $_SESSION['userType'] = $type;
    } else {
        $_SESSION['ErrMsg'] = "<script>alert('Wrong Userid and Password')</script>";
        header("location:index.php");
    }
}
ob_start();
include_once 'protectedStudent.php';
if ($_SESSION['userType'] != "Student")
    $sqlNotice = "SELECT * FROM tbl_notice WHERE curdate() between date_sub(start_date, interval 1 day) and end_date order by start_date desc";
else
    $sqlNotice = "SELECT * FROM tbl_notice WHERE curdate() between date_sub(start_date, interval 1 day) and end_date and status='Protected' order by start_date desc";
$res = mysql_query("$sqlNotice");
?>

<table width="100%" cellspacing="10" cellpadding="10" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
    <tr>
        <td><h1>Notices</h1></td>
    </tr>
    <?php
    $i = 0;
    while ($data = mysql_fetch_array($res)) {
        $i++;
        $published_date = strtotime($data['start_date']);
        $now = time();
        $time_diff = $now - $published_date;
        if (($time_diff / (60 * 60 * 24)) < 1)
            $new = "<img src='image/new.gif' width='30' height='15' />";
        else
            $new = "";
        ?>
        <tr>
            <td>
                <fieldset <?php if ($i % 2 == 0) echo 'style="background-color: #D7D7D7;"' ?>>
                    <h3> <?php echo $data['heading'].$new; ?></h3>
                    <p><b>Date: <?php echo $data['start_date']; ?></b><br /><br />
                        <?php echo $data['content'] ?><br />
                        <?php
                        if (!empty($data['notice_file']))
                            echo '<a href="' . $data['notice_file'] . '" target="_blank">Click here</a> to download the associated file';
                        ?>
                    </p>
                </fieldset>
            </td>
        </tr>
        <?php
    }
    ?>
</table>

<?php
$content = ob_get_contents();
ob_clean();
include'template1.php';
?>