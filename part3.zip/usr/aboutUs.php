<?php
ob_start();
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<!-- saved from url=(0042)http://www.kiit.ac.in/placement/index.html -->
<html xmlns="http://www.w3.org/1999/xhtml"><head><meta http-equiv="Content-Type" content="text/html; charset=ISO-8859-1">

<link rel="stylesheet" type="text/css" href="images/about/style.css">

<title>:: KIIT University :: Training And Placement Department</title>
<link href="images/about/css" rel="stylesheet" type="text/css">
<link rel="stylesheet" type="text/css" href="images/about/jquery.fancybox.css" media="screen">
<style type="text/css">
<!--
body {
	margin-top: 0px;
	margin-left: 0px;
	background-image: url(../imagge/bg.gif);
}
.times1 {	font-family: "Times New Roman", Times, serif;
	font-size: 18px;
	font-style: normal;
	line-height: normal;
	color: 00A651;
	text-decoration: none;
	text-align: justify;
}
.times1 {font-family: "Times New Roman", Times, serif;
	font-size: 18px;
	font-style: normal;
	line-height: normal;
	color: 00A651;
	text-decoration: none;
	text-align: justify;
}
.times11 {font-family: "Times New Roman", Times, serif;
	font-size: 18px;
	font-style: normal;
	line-height: normal;
	color: 00A651;
	text-decoration: none;
	text-align: justify;
}
table.zebra {
	font-size:12px;
	line-height: 16px;
	border: 1px solid #EEE;
	border-width: 1px 1px 0 0;
}
.zebra tr td, .zebra tr th {
	border: 1px solid #EEE;
	border-width: 0 0 1px 1px;
}
.zebra tr.even td, .zebra tr.even th, .zebra tr:nth-child(odd) td, .zebra tr th {
	background-color: #eee;
}
table.zebrax {
	font-size:12px;
	line-height: 16px;
	border: 1px solid #ccc;
}
.zebrax tr td, .zebrax tr th {
	border-bottom: 1px dotted #aaa;

}
.zebrax tr:nth-child(odd) td {
	background-color: #fafafa;
}
.zebrax tr th {
	background-color: #eee;
}
.font_set {font-family: 'Open Sans', sans-serif; }
table.mytab {
    -webkit-border-radius: 5px;
	-moz-border-radius: 5px;
	border-radius: 5px;
	color: #FFFFFF;
	font-weight: bold;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 14px;
}
table.mytab td {
	background-color:#F79646;
	padding:8px;
}
table.mytab th {
	background-color:#E36C0A;
	padding:8px;
	text-align:right;
}
h1 {  text-align: center; margin:0;}
h1 a:link,h1 a:visited {font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold;color:#fff; text-decoration:none; }
table.placement {
	background:#DFE6F0;
	font-family: 'Open Sans', sans-serif;
	font-size:12px;
}
table.placement ul {
	list-style:none;
	margin:0;
	padding:0;
}
table.placement a:link, table.placement a:visited {
	 text-decoration: none;
	 color:#476389;
}
table.placement a:hover {
	color:#514789
}
table.placement ul li {
	padding: 5px 0;
	border-bottom: 1px dotted #974F4F; 
}
table.placement .record {
	background:#0F4988;
	color:#FFFFFF;
	font-size:14px;
	-moz-box-shadow: 0 0 5px #888;
	-webkit-box-shadow: 0 0 5px#888;
	box-shadow: 0 0 5px #888;
}
table.placement .record2 {background:#208B0F;}
table.placement .record2 h3 { margin-top:0; font-size:14px; line-height:20px;}
table.placement .record2 h3 big { font-size:18px; line-height:25px;}
table.placement .record2 div {text-align:left; }
table.placement .record a:link, table.placement .record a:visited, table.placement .record a:hover {
	color:#FFFFFF;
	font-weight: bold;
	font-size: 16px;
	display:block;
	padding:8px;
	text-align:center;
}
#content_holder p{ font-family: 'Open Sans', sans-serif; line-height:24px; margin-top:0; margin-bottom: 24px; color:#444444;}
h1 { font-family:Georgia, "Times New Roman", Times, serif; }
.highlight {
padding: 0 10px 10px;
margin: 0 0 24px;
}
.highlight h5 { color:#CC0033; font-size:18px; margin:0;}
.highlight table { border: 2px solid #FFA610;}
.highlight table th { background-color: #FFA610; }
.highlight table tr:nth-child(2n) td { background-color:#FFE9C3;}
.highlight p {margin-bottom:0 !important; clear:both; font-size:14px;}
.leftfloat { float: left; padding: 0 10px 0 0; text-align:center; margin-bottom:16px;}
.rightfloat { float:right; padding: 0 0 0 10px; text-align:center; margin-bottom:16px;  }
a:link img { outline:none; border:0;}
.leftfloat a:link, .rightfloat a:link { text-decoration:none; line-height: 15px;}
.leftfloat p, .rightfloat p { margin-bottom: 0 !important;}

.small_red {
	font-size: 11px;
	font-weight: normal;
	color: #990000;
	
}
.center_text {text-align:center}
.clear_both { clear:both}
h1 { font-family:Arial, Helvetica, sans-serif; font-size:24px; font-weight:bold; text-align: center; color:#fff; margin:0;}
.style50 {color: #FFFFFF}
.style51 {font-size: 12px; text-decoration: none; font-family: Geneva, Arial, Helvetica, sans-serif;}
.bhagya {	color: #000000;
	font-weight: normal;
	font-family: Geneva, Arial, Helvetica, sans-serif;
	font-size: 12px;
	text-decoration: none;
	text-align: justify;
}
p {text-align:justify; font-size:14px;}
h3, h2 {font-family: 'Open Sans', sans-serif;}
h3 { border-bottom: 1px dashed #AAA;}
ul.font_set li { font-size:15px; line-height:24px;}
-->
</style>
<link href="images/about/1bhagyastyles.css" rel="stylesheet" type="text/css">
<style type="text/css"> 
@media print { body { display:none }}
</style></head>

<body onbeforeprint="document.body.style.display = &#39;none&#39;;" onafterprint="document.body.style.display = &#39;&#39;;">
<table width="1000" border="0" align="center" cellpadding="0" cellspacing="0">
  
  <tbody><tr>
    <td height="0" valign="top" bgcolor="0C3E74"></td>
  </tr>
  <!--<tr>
    <td height="0" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="10">
      <tbody><tr>
        <td height="0" valign="top" background="images/about/bl1.jpg"><table width="100%" border="0" cellspacing="0" cellpadding="0">
          <tbody><tr>
            <td><img src="images/about/top1.jpg" width="322" height="76"></td>
            <td><div align="right"><img src="images/about/top2.jpg" width="401" height="77"></div></td>
          </tr>
        </tbody></table></td>
      </tr>
    </tbody></table>      </td>
  </tr>-->
  
  <tr>
    <td height="0" valign="top"><table width="100%" border="0" cellspacing="0" cellpadding="0">
      
      <tbody><tr>
        <td height="0" colspan="2" valign="top"></td>
        </tr>
      
      <!--<tr>
        <td height="0" colspan="2" valign="top" background="images/about/blue.jpg"><table width="100%" border="0" cellpadding="0" cellspacing="0" background="images/about/blue.jpg">
          <tbody><tr>
            <td height="0" valign="top"><div id="menu-holder"><div class="nav">
    <ul id="menu" class="cmenu">
        <li class="nodiv"><a href="http://www.kiit.ac.in/index.html">Home</a></li>
        <li><span>About us</span>
          <ul>
            <li><a href="http://www.kiit.ac.in/aboutus/vismiss.html">Vision &amp; Mission</a></li>
            <li><a href="http://www.kiit.ac.in/aboutus/overview.html">Overview</a></li>
            <li><a href="http://www.kiit.ac.in/aboutus/nationalstand.html">National &amp; International Standing</a></li>
            <li><a href="http://www.kiit.ac.in/aboutus/executive_committee.html">Executive Committee-KIIT Society</a></li>
          </ul>
        </li>
        <li><a href="http://www.kiit.ac.in/courses/school.html">Schools</a>
            <ul>
                <li><a href="http://www.kiit.ac.in/courses/institutes.html">Institutes</a></li>
                <li><a href="http://www.kiit.ac.in/courses/courses.html">Courses</a></li>
            </ul>
        </li>
        <li><a href="http://www.kiit.ac.in/admission.html">Admission 2014</a></li>
        <li><a href="images/about/KIIT University    Kalinga Institute of Industrial Technology.htm">Training &amp; Placement</a>
          <ul>
            <li><a href="images/about/KIIT University    Kalinga Institute of Industrial Technology.htm">Placement</a></li>
            <li><a href="http://caaskiit.in/" target="_blank">Career Advisory &amp; Augmentation<br>
              Services (CAAS) </a></li>
            <li><a href="http://kiittnp.in/cs/" target="_blank">Certification School</a></li>
          </ul>
        </li>
        <li><a href="http://www.kiit.ac.in/faculty/default.html">Faculty</a></li>
        <li><a href="http://www.kiit.ac.in/campus.html">Facilities</a></li>
        <li><a href="http://www.kiit.ac.in/centrallibrary/index.html">Library</a></li>
        <li><a href="http://www.kiit.ac.in/intprogram/index.html">International Programme</a></li>
        <li><a href="http://www.kiit.ac.in/administration/ncontactus.htm">Contact us</a></li>
    </ul>
</div>
</div></td>
          </tr>
        </tbody></table></td>
        </tr>
      <tr>
        <td width="73%" height="0" valign="top" background="images/about/bl2.jpg">&nbsp;</td>
        <td width="27%" height="0" valign="top" background="images/about/bl2.jpg">&nbsp;</td>
      </tr>-->
      <tr>
        <td height="0" colspan="2" valign="top" bgcolor="#FFFFFF"><img src="images/about/PIXEL.jpg" width="7" height="7"></td>
      </tr>
      <tr>
        <td height="0" colspan="2" valign="top" bgcolor="#FFFFFF"><table width="100%" border="0" cellspacing="0" cellpadding="10">
          <tbody><tr>
            <td bgcolor="#C30000" style="background-color:#C30000;"><h1><strong><strong>Campus Placement 2014: KIIT  Registers Excellent Placement in All Schools</strong></strong></h1></td>
          </tr>
          <tr>
            <td><table id="content_holder" width="100%" border="0" cellpadding="0" cellspacing="0">
           		
           		<tbody><tr>
           		  <td width="34%" id="contt"><div style=" box-shadow: 5px 5px 0 #EEE; border: 1px solid #CCC; margin-bottom:20px; border-radius: 40px 0 40px 0; margin-right: 5px;">
                  <h3 style="border-bottom:0; padding-left:20px">Campus Placement 2014: Highlights </h3>
                  <ul class="font_set">
           		      <li><strong>90% of total 2164 registered & eligible students placed in six schools of KIIT University</strong></li>
           		      <li><strong>As many as 197 companies participated in campus placement programme in different schools</strong></li>
           		      <li><strong>Placement in different schools:  Schools of Engineering - 93%; School of Rural Management - 100%; School of  Biotechnology - 83%; School of Law - 68%; School of Management - 92%; and School  of Computer Application - 74%.&nbsp; </strong></li>
           		      <li><strong>Cent percent placement in KIIT  Polytechnic and KIIT Industrial Training Institute (KIIT-ITI)</strong></li>
           		      <li><strong>Highest salary of Rs. 23.04 lakh  p.a. was offered by Daelim, global engineering &amp; construction major, to a  B.Tech. (Civil) student.</strong></li>
           		      <li><strong>Average salary this season was Rs.  4.2 lakh p.a.</strong></li>
           		      <li><strong>Salary package offered this season  substantially better than previous years.</strong></li>
           		      <li><strong>Maximum number of 523 job offers by  TCS.</strong></li>
           		      <li><strong>More than 30 companies, including  Multinational Companies, visited KIIT University for the first time this season.</strong></li>
           		      <li><strong>Excellent academic placement.</strong></li>
         		      </ul></div>
           		    <div style="float:right; margin-left:20px"><table border="0" cellpadding="5" cellspacing="0" class="zebrax font_set">
           		      <tbody><tr>
           		        <th><strong>Sl.    No.</strong></th>
           		        <th><strong>School</strong></th>
           		        <th><strong>Registered    <br>                            
           		          &amp; Eligible <br>
           		          Students</strong></th>
           		        <th><strong>No.    of <br>
           		          Companies<br>
           		          Visited</strong></th>
           		        <th><strong>Placed</strong></th>
           		        <th><strong>Placed    %</strong></th>
           		        </tr>
           		      <tr>
           		        <td align="center">1</td>
           		        <td>Schools of Engineering</td>
           		        <td align="center">1637</td>
           		        <td align="center">83</td>
           		        <td align="center">1517</td>
           		        <td align="center"><strong>93</strong></td>
           		        </tr>
           		      <tr>
           		        <td align="center">2</td>
           		        <td>School of Computer Application </td>
           		        <td align="center">102</td>
           		        <td align="center">14</td>
           		        <td align="center">75</td>
           		        <td align="center"><strong>74</strong></td>
           		        </tr>
           		      <tr>
           		        <td align="center">3</td>
           		        <td>School of Rural Management</td>
           		        <td align="center">38</td>
           		        <td align="center">16</td>
           		        <td align="center">38</td>
           		        <td align="center"><strong>100</strong></td>
           		        </tr>
           		      <tr>
           		        <td align="center">4</td>
           		        <td>School of Biotechnology </td>
           		        <td align="center">52</td>
           		        <td align="center">13</td>
           		        <td align="center">43</td>
           		        <td align="center"><strong>83</strong></td>
           		        </tr>
           		      <tr>
           		        <td align="center">5</td>
           		        <td>School of Management</td>
           		        <td align="center">225</td>
           		        <td align="center">60</td>
           		        <td align="center">208</td>
           		        <td align="center"><strong>92</strong></td>
           		        </tr>
           		      <tr>
           		        <td align="center">6</td>
           		        <td>School of Law</td>
           		        <td align="center">110</td>
           		        <td align="center">11</td>
           		        <td align="center">75*</td>
           		        <td align="center"><strong>68</strong></td>
           		        </tr>
           		      <tr>
           		        <td>&nbsp;</td>
           		        <td><strong>Total</strong></td>
           		        <td align="center"><strong>2164</strong></td>
           		        <td align="center"><strong>197</strong></td>
           		        <td align="center"><strong>1956</strong></td>
           		        <td align="center"><strong>90</strong></td>
           		        </tr>
           		      </tbody></table>
           		      
           		      <small class="font_set"><strong>* </strong><em>Including 15 academically placed  students.<strong></strong></em></small>
           		      </div>
<!--  <p><strong>While KIIT University had also achieved cent percent  placement for its 2013 passing out students, remarkable thing this year is the  tremendous response from recruiters from the very start of the placement  season. About 90% of the total 2164 registered &amp; eligible students of 2014  passing out batch in various schools of KIIT University are already placed. As  many as 197 companies and organizations participated in the campus placement  process in six Schools � Schools of Engineering, School of Computer  Application, School of Rural Management, School of Biotechnology, School of  Management and School of Law. </strong></p>
           		    <p><strong>All six schools of the University posted  superlative performance in the campus placement programme.  Schools of Engineering (B.Tech. programme),  which accounts for 76% of the total registered students of KIIT University,  recorded 93% placement. School of Rural Management and School of Biotechnology  achieved 100% and 83% placement respectively. Similarly, School of Management  and School of Law registered 92% and 68% placement respectively. School of Computer  Application achieved 74% placement for its MCA students.</strong></p>
           		    <p><strong>Placement of a few students remaining in some schools is a  foregone conclusion with visits of many more companies scheduled in coming  weeks. This apart, many students are likely to join reputed national and  foreign institutions for higher studies. </strong>KIIT University uniquely places  equal emphasis on such academic placement, meticulously grooming interested  students for higher studies and actively supporting their efforts to secure  admission in reputed institutions. As a result there is a growing trend among KIIT  students for such academic placement of late. Last year, more than 300 students  of Schools of Engineering had been academically placed. Students were  successful in GATE, CAT and other competitive examinations and took admission  in IIMs and other reputed national and international institutions.</p>
           		    <p><strong>There is a wave of joy among young graduates of the  University not only because of job offers, but also because salary package  offered this year is higher than previous years. Daelim, a leading engineering  &amp; construction company of the world, offered the highest salary of Rs.  23.04 lakh p.a., to Bitan Ghosh, a B.Tech (Civil) student. Similarly, CTC of  Rs. 12 lakh was offered by Amazon in School of Engineering, while the average  package across the board was Rs. 4.2 lakh. Like last many years, TCS doled out  a maximum of 523 job offers in Schools of Engineering. Other regular visitors  like Wipro, Infosys, Capgemini and UST Global offered more than 50 jobs each. There  was an encouraging participation by core companies like Tata Steel, Shapoorji  Pallonji, Jindal Steel, Tayo Rolls, Tata Power, TAFE, ARSS, Murugappa Group,  Quality International and Enercon; as well as international multinational  companies. </strong></p>
           		    <p><strong>Further, more than 30 companies, which include multinational  corporations, visited KIIT University for the first time this season. </strong>Some of these companies are: Amazon, HP, Ericsson, Cybage Software,  Cavisson Systems, Adstuck, Vegayan Systems, UST Global, The Elitists, Jindal  Steel, Zycus, Cognizant, Mahindra Comviva, Murugappa Group, Trident Group,  Linkhouse Buildwell, Contenental Engineering, Jabong, Perkin Elmer, TAFE,  Maiestas Group and Quality International. <strong>Most of the new companies were at  'Dream-Status' with a high salary package.</strong></p>
           		    <p>KIIT  Polytechnic and KIIT Industrial Training Institute (KIIT-ITI), two institutes  of KIIT Group of Institutions outside the university fold, also recorded cent  percent placement.&nbsp; </p>
           		    <p>KIIT has been achieving cent percent placement since its inception.  Excellent placement for the 2014 batch students once again proves that KIIT  continues to be one of the most favored talent hunting ground for the corporate  world. Such superlative achievement year after year is sustained because of high  brand value of KIIT. The University conducts rigorous training of students,  which helps develop strong foundation for core academic competencies along with  high quality IT skills. Students  get wide professional exposure due to a vibrant schedule of academic  conferences and seminars which are attended by top academicians, scientists and  industry leaders. Excellent performance of past batch students also motivates  companies for repeat visit.</p>
           		    <p><strong>Excellent  placement and growing stature of KIIT as a world-class institution of  professional education has attracted appreciations from intellectuals, students  and guardians. Reputation and popularity of KIIT can be assessed from the fact  that KIITEE-2014, the all India entrance test conducted by the University for  admission into its various programmes held April 25 to May 5, 2014, attracted  2,20,000 applications from all parts of India and 30 foreign countries. This is  a record for highest number of applicants in entrance test for a single campus  of any institution.</strong></p>
           		    <table width="90%" border="0" align="center" cellpadding="5" cellspacing="0">
           		      <tbody><tr>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/1--Total---No-of-Students-&-Offers.jpg" rel="slides-gallery"><img src="images/about/1--Total---No-of-Students-&-Offers.jpg" width="320" height="250"><br>
           		          </a></td>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/2--Total---No-of-Companies-in-Different-Schools.jpg" rel="slides-gallery"><img src="images/about/2--Total---No-of-Companies-in-Different-Schools.jpg" width="320" height="225"><br>
           		          </a></td>
           		        </tr>
         		      </tbody></table>-->
           		    <h3><a href="http://www.kiit.ac.in/placement/place2/full-a.jpg" rel="slides-gallery"><br>
         		      </a>Schools of Engineering</h3>
           		    <p><strong>In what heralds another record year in Schools of  Engineering with respect to campus placement for 2014 graduating batch, as many  as 1517 job offers have been generated till date for total 1637 registered and  eligible B.Tech. and MCA students. These jobs have been offered by 83 companies  � 44 IT, 35 core and 4 others � in Schools of Engineering. Almost 156 multiple  offers have been made by various corporate. Total job offer is set to outstrip  the registered student strength with many reputed companies, especially in core  sector, scheduling their visit in coming weeks. This apart, as in previous  years, many students are waiting to avail academic placement.&nbsp;&nbsp;&nbsp;&nbsp; </strong></p>
           		    <p>Well known  names of the corporate world rushed in as soon as the University opened the  window for campus placement for its Schools of Engineering in August 2013.  Schools of Engineering is the cluster of five Schools imparting education in  Civil Engineering, Computer Engineering, Electrical Engineering, Electronics  &amp; Telecommunication Engineering, Electronics &amp; Electrical Engineering,  Electronics &amp; Instrumentation Engineering, Information Technology,  Mechanical Engineering and Mechanical Engineering (with specialization in  Automobile Engineering). School of Computer Engineering and School of  Electronics Engineering, which account for the highest number of registered  students, already have more than 80% conversions in campus placement drives.&nbsp;</p>
           		    <p><strong>The placement season, which started with Shapoorji &amp;  Pallonji, has attracted 83 companies within eight months since the campus was  opened for the recruitment process. With 523 selections, Tata Consultancy  Services (TCS) was the top recruiter in terms of number of job offers. For the  seventh year in a row, TCS has the distinction of being the top recruiter at  KIIT University.</strong> It was followed by Wipro Technologies which doled out 153 offers. Infosys  selected 99 students, Capgemini selected 62 students, UST Global selected 58  students, whereas 48 students got offer from Cognizant. </p>
           		    <p><strong>The highest salary of Rs. 23.04 lakh p.a. was offered by global  engineering &amp; construction major, Daelim. American E-commerce giant, Amazon  offered a CTC of Rs.12.00 lakh. Trident Group closely followed with a salary  package of Rs.9.00 lacs, followed by Tata Steel with a salary package of  Rs.8.00 lacs.</strong> The Elitists offered a salary package of 7.50 lakh, HP offered Rs. 6.20 lakh,  Thoughtworks offered Rs. 6.23 lakh, Intel Rs. 6.20 lakh, while Deloitte US  India, which recruited 39 students, offered a CTC of Rs. 5.46 lakh.&nbsp;Salary  package offered this season is better than previous years. <strong>Further, more than 30 companies visited KIIT University for the first  time this season.</strong></p>
           		    <table width="90%" border="0" align="center" cellpadding="5" cellspacing="0">
           		      <tbody><tr>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/SOE---Core-&-IT-Companies.jpg" rel="slides-gallery"><img src="images/about/SOE---Core-&-IT-Companies.jpg" width="320" height="223"><br>
           		          </a></td>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/SOE---Top-5-Companies-by-Offer.jpg" rel="slides-gallery"><img src="images/about/SOE---Top-5-Companies-by-Offer.jpg" width="320" height="230"><br>
           		          </a></td>
           		        </tr>
         		      </tbody></table>
           		    <p>Other  companies that visited KIIT campus are SAP Labs, Accenture (off-campus), Cybage  Software, Zentron Labs, Adstuck, Vegayan Systems, NTT Data, Ericsson, Mahindra  Comviva, Yazaki India, Cavisson Systems, L&amp;T IES, Softenger, Jindal Steel,  Zycus, Zeta Interactive, Gyansys, Asahi Glass, JMC Projects, Tata Power,  Everest Industries, Ashiana Housing, Murugappa Group, ISMT, Era Group,  Linkhouse Buildwell, Continental Engineering, Jabong, Perkin Elmer, Sterling  &amp; Wilson, TAFE, Tega Industries, Maiestas Group, Quality International and  ARSS. The average salary package stands at Rs. 4.2 lakh. </p>
           		    <p>Forthcoming campus placements which are scheduled in  the coming weeks will have Harley Davidson, IOTL, Tech Mahindra and Thomson  Digital (HCL Infosystems). It is expected that more than 20 corporates shall  visit KIIT University before the end of the academic season and cent percent  students will be having offers before they graduate in the month of May 2014. </p>
           		    <table width="90%" border="0" align="center" cellpadding="5" cellspacing="0">
           		      <tbody><tr>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/SOE-Top-10-companies-by-CTC.jpg" rel="slides-gallery"><img src="images/about/SOE-Top-10-companies-by-CTC.jpg" width="320" height="220"><br>
           		          </a></td>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/SOE---Sector-wise-Companies.jpg" rel="slides-gallery"><img src="images/about/SOE---Sector-wise-Companies.jpg" width="320" height="224"><br>
           		          </a></td>
           		        </tr>
         		      </tbody></table>
           		    <p><br>
         		      </p>
           		    <table width="100%" border="0" cellspacing="0" cellpadding="0">
           		      <tbody>
<!--                                                            <tr>
           		        <td colspan="2"><h3>School of  Management</h3></td>
           		        </tr>
           		      <tr>
           		        <td width="63%"><p>School of Management of KIIT University has secured  92% placement for all those who registered for the campus recruitment process  this year. As many as 208 of total 225 registered students of 2012-14 MBA batch  have already secured jobs. The highest package of Rs. 7.5 lakh was offered by  Dabur, while average salary across the batch was Rs. 3.77 lakh. More than 60  globally reputed recruiters have so far visited the campus this year for the  campus recruitment programme. </p>
           		          <p>Tech Mahindra doled out maximum 18 job offers. HDFC  Bank and Bandhan Finance recruited 16 and 15 students respectively. Deliotte,  Kare 4u Healthcare and ICICI Securities gave 10 job offers each. Some of the  other companies include Barclays, Capgemini, Col-Pal, Khimji Ramdas, Mahindra  &amp; Mahindra, Manipal and TCS. About 10% of the total student strength opted  out of campus placement process to pursue higher education or join family  business. </p></td>
           		        <td width="37%" align="right"><a href="http://www.kiit.ac.in/placement/placement2014/SOM.jpg" rel="slides-gallery"><img src="images/about/SOM.jpg" width="320" height="250"><br>
           		          </a></td>
           		        </tr>
       		      </tbody></table>
           		    <h3>School of  Rural Management</h3>
           		    <p>School of Rural Management of KIIT University has  achieved unique distinction of cent percent placement from the very first batch  (2007-09). With all 38 registered students of 2012-14 batch of MRM Programme  already placed, this record is set to continue. These 38 students were  recruited by 16 organisations, which participated in the campus placement  process. </p>
           		    <p>Students joined both development sector and  corporate sector.&nbsp; Amongst the  development sector, Bihar Rural Livelihoods Promotion Society (JEEViKA), SRIJAN  and Knowledge Consortium of Gujarat (KCG) were the top recruiters. Similarly,  Development Credit Bank, Mumbai, National Handloom Development Corporation  (NHDC) and Adani Wilmar, Gujarat were the major recruiters from amongst  corporate sector organizations. Other prominent companies that participated in  campus placement for 2012-14 batch students are GCMMF (Amul), Gujarat, American  India Foundation (AIF), New Delhi and NDDB Dairy Services, New Delhi.  Maintaining a perfect placement, School of Rural Management has so far  successfully placed 350 students with 80 recruiters since its inception.</p>
           		    <table width="90%" border="0" align="center" cellpadding="5" cellspacing="0">
           		      <tbody><tr>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/SRM---No.jpg" rel="slides-gallery"><img src="images/about/SRM---No.jpg" width="320" height="250"><br>
           		          </a></td>
           		        <td align="center"><a href="http://www.kiit.ac.in/placement/placement2014/SRM---Development-Sector-&-Corporate-Sector.jpg" rel="slides-gallery"><img src="images/about/SRM---Development-Sector-&-Corporate-Sector.jpg" width="320" height="232"><br>
           		          </a></td>
           		        </tr>
         		      </tbody></table>
           		    <br>
           		    <table width="100%" border="0" cellspacing="0" cellpadding="0">
           		      <tbody><tr>
           		        <td colspan="2"><h3>School of Law</h3></td>
           		        </tr>
           		      <tr>
           		        <td width="63%"><p>In School of Law, 75 out of 110 registered students  have already been placed. This includes 15 students who were academically  placed. School of Law attracted companies from all sectors in the campus  placement process. Prominent among them are Mahindra &amp; Mahindra Financial Services, Pramata,  Mindcrest, Quislex, ICICI Lombard, Bajaj Allianz, Skyline Legal Consultants,  Longbow Legal Services, MNK Law Offices, ANA Law Group and IP Gurus. The School  is confident to place remaining graduates as visits by many more companies are  scheduled in the coming weeks. </p>
           		          <p>Established  only in 2007, the first batch of School of Law passed out in 2012. The School  had achieved 100% place for its very first batch, creating much sensation in  the academic circle. This season the highest salary offered was Rs. 7.5 lakh,  while average salary in the batch was Rs. 4 lakh.</p></td>
           		        <td width="37%" align="right"><a href="http://www.kiit.ac.in/placement/placement2014/SOL-.jpg" rel="slides-gallery"><img src="images/about/SOL-.jpg" width="320" height="250"><br>
           		          </a></td>
           		        </tr>
         		      </tbody></table>
           		    <br>
           		    <table width="100%" border="0" cellspacing="0" cellpadding="0">
           		      <tbody><tr>
           		        <td colspan="2"><h3>School of Biotechnology</h3></td>
           		        </tr>
           		      <tr>
           		        <td width="63%"><p>Out  of 52 registered students in M.Sc. Biotechnology and M.Sc. Applied Microbiology  programmes of School of Biotechnology, 43 have so far been placed. Leading  biotech companies such as B Braun, Nestle, SRL, Lal Path Lab, Intertek Pvt Ltd,  Evolva Biotech, Bharat Biotech, Bionivid, Neelkath IVF Ltd, inDNA Life sciences  Pvt Ltd, Ackme Formulation, Medico Healthcare and Imgenex Pvt Ltd participated  in the campus placement process. Average salary was Rs. 3.5 lakh.</p>
           		          <p>Several  other students have opted for academic placement like Ph.D. programs in national  and international organizations like University of Lausanne (Switzerland),  Chonbuk National University (South Korea), NUS (Singapore), IICB Kolkata,  Banaras Hindu University, NBRC-Gurgaon, NISER-Bhubaneswar, NCCS-Pune,  CIFA-Bhubaneswar, IMMT Bhubaneswar, MSSRF, Chilika Development Authority and  KIIT University. </p></td>
           		        <td width="37%" align="right"><a href="http://www.kiit.ac.in/placement/placement2014/SBT.jpg" rel="slides-gallery"><img src="images/about/SBT.jpg" width="320" height="250"><br>
           		          </a></td>
           		        </tr>-->
         		      </tbody></table>
                    <p>&nbsp;</p>
                    <h3>School of Computer Application  </h3>
           		    <p>School of Computer  Application recorded 74% placement with 75 of total 102 registered and eligible  MCA students bagging job offers from reputed IT companies. Companies like TCS,  Wipro, Accenture, Infosys, Capgemini and Deloitte participated in campus  placement programme of this school of KIIT University. </p>
           		    <p>Previous Years :<br>
           		      <a href="#" target="_blank">RECORD  PLACEMENT IN ALL SCHOOLS  IN 2014</a><br/>
                                                          <a href="http://www.kiit.ac.in/placement_landing2013.html" target="_blank">RECORD PLACEMENT IN ALL SCHOOLS IN 2013</a><br>
           		      <a href="http://www.kiit.ac.in/placement_2012.html" target="_blank">RECORD  PLACEMENT IN ALL SCHOOLS  IN 2012</a></p></td>
         		  </tr>
                </tbody></table></td>
          </tr>
          <tr>
            <td><table width="95%" border="0" align="center" cellpadding="0" cellspacing="0" class="placement">
            	
              <!--<tr>
                <td width="29%" rowspan="11" align="center" valign="middle"><img src="d1.jpg" width="235" height="453" /></td>
              </tr>-->
              <tbody><tr>
                <td valign="top">&nbsp;</td>
                <td colspan="2" valign="top">&nbsp;</td>
                <td valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td width="1%" rowspan="7" align="center" valign="middle">&nbsp;</td>
                <td colspan="2" valign="top">&nbsp;</td>
                </tr>
              <tr>
                <td width="22%" valign="top"><strong>School wise Placement
                </strong>
                  <ul>
                  <li><a href="http://kiittnp.in/" target="_blank">School of Engineering &amp; MCA </a></li>
                  <li><a href="http://kiitbiotech.ac.in/placement/placement.html" target="_blank">School of Biotechnology</a></li>
                  <li><a href="http://www.ksom.ac.in/placement/why-recruit-from-us/" target="_blank">School of Management</a></li>
                  <li><a href="http://ksrm.ac.in/pages/placement/overview.htm" target="_blank">School of Rural Management</a></li>
                  <li><a href="http://kls.ac.in/placement.html" target="_blank">School of Law</a></li>
                </ul></td>
                <td width="76%" valign="middle"><table width="98%" border="0" align="right" cellpadding="5" cellspacing="0">
                  <tbody><tr>
                    <td align="center" class="record record2"><h3><big><strong>Training &amp; Placement Help Desk</strong></big><br>
<big>Ph: 0674 - 2725 419<br>
                      </big>Email: <img style="vertical-align:bottom" src="images/about/email.gif" width="164" height="20"></h3>
                      <div>
                      	<p>Present and past students may contact the Help Desk for issues relating to Training &amp; Placement.</p>
                      	<p>The Help Desk In-charge will resolve the issues on the spot as far as possible. If the issue deserves detailed attention, he / she will intimate the same and request an E-mail to be sent.</p>
                      	<p>Students can send an E-mail to <img src="images/about/email.gif" alt="" width="164" height="20" style="vertical-align:bottom"> directly.<br> 
                      	  Such queries shall be resolved within 48 hours.</p>
                      </div>

                      </td>
                  </tr>
                </tbody></table><br></td>
                <td width="1%" valign="middle">&nbsp;</td>
              </tr>
              
              <tr>
                <td height="0" colspan="2" valign="top">&nbsp;</td>
                <td height="0" valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td height="0" colspan="2" valign="top"><div align="center">
                  <h2>IMPORTANT CONTACT PERSONS</h2>
                </div></td>
                <td height="0" valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td height="0" colspan="2" valign="top"><table width="100%" cellpadding="5" cellspacing="0" class="zebra">
                  <tbody><tr>
                    <td width="20%" valign="top"><strong>Dr. Saranjit Singh</strong>
                        <div></div>
                      <div></div></td>
                    <td width="41%" valign="top">Dean (T&amp;P)</td>
                    <td width="25%" valign="top">placement@kiit.ac.in, 
                      ssingh@kiit.ac.in</td>
                    <td width="14%" valign="top">9437020233</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Prof. Kumar Mohanty</strong></td>
                    <td valign="top">Dean, Career Advisory &amp; Augmentation Services (CAAS)</td>
                    <td valign="top">m.kumar@kiit.ac.in</td>
                    <td valign="top">9937220236</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Mr Venkat Sastry </strong></td>
                    <td valign="top">Director - Corporate Relations</td>
                    <td valign="top">venkats@kiit.ac.in</td>
                    <td valign="top">7200478002&nbsp;</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Ms. Krithika Koul</strong></td>
                    <td valign="top">Mumbai</td>
                    <td valign="top">kiitcr.kk@kiit.ac.in</td>
                    <td valign="top">9004693905</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Mr. Navendu Kar</strong></td>
                    <td valign="top">Orissa/West Bengal</td>
                    <td valign="top">kiitcr.nk@kiit.ac.in</td>
                    <td valign="top">9238314802</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong> Mr. Debraj Mitra</strong></td>
                    <td valign="top"> Delhi / NCR</td>
                    <td valign="top">kiitcr.dm@kiit.ac.in </td>
                    <td valign="top"> 9238314801</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Mr. Bikram Lenka</strong></td>
                    <td valign="top">North&nbsp;</td>
                    <td valign="top">l.bikram@kiit.ac.in&nbsp;</td>
                    <td valign="top">9937937595&nbsp;</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Ms. Mithu Pandey</strong></td>
                    <td valign="top">North</td>
                    <td valign="top">kiitcr.rp@kiit.ac.in</td>
                    <td valign="top">9990077517</td>
                  </tr>
                  <tr>
                    <td valign="top"><strong>Mr. R Siva Prasad</strong></td>
                    <td valign="top">South&nbsp;</td>
                    <td valign="top">kiitcr.sp@kiit.ac.in</td>
                    <td valign="top">9841474312</td>
                  </tr>
                </tbody></table></td>
                <td height="0" valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td height="0" colspan="2" valign="top">&nbsp;</td>
                <td height="0" valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td height="0" colspan="2" valign="top"><div align="center"><strong>For Educational Verification Contact: <a href="mailto:backgroundverification@kiit.ac.in">backgroundverification@kiit.ac.in</a></strong></div></td>
                <td height="0" valign="top">&nbsp;</td>
              </tr>
              <tr>
                <td height="0" valign="top">&nbsp;</td>
                <td height="0" valign="top">&nbsp;</td>
                <td height="0" valign="top">&nbsp;</td>
              </tr>
            </tbody></table></td>
          </tr>

        </tbody></table>
          </td>
        </tr>
      <tr>
        <td height="0" colspan="2" valign="top" bgcolor="#FFFFFF">&nbsp;</td>
      </tr>
      <tr>
        <!--<td height="0" colspan="2" valign="top" bgcolor="4396CA"><p>&nbsp;</p>
          <table width="100%" border="0" cellspacing="0" cellpadding="3">
            <tbody><tr>
              <td class="homelinks"><div align="center">Site Designed &amp; Maintained by  KIIT University </div></td>
            </tr>
          </tbody></table>
          <p>&nbsp;</p></td>-->
        </tr>
    </tbody></table></td>
  </tr>
</tbody></table>
<script src="images/about/jquery.min.js"></script>
<script type="text/javascript">
if(typeof jQuery == 'undefined'){document.write('<script src="/js/jquery-1.8.3.min.js" />')}
</script>
<script type="text/javascript" src="images/about/jquery.fancybox.pack.js"></script>
<script type="text/javascript">
$(function(){
	$('.leftfloat a, .rightfloat a, #contt table a').fancybox({padding: 5, helpers : {	overlay : {	css : {'background' : 'url(plac_assets/js/lightbox/overlay.gif)'	}}}	});
})
</script>



</body></html>
<?php
$pageContent = ob_get_contents();
$pageType = 'Home';
ob_end_clean();
include_once 'template2.php';
?>