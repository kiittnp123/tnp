
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <link rel="icon" href="http://kiit.ac.in/favicon.ico" />        
        <script src="scripts/flexslider/jquery.flexslider-min.js"></script>
        <script>
            $(window).load(function() {
                $('.flexslider').flexslider({
                    animation: 'slide',
                    controlNav: false,
                    pauseOnHover: true,
                    slideshowSpeed: 8000,
                    animationSpeed: 1000,
                    start: function(slider) {
                        $('body').removeClass('loading');
                    }
                });
            });
        </script>
        <script src="scripts/jquery-ui-1.8.12.custom.min.js"></script>
        <script src="scripts/pngFix/jquery.pngFix.js"></script>
        <script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>

        <script type="text/javascript" src="scripts/fadeslideshow.js">

            /***********************************************
             * Ultimate Fade In Slideshow v2.0- (c) Dynamic Drive DHTML code library (www.dynamicdrive.com)
             * This notice MUST stay intact for legal use
             * Visit Dynamic Drive at http://www.dynamicdrive.com/ for this script and 100s more
             ***********************************************/

        </script>

        <meta http-equiv="Content-Type" content="text/html; charset=windows-1252" />
        <title>:: KIIT UNIVERSITY :: Training and Placement Department</title>
        <style type="text/css"><!--
            body {
                margin-top: 0px;
                margin-left: 0px;
                background-image: url(image/main-bg.jpg);
            }
            --></style>
        <link href="style.css" rel="stylesheet" type="text/css" />
        <style type="text/css">
            marquee ul li{list-style:none;}
            marquee ul{padding:0px;}
            <!--
            .style52 {
                color: #0066FF;
                font-weight: bold;
            }
            .style53 {color: #0033FF}
            .style54 {
                font-family: Arial, Helvetica, sans-serif;
                font-weight: bold;
                font-size: 24px;
                color: #FFFFFF;
            }
            .style55 {color: #FFFFFF; font-weight: bold; font-size: 14px; }
            .style58 {font-size: 12px}
            .style59 {
                color: #0066FF;
                font-size: 16px;
            }
            --></style>
    </head>
    <body>
        <table align="center" border="0" cellpadding="0" cellspacing="0" width="1150">
            <tbody>
                <tr>
                    <td bgcolor="0C3E74" height="0" valign="top"><br />
                    </td>
                </tr>
                <tr>
                    <td height="0" valign="top">
                        <table border="0" cellpadding="10" cellspacing="0" width="100%">
                            <tbody>
                                <tr>
                                    <td background="image/bl1.jpg" height="0" valign="top">
                                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                                            <tbody>
                                                <tr>
                                                    <td><div class="style54" align="center"> Department Of Training &amp; Placement </div></td>
                                                    <td>
                                                        <img alt="" src="image/top1.jpg" height="76" width="322"  style="float:right;"/>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </td>
                                </tr>
                            </tbody>
                        </table>      
                    </td>
                </tr>
                <tr>
                    <td height="0" valign="top">
                        <table border="0" cellpadding="0" cellspacing="0" width="100%">
                            <tbody>
                                <tr>
                                    <td colspan="3" background="image/bdot.jpg" bgcolor="0C3E74" height="0" valign="top">
                                        <div id="menu-holder">&nbsp;</div>
                                        <script type="text/javascript" src="js/jquery-1.8.3.min.js"></script>
                                        <script type="text/javascript">
                                            $(function() {
                                                $('#menu-holder').load('menu.html');
                                            })
                                        </script></td></tr>
                                <tr>
                                    <td colspan="3" background="image/bl2.jpg" height="16" valign="top" style="width:100%" >
                                        <div align="right"><a href="#"></a></div><br />
                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="3" bgcolor="#FFFFFF" height="0" valign="top"><img alt="" src="image/PIXEL.jpg" height="7" width="7" /></td>
                                </tr>
                                <tr>
                                    <td colspan="2" bgcolor="#FFFFFF" height="0" valign="top">
                                        <?php
                                        echo $pageContent;
                                        ?>

                                    </td>
                                </tr>
                                <tr>
                                    <td colspan="2" background="image/bl.jpg" valign="top">
                                        <p class="footer" align="center">Developed,Deployed and Maintained by <a href="http://www.innovadorslab.com">Innovadors Lab Pvt. Ltd.</a></p></td></tr></tbody></table></td></tr></tbody></table>
    </body>
</html>