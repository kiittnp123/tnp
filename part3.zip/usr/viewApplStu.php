<?php
include_once 'protectedStudent.php';
include'../db.php';
ob_start();
$sqlstd="SELECT `train_name`, `indus_name`, `contact_name`,`start_date`, `end_date`, `stu_sem`, `status` FROM `tbl_training_noc` WHERE student_id=$_SESSION[userId]";
$resstd=mysql_query($sqlstd);
if(mysql_num_rows($resstd)!=0){
?>
<table align="center" bgcolor="#E2E2E2" style="border-style:ridge" width="800">
<tr>
<td colspan="7" align="center"><font><b><h2>Industrial Training Application Form Details</h2></b></font></td>
</tr>
<tr>
    <td>Training Name:</td>
    <td>Organization</td>
    <td>Concerned Person</td>
    <td>Training Start Date</td>
    <td>Training End Date</td>
    <td>Semester</td>
    <td>Status</td>
</tr>
<?php
while($row=  mysql_fetch_array($resstd)){
?>
<tr bgcolor="#FFFFFF">
    <td><?php echo $row['train_name']?></td>
    <td><?php echo $row['indus_name']?></td>
    <td><?php echo $row['contact_name']?></td>
    <td><?php echo $row['start_date']?></td>
    <td><?php echo $row['end_date']?></td>
    <td><?php echo $row['stu_sem']?></td>
    <td><?php echo $row['status']?></td>
</tr>
<?php
}
?>
</table>
<?php 
}else{
    echo "<font size=13 color=blue face='Trebuchet MS'><p align='center'>You have not applied for any NOC yet</p></font>";
}
$content=ob_get_contents();
ob_clean();
include_once 'template1.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>