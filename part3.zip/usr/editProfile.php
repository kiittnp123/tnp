<?php
ob_start();
include_once 'protectedStudent.php';
include_once '../db.php';
$username=$_SESSION['userName'];
//var_dump($_POST);

$sql="select * from tbl_student where email='$username'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
$status=$row['status'];
if($status=='Created')
    {
     ?>
<table align="center" width="1000" border="0">
        <tr>
        <td colspan="6" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>REGISTRATION FORM</b></font></td>
        </tr><tr>
            <td>Rollno:</td><td><input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td>Current Status:</td><td><input type="text" name="status" value="<?php echo $row['status'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td colspan="6" align="left" style="color: red;">Note:<br /> The registration process has been closed. <br />No more registrations are possible. <br />Please contact Training and Placement Cell for further information.</td>
        </tr>
        
       </table>
</form>    
    <?php
}
elseif ($status=='Pending' || $status == 'Approved') 
    {
    ?>
<table align="center" width="1000" border="0">
        <tr>
        <td colspan="6" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>REGISTRATION FORM</b></font></td>
        </tr><tr>
            <td>Rollno:</td><td><input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td>Current Status:</td><td><input type="text" name="status" value="<?php echo $row['status'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td colspan="6" align="left" bgcolor="#237648" style="color: red;">Note: You have already edited your profile and submitted the information for verification. You are not authorized to make any further changes. Please contact Training and Placement Cell for further help.</td>
        </tr>
        
       </table>
</form>    
    <?php
}
$content=ob_get_contents();
ob_end_clean();
$pageTitle = "TNP || Student Data";
include'template1.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
    echo $_SESSION['ErrMsg'];
    unset ($_SESSION['ErrMsg']);
}
?>