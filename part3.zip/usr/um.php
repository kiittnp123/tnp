<?php
include_once 'protectedStudent.php';
include_once '../db.php';

ob_start();
?>
<table width="100%" cellspacing="10" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
    <tr>
        <td><h1>Coming Soon</h1></td>
    </tr>
    <tr>
        <td align="center"><img src="../img/um.png" width="800" height="400"/></td>
    </tr>
</table>      
<?php
$content = ob_get_contents();
$pageType='Home';
ob_end_clean();
include_once 'template1.php';
?>