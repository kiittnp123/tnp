<?php
session_start();
include_once '../db.php';
include_once '../inc/conf.php';
$sql = "select * from tbl_homepage order by home_id desc limit 1";
$res = mysql_query($sql);
$data = mysql_fetch_array($res);
$sqlnews = "SELECT * FROM tbl_news WHERE STATUS = 'Active' and curdate() between date_sub(start_date, interval 1 day) and end_date order by start_date desc";
$resNews = mysql_query("$sqlnews");
$sqlNotice = "SELECT * FROM tbl_notice WHERE STATUS = 'Open to All' and curdate() between date_sub(start_date, interval 1 day) and end_date order by start_date desc";
$resNotice = mysql_query($sqlNotice);
?>
<table align="center" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFF" width="100%">
    <tr>
        <td>
            <?php
            ob_start();
            ?>
            <script type="text/javascript">

                var mygallery = new fadeSlideShow({
                    wrapperid: "fadeshow1", //ID of blank DIV on page to house Slideshow
                    dimensions: [700, 339], //width/height of gallery in pixels. Should reflect dimensions of largest image
                    imagearray: [
                        ["<?php echo $data['image1'] ?>", "", "", ""],
                        ["<?php echo $data['image2'] ?>", "", "", ""],
                        ["<?php echo $data['image3'] ?>", "", "", ""]
                    ],
                    displaymode: {type: 'auto', pause: 2500, cycles: 0, wraparound: false},
                    persist: false, //remember last viewed slide and recall within same session?
                    fadeduration: 500, //transition duration (milliseconds)
                    descreveal: "ondemand",
                    togglerid: ""
                })


            </script>

            <style>

            </style>

            <table width="100%" style="background:#FFF;margin-left:0%;">
                <tr>
                    <td colspan="2">
                        <table width="100%">
                            <tr>
                                <td align="center" rowspan="2"><a class="btn" href="doc/KIIT Brochure.pdf" target='_blank'>Why Recruit @ KIIT</a>  <a class="btn" href="doc/job-notification-form.doc">Job Notification Form (JNF)</a></td>
                                <td style="width:200px">&nbsp;</td>
                            </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td><div id="fadeshow1" align="center" style= "margin-top: -12%"></div></td>
                    <td >
                        <img alt="" src="image/sir2.jpg" usemap="#Map2" border="0" height="85" width="234" style="margin-top: 16px;" />
                        <map name="Map2" id="Map2">
                            <area alt="" shape="rect" coords="90,62,150,80" href="http://www.kiit.ac.in/aboutus/message.html" target="_blank" />
                            <area alt="" shape="rect" coords="164,60,233,81" href="http://www.achyutasamanta.com/" target="_blank" /></map>

                        <p class="heading">NEWS &amp; EVENTS</p>
                        <hr />
                <marquee direction="up" scrollamount="2" onmouseover="this.stop()" onmouseout="this.start()" style="height: 280px;">
                    <ul>
                        <?php
                        while ($row = mysql_fetch_array($resNews)) {
                            //to display the new.gif image for 24hour within the publication of news                                 
                            $published_date = strtotime($row['start_date']);
                            $now = time();
                            $time_diff = $now - $published_date;
                            if (($time_diff / (60 * 60 * 24)) < 1)
                                $new = "<img src='image/new.gif' width='30' height='15' />";
                            else
                                $new = "";
                            ?>
                            <li><span class="style52"><?php echo $row['heading'] . $new; ?></span><hr /></li>
                            <?php
                        }
                        ?>
                    </ul>
                </marquee>

                <a href="news.php">  <span align="right" style="float: right">View All</span></a>

        </td>
    </tr>

    <tr>
        <td>
            <table width="700px" border="" cellspacing="0" class="table" style="margin-top:-222px;">
                <caption><h3>Associate Deans (Training & Placement)</h3> </caption>
                <thead>
                    <tr>
                        <th>School Name</th>
                        <th>Name Of IEC Member</th>
                        <th>Contact No.</th>
                        <th>E-Mail Id</th>
                    </tr>  
                </thead>
                <tbody> 
                    <tr>
                        <td>Civil Engineering</td>
                        <td>Prof. D.K.Bera</td>
                        <td>7894470698</td>
                        <td><u>dberafce@kiit.ac.in</u></td>
    </tr>  
    <tr>
        <td>Computer Engineering</td>
        <td>Prof. Prachet Bhuyan</td>
        <td>7894427738</td>
        <td><u>pbhuyanfcs@kiit.ac.in</u></td>
</tr>
<tr>
    <td>Electrical Engineering</td>
    <td>Prof Subrat Behera</td>
    <td>9556271032</td>
    <td><u>subrat.sb@gmail.com</u></td>

</tr>
<tr>
    <td>Electronics Engineering</td>
    <td>Prof. Col. S. Pany</td>
    <td>9937289194</td>
    <td><u>spanyfet@kiit.ac.in</u></td>
</tr>
<tr>
    <td>Mechanical Engineering </td>
    <td>Prof. Isham Panigrahi</td>
    <td>9437162857</td>
    <td><u>ipanigrahifme@kiit.ac.in </u></td>
</tr>
</tbody>
</table>
</td>
<td>
    <p class="heading">NOTICE</p>
    <hr/>
<marquee direction="up" scrollamount="2" onmouseover="this.stop()" onmouseout="this.start()" style="height:270px">
    <ul>
        <?php
        while ($row = mysql_fetch_array($resNotice)) {
            //to display the new.gif image for 24hour within the publication of news                                 
            $published_date = strtotime($row['start_date']);
            $now = time();
            $time_diff = $now - $published_date;
            if (($time_diff / (60 * 60 * 24)) < 1)
                $new = "<img src='image/new.gif' width='30' height='15' />";
            else
                $new = "";
            ?>
            <li><span class="style52"><?php echo $row['heading'] . $new; ?></span><hr /></li>
            <?php echo $row['start_date'] ?>
            <?php
        }
        ?>
    </ul>
</marquee>
<a href="notice.php">  <span align="right" style="float: right">View All</span></a>
</td>
</tr>
<tr valign='top'>
    <td>
        <div  style="margin-top: 30px;">
            <a href="certification-about.php">  <img alt="" src="http://kiittnp.in/cs/img/logo-cs-advanced-bg.png" style="float: left; width: 350px; height: 77px;margin-top: 20px;"/></a>
            <form method="post" action="indexPage.php">
                <div class="style55" align="center" style="margin-top:-172px;" style= "width:"><span class="style59">Student / Faculty Login </span><br />
                    <table bgcolor="#CCCCCC" border="0" bordercolor="#FFFFFF" >
                        <tbody>
                            <tr>
                                <td height="26" width="121"><span class="style53">User ID </span></td>
                                <td width="150"><input name="user_name" type="text" /></td>
                            </tr>
                            <tr>
                                <td height="26"><span class="style53">Password</span></td>
                                <td><input name="password" type="password" /></td>
                            </tr>
                            <tr>
                                <td height="26"><span class="style53">User Type</span></td>
                                <td>
                                    <table  style="width: 100%;">
                                        <tr style="width: 100%;">
                                            <td style="width: 50%;">
                                                <input name="user_type" value="Student" type="radio" checked="checked"/>Student
                                            </td>
                                            <td style="width: 50%;">
                                                <input name="user_type" value="Faculty" type="radio" />Faculty
                                            </td>
                                        </tr>
                                    </table>
                                </td>
                            </tr>
                            <tr>
                                <td colspan="2" height="28">
                                    <div class="style53" align="center"><input name="btn_stu_login" value="Sign In" type="submit" /></div>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            </form>
        </div>
    </td>
</tr>
<tr>
    <td>
        <?php
        $con1 = mysql_connect("localhost", "root", "!23Iotserver");
        mysql_select_db("kiittnp_student_noc");
        $query = "SELECT * FROM `tbl_setting`";
        $res = mysql_query($query);
        $row = mysql_fetch_array($res);
        if ($row['value'] == "ON") {
            ?>
            <a href="../applynoc/" style='text-decoration: none;'>  <img alt="" src="image/applyforNOC.gif" style="float: left;width: 200px;height: 40px;margin-left: 46%;"/>
                <br><br>
                <div style="text-align: center;font-weight: bold;color: red;font-size: 17px;font-family: Verdana;margin-right: 141px;margin-left: 291px;">Last Date For Applying NOC(<?php echo $row['last_dt'] ?> at <?php echo $row['last_tm'] ?>.)</div>
                <div style="text-align: center;font-weight: bold;color: blue;font-size: 20px;font-family: Verdana;margin-left: 150px;">Only for B.Tech 4th &amp; 6th semester</div>
                <?php
            } else {

                echo "";
            }
            ?>
    </td>
</tr>
</table>

</td>
<td class="marquee" width="250">
<marquee direction="down" scrollamount="2" onmouseover="this.stop()" onmouseout="this.start()" style="height: 900px;">
    <ul style="list-style:none;margin-left: 5%;">
        <li><img src="images/Campus Recruitment Logo/AKS Software Ltd..gif" alt="AKS" title="AKS" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/AMAZON INDIA.jpg" alt="Amazon" title="Amazon" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/APTEAN.jpeg" alt="APTEAN" title="APTEAN" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/ARICENT.png" alt="ARICENT" title="ARICENT" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Accenture.jpg" alt="Accenture" title="Accenture" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Asahi India Glass Ltd..jpg" alt="Asahi" title="Asahi" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Ashiana Housing.jpg" alt="Ashiana" title="Ashiana" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Capgemini.jpg" alt="Capgemini" title="Capgemini" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Cavisson Systems.png" alt="Cavisson" title="Cavisson" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Cignex_Datamatics.jpg" alt="Cignex_Datamatics" title="Cignex_Datamatics" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Cognizant.jpg" alt="Cognizant" title="Cognizant" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Cybage Software.jpg" alt="Cybage" title="Cybage" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Deloitte U.S. India.jpg" alt="Deloitte" title="Deloitte" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/ERA Group.jpg" alt="ERA" title="ERA" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Ericsson.png" alt="Ericsson" title="Ericsson" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/FCS (A TEK SYSTEMS).jpg" alt="FCS" title="FCS" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/FIAT_INDIA.jpg" alt="FIAT_INDIA" title="FIAT_INDIA" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/FLIPKART.png" alt="FLIPKART" title="FLIPKART" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Focus Academy for Career Enhancement.jpg" alt="Focus" title="Focus" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/GyanSys Global Services India.jpg" alt="GyanSys" title="GyanSys" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/HP (R&D).jpg" alt="HP" title="HP" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/I Nautix.jpg" alt="I Nautix" title="I Nautix" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Infosys.png" alt="Infosys" title="Infosys" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Intel India.jpg" alt="Intel" title="Intel" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Josh Technology.png" alt="Josh" title="Josh" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/LnT Infotech.jpg" alt="LnT" title="LnT" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Lowe-Lintas.jpg" alt="Lowe-Lintas" title="Lowe-Lintas" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Mahindra Comviva.jpg" alt="Mahindra Comviva" title="Mahindra Comviva" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Mu-Sigma.jpg" alt="Mu-Sigma" title="Mu-Sigma" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Paharpur Business Center.gif" alt="Paharpur" title="Paharpur" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/R Systems International Ltd..png" alt="R Systems" title="R Systems" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/RANKWATCH.jpg" alt="RANKWATCH" title="RANKWATCH" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Robert Bosch.png" alt="Robert Bosch" title="Robert Bosch" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/SAP Labs.png" alt="SAP" title="SAP" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Shapoorji Pallonji Co.Ltd..jpg" alt="Shapoorji" title="Shapoorji" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Shyam Indus Power Solutions.gif" alt="Shyam" title="Shyam" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/TATA STEEL.jpg" alt="TATA STEEL" title="TATA STEEL" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/TEGA INDUSTRIES.jpg" alt="TEGA" title="TEGA" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Tata-Power.jpg" alt="Tata-Power" title="Tata-Power" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Tech Mahindra.gif" alt="Tech Mahindra" title="Tech Mahindra" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Thoughtworks.png" alt="Thoughtworks" title="Thoughtworks" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Triveni Turbine.jpg" alt="Triveni Turbine" title="Triveni Turbine" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/VOLATAS  LTD..jpg" alt="VOLATAS" title="VOLATAS" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/WIPRO.jpg" alt="WIPRO" title="WIPRO" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/XL Dynamics India.jpg" alt="XL Dynamics" title="XL Dynamics" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/ZENTRON LABS.png" alt="ZENTRON LABS" title="ZENTRON LABS" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/ZYCUS.jpg" alt="ZYCUS" title="ZYCUS" width="60" height="60"></li>
        <li><img src="images/Campus Recruitment Logo/Zeta Interactive.jpg" alt="Zeta Interactive" title="Zeta Interactive" width="60" height="60"></li>

    </ul>
</marquee>
</td>
</table>
<?php
$pageContent = ob_get_contents();
$pageType = 'Home';
ob_end_clean();
include_once 'template2.php';
if (isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg'])) {
    echo $_SESSION['ErrMsg'];
    unset($_SESSION['ErrMsg']);
}
?>

<style>
    .marquee li{
        height: 90px;
    }
    .marquee img {
        margin-top: 50%;
        background: #fff;
        border: solid 1px #ccc;
        padding: 5px;
        width: 128px;
    }
</style>
