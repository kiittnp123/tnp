<?php
ob_start();
$certification=$_GET['cat'];
if($certification=='Microsoft')
    $heading="Microsoft Offering";
    elseif ($certification=='Oracle') 
        $heading="Oracle Offering";
        elseif ($certification=='Adobe') 
            $heading='Adobe Offering';
            elseif ($certification=='hp') 
                $heading='HP Offering';
            elseif ($certification=='Certiport') 
            $heading='Certiport Offering';
            elseif ($certification=='Dassult') 
                $heading='DassultSystem Offering ';
            elseif ($certification=='Autodesk') 
                $heading='Autodesk Offering';
            else
                $heading="IBM Offering";
        
?>
<table width="100%" cellspacing="10" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
    <tr>
        <td><h1><?php echo $heading;?></h1></td>
    </tr>
    <tr>
        <td><?php
        $form='';
        if($certification=='Microsoft'){
            $form.="<table>
                        <tr>
                            <td><a href='../data/microsoft/1.pdf' target='_blank'>98 -372 MTA:  Microsoft .NET Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/2.pdf' target='_blank'>98-373 MTA: Mobile Development Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/3.pdf' target='_blank'>98-374 MTA: Gaming Development Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/4.pdf' target='_blank'>98-365 Windows Server Administration Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/5.pdf' target='_blank'>98-366 Networking Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/6.pdf' target='_blank'>98-367 Security Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/7.pdf' target='_blank'>Exam 98-361 MTA: Software Development Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/8.pdf' target='_blank'>Exam 98-362 TA: Windows Development Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/9.pdf' target='_blank'>Exam 98-363 MTA: Web Development Fundamentals</a></td>
                        </tr>
                        <tr>
                            <td><a href='../data/microsoft/10.pdf' target='_blank'>Exam 98-364 MTA: Database Fundamentals</a></td>
                        </tr>
                    </table>";
            
        }
        elseif ($certification=='Oracle') {
                $form.="<table>
                            <tr>
                                <td><a href='../data/oracle/1.pdf' target='_blank'>Developing Applications With the Java SE 6 Platform (SL-285-SE6)</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/oracle/2.pdf' target='_blank'>Fundamentals of the Java Programming Language, Java SE 6 (SL-110-SE6)</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/oracle/3.pdf' target='_blank'>Oracle Database: Introduction to SQL</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/oracle/4.pdf' target='_blank'>Oracle Database: SQL and PL/SQL Fundamentals</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/oracle/5.pdf' target='_blank'>Web Component Development with Servlets & JSPs, Java EE 6</a></td>
                            </tr>
                        </table>";
        }
        elseif ($certification=='Adobe') {
            $form.="<table>
                            <tr>
                                <td><a href='../data/adobe/1.pdf' target='_blank'>Rich Media Communication using Adobe Flash</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/adobe/2.pdf' target='_blank'>Adobe Certified Associate Brochure</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/adobe/3.pdf' target='_blank'>Adobe Dreamweaver Exam Objectives</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/adobe/4.pdf' target='_blank'>Adobe Flash Exam Objectives</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/adobe/5.pdf' target='_blank'>Adobe Photoshop Exam Objectives</a></td>
                            </tr>
                        </table>";
        }
        elseif ($certification=='Autodesk') {
            $form.="<table>
                            <tr>
                                <td><a href='../data/autodesk/1.pdf' target='_blank'>Autodesk Certification by Certiport</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/autodesk/2.pdf' target='_blank'>Autodesk Inventor Skills</a></td>
                            </tr>
                        </table>";
        }elseif ($certification == 'Certiport') {
             $form.="<table>
                            <tr>
                                <td><a href='../data/certiport/1.pdf' target='_blank'>Certiport Corporate Brochure</a></td>
                            </tr>
                            
                        </table>";
        }elseif ($certification == 'Dassult') {
             $form.="<table>
                            <tr>
                                <td><a href='../data/dassult/1.pdf' target='_blank'>DASSULT SYSTEM CATIA CERTIFICATIONS</a></td>
                            </tr>
                            
                        </table>";
        } elseif($certification == 'hp'){
            $form.="<table>
                            <tr>
                                <td><a href='../data/hp/1.pdf' target='_blank'>HP Accredited Technical Associate Programme</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/hp/2.pdf' target='_blank'>HP ATA - Connected Devices Certification</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/hp/3.pdf' target='_blank'>HP ATA - Servers and Storage certification</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/hp/4.pdf' target='_blank'></a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/hp/5.pdf' target='_blank'></a></td>
                            </tr>
                        </table>";
        }
        else{
            $form.="<table>
                            <tr>
                                <td><a href='../data/ibm/1.pdf' target='_blank'>Test 000-136 IBM Certified Application Developer - Rational Application Developer v7 </a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/ibm/2.pdf' target='_blank'>Test 000-819 IBM Certified Associate Developer - Rational Application Developer V8 </a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/ibm/3.pdf' target='_blank'>IBM Certified Database Associate - DB2 10.1 Fundamentals</a></td>
                            </tr>
                            <tr>
                                <td><a href='../data/ibm/4.pdf' target='_blank'>IBM Certified System Administrator - WebSphere Application Server Network Deployment V7.0</a></td>
                            </tr>
                            
                        </table>";
        }
        echo $form;
        ?></td>
    </tr>
</table>      
<?php
$pageContent = ob_get_contents();
$pageType='Home';
ob_end_clean();
include_once 'template2.php';
?>
