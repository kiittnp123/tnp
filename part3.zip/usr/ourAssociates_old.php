<?php

error_reporting(0);
include_once '../inc/conf.php';
ob_start();
?>
<style type="text/css">
    /* ---------- gallery styles start here ----------------------- */
    .gallery {
        list-style: none;
        margin: 0;
        padding: 0;
    }
    .gallery td {
        padding: 10px;
        margin: 0;
        float: left;
        position: relative;

        height: 130px;
    }
    .gallery img {
        background: #fff;
        border: solid 1px #ccc;
        padding: 5px;
    }
    .gallery td:hover img {
        border-color: #999;
    }
    .gallery em {
        width: 102px;
        background: url(images/bubble.gif) no-repeat;
        padding: 3px 0 6px;
        display: none;
        position: absolute;
        top: -2px;
        left: 20px;
        font-style: normal;
        text-align: center;
    }
    .gallery a {
        text-decoration: none;
        color: #000;
    }
    .gallery a:hover em {
        display: block;
    }
</style>
<h1>Visiting Companies</h1>
<table class="gallery" style="width: 100%;font-family: trebuchet MS; font-size: 13px;line-height: 1.5;text-align: center;font-weight: bold;">
    <tr>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/3I INFOTECH.jpg" alt="3i Infotech" style='height:50px;width:100px;'/><br>3i Infotech</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ABG GROUP.jpg" alt="ABG Group" style='height:50px;width:100px;'/><br>ABG Group</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ACCENTURE.png" alt="Accenture" style='height:50px;width:100px;'/><br>Accenture</a></a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ACCRETE CONSULTING ENGINEERS.jpg" alt="Accrete consulting Engineers" style='height:50px;width:100px;'/><br>Accrete consulting Engineers</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ADEPTO GEOINFORMATICS.jpg" alt="ADEPTO GEOINFORMATICS" style='height:50px;width:100px;'/><br>Adepto Geoinfomatics</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ADP TECHNOLOGY.gif" alt="ADP TECHNOLOGY" style='height:50px;width:100px;'/><br>ADP Technology</a></td>        	
          
       <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/AGNI POWER & ELECTRONICS PVT.LTD.jpg" alt="AGNI POWER & ELECTRONICS PVT.LTD" style='height:50px;width:100px;'><br>AGNI Power & Electronics Pvt. Ltd.</a></td> -->     
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Amazon-Logo.jpg" alt="Amazon" style='height:50px;width:100px;'/><br>Amazon</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/AMDOCS.jpg" alt="AMDOCS" style='height:50px;width:100px;'/><br>AMDOCS</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ARAKYA.jpg" alt="ARAKYA" style='height:50px;width:100px;'/><br>ARAKYA</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/argusoft-logo.jpg" alt="Argusoft India Ltd." style='height:50px;width:100px;'/><br>Argusoft India Ltd.</a></td> 
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Aricent.jpg" alt="ARICENT" style='height:50px;width:100px;'/><br>ARICENT</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ASHIANA HOUSING.gif" alt="Ashiana Housing" style='height:50px;width:100px;'/><br>Ashiana Housing</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/BERGEN SOLAR POWER & ENERGY.jpg" alt="Bergen Solar Power & Energy" style='height:50px;width:100px;'/><br>Bergen Solar Power & Energy</a></td>
    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/BHUSHAN STEEL.jpg" alt="Bhushan Steel" style='height:50px;width:100px;'/><br>Bhushan Steel</a></td>
        <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/CADAPULT TECHNOLOGY.jpg" alt="Cadapult Technology" style='height:50px;width:100px;'/><br>Cadapult Technology</a></td>-->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/CAPGEMINI.png" alt="Capgemini" style='height:50px;width:100px;'/><br>Capgemini</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/CINDA ENGINEERING.png" alt="Cinda Engineering" style='height:50px;width:100px;'/><br>CINDA Engineering</a></td>
        <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/CONCIERGE TECHNOLOGIES.jpg" alt="Concierge Technlogies" style='height:50px;width:100px;'/><br>Concierge Technlogies</a></td>   -->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/cognizant-logo.png" alt="Cognizant" style='height:50px;width:100px;'/><br>Cognizant</a></td>           
        <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/DAS ELECTRONICS.jpg" alt="DAS Electronics" style='height:50px;width:100px;'/><br>DAS Electronics</a></td> -->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/deloitte_logo.gif" alt="Deloitte" style='height:50px;width:100px;'/><br>Deloitte</a></td>    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/DISCOVERTURE SOLUTIONS.jpg" alt="Discoverture Solutions" style='height:50px;width:100px;'/><br>Discoverture Solutions</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/kiitlogo.png" alt="EAM Division,KIIT" style='height:50px;width:100px;'/><br>EAM Division,KIIT</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/elitists-logo.jpg" alt="Elitists" style='height:50px;width:100px;'/><br>Elitists</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ENERCON (WINDWORLD).png" alt="ENERCON" style='height:50px;width:100px;'/><br>ENERCON</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ENZEN GLOBAL SOLUTION.jpg" alt="ENZEN Global Solution" style='height:50px;width:100px;'/><br>ENZEN Global Solution</a></td>    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ERA GROUP.gif" alt="ERA Group" style='height:50px;width:100px;'/><br>ERA Group</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ERICSSON-logo.jpg" alt="ERICSSON" style='height:50px;width:100px;'/><br>ERICSSON</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/EVEREST INDUSTRIES.gif" alt="Everest Industries" style='height:50px;width:100px;'/><br>Everest Industries</a></td>
    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/FUTURE GENERALI.jpg" alt="Future Generali" style='height:50px;width:100px;'/><br>Future Generali</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/GENPACT.jpg" alt="GENPACT" style='height:50px;width:100px;'/><br>GENPACT</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/GYANSYS INFOTECH.png" alt="Gyansys Infotech" style='height:50px;width:100px;'/><br>Gyansys Infotech</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/HCL INFOSYSTEM.jpg" alt="HCL Infosystem" style='height:50px;width:100px;'/><br>HCL Infosystem</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/hp-logo.gif" alt="HP India" style='height:50px;width:100px;'/><br>HP India</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/IBM INDIA.jpg" alt="IBM India" style='height:50px;width:100px;'/><br>IBM India</a></td>
        <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/IDENTITY.jpg" alt="IDENTITY" style='height:50px;width:100px;'/><br>IDENTITY</a></td> -->
    
        <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/IDEO TECHNOLOGICAL RESOURCE LTD.png" alt="IDEO Technological Resource ltd." style='height:50px;width:100px;'/><br>IDEO Technological Resource Ltd.</a></td> -->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/I-DESIGN.jpg" alt="I-Design" style='height:50px;width:100px;'/><br>I-Design</a></td>
        <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/IDSPL.png" alt="IDSPL" style='height:50px;width:100px;'/><br>IDSPL</a></td> -->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Incept-logo.png" alt="INCEPT Techonology" style='height:50px;width:100px;'/><br>INCEPT Techonology</a></td>
     <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/INDIA FIRST LIFE INSURANCE.gif" alt="India First Life Insurance" style='height:50px;width:100px;'/><br>India First Life Insurance</a></td>-->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/INDIAN SEAMLESS METAL TUBES.jpg" alt="Indian Seamless Metal Tubes" style='height:50px;width:100px;'/><br>Indian Seamless Metal Tubes</a></td>
    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/INFOTECH ENTERPRISES LTD.jpg" alt="Infotech Enterprises Ltd." style='height:50px;width:100px;'/><br>Infotech Enterprises Ltd.</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/INTEL INDIA.png" alt="Intel India" style='height:50px;width:100px;'/><br>Intel India</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ITW SIGNODE.jpg" alt="ITW SIGNODE" style='height:50px;width:100px;'/><br>ITW SIGNODE</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/J KUMAR INFRASTRUCTURE.png" alt="J Kumar Infrastructure" style='height:50px;width:100px;'/><br>J Kumar Infrastructure</a></td>   
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/JSPL-logo.jpg" alt="Jindal Steel Power Limited" style='height:50px;width:100px;'/><br>Jindal Steel Power Limited</a></td>           
      <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/KEC INTERNATIONAL.jpg" alt="KEC International" style='height:50px;width:100px;'/><br>KEC International</a></td>-->      
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/KIMS.gif" alt="KIMS" style='height:50px;width:100px;'/><br>KIMS</a></td>        
    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/KINAM RICE & ALLIED PRODUCTS.jpg" alt="Kinam Rice & Allied Products" style='height:50px;width:100px;'/><br>Kinam Rice & Allied Products</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/KURLON.gif" alt="KURLON" style='height:50px;width:100px;'/><br>KURLON</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Ln T ECC.jpg" alt="L&T ECC" style='height:50px;width:100px;'/><br>L&T ECC</a></td>
        <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/MGMR NET LTD.jpg" alt="MGMR NET Ltd." style='height:50px;width:100px;'/><br>MGMR NET Ltd.</a></td>-->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Mahindra Comviva-logo.png" alt="Mahindra Comviva" style='height:50px;width:100px;'/><br>Mahindra Comviva</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/MICROSOFT.png" alt="Microsoft" style='height:50px;width:100px;'/><br>Microsoft</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/mrf-logo.png" alt="MRF Tyre" style='height:50px;width:100px;'/><br>MRF Tyre</a></td>
    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/MU-SIGMA.jpg" alt="MU-SIGMA" style='height:50px;width:100px;'/><br>MU-SIGMA</a></td>
        <!--<td style="width: 14.28%"><a href="#"><img src="images/comp_logo/NOVEL TELENET.png" alt="Novel Telenet" style='height:50px;width:100px;'/><br>Novel Telenet</a></td>-->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/NTT DATA.png" alt="NTT Data" style='height:50px;width:100px;'/><br>NTT Data</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ORACLE INDIA (P) LTD.jpg" alt="Oracle India(P) Ltd." style='height:50px;width:100px;'/><br>Oracle India(P) Ltd.</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/POSCO MAHARASTRA STEEL PVT. LTD.png" alt="Posco Maharastra Steel Pvt. Ltd." style='height:50px;width:100px;'/><br>Posco Maharastra Steel Pvt. Ltd.</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/QED ENABLED SOLUTIONS.jpg" alt="QED Enabled Solutions" style='height:50px;width:100px;'/><br>QED Enabled Solutions</a></td>
           
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/RAM KRISHNA FORGING LTD.jpg" alt="Ram Krishna Forging Ltd." style='height:50px;width:100px;'/><br>Ram Krishna Forging Ltd.</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SAG INFOTECH.jpg" alt="SAG Infotech" style='height:50px;width:100px;'/><br>SAG Infotech</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SANKALP SEMI CONDUCTOR.jpg" alt="Sankalp Semi Conductor" style='height:50px;width:100px;'/><br>Sankalp Semi Conductor</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SAP.png" alt="SAP" style='height:50px;width:100px;'/><br>SAP</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SEW INFRASTRUCTURE.png" alt="SEW Infrastructure" style='height:50px;width:100px;'/><br>SEW Infrastructure</a></td>       
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SHAPOORJI & PALLONJI.png" alt="Shapoorji & Pallonji" style='height:50px;width:100px;'/><br>Shapoorji & Pallonji</a></td>  
                
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SHRIRAM TRANSPORT FINANCE LTD.jpg" alt="Shriram Transport Finance Ltd." style='height:50px;width:100px;'/><br>Shriram Transport Finance Ltd.</a></td>  
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SIEMENS INFORMATION SYSTEMS LTD.jpg" alt="Siemens Information Systems Ltd." style='height:50px;width:100px;'/><br>Siemens Information Systems Ltd.</a></td>  
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SM CONSULTANTS.png" alt="SM Consultants" style='height:50px;width:100px;'/><br>SM Consultants</a></td>          
        <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/SMARTCLUES.png" alt="Smartclues" style='height:50px;width:100px;'/><br>Smartclues</a></td>          -->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/STERLING & WILLSON.jpg" alt="Sterling & Willson" style='height:50px;width:100px;'/><br>Sterling & Willson</a></td>       
        <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TAKSHAK GROUP.jpg" alt="Takshak Group" style='height:50px;width:100px;'/><br>Takshak Group</a></td> -->
                  
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TATA POWER.jpg" alt="Tata Power" style='height:50px;width:100px;'/><br>Tata Power</a></td>       
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TATA STEEL.jpg" alt="Tata Steel" style='height:50px;width:100px;'/><br>Tata Steel</a></td>       
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TCS.jpg" alt="TCS" style='height:50px;width:100px;'/><br>TCS</a></td>       
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TEBMA SHIPYARD.jpg" alt="Temba Shipyard" style='height:50px;width:100px;'/><br>Temba Shipyard</a></td>       
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TEGA INDUSTRIES.gif" alt="TEGA Industries" style='height:50px;width:100px;'/><br>TEGA Industries</a></td>  
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TRACTORS INDIA LTD.gif" alt="Tractors India Ltd." style='height:50px;width:100px;'/><br>Tractors India Ltd.</a></td>
                  
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/TRICON INFOTECH.jpg" alt="Tricon Infotech" style='height:50px;width:100px;'/><br>Tricon Infotech</a></td>    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/UNISYS GLOBAL SERVICES.jpg" alt="Unisys Global Services" style='height:50px;width:100px;'/><br>Unisys Global Services</a></td>  
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ust_global_logo.jpg" alt="UST Global" style='height:50px;width:100px;'/><br>UST Global</a></td>          
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/VEDANTA.jpg" alt="Vedanta" style='height:50px;width:100px;'/><br>Vedanta</a></td>    
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/VYOM LABS.png" alt="VYOM Labs" style='height:50px;width:100px;'/><br>VYOM Labs</a></td> 
        <!-- <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ZENOOVA TECHNOLOGIES.jpg" alt="Zenoova Technologies" style='height:50px;width:100px;'/><br>Zenoova Technologies</a></td> -->
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ZENTRON LABS.jpg" alt="Zentron Labs" style='height:50px;width:100px;'/><br>Zentron Labs</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/zycus-logo.png" alt="Zycus" style='height:50px;width:100px;'/><br>Zycus</a></td>
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/fcs-logo.jpg" alt="FCS" style='height:50px;width:100px;'/><br>FCS</a></td>
         <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/AKS SoftwareLimite.gif" alt="AKS SoftwareLimite" style='height:50px;width:100px;'/><br>AKS SoftwareLimite</a></td>
         <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Cumi_logo.jpg" alt="Cumi" style='height:50px;width:100px;'/><br>Cumi</a></td>
         <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/inautix.png" alt="inautix" style='height:50px;width:100px;'/><br>inautix</a></td>
          <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/ThoughtWorks.jpg" alt="ThoughtWorks" style='height:50px;width:100px;'/><br>ThoughtWorks</a></td>
          <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Fiat.jpg" alt="Fiat" style='height:50px;width:100px;'/><br>Fiat</a></td>
          
          <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/AK Software.png" alt="AK Software" style='height:50px;width:100px;'/><br>AK Software</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Aptean.png" alt="Aptean" style='height:50px;width:100px;'/><br>Aptean</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/FCS-Tek System.png" alt="FCS-Tek System" style='height:50px;width:100px;'/><br>FCS-Tek System</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Fiat India Automobile.png" alt="Fiat India Automobile" style='height:50px;width:100px;'/><br>Fiat India Automobile</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Inoutix.png" alt="Inoutix" style='height:50px;width:100px;'/><br>Inoutix</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Lowe Lintas.png" alt="Lowe Lintas" style='height:50px;width:100px;'/><br>Lowe Lintas</a></td>        
        <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/Rank Watch.png" alt="Rank Watch" style='height:50px;width:100px;'/><br>Rank Watch</a></td>        
          
          <td style="width: 14.28%"><a href="#"><img src="images/comp_logo/l&t-info.png" alt="l&t-info" style='height:50px;width:100px;'/><br>l&t-info</a></td>
    </tr>
</table>

<?php

$pageContent = ob_get_contents();
$pageType = 'Home';
ob_end_clean();
include_once 'template2.php';
?>