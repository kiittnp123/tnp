<?php
include_once '../db.php';
include_once '../inc/conf.php';
$todayDate = date("Y-m-d");
$sqlnews="SELECT * FROM tbl_news WHERE STATUS = 'Active' and '$todayDate' between start_date and end_date order by start_date desc";
$res=mysql_query("$sqlnews");
ob_start();
?>
<table width="100%" cellspacing="10" cellpadding="10" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
    <tr>
        <td><h1>News and Events</h1></td>
    </tr>

        <?php		
		$i=0;
		while($data=mysql_fetch_array($res))
		{ 
		$i++;
		//to display the new.gif image for 24hour within the publication of news                                 
	        $published_date = strtotime($data['start_date']);
        	$now = time();
	        $time_diff = $now - $published_date;
	        if (($time_diff / (60 * 60 * 24)) < 1)
	            $new = "<img src='image/new.gif' width='30' height='15' />";
        	else
	            $new = "";
		?>
                    <tr>
                        <td>
                            <fieldset <?php if($i%2==0) echo 'style="background-color: #D7D7D7;"' ?>>
                             <h3><?php echo $data['heading'].$new; ?></h3>
                          <p> <b>Date:  <?php echo $data['start_date'] ?></b></p>
                             <?php
                             if($data['news_img'] != '')
                             {
                             ?>
                             <img src="<?php echo $data['news_img'] ?>" alt="Image" width="125" height="125" align="left" style="padding: 10px;">
                            <?php
                             }
                            ?>
                    <p><br />
                       <?php echo $data['content'] ?></p>
                            </fieldset>
                        </td>
                    </tr>
        <?php
		}
		?>
</table>
<?php
$pageContent = ob_get_contents();
$pageType="News";
ob_end_clean();
include_once 'template2.php';
?>