<?php
ob_start();
include_once 'protectedStudent.php';
include_once '../db.php';
$username=$_SESSION['userName'];
if($_SESSION['regdSetting']=="ON"){
//var_dump($_POST);
if(isset($_POST['btn_save_personal']) && !empty($_POST['btn_save_personal']) && $_POST['btn_save_personal']=='PROCEED TOWARDS ACADEMIC SECTION')
    {
        $name=mysql_real_escape_string($_POST['fname'])." ".mysql_real_escape_string($_POST['mname'])." ".mysql_real_escape_string($_POST['lname']);
        $yearjoin=mysql_real_escape_string($_POST['yearjoin']);
	$yr_passout=mysql_real_escape_string($_POST['yearpass']);
        $boarding=mysql_real_escape_string($_POST['boarding']);
	$category=mysql_real_escape_string($_POST['category']);
	$gender=mysql_real_escape_string($_POST['gender']);
        $dob=mysql_real_escape_string($_POST['dob']);
        $perm_contact=mysql_real_escape_string($_POST['permanent_contact']);
        $stu_mobile=mysql_real_escape_string($_POST['txtmobile']);
        $stu_email=mysql_real_escape_string($_POST['txtaltemail']);
        $fname=mysql_real_escape_string($_POST['txtfhname']);
        $fmobile=mysql_real_escape_string($_POST['txtfmobile']);
	$femail=mysql_real_escape_string($_POST['txtfemail']);
	$f_org=mysql_real_escape_string($_POST['father_industry']);
	/*$f_address=mysql_real_escape_string($_POST['father_post']);*/
	$father_add_1=mysql_real_escape_string($_POST['father_add_1']);
	$father_add_2=mysql_real_escape_string($_POST['father_add_2']);
	$father_add_city=mysql_real_escape_string($_POST['father_add_city']);
	$father_add_state=mysql_real_escape_string($_POST['father_add_state']);
	$father_add_pin=mysql_real_escape_string($_POST['father_add_pin']);
	/*$perm_address=mysql_real_escape_string($_POST['txtpermadd']);*/
	$permanent_add_1=mysql_real_escape_string($_POST['permanent_add_1']);
	$permanent_add_2=mysql_real_escape_string($_POST['permanent_add_2']);
	$permanent_add_city=mysql_real_escape_string($_POST['permanent_add_city']);
	$permanent_add_state=mysql_real_escape_string($_POST['permanent_add_state']);
	$permanent_add_pin=mysql_real_escape_string($_POST['permanent_add_pin']);
	/*$corr_address=mysql_real_escape_string($_POST['txtcorresadd']);*/
	$corres_add_1=mysql_real_escape_string($_POST['corres_add_1']);
	$corres_add_2=mysql_real_escape_string($_POST['corres_add_2']);
	$corres_add_city=mysql_real_escape_string($_POST['corres_add_city']);
	$corres_add_state=mysql_real_escape_string($_POST['corres_add_state']);
	$corres_add_pin=mysql_real_escape_string($_POST['corres_add_pin']);
        
        $destination='';
	if($_FILES['img']['type'] == 'image/png' ||
           $_FILES['img']['type'] == 'image/jpeg' || 
           $_FILES['img']['type'] == 'image/gif')
			   {
				   $std_id="select student_id from tbl_student where email='$username'";
				   $res_id=mysql_query($std_id);
				   $data=mysql_fetch_array($res_id);
                                   $id=$data[0];
                                   $arr=explode(".", $_FILES['img']['name']);
                                   $ext=end($arr);
                                   $destination="../img/student".$id.".".$ext;
                                   $res=move_uploaded_file($_FILES['img']['tmp_name'], $destination);
                           }
	$personalUpdateSql="UPDATE tbl_student 
                            set
                            name='$name',
                            year_join=$yearjoin,
                            year_passout=$yr_passout,
                            boarding='$boarding',
                            category='$category',
                            gender='$gender',
                            dob='$dob',
                            mobile_perm='$perm_contact',
                            mobile='$stu_mobile',
                            alt_email='$stu_email',
                            father_name='$fname',
                            father_mobile='$fmobile',
                            father_email='$femail',
                            father_add_1='$father_add_1',
							father_add_2='$father_add_2',
							father_add_city='$father_add_city',
							father_add_state='$father_add_state',
							father_add_pin='$father_add_pin',
                            father_org='$f_org',
                            permanent_add_1='$permanent_add_1',
							permanent_add_2='$permanent_add_2',
							permanent_add_city='$permanent_add_city',
							permanent_add_state='$permanent_add_state',
							permanent_add_pin='$permanent_add_pin',
                            corres_add_1='$corres_add_1',
							corres_add_2='$corres_add_2',
							corres_add_city='$corres_add_city',
							corres_add_state='$corres_add_state',
							corres_add_pin='$corres_add_pin',
                            image='$destination'
                            where email='$username'";
	$personalUpdateRes=  mysql_query($personalUpdateSql);
        //echo $personalUpdateSql;
        if($personalUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("Personal information saved. Please proceed with academic information")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
}
if(isset($_POST['btn_save_academic']) && !empty($_POST['btn_save_academic']) && $_POST['btn_save_academic']=='PROCEED TO FINAL SUBMISSION')
    {
        if(isset($_POST['ssc_done']) && !empty($_POST['ssc_done']) && $_POST['ssc_done']=='ssc'){
            $ssc_school=mysql_real_escape_string($_POST['ssc_school']);
			$ssc_board=mysql_real_escape_string($_POST['ssc_board']);
            $ssc_state=mysql_real_escape_string($_POST['ssc_state']);
            $ssc_yop=mysql_real_escape_string($_POST['ssc_yop']);
            $ssc_board_total=mysql_real_escape_string($_POST['ssc_board_total']);
            $ssc_board_secure=mysql_real_escape_string($_POST['ssc_board_secured']);
            $ssc_total=mysql_real_escape_string($_POST['ssc_total']);
            $ssc_secure=mysql_real_escape_string($_POST['ssc_secured']);
            $ssc_distance=mysql_real_escape_string($_POST['ssc_distance']);
        }else{
            $ssc_school='NA';
			$ssc_board='NA';
            $ssc_state='NA';
            $ssc_yop=0;
            $ssc_board_total=0;
            $ssc_board_secure=0;
            $ssc_total=0;
            $ssc_secure=0;
            $ssc_distance='NA';
        }
        if(isset($_POST['hsc_done']) && !empty($_POST['hsc_done']) && $_POST['hsc_done']=='hsc'){
            $hsc_school=mysql_real_escape_string($_POST['hsc_school']);
			$hsc_board=mysql_real_escape_string($_POST['hsc_board']);
            $hsc_state=mysql_real_escape_string($_POST['hsc_state']);
            $hsc_yop=mysql_real_escape_string($_POST['hsc_yop']);
            $hsc_yoj=mysql_real_escape_string($_POST['hsc_yoj']);
            $hsc_board_total=mysql_real_escape_string($_POST['hsc_board_total']);
            $hsc_board_secure=mysql_real_escape_string($_POST['hsc_board_secured']);
            $hsc_total=mysql_real_escape_string($_POST['hsc_total']);
            $hsc_secure=mysql_real_escape_string($_POST['hsc_secured']);
            $hsc_distance=mysql_real_escape_string($_POST['hsc_distance']);
        }else{
            $hsc_school='NA';
			$hsc_board='NA';
            $hsc_state='NA';
            $hsc_yoj=0;
            $hsc_yop=0;
            $hsc_board_total=0;
            $hsc_board_secure=0;
            $hsc_total=0;
            $hsc_secure=0;
            $hsc_distance='NA';
        }
        if(isset($_POST['dip_done']) && !empty($_POST['dip_done']) && $_POST['dip_done']=='dip'){
            $dip_school=mysql_real_escape_string($_POST['dip_school']);
			$dip_board=mysql_real_escape_string($_POST['dip_board']);
            $dip_state=mysql_real_escape_string($_POST['dip_state']);
            $dip_yop=mysql_real_escape_string($_POST['dip_yop']);
            $dip_yoj=mysql_real_escape_string($_POST['dip_yoj']);
            $dip_board_total=mysql_real_escape_string($_POST['dip_board_total']);
            $dip_board_secure=mysql_real_escape_string($_POST['dip_board_secured']);
            $dip_total=mysql_real_escape_string($_POST['dip_total']);
            $dip_secure=mysql_real_escape_string($_POST['dip_secured']);
            $dip_distance=mysql_real_escape_string($_POST['dip_distance']);
        }else{
            $dip_school='NA';
			$dip_board='NA';
            $dip_state='NA';
            $dip_yop=0;
            $dip_yoj=0;
            $dip_board_total=0;
            $dip_board_secure=0;
            $dip_total=0;
            $dip_secure=0;
            $dip_distance='NA';
        }
        if(isset($_POST['gra_done']) && !empty($_POST['gra_done']) && $_POST['gra_done']=='gra'){
            $gra_school=mysql_real_escape_string($_POST['gra_school']);
			$gra_board=mysql_real_escape_string($_POST['gra_board']);
            $gra_state=mysql_real_escape_string($_POST['gra_state']);
            $gra_yop=mysql_real_escape_string($_POST['gra_yop']);
            $gra_yoj=mysql_real_escape_string($_POST['gra_yoj']);
            $gra_board_total=mysql_real_escape_string($_POST['gra_board_total']);
            $gra_board_secure=mysql_real_escape_string($_POST['gra_board_secured']);
            $gra_total=mysql_real_escape_string($_POST['gra_total']);
            $gra_secure=mysql_real_escape_string($_POST['gra_secured']);
            $gra_distance=mysql_real_escape_string($_POST['gra_distance']);
            $gra_stream=mysql_real_escape_string($_POST['gra_stream']);
            $gra_honors=mysql_real_escape_string($_POST['gra_honours']);
        }else{
            $gra_school='NA';
			$gra_board='NA';
            $gra_state='NA';
            $gra_yop=0;
            $gra_yoj=0;
            $gra_board_total=0;
            $gra_board_secure=0;
            $gra_total=0;
            $gra_secure=0;
            $gra_distance='NA';
            $gra_stream='NA';
            $gra_honors='NA';
        }
        
        $branch=mysql_real_escape_string($_POST['branch']);
	$stream=mysql_real_escape_string($_POST['stream']);
        if(isset($_POST['lateral_entry']) && !empty($_POST['lateral_entry']))
            $lateralEntry=mysql_real_escape_string($_POST['lateral_entry']);
        else
            $lateralEntry = 'no';
        
        if($lateralEntry == 'yes'){
            $sgpa_1=0.00;
            $sgpa_2=0.00;
            $cgpa_1=0.00;
            $cgpa_2=0.00;
            $back_1=0;
            $back_2=0;
        }else{
            $sgpa_1=mysql_real_escape_string($_POST['sgpa_1']);
            $sgpa_2=mysql_real_escape_string($_POST['sgpa_2']);
            $cgpa_1=mysql_real_escape_string($_POST['cgpa_1']);
            $cgpa_2=mysql_real_escape_string($_POST['cgpa_2']);
            $back_1=mysql_real_escape_string($_POST['backlog_1']);
            $back_2=mysql_real_escape_string($_POST['backlog_2']);
        }
	$sgpa_3=mysql_real_escape_string($_POST['sgpa_3']);
	$sgpa_4=mysql_real_escape_string($_POST['sgpa_4']);
	$sgpa_5=mysql_real_escape_string($_POST['sgpa_5']);
	$sgpa_6=mysql_real_escape_string($_POST['sgpa_6']);
        $cgpa_3=mysql_real_escape_string($_POST['cgpa_3']);
	$cgpa_4=mysql_real_escape_string($_POST['cgpa_4']);
	$cgpa_5=mysql_real_escape_string($_POST['cgpa_5']);
	$cgpa_6=mysql_real_escape_string($_POST['cgpa_6']);
        $back_3=mysql_real_escape_string($_POST['backlog_3']);
	$back_4=mysql_real_escape_string($_POST['backlog_4']);
	$back_5=mysql_real_escape_string($_POST['backlog_5']);
	$back_6=mysql_real_escape_string($_POST['backlog_6']);
        if($stream == 'M.Tech' || $stream == 'MCA'){
            $sgpa_7=0.00;
            $sgpa_8=0.00;
            $sgpa_9=0.00;
            $sgpa_10=0.00;
            $cgpa_7=0.00;
            $cgpa_8=0.00;
            $cgpa_9=0.00;
            $cgpa_10=0.00;
            $back_7=0;
            $back_8=0;
            $back_9=0;
            $back_10=0;
        }else{
            $sgpa_7=mysql_real_escape_string($_POST['sgpa_7']);
            $sgpa_8=mysql_real_escape_string($_POST['sgpa_8']);
            $cgpa_7=mysql_real_escape_string($_POST['cgpa_7']);
            $cgpa_8=mysql_real_escape_string($_POST['cgpa_8']);
            $back_7=mysql_real_escape_string($_POST['backlog_7']);
            $back_8=mysql_real_escape_string($_POST['backlog_8']);
            if($stream == 'B.Tech'){
                $sgpa_9=0.00;
                $sgpa_10=0.00;
                $cgpa_9=0.00;
                $cgpa_10=0.00;
                $back_9=0;
                $back_10=0;
            }else{
                $sgpa_9=mysql_real_escape_string($_POST['sgpa_9']);
                $sgpa_10=mysql_real_escape_string($_POST['sgpa_10']);
                $cgpa_9=mysql_real_escape_string($_POST['cgpa_9']);
                $cgpa_10=mysql_real_escape_string($_POST['cgpa_10']);
                $back_9=mysql_real_escape_string($_POST['backlog_9']);
                $back_10=mysql_real_escape_string($_POST['backlog_10']);
            }
        }
if(isset($_POST['ssc_done']) && $_POST['ssc_done']=='ssc' && isset($_POST['hsc_done']) && $_POST['hsc_done']=='hsc'){
 $gap_10_12 = $_POST['hsc_yoj'] - $_POST['ssc_yop'];
}else{
 $gap_10_12 = 0;
}
if(isset($_POST['ssc_done']) && $_POST['ssc_done']=='ssc' && isset($_POST['dip_done']) && $_POST['dip_done']=='dip'){
  $gap_10_dip = $_POST['dip_yoj'] - $_POST['ssc_yop'];
}else{
  $gap_10_dip = 0;
}
if(isset($_POST['hsc_done']) && $_POST['hsc_done']=='hsc' && isset($_POST['gra_done']) && $_POST['gra_done']=='gra'){
  $gap_12_gra = $_POST['gra_yoj'] - $_POST['hsc_yop'];
}else{
  if(isset($_POST['hsc_done']) && $_POST['hsc_done']=='hsc' )
    $gap_12_gra = $_POST['year_join'] - $_POST['hsc_yop'];
  else
    $gap_12_gra = 0;
}
if(isset($_POST['dip_done']) && $_POST['dip_done']=='dip' && isset($_POST['gra_done']) && $_POST['gra_done']=='gra'){
  $gap_dip_gra = $_POST['gra_yoj'] - $_POST['dip_yop'];
}else{
  if(isset($_POST['dip_done']) && $_POST['dip_done']=='dip' )
    $gap_dip_gra = $_POST['year_join'] - $_POST['dip_yop'];
  else
    $gap_dip_gra = 0;
}
if(isset($_POST['gra_done']) && $_POST['gra_done']=='gra'){
    $gap_gra_pg = $_POST['year_join'] - $_POST['gra_yop'];
}else{
    $gap_gra_pg = 0;
}
        $academicUpdateSql="UPDATE `tbl_student` SET 
                         `branch`='$branch',
                         `stream`='$stream',
                         `ssc_school`='$ssc_school',
						 `ssc_board`='$ssc_board',
                         `ssc_state`='$ssc_state',
                         `ssc_yop`='$ssc_yop',
                         `ssc_board_total`='$ssc_board_total',
                         `ssc_board_secure`='$ssc_board_secure',
                         `ssc_total`='$ssc_total',
                         `ssc_secure`='$ssc_secure',
                         `ssc_distance`='$ssc_distance',
                         `hsc_school`='$hsc_school',
						 `hsc_board`='$hsc_board',
                         `hsc_state`='$hsc_state',
                         `hsc_yop`='$hsc_yop',
                         `hsc_yoj`='$hsc_yoj',
                         `hsc_board_total`='$hsc_board_total',
                         `hsc_board_secure`='$hsc_board_secure',
                         `hsc_total`='$hsc_total',
                         `hsc_secure`='$hsc_secure',
                         `hsc_distance`='$hsc_distance',
                         `dip_school`='$dip_school',
						 `dip_board`='$dip_board',
                         `dip_state`='$dip_state',
                         `dip_yop`='$dip_yop',
                         `dip_yoj`='$dip_yoj',
                         `dip_board_total`='$dip_board_total',
                         `dip_board_secure`='$dip_board_secure',
                         `dip_total`='$dip_total',
                         `dip_secure`='$dip_secure',
                         `dip_distance`='$dip_distance',
                         `gra_school`='$gra_school',
						 `gra_board`='$gra_board',
                         `gra_state`='$gra_state',
                         `gra_yop`='$gra_yop',
                         `gra_yoj`='$gra_yoj',
                         `gra_board_total`='$gra_board_total',
                         `gra_board_secure`='$gra_board_secure',
                         `gra_total`='$gra_total',
                         `gra_secure`='$gra_secure',
                         `gra_distance`='$gra_distance',
                         `gra_stream`='$gra_stream',
                         `gra_honors`='$gra_honors',
                         `sgpa_1`='$sgpa_1',
                         `sgpa_2`='$sgpa_2',
                         `sgpa_3`='$sgpa_3',
                         `sgpa_4`='$sgpa_4',
                         `sgpa_5`='$sgpa_5',
                         `sgpa_6`='$sgpa_6',
                         `sgpa_7`='$sgpa_7',
                         `sgpa_8`='$sgpa_8',
                         `sgpa_9`='$sgpa_9',
                         `sgpa_10`='$sgpa_10',
                         `cgpa_1`='$cgpa_1',
                         `cgpa_2`='$cgpa_2',
                         `cgpa_3`='$cgpa_3',
                         `cgpa_4`='$cgpa_4',
                         `cgpa_5`='$cgpa_5',
                         `cgpa_6`='$cgpa_6',
                         `cgpa_7`='$cgpa_7',
                         `cgpa_8`='$cgpa_8',
                         `cgpa_9`='$cgpa_9',
                         `cgpa_10`='$cgpa_10',
                         `back_1`='$back_1',
                         `back_2`='$back_2',
                         `back_3`='$back_3',
                         `back_4`='$back_4',
                         `back_5`='$back_5',
                         `back_6`='$back_6',
                         `back_7`='$back_7',
                         `back_8`='$back_8',
                         `back_9`='$back_9',
                         `back_10`='$back_10',
                         `lateral`='$lateralEntry',
                         `gap_10_12`='$gap_10_12',
                         `gap_10_dip`='$gap_10_dip',
                         `gap_12_gra`='$gap_12_gra',
                         `gap_dip_gra`='$gap_dip_gra',
                         `gap_gra_pg`='$gap_gra_pg'
                          WHERE email='$username'";
        //echo $academicUpdateSql;
        $academicUpdateRes=  mysql_query($academicUpdateSql);
        if($academicUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("Academic information saved. Please proceed with final part")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
}
if(isset($_POST['btn_save_final']) && !empty($_POST['btn_save_final']) && $_POST['btn_save_final']=='SUBMIT FOR VERIFICATION')
    {
        
        $gap_reason=mysql_real_escape_string($_POST['gap_reason']);
	$hobby=mysql_real_escape_string($_POST['hobby']);
	$preference=mysql_real_escape_string($_POST['pref']);
        $projectName=mysql_real_escape_string($_POST['pro1_name']);
        $projectOrg=mysql_real_escape_string($_POST['pro1_org']);
        $projectDuration=mysql_real_escape_string($_POST['pro1_dur']);
        $projectGuide=mysql_real_escape_string($_POST['pro1_guide']);
        $projectSummary=mysql_real_escape_string($_POST['pro1_sum']);
        
        $finalUpdateSql="update tbl_student set
                         gap_reason='$gap_reason',
                         hobby='$hobby',
                         preference='$preference',
                         pro_name='$projectName',
                         pro_org='$projectOrg',
                         pro_duration='$projectDuration',
                         pro_guide='$projectGuide',
                         pro_summary='$projectSummary',
                         status='Pending'
                         where email='$username'";
        $finalUpdateRes=  mysql_query($finalUpdateSql);
        if($finalUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("You have been successfully registered.")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
}
$sql="select * from tbl_student where email='$username'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
$status=$row['status'];
if($status=='Created')
    {
    if(isset($_GET['section']) && !empty($_GET['section']) && $_GET['section']=='personal')
        {
?>
<script type="text/javascript">
function chkCorresAddress(id){
	if(document.getElementById(id).checked==true){
		document.getElementById("corres_add_1").value=document.getElementById("permanent_add_1").value;
		document.getElementById("corres_add_1").readOnly=true;
	    document.getElementById("corres_add_2").value=document.getElementById("permanent_add_2").value;
		document.getElementById("corres_add_2").readOnly=true;
		document.getElementById("corres_add_city").value=document.getElementById("permanent_add_city").value;
		document.getElementById("corres_add_city").readOnly=true;
		document.getElementById("corres_add_state").value=document.getElementById("permanent_add_state").value;
		document.getElementById("corres_add_state").readOnly=true;
		document.getElementById("corres_add_pin").value=document.getElementById("permanent_add_pin").value;	
		document.getElementById("corres_add_pin").readOnly=true;
		}
	else if(document.getElementById(id).checked==false){
		document.getElementById("corres_add_1").value="";
		document.getElementById("corres_add_1").readOnly=false;
	    document.getElementById("corres_add_2").value="";
		document.getElementById("corres_add_2").readOnly=false;
		document.getElementById("corres_add_city").value="";
		document.getElementById("corres_add_city").readOnly=false;
		document.getElementById("corres_add_state").value="";
		document.getElementById("corres_add_state").readOnly=false;
		document.getElementById("corres_add_pin").value="";	
		document.getElementById("corres_add_pin").readOnly=false;
		}
	}

    function validatePersonalInfo(c)
    {
        if(c.fname.value==''){
            alert('Name cannot be empty');
            return false;
        }
        if(c.permanent_contact.value==''){
            alert('Permanent Contact Number cannot be empty');
            return false;
        }
        if(c.txtmobile.value==''){
            alert('Mobile Number(self) cannot be empty');
            return false;
        }
        if(c.txtaltemail.value==''){
            alert('Student Email cannot be empty');
            return false;
        }
        if(c.txtfhname.value==''){
            alert(' Father Name cannot be empty');
            return false;
        }
        if(c.txtfmobile.value==''){
            alert('Father Mobile cannot be empty');
            return false;
        }
        
        if(c.father_industry.value==''){
            alert('Father Occupation cannot be empty');
            return false;
        }
        if(c.father_post.value==''){
            alert('Father Designation cannot be empty');
            return false;
        }
        if(c.txtpermadd.value==''){
            alert('Permanent Address cannot be empty');
            return false;
        }
        if(c.txtcorresadd.value==''){
            alert('Correspondence Address cannot be empty');
            return false;
        }
        return true;
    }

</script>
<form action="editProfileNew.php" method="post" enctype="multipart/form-data" onsubmit="return validatePersonalInfo(this)">
        <input type="hidden" name="section" value="academic" />
        <table align="center" width="1000">
        <tr>
            <td colspan="2" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>REGISTRATION FORM</b></font></td>
        </tr>
        <tr>
            <td colspan="2" align="left" bgcolor="yellow" style="color: red;">Note: <ul>
                    <li>You will be able to edit your profile only once. </li>
                    <li>After it is submitted for verification, no changes would be allowed. </li>
                    <li>Please be careful while entering your information, and make sure that you enter only the correct Information. </li>
                    <li>For any further issues regarding the information stored in your profile, please contact Training and Placement Cell for assistance.</li></ul></td>
        </tr>
        <tr>
            <td align="left" colspan="2" bgcolor="#003399"><font color="#FFFFFF">Personal Detail</font></td>
        </tr>
        <tr>
            <td align="left" colspan="2">
                First Name:<input type="text" name="fname" size="25" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                Middle Name:<input type="text" name="mname" size="25" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                Last Name:<input type="text" name="lname" size="25" />
            </td>
        </tr>
        <tr>
            <td align="left" >
                Roll no:
            </td>
            <td>
                <input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" />
            </td>
        </tr>
        <tr>
            <td>
            Year of Joining:
            </td>
            <td>
            <select name="yearjoin" id="yearjoin">
            <option><?php echo $row['year_join']?></option>
            <?php include '../inc/yearList.php'; ?>
            </select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Passing:
            </td>
            <td>
                <select name="yearpass">
                <option><?php echo $row['year_passout']?></option>
                    <?php include '../inc/yearList.php'; ?>
                </select>
            </td>
        </tr>
        
        
        <tr>
            <td align="left">
                       Boarding:
            </td>
            <td>           
            <select name="boarding">
                                    <option>Hostel</option>
                                    <option>Day Scholar</option>
                                </select>
            </td>
        </tr>
        <tr>
            <td>
                Category:
                </td>
            <td>
                <select name="category">
                                    <option>General</option>
                                    <option>OBC</option>
                                    <option>Minority</option>
                                    <option>PH</option>
                                    <option>SC</option>
                                    <option>ST</option>
                                    <option>GC</option></select>
            </td>
        </tr>
        <tr>
            <td>       Gender:
                </td>
            <td>
                <select name="gender">
                                    <option>Male</option>
                                    <option>Female</option></select></td>
        </tr>
        <tr>
            <td>
                Date Of Birth
             </td>
            <td>
                <script type="text/javascript">DateInput('dob', true, 'YYYY-MM-DD')</script>
            </td></tr>
        <tr>
               <td>Permanent Contact Number 
       </td>
            <td>            
       <input type="text" name="permanent_contact" size="25" /> </td>
        </tr>
        <tr>
            <td>Upload Your Image:</td>
            <td><input type="file" name="img" /></td>
        </tr>
        <tr>
            <td align="left">
               Mobile Number(Self)</td>
            <td><input type="text" name="txtmobile" size="25" />
         </td>
        </tr>
        <tr>
            <td>e-Mail ID (Self)</td>
            <td><input type="text" name="txtaltemail" size="25"/></td>
        </tr>
        <tr>
            <td align="left">Father's Name:</td>
            <td>
                <input type="text" name="txtfhname" size="50" />
              
            </td>
        </tr>
        <tr>
            <td align="left">
              Father's Mobile Number</td>
            <td><input type="text" name="txtfmobile" size="25" />
               </td>
        </tr>
        <tr>
            <td>
              Father's e-Mail ID</td>
            <td>
                <input type="text" name="txtfemail" size="25"/>
            </td>
        </tr>
        <tr valign="top">
            <td align="left" valign="top">
                Occupation with:</td>
            <td>
                <input type="text" name="father_industry" size="25"/>
            </td>
        </tr>
        <tr>
            <td align="left" valign="middle">
                Designation & Address</td>
            <td>
               <!--<textarea name="father_post" rows="5" cols="50"></textarea>-->
               <table border="0">
                      <tr>
                          <td>Line 1</td>
                          <td><input type="text" name="father_add_1"></td>
                      </tr>
                      <tr>
                          <td>Line 2</td>
                          <td><input type="text" name="father_add_2"></td>
                      </tr>
                      <tr>
                          <td>City</td>
                          <td><input type="text" name="father_add_city"></td>
                      </tr>
                      <tr>
                          <td>State</td>
                          <td><input type="text" name="father_add_state"></td>
                      </tr>
                      <tr>
                          <td>Pin</td>
                          <td><input type="text" name="father_add_pin"></td>
                      </tr>
               </table>
            </td>
        </tr>
        <tr>
            <td align="left" valign="middle">
                 Permanent Address</td>
            <td>
                <!--<textarea name="txtpermadd" rows="5" cols="50"></textarea>-->
                <table border="0">
                      <tr>
                          <td>Line 1</td>
                          <td><input type="text" name="permanent_add_1" id="permanent_add_1"></td>
                      </tr>
                      <tr>
                          <td>Line 2</td>
                          <td><input type="text" name="permanent_add_2" id="permanent_add_2"></td>
                      </tr>
                      <tr>
                          <td>City</td>
                          <td><input type="text" name="permanent_add_city" id="permanent_add_city"></td>
                      </tr>
                      <tr>
                          <td>State</td>
                          <td><input type="text" name="permanent_add_state" id="permanent_add_state"></td>
                      </tr>
                      <tr>
                          <td>Pin</td>
                          <td><input type="text" name="permanent_add_pin" id="permanent_add_pin"></td>
                      </tr>
               </table>
            </td>
        </tr>
        <tr>
            <td align="left" valign="middle">
                 Correspondence Address</td>
            <td>
                <!--<textarea name="txtcorresadd" rows="5" cols="50"></textarea>-->
                <table border="0">
                      <tr>
                          <td>Same as Permanent address</td>
                          <td><input type="checkbox" id="chkField" onchange="chkCorresAddress(this.id)"></td>
                      </tr>
                      <tr>
                          <td>Line 1</td>
                          <td><input type="text" name="corres_add_1" id="corres_add_1"></td>
                      </tr>
                      <tr>
                          <td>Line 2</td>
                          <td><input type="text" name="corres_add_2" id="corres_add_2"></td>
                      </tr>
                      <tr>
                          <td>City</td>
                          <td><input type="text" name="corres_add_city" id="corres_add_city"></td>
                      </tr>
                      <tr>
                          <td>State</td>
                          <td><input type="text" name="corres_add_state" id="corres_add_state"></td>
                      </tr>
                      <tr>
                          <td>Pin</td>
                          <td><input type="text" name="corres_add_pin" id="corres_add_pin"></td>
                      </tr>
               </table>
            </td>
        </tr>
        <tr>
            <td>
                <br />
                Select all the completed Academic Qualifications<br /><br />
                <div style="color: darksalmon;background-color: teal"> For example, if you are pursuing M. Tech currently, then you would need to <br /> select 10<sup>th</sup>, 12<sup>th</sup> OR Diploma OR Both(as the case may be), AND Graduation</div>
            </td>
            <td>
                <input type="checkbox" value="ssc" name="ssc_done"/>10<sup>th</sup>
                <input type="checkbox" value="hsc" name="hsc_done"/>12<sup>th</sup>
                <input type="checkbox" value="dip" name="dip_done"/>Diploma
                <input type="checkbox" value="gra" name="gra_done"/>Graduation<br />
                
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="btn_save_personal" value="PROCEED TOWARDS ACADEMIC SECTION" />
            </td>
        </tr>
        </table>
    </form>
<?php        
    }
    elseif (isset($_POST['section']) && !empty($_POST['section']) && $_POST['section']=='academic') 
        {
       
?>
<form action="editProfileNew.php" method="post" id="acaInfo" onsubmit="return isAcademicInfo(this)">
    <input type="hidden" name="section" value="other" />
    <input type="hidden" name="year_join" value="<?php echo $_POST['yearjoin']?>" />
    <table align="center" width="1000">
    <?php 
    if(isset($_POST['ssc_done']) && !empty($_POST['ssc_done']) && $_POST['ssc_done']=='ssc'){
    ?>
    <input type="hidden" name="ssc_done" value="ssc" id="ssc_done"/>
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">10<sup>th</sup> (SSC)</font></td>
        </tr>
        <tr>
            <td>
                School Name
            </td>
            <td>
                <input type="text" name="ssc_school" value="" />
            </td>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="ssc_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='ssc_state'>
                    <?php include '../inc/stateList.php';?>
                </select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="ssc_yop" id="ssc_yop">
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
            <td>
                Passed from a Distance Course
            </td>
            <td>
                <input type="radio" name="ssc_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="ssc_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="ssc_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="ssc_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="ssc_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="ssc_secured" value="" />
                </td>
            
        </tr>

    <?php
    }
    if(isset($_POST['hsc_done']) && !empty($_POST['hsc_done']) && $_POST['hsc_done']=='hsc'){
?>
        <input type="hidden" name="hsc_done" value="hsc" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">12<sup>th</sup> (HSC)</font></td>
        </tr>
        <tr>
            <td>
                School/College Name
            </td>
            <td>
                <input type="text" name="hsc_school" value="" />
            </td>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="hsc_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='hsc_state'>
<?php include '../inc/stateList.php';?>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <select name="hsc_yoj" id="ssc_yop" onchange="yearGap(this)">
                           <?php include '../inc/yearList.php';?>
                        </select>
            </td>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="hsc_yop" id="ssc_yop" onchange="yearGap(this)">
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
        </tr>
            <tr>
                <td colspan="2">
                Passed from a Distance Course
            </td>
            <td colspan="2">
                <input type="radio" name="hsc_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="hsc_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="hsc_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="hsc_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="hsc_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="hsc_secured" value="" />
                </td>
            
        </tr>
    <?php
    }
    if(isset($_POST['dip_done']) && !empty($_POST['dip_done']) && $_POST['dip_done']=='dip'){
?>
        <input type="hidden" name="dip_done" value="dip" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">Diploma</font></td>
        </tr>
        <tr>
            <td>
                School/College Name
            </td>
            <td>
                <input type="text" name="dip_school" value="" />
            </td>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="dip_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='dip_state'>
<?php include '../inc/stateList.php';?>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <select name="dip_yoj" id="ssc_yop" onchange="yearGap(this)">
                           <?php include '../inc/yearList.php';?>
                        </select>
            </td>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="dip_yop" id="ssc_yop" onchange="yearGap(this)">
                           <?php include '../inc/yearList.php';?>
                        </select>
            </td>
        </tr>
        <tr>
        <td colspan="2">
                Passed from a Distance Course
            </td>
            <td colspan="2">
                <input type="radio" name="dip_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="dip_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="dip_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="dip_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="dip_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="dip_secured" value="" />
                </td>
            
        </tr>
    <?php
    }
    if(isset($_POST['gra_done']) && !empty($_POST['gra_done']) && $_POST['gra_done']=='gra'){
?>
        <input type="hidden" name="gra_done" value="gra" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">GRADUATION</font></td>
        </tr>
        <tr>
            <td>
                School/College Name
            </td>
            <td>
                <input type="text" name="gra_school" value="" />
            </td>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="gra_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='gra_state'>
<?php include '../inc/stateList.php';?>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <select name="gra_yoj" id="ssc_yop" onchange="yearGap(this)">
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="gra_yop" id="ssc_yop" onchange="yearGap(this)">
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                Passed from a Distance Course
            </td>
            <td colspan="2">
                <input type="radio" name="gra_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="gra_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td>
                Graduation Stream
                </td>
            <td><input type="text" name="gra_stream" value="" />
                </td>
            <td>
                Graduation Honours
                </td>
            <td><input type="text" name="gra_honours" value="" />
                </td>
            
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="gra_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="gra_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="gra_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="gra_secured" value="" />
                </td>
            
        </tr>
          <?php
    }
          ?>
        
        <tr>
           <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">Current Course(B.Tech / MCA / M.Tech)</font></td>
        </tr>
        <tr>
            <td colspan="2" align="left">
                       Stream:
            </td>
            <td colspan="2"><select name="stream" id='streamId' >
                   					
                                    <option>B.Tech</option>
                                    <option>MCA</option>
                                    <option>M.Tech</option>
                                    <option value='Dual Degree B.Tech and M.Tech'>Dual Degree-B Tech + M Tech</option>
                                    <option>Dual Degree-B Tech + MBA</option>
                       </select>
              
               </td>
        </tr>
        <tr>
            <td colspan="2">
                  Branch: 
                  </td>
                  <td colspan="2">
                  <select name="branch">
           <option>Computer Science Engg.</option>
<option>Information Technology Engg.</option>
<option>Electrical Engg.</option>
<option>Electronics & Electrical Engg.</option>
<option>Electronics & Telecomm. Engg.</option>
<option>Electronics & Instrumentation Engg.</option>
<option>Mechanical Engg.</option>
<option>Civil Engg.</option>
<option>Automobile Engg.</option>
<option>Construction Engg. & Management</option>
<option>Structural Engg.</option>
<option>Computer Science</option>
<option>Computer Science & Information Security</option>
<option>Database Engg.</option>
<option>Software Engg.</option>
<option>Communication System Engg.</option>
<option>VLSI Design & Embedded System</option>
<option>Power Electronics and Drives</option>
<option>Power Engg. & Energy System</option>
<option>Thermal Engg.</option>
<option>Manufacturing Process & Systems</option>
<option>RF & Microwave Engg.</option>
           <option>MCA</option>
                  </select>
            
              
            </td>
        </tr>
        <tr>
            <td colspan="4">
                <input type="checkbox" value="yes" name="lateral_entry" /> Lateral Entry(Only applicable for B.Tech Stream)
            </td>
        </tr>
        <tr>
            <td colspan="4">
                <table>
                    <tr>
                        <td>Semester</td>
                        <td>1<sup>st</sup></td>
                        <td>2<sup>nd</sup></td>
                        <td>3<sup>rd</sup></td>
                        <td>4<sup>th</sup></td>
                        <td>5<sup>th</sup></td>
                        <td>6<sup>th</sup></td>
                        <td>7<sup>th</sup></td>
                        <td>8<sup>th</sup></td>
                        <td>9<sup>th</sup></td>
                        <td>10<sup>th</sup></td>
                    </tr>
                    <tr>
                        <td>SGPA</td>
                        <td><input type="text" name="sgpa_1" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_2" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_3" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_4" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_5" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_6" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_7" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_8" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_9" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_10" value="" size="5" /></td>
                    </tr>
                    <tr>
                        <td>CGPA</td>
                        <td><input type="text" name="cgpa_1" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_2" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_3" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_4" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_5" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_6" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_7" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_8" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_9" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_10" value="" size="5" /></td>
                       
                    </tr>
                    <tr>
                        <td>No. Of Backlogs</td>
                        <td><input type="text" name="backlog_1" value="" size="5" /></td>
                        <td><input type="text" name="backlog_2" value="" size="5" /></td>
                        <td><input type="text" name="backlog_3" value="" size="5" /></td>
                        <td><input type="text" name="backlog_4" value="" size="5" /></td>
                        <td><input type="text" name="backlog_5" value="" size="5" /></td>
                        <td><input type="text" name="backlog_6" value="" size="5" /></td>
                        <td><input type="text" name="backlog_7" value="" size="5" /></td>
                        <td><input type="text" name="backlog_8" value="" size="5" /></td>
                        <td><input type="text" name="backlog_9" value="" size="5" /></td>
                        <td><input type="text" name="backlog_10" value="" size="5" /></td>
                    </tr>
                    
                </table>
                </td>
        </tr>
         
        <tr>
            <td colspan="4">
                <input type="submit" name="btn_save_academic" value="PROCEED TO FINAL SUBMISSION" />
            </td>
        </tr>
        
</table>
</form>

<?php        
    }
    elseif (isset($_POST['section']) && !empty($_POST['section']) && $_POST['section']=='other') 
        {
    ?>
<form action="editProfileNew.php" method="post" >
            <table>
                <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Other Details</font></td>
        </tr>
                <tr>
                        <td>If you have year gaps during your academic career.<br />
                        Please provide a reason for the same</td>
                        <td><textarea name="gap_reason" rows="4" cols="40"></textarea></td>
                    </tr>
              
        <tr>
            <td>
                Hobbies
            </td>
            <td>
                <textarea name="hobby" rows="4" cols="40"></textarea> 
            </td>
        </tr>
        <tr>
            <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Project / Summer Training(Please mention all informal & formal Projects)</font></td>
        </tr>
        <tr>
                <td>Project Name</td>
                <td><input type="text" name="pro1_name" value="" /></td>
        </tr>
        <tr>
                        <td>Institution / Organization</td>
                                    <td><input type="text" name="pro1_org" value="" /></td>
                        </tr>
        <tr>
                        <td>Duration of the Project</td>
                        <td><input type="text" name="pro1_dur" value="" /></td>
                        </tr>
        <tr>
                        <td>Project Guide(s)</td>
                        <td><input type="text" name="pro1_guide" value="" /></td>
                        </tr>
        <tr>
                        <td>Project Summary</td>
                        <td><textarea name="pro1_sum" rows="4" cols="40"></textarea></td>
                    </tr>
         <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Order of Preference</font></td>
        </tr>
        <tr>
            <td colspan="2">
                You would give higher preference to <select name="pref">
                            <option>Job</option>
                            <option>Higher Studies</option>
                        </select>
            </td>
        </tr>
        <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Declaration</font></td>
        </tr>
        <tr>
            <td colspan="2">
                The information furnished above is true to the best of my knowledge and I agree with the rules and regulation 
                of Training and Placement, KiiT University, Bhubaneshwar
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="btn_save_final" value="SUBMIT FOR VERIFICATION" />
            </td>
        </tr>
            </table>
        </form>
        <?php
}
}
elseif ($status=='Pending' || $status == 'Approved') 
    {
    ?>
<table align="center" width="1000" border="0">
        <tr>
        <td colspan="6" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>REGISTRATION FORM</b></font></td>
        </tr><tr>
            <td>Rollno:</td><td><input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td>Current Status:</td><td><input type="text" name="status" value="<?php echo $row['status'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td colspan="6" align="left" bgcolor="#237648" style="color: red;">Note: You have already edited your profile and submitted the information for verification. You are not authorized to make any further changes. Please contact Training and Placement Cell for further help.</td>
        </tr>
        
       </table>
</form>    
    <?php
}
}else{
    include_once './editProfile.php';
}
$content=ob_get_contents();
ob_end_clean();
$pageTitle = "TNP || Student Data";
include'template1.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
    echo $_SESSION['ErrMsg'];
    unset ($_SESSION['ErrMsg']);
}
?>