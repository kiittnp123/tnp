<?php

/* include_once 'protected.php';
  include'db.php';
  ob_start();

  if (!$_SESSION['userName']) {
  header("location:logout.php");
  }
 */
ob_start();
?>
<?php

error_reporting(0);
include 'db.php';
if (isset($_POST['btnprint'])) {
    $train_name = $_POST['tname'];
    $org_name = mysql_real_escape_string($_POST['txtorgname']);
    $contact_name = mysql_real_escape_string($_POST['txtname']);
    $contact_desig = mysql_real_escape_string($_POST['txtdesig']);
    //$org_address = mysql_real_escape_string(nl2br($_POST['txtaddress']));
	$address1= mysql_real_escape_string($_POST['address1']);
	$address2= mysql_real_escape_string($_POST['address2']);
	$org_address=$address1."<br/>".$address2;
    $ref_name = mysql_real_escape_string($_POST['txtref']);
    $ref_contact = mysql_real_escape_string($_POST['txtmob']);
    $ref_email = mysql_real_escape_string($_POST['txtemail']);
    $from_date = $_POST['year'] . "-" . $_POST['month'] . "-" . $_POST['date'];
    $to_date = $_POST['toyear'] . "-" . $_POST['tomonth'] . "-" . $_POST['todate'];
    $stu_name = mysql_real_escape_string($_POST['stuname']);
    $stu_roll = mysql_real_escape_string($_POST['sturoll']);
    $stu_stream = mysql_real_escape_string($_POST['stustream']);
    $stu_branch = mysql_real_escape_string($_POST['stubranch']);
    $stu_sem = mysql_real_escape_string($_POST['stusem']);
    $stu_con = mysql_real_escape_string($_POST['stucon']);
    $stu_email = mysql_real_escape_string($_POST['stuemail']);
    $stu_university = mysql_real_escape_string($_POST['university']);
    /* if($train_name !="" && $org_name !="" && $contact_name !="" && $contact_desig !="" && $org_address !="" && $ref_name !="" && $ref_contact !="" &&$ref_email !="" && $from_date !="" && $to_date != "" && $stu_name !="" && $stu_roll !="" && $stu_stream !="" && $stu_branch !="" && $stu_sem !="" && $stu_con !="" && $stu_email !="" && $stu_university != ""){ */
    $sql = "insert into tbl_noc(train_name,indus_name,contact_name,contact_desig,indus_addr,ref_name,ref_mobile,ref_email,start_date,end_date,stu_roll,stu_name,stu_stream,stu_branch,stu_sem,stu_mobile,stu_email,stu_university,status) values('$train_name','$org_name','$contact_name','$contact_desig','$org_address','$ref_name','$ref_contact','$ref_email','$from_date','$to_date','$stu_roll','$stu_name','$stu_stream','$stu_branch','$stu_sem','$stu_con','$stu_email','$stu_university','Pending')";
    $res = mysql_query($sql);
    //echo "data saved..";
    if ($res) {
        echo "<br><br><div style='text-align:center;'>Thanks for filling up NOC Forwarding form.<br><br><span style='color: green;font-weight: bold;'>Your NOC form is submitted successfully. </span><br><br>Please contact respective Training & Placement Department within 4 to 5 working days <br>with your <b>College ID Card & Industrial Application Form (approved from respective department<br/>(Associative Dean T&P))</b> <br>& collect your NOC forwarding letter.<br><br><br><b><u>Office Address</u></b><br>Department of Training & Placement,<br>Campus - 2,<br>Near Railway Railway Reservation Center,<br>Bhubaneswar, Odisha<br><b>Email ID:</b> internship@kiit.ac.in</div>";
    } else {
        ?>
        <script>
            alert("All fields are mandatory !");
        </script>
        <?php

    }
}
?>

<?php

$pageContent = ob_get_contents();
ob_clean();
include_once 'TNPOtemplate1.php';
?>
