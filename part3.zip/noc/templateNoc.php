<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<script src="../calendar/calendarDateInput.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script type="text/javascript">
    function allSet(c){
    //alert(c);
    if(document.getElementById("allSelect").checked==true){
        for(var i=1;i<=c;i++)
            document.getElementById("studentIdCheck"+i).checked=true;
    }else{
        for(var i=1;i<=c;i++){
            document.getElementById("studentIdCheck"+i).checked=false;
        }
    }
    }
</script>
</head>

<body background="../img/background4.gif" style="background-repeat:repeat-x">
    <table align="center" border="0">
  <tr>
 <td colspan="2"><img name="kiitlogo" src="../img/kiitlogo.png" /></td>
  </tr>
        <tr>
 <td colspan="2" >
     <table align="center">
         <tr>
             <td>
    <ul class="TabbedPanelsTabGroup" align="center">
    
        <li class="TabbedPanelsTab" tabindex="0"><a href="indexNoc.php">Homepage</a></li>
        <li class="TabbedPanelsTab" tabindex="0"><a href="issueNoc.php">View Applied NOC</a></li>
        <li class="TabbedPanelsTab" tabindex="0"><a href="trainAppl.php">issue NOC</a></li>
        <li class="TabbedPanelsTab" tabindex="0"><a href="changePassword.php">Change Password</a></li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="logout.php">Logout</a></li>
    </ul>    
             </td>
         </tr>
     </table>
 </td>
</tr>

<tr>
<td colspan="2" align="left"><?php echo $content ?></td>
</tr>
</table>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>
</body>
</html>
