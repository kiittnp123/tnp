<?php
include_once 'protectedNoc.php';
include'../db.php';
ob_start();
if(isset($_POST['btnprint']) && !empty($_POST['btnprint']) && $_POST['btnprint'] == 'Accept and Print NOC')
{	
  $train_name=mysql_real_escape_string($_POST['tname']);
  $org_name=mysql_real_escape_string($_POST['txtorgname']);
  $contact_name=mysql_real_escape_string($_POST['txtname']);
  $contact_desig=mysql_real_escape_string($_POST['txtdesig']);
  $org_address=nl2br(mysql_real_escape_string($_POST['txtaddress']));
  $ref_name=mysql_real_escape_string($_POST['txtref']);
  $ref_contact=mysql_real_escape_string($_POST['txtmob']);
  $ref_email=mysql_real_escape_string($_POST['txtemail']);
  $from_date=mysql_real_escape_string($_POST['start_date']);
  $to_date=mysql_real_escape_string($_POST['end_date']);
 
  $stu_roll=mysql_real_escape_string($_POST['sturoll']);
  $stu_sem=mysql_real_escape_string($_POST['stusem']);
  $sql="insert into tbl_training_noc(train_name,indus_name,contact_name,contact_desig,indus_addr,ref_name,ref_mobile,ref_email,start_date,end_date,
        student_id,stu_sem,status) 
        values
        ('$train_name','$org_name','$contact_name','$contact_desig','$org_address','$ref_name','$ref_contact','$ref_email','$from_date','$to_date',
          (select student_id from tbl_student where roll_no=$stu_roll), '$stu_sem','Accepted')";
  //echo $sql;
  $res=mysql_query($sql);
  //echo "data saved..";
  if($res)
	   {      
          $id = mysql_insert_id($con);
	  header("location:nocLetterNew.php?id=".$id);
	   }
 else {
           $_SESSION['errMsg']="<script>alert('Some problem with the database has occurred. Please try again !!!')</script>";    
           }
}
?>
<script type="text/javascript">
    function validNoc(c){
        if(c.txtorgname.value==''){ 
            alert('Organization Field is a compulsory Field');
            return false;
            }
        if(c.sturoll.value==''){
            alert('Student Roll Number is a compulsory Field');
            return false;
            }
        return true;
            }
    
</script>
<form method="post" action="trainAppl.php" name="trainoc" onsubmit="return validNoc(this)">

<table align="center" bgcolor="#E2E2E2" style="border-style:ridge" width="800">
<tr>
<td colspan="4" align="center"><font><b><h2>Industrial Training Application Form</h2></b></font></td>
</tr>
<tr>
    <td>Training Name:</td><td><input type="radio" name="tname" value="Winter Training" checked="checked" />Winter Training <br/>
                           <input type="radio" name="tname" value="Summer Training " />Summer Training</td>
</tr>
<tr bgcolor="#FFFFFF">
<td colspan="4" align="center"><font size="+1"><b>Organisation Details</b></font></td>
</tr>
<tr>
<td>Name of the Industry/Organisation Name:</td>
<td><input type="text" name="txtorgname" style="width:200px" /></td>
</tr>
<tr>
<td>Name of the concerned Person:<br/>(To whom Letter shall be issued)</td>
<td><input type="text" name="txtname" style="width:200px" /></td>
</tr>
<tr>
<td>Designation of the concerned Person:<br/>(To whom Letter shall be issued)</td>
<td><input type="text" name="txtdesig" style="width:200px" /></td>
</tr>
<tr>
<td>Industry/Organisation Address:</td>
<td><textarea name="txtaddress" rows="3" cols="18"></textarea></td>
</tr>
<tr>
<td>Industry/Organisation Ref. Person Name:</td>
<td><input type="text" name="txtref" style="width:200px" /></td>
</tr>
<tr>
<td>Ref. person Contact No:</td>
<td><input type="text" name="txtmob" /></td>
<td align="right">Email Id:</td>
<td><input type="text" name="txtemail" /></td>
</tr>
<tr>
<td>Training Period:</td>
<td><script type="text/javascript">DateInput('start_date', true, 'YYYY-MM-DD')</script></td>
<td align="right">to</td>
<td><script type="text/javascript">DateInput('end_date', true, 'YYYY-MM-DD')</script></td>
</tr>
<tr bgcolor="#FFFFFF">
<td colspan="4" align="center"><font size="+1"><b>Student Details</b></font></td>
</tr>
<tr>
<td>College Roll No:</td>
<td><input type="text" name="sturoll" id="sturoll" /></td>
</tr>
<tr>
<td>Semester:</td>
<td><select name="stusem">
     <option selected="selected">1st Semester</option>
     <option>2nd Semester</option>
     <option>3rd Semester</option>
     <option>4th Semester</option>
     <option>5th Semester</option>
     <option>6th Semester</option>
     <option>7th Semester</option>
     <option>8th Semester</option>
</select></td>
</tr>
<tr>
<td colspan="4" align="center"><input type="submit" name="btnprint" value="Accept and Print NOC" />
                               <input type="reset" name="btnreset" value="NEW" /></td>
</tr>
</table>
</form>
<?php 
$content=ob_get_contents();
ob_clean();
include_once 'templateNoc.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
} 

?>


