<?php
include_once 'protectedNoc.php';
$id=$_GET['id'];
include_once '../db.php';
$sql="select * from tbl_training_noc,tbl_student where noc_id=$id and tbl_training_noc.student_id=tbl_student.student_id";
$res=mysql_query($sql);
//$letter="";
$data=mysql_fetch_array($res);
$sem = $data['stu_sem'];
$stream = $data['stream'];
$t1=  strtotime($data['start_date']);
$t2=  strtotime($data['end_date']);
$startDate=date("Y-F-d",$t1);
$endDate=date("Y-F-d",$t2);
//$diff = abs(strtotime($startDate) - strtotime($endDate));

//$days = floor(($diff) / (60*60*24));

if($sem==1){
    $current="1<sup>st</sup>";
}
elseif ($sem==2) {
    $current="2<sup>nd</sup>";
}
elseif ($sem==3) {
    $current="3<sup>rd</sup>";
}
 else {
    $current="$sem<sup>th</sup>";
}
if($stream=='B.Tech'){
    $total="8<sup>th</sup>";
}
elseif($stream=='M.Tech'){
    $total="4<sup>th</sup>";
}
elseif($stream=='MCA'){
    $total="6<sup>th</sup>";
}
else{
    $total="10<sup>th</sup>";
}
ob_start();
?>
<table cellpadding="7" style="font-size: 12; font-family: 'Californian FB'; ">
<tr>
<td>From:<br />
    Training & Placement Department<br />
    KIIT University,Kolab Campus<br/>
    Bhubaneswar-751024,Odisha.<br/>
    Telephone:0674-6542304 / Tele Fax:0674-2725733<br/>
    E-mail:<u>training@kiit.ac.in / placement@kiit.ac.in</u>
</td>
</tr>
<tr>
<td><br />
    To<br/>
    <?php if($data['contact_name'] != '' ) echo $data['contact_name']."<br/>"; ?>
    <?php if($data['contact_desig'] != '' ) echo $data['contact_desig']."<br/>"; ?>
    <?php echo $data['indus_name']; ?><br/>
    <?php echo $data['indus_addr']; ?>
</td>
</tr>
<tr>
<td><b>Sub:<?php echo $data['train_name']; echo" / Internship for our students completing $sem of $total Semester $stream Program in your organization for 30 days." ?></b></td>
</tr>
<tr>
<td><p align="justify">Sir/Madam,<br/>
    This is reference of KIIT University, a student has to undergo a Industry Training for a period of 30 days in an outside 
    Industry / Organization preferably in the area of his/her specialization after completion of his/her 
        <?php echo $sem; ?> course. 
    </p>
    <p align="justify">Yours being a reputed Organization / Industry , we request you to kindly accommodate the following student of our University 
    and arrange a Project / Industry Training within the period from <?php echo $startDate; echo" to "; echo $endDate; ?> for a 
    period of 30 days.
    </p>
</td>
</tr>
<tr>
<td><b>Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $data['name']; ?><br />
    Branch:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $data['branch']; ?><br />
    Roll No:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $data['roll_no']; ?><br />
    Semester:&nbsp;&nbsp;&nbsp;&nbsp;<?php echo $data['stu_sem']; ?><br />
    Contact No:&nbsp;<?php echo $data['mobile']; ?>    
    </b>
</td>
</tr>
<tr>
<td>
<p align="justify">This training will go a long way in preparing the student professionally and we have, no-objection for allowing the able student 
for Training in your Industry / Organization. We are looking forward to your confirmation at your earliest convenience.
</p>
</td></tr>
<tr><td>
Thanking You </td></tr>
<tr><td>
Yours Faithfully</td></tr>
<tr><td>
  <p>      <br />
Dr.Saranjit Singh<br/>
Dean (T & P)<br/>
KIIT University<br/>
Bhubaneswar-751024
  </p>
</td>
</tr>
</table>
<?php
$_SESSION['pdfData']=  ob_get_contents();
ob_end_clean();
//echo $_SESSION['pdfData'];
header("location:export.php");
?>