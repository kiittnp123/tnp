<?php 
ob_start();
include_once 'protectedNoc.php';
include'../db.php';
?>
<script>
function display(c)
{
  if(c.value == "1")
  {
     document.getElementById('form1').style.display='block';
     document.getElementById('form2').style.display='none';
	 
  }
   else if(c.value == "2")
   {
	 document.getElementById("form1").style.display='none';
     document.getElementById("form2").style.display='block';
   } 
}
function isempty()
{
	if(document.form1.rollno.value=='')
	{
		alert("Plz enter the roll no"); 
		document.form1.rollno.focus();
		return false;
	}
	
}
</script>

<form action="issueNoc.php" method="get" name="addstd" id="form3">
<table align="center">
<tr>
<td>VIEW:</td>
<td><input id="one" type="radio" name="rdbtn1"  value="1" onclick="display(this)" />BY ROLL NO.</td>
<td><input id="two" type="radio" name="rdbtn1"  value="2" onclick="display(this)" />ALL</td>
</tr>
</table>
</form>

<form id='form1' style="display:none" name="form1" onsubmit="return isempty()" method="post" action="issueNoc.php">
<table align="center" bgcolor="#E8E8E8">
<tr>
<td>Enter Roll no.</td><td><input type="text" name="rollno"/></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btn_submitroll" value="Submit" /></td>
</tr>
</table>
</form>

<form id='form2' style="display:none" name="form2" method='post' action="issueNoc.php" >
<table align="center" bgcolor="#E8E8E8">
<tr>
<td>Choose Type:</td> 
<td><select name="ddltype">
		<option>Pending</option>
                <option>Accepted</option>
    </select></td>
<tr>
<td colspan="2" align="center"><input type="submit" name="btn_submittype" value="Submit" /></td>
</tr>
</table>
</form>

<?php
if(isset($_POST['deleteNOC']) && !empty($_POST['deleteNOC']) && $_POST['deleteNOC'] =='Reject NOC Request')
     {
		 if(isset($_POST['id'])&& !empty($_POST['id']))
	{
	    $id=mysql_real_escape_string($_POST['id']);
            $sqlupdate="delete from tbl_training_noc where noc_id='$id'";
            $resupdate=mysql_query($sqlupdate);
            if($resupdate)
		{
		 $_SESSION['errMsg']="<script>alert('The NOC Request has been rejected')</script>";	
		}
                else{
                    $_SESSION['errMsg']="<script>alert('Problem Occurred')</script>";
                }
	}
}
if(isset($_POST['acceptNOC']) && !empty($_POST['acceptNOC']) && $_POST['acceptNOC'] =='Accept and Print NOC')
     {
		 if(isset($_POST['id'])&& !empty($_POST['id']))
	{
	    $id=mysql_real_escape_string($_POST['id']);
            $sqlupdate="update tbl_training_noc set status='Accepted' where noc_id='$id'";
            $resupdate=mysql_query($sqlupdate);
            if($resupdate)
		{
		 $_SESSION['errMsg']="<script>alert('Accepted !!')</script>";
                header("location:nocLetterNew.php?id=".$id); 	
		}
                else{
                    $_SESSION['errMsg']="<script>alert('Problem Occurred')</script>";
                }
	}
}
//  to retrieve the selected data according to rollno

if(isset($_POST['btn_submitroll']) && !empty($_POST['btn_submitroll']))
	{
		$roll=mysql_real_escape_string($_POST['rollno']);
		$sql1="select noc_id,train_name,indus_name,indus_addr,roll_no,name,stream,branch,stu_sem,tbl_training_noc.status 
                       from 
                       tbl_training_noc,tbl_student 
                       where 
                       roll_no='$roll' 
                           and 
                       tbl_training_noc.student_id=tbl_student.student_id";
            
		$res=mysql_query("$sql1");
		$rows=mysql_num_rows($res);
if($rows>0)
{?>
   <form method="post" action="">
       <table align="center" border="3" style="background-color: #DFDFDF;">
           <tr style="background-color: #000099">
      <td></td>
      <td style="color: #FFFFFF">Training name</td>
      <td style="color: #FFFFFF">Organization Name</td>
      <td style="color: #FFFFFF">Organization Address</td>
      <td style="color: #FFFFFF">Roll No</td>
      <td style="color: #FFFFFF">Name</td>
      <td style="color: #FFFFFF">Stream</td>
      <td style="color: #FFFFFF">Branch</td>
      <td style="color: #FFFFFF">Semester</td>
      <td style="color: #FFFFFF">Status</td>
      </tr>
<?php  while($data=mysql_fetch_array($res))
  { ?>
	<tr>
    <td><input type="radio" name="id" value="<?php echo $data[0] ?>" /></td>
     <td><?php echo $data[1] ?></td>
     <td><?php echo $data[2] ?></td>
     <td><?php echo $data[3] ?></td>
     <td><?php echo $data[4] ?></td>
     <td><?php echo $data[5] ?></td>
     <td><?php echo $data[6] ?></td>
     <td><?php echo $data[7] ?></td>
     <td><?php echo $data[8] ?></td>
     <td><?php echo $data[9] ?></td>
     </tr>
      
  <?php } ?>
     <tr>
     <td colspan="5" align="center"><input type="submit" name="acceptNOC" value="Accept and Print NOC" /></td>
     <td colspan="5" align="center"><input type="submit" name="deleteNOC" value="Reject NOC Request" /></td>
     </tr>
       </table>
      </form> 
<?php 
}
else
{
  $_SESSION['errMsg']="<script>alert('Data Not Found..')</script>";
}
}
//  to retrieve the selected data according to status

	
 if(isset($_POST['btn_submittype']) && !empty($_POST['btn_submittype']))
	{
	  $type=mysql_real_escape_string($_POST["ddltype"]);
          $sql2="select noc_id,train_name,indus_name,indus_addr,roll_no,name,stream,branch,stu_sem,tbl_training_noc.status 
                       from 
                       tbl_training_noc,tbl_student 
                       where 
                       tbl_training_noc.status='$type' 
                           and 
                       tbl_training_noc.student_id=tbl_student.student_id";
          //echo $sql2;
	  $result=mysql_query("$sql2");
	  $numrow=mysql_num_rows($result);
	  if($numrow>0)
	  { ?>
<form method="post" action="">
   <table align="center" border="3">
      <tr>
          <td>&nbsp;</td>
      <td>Training name</td>
      <td>Organization Name</td>
      <td>Organization Address</td>
      <td>Roll No</td>
      <td>Name</td>
      <td>Stream</td>
      <td>Branch</td>
      <td>Semester</td>
      <td>Status</td>
      </tr>
<?php 
		while($val=mysql_fetch_array($result))  
		{ ?>
      <tr>
      <td><input type="radio" name="id" value="<?php echo $val[0] ?>" /></td>
		  	
            <td><?php echo $val[1] ?></td>
            <td><?php echo $val[2] ?></td>
            <td><?php echo $val[3] ?></td>
            <td><?php echo $val[4] ?></td>
            <td><?php echo $val[5] ?></td>
            <td><?php echo $val[6] ?></td>
            <td><?php echo $val[7] ?></td>
            <td><?php echo $val[8] ?></td>
   <td><?php echo $val[9] ?></td></tr>
		<?php }
	 ?>
      <tr>
     <td colspan="5" align="center"><input type="submit" name="acceptNOC" value="Accept and Print NOC" /></td>
     <td colspan="5" align="center"><input type="submit" name="deleteNOC" value="Reject NOC Request" /></td>
     </tr>
   </table>
</form>
             <?php
                }
	  else
	   {
		 $_SESSION['errMsg']="<script>alert('Data Not Found..')</script>";
	   }
	}
$content=ob_get_contents();
ob_clean();
include'templateNoc.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>
