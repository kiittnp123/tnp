<?php
include_once 'protectedNoc.php';
ob_start();
?>
<marquee><font size="+5">WELCOME</font></marquee>
<?php
$content=  ob_get_contents();
ob_end_clean();
include_once 'templateNoc.php';
?>
