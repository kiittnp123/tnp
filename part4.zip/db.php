<?php
$db_name="kiittnp_tnp_ilabs";
$server="cbxfpbjpqu";
$user="cbxfpbjpqu";
$password="placakiit";
$con=mysql_connect($server,$user,$password);
mysql_select_db($db_name);
?>