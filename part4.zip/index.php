<?php
header('location: ./usr');
?>