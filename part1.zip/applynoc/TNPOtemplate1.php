<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Training Application</title>
        <script src="SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
        <link href="SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
        <script language="javascript" type="text/javascript">
            function isempty()
            {

            if(document.trainoc.txtorgname.value=='')
            {
            alert("Organization name cant be left blank"); 
            document.trainoc.txtorgname.focus();
            return false;
            }
            if(document.trainoc.txtname.value=='')
            {
            alert("Concerned Person name cant be left blank"); 
            document.trainoc.txtname.focus();
            return false;
            }
            if(document.trainoc.txtdesig.value=='')
            {
            alert("Designation of concerned person cant be left blank"); 
            document.trainoc.txtdesig.focus();
            return false;
            }
            if(document.trainoc.txtaddress.value=='')
            {
            alert("Organization address cant be left blank"); 
            document.trainoc.txtaddress.focus();
            return false;
            }	
            if(document.trainoc.txtref.value=='')
            {
            alert("Reference person name cant be left blank"); 
            document.trainoc.txtref.focus();
            return false;
            }
            if(document.trainoc.txtmob.value=='')
            {
            alert("Reference person contact no cant be left blank"); 
            document.trainoc.txtmob.focus();
            return false;
            }	
            if(document.trainoc.txtemail.value=='')
            {
            alert("Reference person email_id cant be left blank"); 
            document.trainoc.txtemail.focus();
            return false;
            }
            if(document.trainoc.stuname.value=='')
            {
            alert("student name cant be left blank"); 
            document.trainoc.stuname.focus();
            return false;
            }
            if(document.trainoc.sturoll.value=='')
            {
            alert("student roll no cant be left blank"); 
            document.trainoc.sturoll.focus();
            return false;
            }
            if(document.trainoc.stucon.value=='')
            {
            alert("Contact cant be left blank"); 
            document.trainoc.stucon.focus();
            return false;
            }
            if(document.trainoc.stuemail.value=='')
            {
            alert("Email id cant be left blank"); 
            document.trainoc.stuemail.focus();
            return false;
            }		
            }

            function isstream()
            {
            var stream=document.trainoc.stustream.value;
            if(stream=='--select--')
            {
            alert("Please select a stream..");
            }	 
            }
            function isbranch()
            {
            var branch=document.trainoc.stubranch.value;
            if(branch=='--select--')
            {
            alert("Please select a branch..");
            }	 
            }

        </script>
    </head>
    <body background="img/Brown-Striped-Packaging-l.jpg">
    <center><img src="img/kiitlogo.png" /></center>
        <table align="center" width="800">
            <tr>
                <td>
                    <!--<div id="TabbedPanels1" class="TabbedPanels">
                        <ul class="TabbedPanelsTabGroup">
                            <li class="TabbedPanelsTab" tabindex="0"><a href="trainAppl.php">Training Application</a></li>
                            <li class="TabbedPanelsTab" tabindex="0"><a href="issueNoc.php">Issue Application</a></li>
                            <li class="TabbedPanelsTab" tabindex="0"><a href="logout.php">Log Out</a></li>
                        </ul>
                    </div>-->
                </td></tr>
            <tr>
                <td align="left"><?php echo $pageContent ?></td>
            </tr>
        </table>
        <script type="text/javascript">
            var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
        </script>
    </body>
</html>