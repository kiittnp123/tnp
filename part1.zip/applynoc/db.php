<?php
$db_name="kiittnp_test_noc";
$server="localhost";
$user="kiittnp";
$password="Fs*fyaFU4o}-";
$con=mysql_connect($server,$user,$password);
mysql_select_db($db_name);
?>