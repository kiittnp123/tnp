<?php
/* include_once 'protected.php';
  include'db.php';
  ob_start();

  if (!$_SESSION['userName']) {
  header("location:logout.php");
  }
 */
ob_start();
?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
        <title>Untitled Document</title>
        <script>
            function toggleForm(id) {
                //alert("");
                if (document.getElementById(id).id == "next") {
                    document.getElementById("indusTrain").style.display = "table";
                    document.getElementById("studTrain").style.display = "none";
                }
                else if (document.getElementById(id).id == "back") {
                    document.getElementById("indusTrain").style.display = "none";
                    document.getElementById("studTrain").style.display = "table";
                }
            }


            function toggleButton(id) {
                if (document.getElementById(id).value == "Kiit") {
                    document.getElementById("next").style.display = "block";
                    document.getElementById("submit").style.display = "none";
                } else if (document.getElementById(id).value == "Other") {
                    document.getElementById("next").style.display = "none";
                    document.getElementById("submit").style.display = "block";
                }
            }
            function validateForm() {
//tname, stuname, sturoll,stucon, stuemail, university,txtorgname, txtname, txtdesig, txtaddress, txtref, txtmob, date, month, year, todate, tomonth, toyear
                var tname = document.frmTrainoc.tname.value;
                var stuname = document.frmTrainoc.stuname.value;
                var sturoll = document.frmTrainoc.sturoll.value;
                var stucon = document.frmTrainoc.stuemail.value;
                var stuemail = document.frmTrainoc.stuemail.value;
                var university = document.frmTrainoc.university.value;
                var txtorgname = document.frmTrainoc.txtorgname.value;
                var txtname = document.frmTrainoc.txtname.value;
                var txtdesig = document.frmTrainoc.txtdesig.value;
                var txtaddress = document.frmTrainoc.txtaddress.value;
                var txtref = document.frmTrainoc.txtref.value;
                var txtmob = document.frmTrainoc.txtmob.value;
                var date = document.frmTrainoc.date.value;
                var month = document.frmTrainoc.month.value;
                var year = document.frmTrainoc.year.value;
                var todate = document.frmTrainoc.todate.value;
                var tomonth = document.frmTrainoc.txmonth.value;
                var toyear = document.frmTrainoc.txtyear.value;
				alert("");
alert(tname);
                if (tname === "") {
                    alert("Please select a training Name.");
                    document.getElementById("indusTrain").style.display = "none";
                    document.getElementById("studTrain").style.display = "block";
                    document.frmTrainoc.tname.focus();
                    return false;

                } else if (stuname === "") {
                    return false;

                } else if (sturoll === "") {
                    return false;

                } else if (stucon === "") {
                    return false;

                } else if (stuemail === "") {
                    return false;

                } else if (university === "") {
                    return false;

                } else if (txtorgname === "") {
                    return false;

                } else if (txtname === "") {
                    return false;

                } else if (txtdesig === "") {
                    return false;

                } else if (txtaddress === "") {
                    return false;

                } else if (txtref === "") {
                    return false;

                } else if (txtmob === "") {
                    return false;

                } else if (date === 'NA') {
                    return false;

                } else if (month === 'NA') {
                    return false;

                } else if (year === 'NA') {
                    return false;

                } else if (todate === 'NA') {
                    return false;

                } else if (tomonth === 'NA') {
                    return false;

                } else if (toyear === 'NA') {
                    return false;
                }
                else {
                    return true;
                }
            }
            window.onload = function(){
                var sel = document.getElementById("university");
                if(sel.options[sel.selectedIndex].value === "Kiit"){
                    document.getElementById("next").style.display = "block";                    
                }
            }
			 function validation(str){
				/*var tname = document.frmTrainoc.tname.value;
                var stuname = document.frmTrainoc.stuname.value;
                var sturoll = document.frmTrainoc.sturoll.value;
                var stucon = document.frmTrainoc.stuemail.value;
                var stuemail = document.frmTrainoc.stuemail.value;
                var university = document.frmTrainoc.university.value;
                var txtorgname = document.frmTrainoc.txtorgname.value;
                var txtname = document.frmTrainoc.txtname.value;
                var txtdesig = document.frmTrainoc.txtdesig.value;
                var txtaddress = document.frmTrainoc.txtaddress.value;
                var txtref = document.frmTrainoc.txtref.value;
                var txtmob = document.frmTrainoc.txtmob.value;
                var date = document.frmTrainoc.date.value;
                var month = document.frmTrainoc.month.value;
                var year = document.frmTrainoc.year.value;
                var todate = document.frmTrainoc.todate.value;
                var tomonth = document.frmTrainoc.txmonth.value;
                var toyear = document.frmTrainoc.txtyear.value;*/
				var tname = document.forms["frmTrainoc"]["tname"].value;
				var stuname= document.forms["frmTrainoc"]["stuname"].value;
				var sturoll = document.forms["frmTrainoc"]["sturoll"].value;
				var stucon = document.forms["frmTrainoc"]["stucon"].value;
				var stuemail = document.forms["frmTrainoc"]["stuemail"].value;
				var university = document.forms["frmTrainoc"]["university"].value;
				var txtorgname = document.forms["frmTrainoc"]["txtorgname"].value;
				var txtname = document.forms["frmTrainoc"]["txtname"].value;
				var txtdesig = document.forms["frmTrainoc"]["txtdesig"].value;
				//var txtaddress =
				var txtref = document.forms["frmTrainoc"]["txtref"].value;
				var txtmob = document.forms["frmTrainoc"]["txtmob"].value;
				var date = document.forms["frmTrainoc"]["date"].value;
				var month = document.forms["frmTrainoc"]["month"].value;
				var year = document.forms["frmTrainoc"]["year"].value;
				var todate = document.forms["frmTrainoc"]["todate"].value;
				var tomonth = document.forms["frmTrainoc"]["tomonth"].value;
				var toyear = document.forms["frmTrainoc"]["toyear"].value;
				if(tname=="" || stuname=="" || sturoll=="" || stucon=="" || stuemail=="" || university=="" || txtorgname=="" || txtname=="" || txtdesig=="" || txtref=="" || txtmob=="" || date=="" || month=="" || year=="" || todate=="" || tomonth=="" || toyear==""){
					alert("All fields are mandatory");
					return false;
				}else return true;
				
				      }
        </script>
    </head>

    <body>

        <form method="post" name="frmTrainoc" action="successMsg.php" onsubmit="return validation();">        
            <table align="center" bgcolor="#E2E2E2" style="border-style:ridge" width="800" id="studTrain">
                <!---->
                <tr>
                    <td colspan="4" align="center"><font><b><h2>Industrial Training Application Form</h2></b></font></td>
                </tr>
                <tr>
                    <td>Training Name:</td>
                    <td>
                        <input type="radio" name="tname" value="Winter Training" />Winter Training <br/>
                        <input type="radio" name="tname" value="Summer Training " />Summer Training
                    </td>
                </tr>
                <tr bgcolor="#FFFFFF">
                    <td colspan="4" align="center" style="text-align: right;">
                        <font size="+1"><b style="margin-right: 20%;">Student Details</b>
                            <span style="color: red;font-size: 16px;font-weight: bold;text-align: right;">*All fields are mandatory</span>
                        </font>
                    </td>
                </tr>
                <tr>
                    <td>Name:</td>
                    <td>
                        <input type="text" name="stuname" />
                    </td>
                </tr>
                <tr>
                    <td>College Roll No:</td>
                    <td><input type="text" name="sturoll" /></td>
                </tr>
                <tr>
                    <td>Stream:</td>
                    <td>
                        <select name="stustream">                            
                            <option>B.TECH</option>
                            <option>M.C.A.</option>
                            <option>M.TECH</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Branch:</td>
                    <td><select name="stubranch">                            
                            <option>Computer Science Engg.</option>
                            <option>Information Technology Engg.</option>
                            <option>Electrical Engg.</option>
                            <option>Electronics & Electrical Engg.</option>
                            <option>Electronics & Telecomm. Engg.</option>
                            <option>Electronics & Instrumentation Engg.</option>
                            <option>Mechanical Engg.</option>
                            <option>Civil Engg.</option>
                            <option>Automobile Engg.</option>
                        </select></td>
                </tr>
                <tr>
                    <td>Semester:</td>
                    <td><select name="stusem">
                            <option>1st Semester</option>
                            <option>2nd Semester</option>
                            <option>3rd Semester</option>
                            <option>4th Semester</option>
                            <option>5th Semester</option>
                            <option>6th Semester</option>
                            <option>7th Semester</option>
                            <option>8th Semester</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td>Contact No:</td>
                    <td><input type="text" name="stucon" /></td>
                </tr>
                <tr>
                    <td>Email Id:</td>
                    <td><input type="text" name="stuemail" /></td>
                </tr>
                <tr>
                    <td>University Name:</td>
                    <td>
                        <select name="university" id="university" onchange="toggleButton(this.id)">
                            <option value="">Select University</option>
                            <option value="Kiit">Kiit University</option>
                            <option value="Other">Other University</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" align="center">
                        <input type="button" value="Next" id="next" style="display:none" onclick="toggleForm(this.id);">
                    </td>
                </tr>
            </table> 
            <table align="center" bgcolor="#E2E2E2" style="border-style:ridge;display:none" width="800" id="indusTrain">
                <tr bgcolor="#FFFFFF">                    
                    <td colspan="4" align="center" style="text-align: right;">
                        <font size="+1"><b style="margin-right: 20%;">Organisation Details</b>
                            <span style="color: red;font-size: 16px;font-weight: bold;text-align: right;">*All fields are mandatory</span>
                        </font>
                    </td>
                </tr>
                <tr>
                    <td>Name of the Industry/Organisation Name:</td>
                    <td><input type="text" name="txtorgname" style="width:200px" /></td>
                </tr>
                <tr>
                    <td>Name of the concerned Person:<br/>(To whom Letter shall be issued)</td>
                    <td><input type="text" name="txtname" style="width:200px" /></td>
                </tr>
                <tr>
                    <td>Designation of the concerned Person:<br/>(To whom Letter shall be issued)</td>
                    <td><input type="text" name="txtdesig" style="width:200px" /></td>
                </tr>
                <tr>
                    <td>Industry/Organisation Address:</td>
                    <!--<td><textarea name="txtaddress" rows="4" cols="30"></textarea></td>-->
                    <td><table border="0">
                                <tr>
                                    <td>Address1</td>
                                    <td><input type="text" name="address1" size="30" placeholder="Enter local address"></td>
                                </tr>
                                <tr>
                                    <td>Address2</td>
                                    <td><input type="text" name="address2" size="30" placeholder="Enter city,State,Pin..."></td>
                                </tr>
                        </table>
                    </td>
                </tr>
                <tr>
                    <td>Industry/Organisation Ref. Person Name:</td>
                    <td><input type="text" name="txtref" style="width:200px" /></td>
                </tr>
                <tr>
                    <td>Ref. person Contact No:</td>
                    <td><input type="text" name="txtmob" /></td>
                    <td align="right">Email Id:</td>
                    <td><input type="text" name="txtemail" /></td>
                </tr>
                <tr>
                    <td>Training Period:</td>
                    <td>
                        <select name="date">
                            <option value="NA">Date</option>
                            <option value="01">1</option>
                            <option value="02">2</option>
                            <option value="03">3</option>
                            <option value="04">4</option>
                            <option value="05">5</option>
                            <option value="06">6</option>
                            <option value="07">7</option>
                            <option value="08">8</option>
                            <option value="09">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
                            <option value="31">31</option>
                        </select>
                        <select name="month">
                            <option value="NA">Month</option>
                            <option value="01">Jan</option>
                            <option value="02">Feb</option>
                            <option value="03">Mar</option>
                            <option value="04">Apr</option>
                            <option value="05">May</option>
                            <option value="06">Jun</option>
                            <option value="07">Jul</option>
                            <option value="08">Aug</option>
                            <option value="09">Sep</option>
                            <option value="10">Oct</option>
                            <option value="11">Nov</option>
                            <option value="12">Dec</option></select>
                        <select name="year">
                            <option value="NA">Year</option>
                            <option value="2012">2012</option>
                            <option value="2013">2013</option>
                            <option value="2014">2014</option>
                            <option value="2015">2015</option>
                            <option value="2016">2016</option>
                            <option value="2017">2017</option>
                            <option value="2018">2018</option>
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                        </select>
                    </td>
                    <td>to</td>
                    <td>
                        <select name="todate">
                            <option value="NA">Date</option>
                            <option value="01">1</option>
                            <option value="02">2</option>
                            <option value="03">3</option>
                            <option value="04">4</option>
                            <option value="05">5</option>
                            <option value="06">6</option>
                            <option value="07">7</option>
                            <option value="08">8</option>
                            <option value="09">9</option>
                            <option value="10">10</option>
                            <option value="11">11</option>
                            <option value="12">12</option>
                            <option value="13">13</option>
                            <option value="14">14</option>
                            <option value="15">15</option>
                            <option value="16">16</option>
                            <option value="17">17</option>
                            <option value="18">18</option>
                            <option value="19">19</option>
                            <option value="20">20</option>
                            <option value="21">21</option>
                            <option value="22">22</option>
                            <option value="23">23</option>
                            <option value="24">24</option>
                            <option value="25">25</option>
                            <option value="26">26</option>
                            <option value="27">27</option>
                            <option value="28">28</option>
                            <option value="29">29</option>
                            <option value="30">30</option>
                            <option value="31">31</option>
                        </select>
                        <select name="tomonth">
                            <option value="NA">Month</option>
                            <option value="01">Jan</option>
                            <option value="02">Feb</option>
                            <option value="03">Mar</option>
                            <option value="04">Apr</option>
                            <option value="05">May</option>
                            <option value="06">Jun</option>
                            <option value="07">Jul</option>
                            <option value="08">Aug</option>
                            <option value="09">Sep</option>
                            <option value="10">Oct</option>
                            <option value="11">Nov</option>
                            <option value="12">Dec</option></select>
                        <select name="toyear">
                            <option value="NA">Year</option>
                            <option value="2012">2012</option>
                            <option value="2013">2013</option>
                            <option value="2014">2014</option>
                            <option value="2015">2015</option>
                            <option value="2016">2016</option>
                            <option value="2017">2017</option>
                            <option value="2018">2018</option>
                            <option value="2019">2019</option>
                            <option value="2020">2020</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <td colspan="4" align="center">
                        <input type="submit" name="btnprint" value="Submit" />
                        <input type="reset" name="btnreset" value="Reset" />
                        <input type="button" value="Back" id="back"  onclick="toggleForm(this.id);" />
                    </td>
                </tr>
            </table>
        </form>

    </body>
</html>

<?php
$pageContent = ob_get_contents();
ob_clean();
include_once 'TNPOtemplate1.php';
?>