<?php

header("location: studentAppl.php");

