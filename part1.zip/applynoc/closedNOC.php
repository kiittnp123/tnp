<?php

/* include_once 'protected.php';
  include'db.php';
  ob_start();

  if (!$_SESSION['userName']) {
  header("location:logout.php");
  }
 */
ob_start();

        echo "<br><br><div style='text-align:center;'><b><p style='font-size:20px;color:red;'>NOC Forwarding form submission has been CLOSED.</p></b><br><br>Please contact Training & Placement Department.<br><br><b><u>Office Time</u></b><br><b>B. Tech 4th Semester:</b> 2:30pm to 4:30pm<br><b>B. Tech 6th Semester:</b> 5:00pm to 6:30pm<br><br><br><b><u>Office Address</u></b><br>Department of Training & Placement,<br>Campus - 2,<br>Near Railway Railway Reservation Center,<br>Bhubaneswar, Odisha<br><b>Email ID:</b> training@kiit.ac.in</div>";
    

$pageContent = ob_get_contents();
ob_clean();
include_once 'TNPOtemplate1.php';
?>