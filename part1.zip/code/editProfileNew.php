<?php
ob_start();
include_once 'protectedStudent.php';
include_once '../db.php';
$username=$_SESSION['userName'];
//var_dump($_POST);
if(isset($_POST['btn_save_personal']) && !empty($_POST['btn_save_personal']) && $_POST['btn_save_personal']=='PROCEED TOWARDS ACADEMIC SECTION')
    {
        $name=$_POST['fname']." ".$_POST['mname']." ".$_POST['lname'];
        $yearjoin=$_POST['yearjoin'];
	$yr_passout=$_POST['yearpass'];
        $boarding=$_POST['boarding'];
	$category=$_POST['category'];
	$gender=$_POST['gender'];
        $dob=$_POST['year']."-".$_POST['month']."-".$_POST['date'];
        $perm_contact=$_POST['permanent_contact'];
        $stu_mobile=$_POST['txtmobile'];
        $stu_email=$_POST['txtaltemail'];
        $fname=$_POST['txtfhname'];
        $fmobile=$_POST['txtmobile'];
	$femail=$_POST['txtfemail'];
	$f_org=$_POST['father_industry'];
	$f_address=$_POST['father_post'];
	$perm_address=$_POST['txtpermadd'];
	$corr_address=$_POST['txtcorresadd'];
        
        $destination='';
	if($_FILES['img']['type'] == 'image/png' ||
           $_FILES['img']['type'] == 'image/jpeg' || 
           $_FILES['img']['type'] == 'image/gif')
			   {
				   $std_id="select student_id from tbl_student where email='$username'";
				   $res_id=mysql_query($std_id);
				   $data=mysql_fetch_array($res_id);
                                   $id=$data[0];
                                   $ext=end(explode(".", $_FILES['img']['name']));
                                   $destination="../img/student".$id.".".$ext;
                                   $res=move_uploaded_file($_FILES['img']['tmp_name'], $destination);
                           }
	$personalUpdateSql="UPDATE tbl_student 
                            set
                            name='$name',
                            year_join=$yearjoin,
                            year_passout=$yr_passout,
                            boarding='$boarding',
                            category='$category',
                            gender='$gender',
                            dob='$dob',
                            mobile_perm='$perm_contact',
                            mobile='$stu_mobile',
                            alt_email='$stu_email',
                            father_name='$fname',
                            father_mobile='$fmobile',
                            father_email='$femail',
                            father_add='$f_address',
                            father_org='$f_org',
                            permanent_address='$perm_address',
                            corres_address='$corr_address',
                            image='$destination'
                            where email='$username'";
	$personalUpdateRes=  mysql_query($personalUpdateSql);
        //echo $personalUpdateSql;
        if($personalUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("Personal information saved. Please proceed with academic information")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
}
if(isset($_POST['btn_save_academic']) && !empty($_POST['btn_save_academic']) && $_POST['btn_save_academic']=='PROCEED TO FINAL SUBMISSION')
    {
        if(isset($_POST['ssc_done']) && !empty($_POST['ssc_done']) && $_POST['ssc_done']=='ssc'){
            $ssc_board=$_POST['ssc_board'];
            $ssc_state=$_POST['ssc_state'];
            $ssc_yop=$_POST['ssc_yop'];
            $ssc_board_total=$_POST['ssc_board_total'];
            $ssc_board_secure=$_POST['ssc_board_secured'];
            $ssc_total=$_POST['ssc_total'];
            $ssc_secure=$_POST['ssc_secured'];
            $ssc_distance=$_POST['ssc_distance'];
        }else{
            $ssc_board='NA';
            $ssc_state='NA';
            $ssc_yop=0;
            $ssc_board_total=0;
            $ssc_board_secure=0;
            $ssc_total=0;
            $ssc_secure=0;
            $ssc_distance='NA';
        }
        if(isset($_POST['hsc_done']) && !empty($_POST['hsc_done']) && $_POST['hsc_done']=='hsc'){
            $hsc_board=$_POST['hsc_board'];
            $hsc_state=$_POST['hsc_state'];
            $hsc_yop=$_POST['hsc_yop'];
            $hsc_yoj=$_POST['hsc_yoj'];
            $hsc_board_total=$_POST['hsc_board_total'];
            $hsc_board_secure=$_POST['hsc_board_secured'];
            $hsc_total=$_POST['hsc_total'];
            $hsc_secure=$_POST['hsc_secured'];
            $hsc_distance=$_POST['hsc_distance'];
        }else{
            $hsc_board='NA';
            $hsc_state='NA';
            $hsc_yop=0;
            $hsc_board_total=0;
            $hsc_board_secure=0;
            $hsc_total=0;
            $hsc_secure=0;
            $hsc_distance='NA';
        }
        if(isset($_POST['dip_done']) && !empty($_POST['dip_done']) && $_POST['dip_done']=='dip'){
            $dip_board=$_POST['dip_board'];
            $dip_state=$_POST['dip_state'];
            $dip_yop=$_POST['dip_yop'];
            $dip_yoj=$_POST['dip_yoj'];
            $dip_board_total=$_POST['dip_board_total'];
            $dip_board_secure=$_POST['dip_board_secured'];
            $dip_total=$_POST['dip_total'];
            $dip_secure=$_POST['dip_secured'];
            $dip_distance=$_POST['dip_distance'];
        }else{
            $dip_board='NA';
            $dip_state='NA';
            $dip_yop=0;
            $dip_board_total=0;
            $dip_board_secure=0;
            $dip_total=0;
            $dip_secure=0;
            $dip_distance='NA';
        }
        if(isset($_POST['gra_done']) && !empty($_POST['gra_done']) && $_POST['gra_done']=='gra'){
            $gra_board=$_POST['gra_board'];
            $gra_state=$_POST['gra_state'];
            $gra_yop=$_POST['gra_yop'];
            $gra_yoj=$_POST['gra_yoj'];
            $gra_board_total=$_POST['gra_board_total'];
            $gra_board_secure=$_POST['gra_board_secured'];
            $gra_total=$_POST['gra_total'];
            $gra_secure=$_POST['gra_secured'];
            $gra_distance=$_POST['gra_distance'];
            $gra_stream=$_POST['gra_stream'];
            $gra_honors=$_POST['gra_honours'];
        }else{
            $gra_board='NA';
            $gra_state='NA';
            $gra_yop=0;
            $gra_yoj=0;
            $gra_board_total=0;
            $gra_board_secure=0;
            $gra_total=0;
            $gra_secure=0;
            $gra_distance='NA';
            $gra_stream='NA';
            $gra_honors='NA';
        }
        
        $branch=$_POST['branch'];
	$stream=$_POST['stream'];
        if(isset($_POST['lateral_entry']) && !empty($_POST['lateral_entry']))
            $lateralEntry=$_POST['lateral_entry'];
        else
            $lateralEntry = 'no';
        
        if($lateralEntry == 'yes'){
            $sgpa_1=0.00;
            $sgpa_2=0.00;
            $cgpa_1=0.00;
            $cgpa_2=0.00;
            $back_1=0;
            $back_2=0;
        }else{
            $sgpa_1=$_POST['sgpa_1'];
            $sgpa_2=$_POST['sgpa_2'];
            $cgpa_1=$_POST['cgpa_1'];
            $cgpa_2=$_POST['cgpa_2'];
            $back_1=$_POST['backlog_1'];
            $back_2=$_POST['backlog_2'];
        }
	$sgpa_3=$_POST['sgpa_3'];
	$sgpa_4=$_POST['sgpa_4'];
	$sgpa_5=$_POST['sgpa_5'];
	$sgpa_6=$_POST['sgpa_6'];
        $cgpa_3=$_POST['cgpa_3'];
	$cgpa_4=$_POST['cgpa_4'];
	$cgpa_5=$_POST['cgpa_5'];
	$cgpa_6=$_POST['cgpa_6'];
        $back_3=$_POST['backlog_3'];
	$back_4=$_POST['backlog_4'];
	$back_5=$_POST['backlog_5'];
	$back_6=$_POST['backlog_6'];
        if($stream == 'M.Tech' || $stream == 'MCA'){
            $sgpa_7=0.00;
            $sgpa_8=0.00;
            $sgpa_9=0.00;
            $sgpa_10=0.00;
            $cgpa_7=0.00;
            $cgpa_8=0.00;
            $cgpa_9=0.00;
            $cgpa_10=0.00;
            $back_7=0;
            $back_8=0;
            $back_9=0;
            $back_10=0;
        }else{
            $sgpa_7=$_POST['sgpa_7'];
            $sgpa_8=$_POST['sgpa_8'];
            $cgpa_7=$_POST['cgpa_7'];
            $cgpa_8=$_POST['cgpa_8'];
            $back_7=$_POST['backlog_7'];
            $back_8=$_POST['backlog_8'];
            if($stream == 'B.Tech'){
                $sgpa_9=0.00;
                $sgpa_10=0.00;
                $cgpa_9=0.00;
                $cgpa_10=0.00;
                $back_9=0;
                $back_10=0;
            }else{
                $sgpa_9=$_POST['sgpa_9'];
                $sgpa_10=$_POST['sgpa_10'];
                $cgpa_9=$_POST['cgpa_9'];
                $cgpa_10=$_POST['cgpa_10'];
                $back_9=$_POST['backlog_9'];
                $back_10=$_POST['backlog_10'];
            }
        }
	
        $academicUpdateSql="UPDATE `tbl_student` SET 
                         `branch`='$branch',
                         `stream`='$stream',
                         `ssc_board`='$ssc_board',
                         `ssc_state`='$ssc_state',
                         `ssc_yop`='$ssc_yop',
                         `ssc_board_total`='$ssc_board_total',
                         `ssc_board_secure`='$ssc_board_secure',
                         `ssc_total`='$ssc_total',
                         `ssc_secure`='$ssc_secure',
                         `ssc_distance`='$ssc_distance',
                         `hsc_board`='$hsc_board',
                         `hsc_state`='$hsc_state',
                         `hsc_yop`='$hsc_yop',
                         `hsc_yoj`='$hsc_yoj',
                         `hsc_board_total`='$hsc_board_total',
                         `hsc_board_secure`='$hsc_board_secure',
                         `hsc_total`='$hsc_total',
                         `hsc_secure`='$hsc_secure',
                         `hsc_distance`='$hsc_distance',
                         `dip_board`='$dip_board',
                         `dip_state`='$dip_state',
                         `dip_yop`='$dip_yop',
                         `dip_yoj`='$dip_yoj',
                         `dip_board_total`='$dip_board_total',
                         `dip_board_secure`='$dip_board_secure',
                         `dip_total`='$dip_total',
                         `dip_secure`='$dip_secure',
                         `dip_distance`='$dip_distance',
                         `gra_board`='$gra_board',
                         `gra_state`='$gra_state',
                         `gra_yop`='$gra_yop',
                         `gra_yoj`='$gra_yoj',
                         `gra_board_total`='$gra_board_total',
                         `gra_board_secure`='$gra_board_secure',
                         `gra_total`='$gra_total',
                         `gra_secure`='$gra_secure',
                         `gra_distance`='$gra_distance',
                         `gra_stream`='$gra_stream',
                         `gra_honors`='$gra_honors',
                         `sgpa_1`='$sgpa_1',
                         `sgpa_2`='$sgpa_2',
                         `sgpa_3`='$sgpa_3',
                         `sgpa_4`='$sgpa_4',
                         `sgpa_5`='$sgpa_5',
                         `sgpa_6`='$sgpa_6',
                         `sgpa_7`='$sgpa_7',
                         `sgpa_8`='$sgpa_8',
                         `sgpa_9`='$sgpa_9',
                         `sgpa_10`='$sgpa_10',
                         `cgpa_1`='$cgpa_1',
                         `cgpa_2`='$cgpa_2',
                         `cgpa_3`='$cgpa_3',
                         `cgpa_4`='$cgpa_4',
                         `cgpa_5`='$cgpa_5',
                         `cgpa_6`='$cgpa_6',
                         `cgpa_7`='$cgpa_7',
                         `cgpa_8`='$cgpa_8',
                         `cgpa_9`='$cgpa_9',
                         `cgpa_10`='$cgpa_10',
                         `back_1`='$back_1',
                         `back_2`='$back_2',
                         `back_3`='$back_3',
                         `back_4`='$back_4',
                         `back_5`='$back_5',
                         `back_6`='$back_6',
                         `back_7`='$back_7',
                         `back_8`='$back_8',
                         `back_9`='$back_9',
                         `back_10`='$back_10',
                         `lateral`='$lateralEntry' 
                          WHERE email='$username'";
        $academicUpdateRes=  mysql_query($academicUpdateSql);
        if($academicUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("Academic information saved. Please proceed with final part")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
}
if(isset($_POST['btn_save_final']) && !empty($_POST['btn_save_final']) && $_POST['btn_save_final']=='SUBMIT FOR VERIFICATION')
    {
        
        $gap_reason=$_POST['gap_reason'];
	$hobby=$_POST['hobby'];
	$preference=$_POST['pref'];
        $projectName=$_POST['pro1_name'];
        $projectOrg=$_POST['pro1_org'];
        $projectDuration=$_POST['pro1_dur'];
        $projectGuide=$_POST['pro1_guide'];
        $projectSummary=$_POST['pro1_sum'];
        
        $finalUpdateSql="update tbl_student set
                         gap_reason='$gap_reason',
                         hobby='$hobby',
                         preference='$preference',
                         pro_name='$projectName',
                         pro_org='$projectOrg',
                         pro_duration='$projectDuration',
                         pro_guide='$projectGuide',
                         pro_summary='$projectSummary',
                         status='Pending'
                         where email='$username'";
        $finalUpdateRes=  mysql_query($finalUpdateSql);
        if($finalUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("You have been successfully registered.")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
}
if(isset($_POST['btn_update_verification']) && !empty($_POST['btn_update_verification']) && $_POST['btn_update_verification']=='SUBMIT FOR VERIFICATION')
    {
        
    $stream=$_POST['stream'];
    //echo $stream;
    if(isset($_POST['lateral_entry']) && !empty($_POST['lateral_entry']))
            $lateralEntry=$_POST['lateral_entry'];
        else
            $lateralEntry = 'no';
        
        if($lateralEntry == 'yes'){
            $sgpa_1=0.00;
            $sgpa_2=0.00;
            $cgpa_1=0.00;
            $cgpa_2=0.00;
            $back_1=0;
            $back_2=0;
        }else{
            $sgpa_1=$_POST['sgpa_1'];
            $sgpa_2=$_POST['sgpa_2'];
            $cgpa_1=$_POST['cgpa_1'];
            $cgpa_2=$_POST['cgpa_2'];
            $back_1=$_POST['backlog_1'];
            $back_2=$_POST['backlog_2'];
        }
	$sgpa_3=$_POST['sgpa_3'];
	$sgpa_4=$_POST['sgpa_4'];
	$sgpa_5=$_POST['sgpa_5'];
	$sgpa_6=$_POST['sgpa_6'];
        $cgpa_3=$_POST['cgpa_3'];
	$cgpa_4=$_POST['cgpa_4'];
	$cgpa_5=$_POST['cgpa_5'];
	$cgpa_6=$_POST['cgpa_6'];
        $back_3=$_POST['backlog_3'];
	$back_4=$_POST['backlog_4'];
	$back_5=$_POST['backlog_5'];
	$back_6=$_POST['backlog_6'];
        if($stream == 'M.Tech' || $stream == 'MCA'){
            $sgpa_7=0.00;
            $sgpa_8=0.00;
            $sgpa_9=0.00;
            $sgpa_10=0.00;
            $cgpa_7=0.00;
            $cgpa_8=0.00;
            $cgpa_9=0.00;
            $cgpa_10=0.00;
            $back_7=0;
            $back_8=0;
            $back_9=0;
            $back_10=0;
        }else{
            $sgpa_7=$_POST['sgpa_7'];
            $sgpa_8=$_POST['sgpa_8'];
            $cgpa_7=$_POST['cgpa_7'];
            $cgpa_8=$_POST['cgpa_8'];
            $back_7=$_POST['backlog_7'];
            $back_8=$_POST['backlog_8'];
            if($stream == 'B.Tech'){
                $sgpa_9=0.00;
                $sgpa_10=0.00;
                $cgpa_9=0.00;
                $cgpa_10=0.00;
                $back_9=0;
                $back_10=0;
            }else{
                $sgpa_9=$_POST['sgpa_9'];
                $sgpa_10=$_POST['sgpa_10'];
                $cgpa_9=$_POST['cgpa_9'];
                $cgpa_10=$_POST['cgpa_10'];
                $back_9=$_POST['backlog_9'];
                $back_10=$_POST['backlog_10'];
            }
        }        
        $cgpaUpdateSql="UPDATE `tbl_student` SET 
                               `sgpa_1`='$sgpa_1',
                               `sgpa_2`='$sgpa_2',
                               `sgpa_3`='$sgpa_3',
                               `sgpa_4`='$sgpa_4',
                               `sgpa_5`='$sgpa_5',
                               `sgpa_6`='$sgpa_6',
                               `sgpa_7`='$sgpa_7',
                               `sgpa_8`='$sgpa_8',
                               `sgpa_9`='$sgpa_9',
                               `sgpa_10`='$sgpa_10',
                               `cgpa_1`='$cgpa_1',
                               `cgpa_2`='$cgpa_2',
                               `cgpa_3`='$cgpa_3',
                               `cgpa_4`='$cgpa_4',
                               `cgpa_5`='$cgpa_5',
                               `cgpa_6`='$cgpa_6',
                               `cgpa_7`='$cgpa_7',
                               `cgpa_8`='$cgpa_8',
                               `cgpa_9`='$cgpa_9',
                               `cgpa_10`='$cgpa_10',
                               `back_1`='$back_1',
                               `back_2`='$back_2',
                               `back_3`='$back_3',
                               `back_4`='$back_4',
                               `back_5`='$back_5',
                               `back_6`='$back_6',
                               `back_7`='$back_7',
                               `back_8`='$back_8',
                               `back_9`='$back_9',
                               `back_10`='$back_10',
                                status='Pending' 
                                WHERE email='$username'";
        $cgpaUpdateRes=mysql_query($cgpaUpdateSql);
        if($cgpaUpdateRes)
            $_SESSION['ErrMsg']='<script>alert("Your information is successfully updated and sent for verification.")</script>';
	else
            $_SESSION['ErrMsg']='<script>alert("Some problem occurred. Please contact administrator")</script>';
        

}
$sql="select * from tbl_student where email='$username'";
$res=mysql_query($sql);
$row=mysql_fetch_array($res);
$status=$row['status'];
if($status=='Created')
    {
    if(isset($_GET['section']) && !empty($_GET['section']) && $_GET['section']=='personal'){
?>
<form action="editProfileNew.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="section" value="academic" />
        <table align="center" width="1000">
        <tr>
            <td colspan="2" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>REGISTRATION FORM</b></font></td>
        </tr>
        <tr>
            <td align="left" colspan="2" bgcolor="#003399"><font color="#FFFFFF">Personal Detail</font></td>
        </tr>
        <tr>
            <td align="left" colspan="2">
                First Name:<input type="text" name="fname" size="25" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                Middle Name:<input type="text" name="mname" size="25" />&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                Last Name:<input type="text" name="lname" size="25" /></td>
        </tr>
        <tr>
            <td align="left" >
                Roll no:
            </td>
            <td>
                <input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" />
            </td>
        </tr>
        <tr>
            <td>
            Year of Joining:
            </td>
            <td>
            <select name="yearjoin" id="yearjoin">
            <?php include_once '../inc/yearList.php'; ?>
            </select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Passing:
            </td>
            <td>
                <select name="yearpass">
                    <?php include_once '../inc/yearList.php'; ?>
                </select>
            </td>
        </tr>
        
        
        <tr>
            <td align="left">
                       Boarding:
            </td>
            <td>           
            <select name="boarding">
                                    <option>Hostel</option>
                                    <option>Day Scholar</option>
                                </select>
            </td>
        </tr>
        <tr>
            <td>
                Category:
                </td>
            <td>
                <select name="category">
                                    <option>General</option>
                                    <option>OBC</option>
                                    <option>Minority</option>
                                    <option>PH</option>
                                    <option>SC</option>
                                    <option>ST</option>
                                    <option>GC</option></select>
            </td>
        </tr>
        <tr>
            <td>       Gender:
                </td>
            <td>
                <select name="gender">
                                    <option>Male</option>
                                    <option>Female</option></select></td>
        </tr>
        <tr>
            <td>
                Date Of Birth
             </td>
            <td>
                <select name="date">
            		<option value="Date">Date</option>
                        <option value="01">1</option>
                        <option value="02">2</option>
                        <option value="03">3</option>
                        <option value="04">4</option>
                        <option value="05">5</option>
                        <option value="06">6</option>
                        <option value="07">7</option>
                        <option value="08">8</option>
                        <option value="09">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option></select>
           		<select name="month">
                		<option value="Month">Month</option>
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">Aug</option>
                        <option value="09">Sept</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option></select>
                <select name="year">
                		<option value="Year">Year</option>
                        <option value="1980">1980</option>
                        <option value="1981">1981</option>
                        <option value="1982">1982</option>
                        <option value="1983">1983</option>
                        <option value="1984">1984</option>
                        <option value="1985">1985</option>
                        <option value="1986">1986</option>
                        <option value="1987">1987</option>
                        <option value="1988">1988</option>
                        <option value="1989">1989</option>
                        <option value="1990">1990</option>
                        <option value="1991">1991</option>
                        <option value="1992">1992</option>
                        <option value="1993">1993</option>
                        <option value="1994">1994</option>
                        <option value="1995">1995</option>
                        <option value="1996">1996</option>
                        <option value="1997">1997</option>
                        <option value="1998">1998</option>
                        <option value="1999">1999</option>
                        <option value="2000">2000</option></select>
            </td></tr>
        <tr>
               <td>Permanent Contact Number 
       </td>
            <td>            
       <input type="text" name="permanent_contact" size="25" /> </td>
        </tr>
        <tr>
            <td>Upload Your Image:
            </td>
            <td>
             <input type="file" name="img" /></td>
        </tr>
        <tr>
            <td align="left">
               Mobile Number(Self)</td>
            <td><input type="text" name="txtmobile" size="25" />
         </td>
        </tr>
        <tr>
            <td>
               e-Mail ID (Self)</td>
            <td><input type="text" name="txtaltemail" size="25"/>
            </td>
        </tr>
        <tr>
            <td align="left">
                Father's Name:</td>
            <td>
                <input type="text" name="txtfhname" size="50" />
              
            </td>
        </tr>
        <tr>
            <td align="left">
              Father's Mobile Number</td>
            <td><input type="text" name="txtmobile" size="25" />
               </td>
        </tr>
        <tr>
            <td>
              Father's e-Mail ID</td>
            <td>
                <input type="text" name="txtfemail" size="25"/>
            </td>
        </tr>
        <tr valign="top">
            <td align="left" valign="top">
                Occupation with:</td>
            <td>
                <input type="text" name="father_industry" size="25"/>
            </td>
        </tr>
        <tr>
            <td align="left" valign="middle">
                Designation & Address</td>
            <td><textarea name="father_post" rows="5" cols="50"></textarea>
            </td>
        </tr>
        <tr>
            <td align="left" valign="middle">
                 Permanent Address</td>
            <td><textarea name="txtpermadd" rows="5" cols="50"></textarea>
            </td>
        </tr>
        <tr>
            <td align="left" valign="middle">
                 Correspondence Address</td>
            <td><textarea name="txtcorresadd" rows="5" cols="50"></textarea>
            </td>
        </tr>
        <tr>
            <td>
                Select your completed Academic Qualifications
            </td>
            <td>
                <input type="checkbox" value="ssc" name="ssc_done"/>10<sup>th</sup>
                <input type="checkbox" value="hsc" name="hsc_done"/>12<sup>th</sup>
                <input type="checkbox" value="dip" name="dip_done"/>Diploma
                <input type="checkbox" value="gra" name="gra_done"/>Graduation
            </td>
        </tr>
        <tr>
            <td colspan="2">
                <input type="submit" name="btn_save_personal" value="PROCEED TOWARDS ACADEMIC SECTION" />
            </td>
        </tr>
        </table>
    </form>
<?php        
    }
    elseif (isset($_POST['section']) && !empty($_POST['section']) && $_POST['section']=='academic') {
       
?>
<form action="editProfileNew.php" method="post">
    <input type="hidden" name="section" value="other" />
<table align="center" width="1000">
    <?php 
    if(isset($_POST['ssc_done']) && !empty($_POST['ssc_done']) && $_POST['ssc_done']=='ssc'){
    ?>
    <input type="hidden" name="ssc_done" value="ssc" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">10<sup>th</sup> (SSC)</font></td>
        </tr>
        <tr>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="ssc_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='ssc_state'>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Pondicherry">Pondicherry</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Tripura">Tripura</option>
<option value="Uttaranchal">Uttaranchal</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="West Bengal">West Bengal</option>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="ssc_yop" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            
                            <option>2012</option>
                                    <option>2013</option>
                                    <option>2014</option>
                                    <option>2015</option>
                                    <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
                <option>2020</option>
                        </select>
            </td>
            <td>
                Passed from a Distance Course
            </td>
            <td>
                <input type="radio" name="ssc_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="ssc_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="ssc_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="ssc_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="ssc_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="ssc_secured" value="" />
                </td>
            
        </tr>
    <?php
    }
    if(isset($_POST['hsc_done']) && !empty($_POST['hsc_done']) && $_POST['hsc_done']=='hsc'){
?>
        <input type="hidden" name="hsc_done" value="hsc" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">12<sup>th</sup> (HSC)</font></td>
        </tr>
        <tr>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="hsc_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='hsc_state'>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Pondicherry">Pondicherry</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Tripura">Tripura</option>
<option value="Uttaranchal">Uttaranchal</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="West Bengal">West Bengal</option>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <select name="hsc_yoj" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            <option>2012</option>
                            <option>2013</option>
                            <option>2014</option>
                            <option>2015</option>
                            <option>2016</option>
                            <option>2017</option>
                            <option>2018</option>
                            <option>2019</option>
                            <option>2020</option>
                        </select>
            </td>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="hsc_yop" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            
                            <option>2012</option>
                                    <option>2013</option>
                                    <option>2014</option>
                                    <option>2015</option>
                                    <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
                <option>2020</option>
                        </select>
            </td>
        </tr>
            <tr>
                <td colspan="2">
                Passed from a Distance Course
            </td>
            <td colspan="2">
                <input type="radio" name="hsc_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="hsc_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="hsc_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="hsc_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="hsc_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="hsc_secured" value="" />
                </td>
            
        </tr>
    <?php
    }
    if(isset($_POST['dip_done']) && !empty($_POST['dip_done']) && $_POST['dip_done']=='dip'){
?>
        <input type="hidden" name="dip_done" value="dip" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">Diploma</font></td>
        </tr>
        <tr>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="dip_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='dip_state'>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Pondicherry">Pondicherry</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Tripura">Tripura</option>
<option value="Uttaranchal">Uttaranchal</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="West Bengal">West Bengal</option>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <select name="dip_yoj" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            
                            <option>2012</option>
                                    <option>2013</option>
                                    <option>2014</option>
                                    <option>2015</option>
                                    <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
                <option>2020</option>
                        </select>
            </td>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="dip_yop" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            
                            <option>2012</option>
                                    <option>2013</option>
                                    <option>2014</option>
                                    <option>2015</option>
                                    <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
                <option>2020</option>
                        </select>
            </td>
        </tr>
        <tr>
        <td colspan="2">
                Passed from a Distance Course
            </td>
            <td colspan="2">
                <input type="radio" name="dip_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="dip_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="dip_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="dip_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="dip_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="dip_secured" value="" />
                </td>
            
        </tr>
    <?php
    }
    if(isset($_POST['gra_done']) && !empty($_POST['gra_done']) && $_POST['gra_done']=='gra'){
?>
        <input type="hidden" name="gra_done" value="gra" />
    <tr>
        <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">GRADUATION</font></td>
        </tr>
        <tr>
            <td>
                Board / Council
            </td>
            <td>
                <input type="text" name="gra_board" value="" />
            </td>
            <td>
                State
            </td>
            <td>
                <select name='gra_state'>
<option value="Andaman and Nicobar Islands">Andaman and Nicobar Islands</option>
<option value="Andhra Pradesh">Andhra Pradesh</option>
<option value="Arunachal Pradesh">Arunachal Pradesh</option>
<option value="Assam">Assam</option>
<option value="Bihar">Bihar</option>
<option value="Chandigarh">Chandigarh</option>
<option value="Chhattisgarh">Chhattisgarh</option>
<option value="Dadra and Nagar Haveli">Dadra and Nagar Haveli</option>
<option value="Daman and Diu">Daman and Diu</option>
<option value="Delhi">Delhi</option>
<option value="Goa">Goa</option>
<option value="Gujarat">Gujarat</option>
<option value="Haryana">Haryana</option>
<option value="Himachal Pradesh">Himachal Pradesh</option>
<option value="Jammu and Kashmir">Jammu and Kashmir</option>
<option value="Jharkhand">Jharkhand</option>
<option value="Karnataka">Karnataka</option>
<option value="Kerala">Kerala</option>
<option value="Lakshadweep">Lakshadweep</option>
<option value="Madhya Pradesh">Madhya Pradesh</option>
<option value="Maharashtra">Maharashtra</option>
<option value="Manipur">Manipur</option>
<option value="Meghalaya">Meghalaya</option>
<option value="Mizoram">Mizoram</option>
<option value="Nagaland">Nagaland</option>
<option value="Orissa">Orissa</option>
<option value="Pondicherry">Pondicherry</option>
<option value="Punjab">Punjab</option>
<option value="Rajasthan">Rajasthan</option>
<option value="Sikkim">Sikkim</option>
<option value="Tamil Nadu">Tamil Nadu</option>
<option value="Tripura">Tripura</option>
<option value="Uttaranchal">Uttaranchal</option>
<option value="Uttar Pradesh">Uttar Pradesh</option>
<option value="West Bengal">West Bengal</option>
</select>
            </td>
        </tr>
        <tr>
            <td>
                Year of Joining
            </td>
            <td>
                <select name="gra_yoj" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            
                            <option>2012</option>
                                    <option>2013</option>
                                    <option>2014</option>
                                    <option>2015</option>
                                    <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
                <option>2020</option>
                        </select>
            </td>
            <td>
                Year of Passing
            </td>
            <td>
                <select name="gra_yop" id="ssc_yop" onchange="yearGap(this)">
                            <option>2000</option>
                            <option>2001</option>
                            <option>2002</option>
                            <option>2003</option>
                            <option>2004</option>
                            <option>2005</option>
                            <option>2006</option>
                            <option>2007</option>
                            <option>2008</option>
                            <option>2009</option>
                            <option>2010</option>
                            <option>2011</option>
                            
                            <option>2012</option>
                                    <option>2013</option>
                                    <option>2014</option>
                                    <option>2015</option>
                                    <option>2016</option>
                <option>2017</option>
                <option>2018</option>
                <option>2019</option>
                <option>2020</option>
                        </select>
            </td>
        </tr>
        <tr>
            <td colspan="2">
                Passed from a Distance Course
            </td>
            <td colspan="2">
                <input type="radio" name="gra_distance" value="yes" checked="checked" />Yes
                <input type="radio" name="gra_distance" value="no" />No
            </td>
        </tr>
        <tr>
            <td>
                Graduation Stream
                </td>
            <td><input type="text" name="gra_stream" value="" />
                </td>
            <td>
                Graduation Honours
                </td>
            <td><input type="text" name="gra_honours" value="" />
                </td>
            
        </tr>
        <tr>
            <td colspan="4">
                Marks as per Board / Council
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
            </td>
            <td>
                <input type="text" name="gra_board_total" value="" />
            </td>
            <td>
                Marks Secured
            </td>
            <td>
                <input type="text" name="gra_board_secured" value="" />
            </td>
        </tr>
        <tr>
            <td colspan="4">
                Marks in all the subjects appeared:(including optional & extra optional)
            </td>
        </tr>
        <tr>
            <td>
                Total Marks
                </td>
            <td><input type="text" name="gra_total" value="" />
                </td>
            <td>
                Marks Secured
                </td>
            <td><input type="text" name="gra_secured" value="" />
                </td>
            
        </tr>
          <?php
    }
          ?>
        
        <tr>
           <td colspan="4" align="left" bgcolor="#237648"><font color="#FFFFFF">Current Course(B.Tech / MCA / M.Tech)</font></td>
        </tr>
        <tr>
            <td colspan="2" align="left">
                       Stream:
            </td>
            <td colspan="2"><select name="stream" id='streamId' >
                   					
                                    <option>B.Tech</option>
                                    <option>MCA</option>
                                    <option>M.Tech</option>
                                    <option>Dual Degree-B Tech + M Tech</option>
                                    <option>Dual Degree-B Tech + MBA</option>
                       </select>
              
               </td>
        </tr>
        <tr>
            <td colspan="2">
                  Branch: 
                  </td>
                  <td colspan="2">
                  <select name="branch">
           <option>Computer Science Engg.</option>
           <option>Information Technology Engg.</option>
           <option>Electrical Engg.</option>
           <option>Electronics & Electrical Engg.</option>
           <option>Electronics & Telecomm. Engg.</option>
           <option>Electronics & Instrumentation Engg.</option>
           <option>Mechanical Engg.</option>
           <option>Civil Engg.</option>
           <option>Automobile Engg.</option>
           <option>MCA</option>
                  </select>
            
              
            </td>
        </tr>
        <tr>
            <td colspan="4">
                <input type="checkbox" value="yes" name="lateral_entry" /> Lateral Entry(Only applicable for B.Tech Stream)
            </td>
        </tr>
        <tr>
            <td colspan="4">
                <table>
                    <tr>
                        <td>Semester</td>
                        <td>1<sup>st</sup></td>
                        <td>2<sup>nd</sup></td>
                        <td>3<sup>rd</sup></td>
                        <td>4<sup>th</sup></td>
                        <td>5<sup>th</sup></td>
                        <td>6<sup>th</sup></td>
                        <td>7<sup>th</sup></td>
                        <td>8<sup>th</sup></td>
                        <td>9<sup>th</sup></td>
                        <td>10<sup>th</sup></td>
                    </tr>
                    <tr>
                        <td>SGPA</td>
                        <td><input type="text" name="sgpa_1" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_2" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_3" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_4" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_5" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_6" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_7" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_8" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_9" value="" size="5" /></td>
                        <td><input type="text" name="sgpa_10" value="" size="5" /></td>
                    </tr>
                    <tr>
                        <td>CGPA</td>
                        <td><input type="text" name="cgpa_1" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_2" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_3" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_4" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_5" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_6" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_7" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_8" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_9" value="" size="5" /></td>
                        <td><input type="text" name="cgpa_10" value="" size="5" /></td>
                       
                    </tr>
                    <tr>
                        <td>No. Of Backlogs</td>
                        <td><input type="text" name="backlog_1" value="" size="5" /></td>
                        <td><input type="text" name="backlog_2" value="" size="5" /></td>
                        <td><input type="text" name="backlog_3" value="" size="5" /></td>
                        <td><input type="text" name="backlog_4" value="" size="5" /></td>
                        <td><input type="text" name="backlog_5" value="" size="5" /></td>
                        <td><input type="text" name="backlog_6" value="" size="5" /></td>
                        <td><input type="text" name="backlog_7" value="" size="5" /></td>
                        <td><input type="text" name="backlog_8" value="" size="5" /></td>
                        <td><input type="text" name="backlog_9" value="" size="5" /></td>
                        <td><input type="text" name="backlog_10" value="" size="5" /></td>
                    </tr>
                    
                </table>
                </td>
        </tr>
         
        <tr>
            <td colspan="4">
                <input type="submit" name="btn_save_academic" value="PROCEED TO FINAL SUBMISSION" />
            </td>
        </tr>
        
</table>
</form>

<?php        
    }
    elseif (isset($_POST['section']) && !empty($_POST['section']) && $_POST['section']=='other') {
    ?>
<form action="editProfileNew.php" method="post" >
            <table>
                <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Other Details</font></td>
        </tr>
                <tr>
                        <td>If you have year gaps during your academic career.<br />
                        Please provide a reason for the same</td>
                        <td><textarea name="gap_reason" rows="4" cols="40"></textarea></td>
                    </tr>
              
        <tr>
            <td>
                Hobbies
            </td>
            <td>
                <textarea name="hobby" rows="4" cols="40"></textarea> 
            </td>
        </tr>
        <tr>
            <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Project / Summer Training(Please mention all informal & formal Projects)</font></td>
        </tr>
        <tr>
                <td>Project Name</td>
                <td><input type="text" name="pro1_name" value="" /></td>
        </tr>
        <tr>
                        <td>Institution / Organization</td>
                                    <td><input type="text" name="pro1_org" value="" /></td>
                        </tr>
        <tr>
                        <td>Duration of the Project</td>
                        <td><input type="text" name="pro1_dur" value="" /></td>
                        </tr>
        <tr>
                        <td>Project Guide(s)</td>
                        <td><input type="text" name="pro1_guide" value="" /></td>
                        </tr>
        <tr>
                        <td>Project Summary</td>
                        <td><textarea name="pro1_sum" rows="4" cols="40"></textarea></td>
                    </tr>
         <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Order of Preference</font></td>
        </tr>
        <tr>
            <td colspan="2">
                You would give higher preference to <select name="pref">
                            <option>Job</option>
                            <option>Higher Studies</option>
                        </select>
            </td>
        </tr>
        <tr>
           <td colspan="2" align="left" bgcolor="#237648"><font color="#FFFFFF">Declaration</font></td>
        </tr>
        <tr>
            <td colspan="2">
                The information furnished above is true to the best of my knowledge and I agree with the rules and regulation 
                of Training and Placement, KiiT University, Bhubaneshwar
            </td>
        </tr>
        <tr>
            <td>
                <input type="submit" name="btn_save_final" value="SUBMIT FOR VERIFICATION" />
            </td>
        </tr>
            </table>
        </form>
        <?php
}
}
elseif ($status=='Pending' || $status == 'Approved') {
    ?>
<form action="editProfileNew.php" method="post">
    <input type="hidden" name="lateral_entry" value="<?php echo $row['lateral']?>" />
    <input type="hidden" name="stream" value="<?php echo $row['stream']?>" />
        <table align="center" width="1000" border="0">
        <tr>
        <td colspan="6" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>REGISTRATION FORM</b></font></td>
        </tr><tr>
            <td>Rollno:</td><td><input type="text" name="txtroll" value="<?php echo $row['roll_no'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
            <td>Current Status:</td><td><input type="text" name="status" value="<?php echo $row['status'] ?>" size="25" readonly="readOnly" /></td>
        </tr>
        <tr>
           <td colspan="6" align="left" bgcolor="#237648"><font color="#FFFFFF">Current Course(B.Tech / MCA / M.Tech)</font></td>
        </tr>
        <tr>
            <td colspan="6">
                <table>
                    <tr>
                        <td>Semester</td>
                        <td>1<sup>st</sup></td>
                        <td>2<sup>nd</sup></td>
                        <td>3<sup>rd</sup></td>
                        <td>4<sup>th</sup></td>
                        <td>5<sup>th</sup></td>
                        <td>6<sup>th</sup></td>
                        <td>7<sup>th</sup></td>
                        <td>8<sup>th</sup></td>
                        <td>9<sup>th</sup></td>
                        <td>10<sup>th</sup></td>
                    </tr>
                    <tr>
                        <td>SGPA</td>
                        <td><input type="text" name="sgpa_1" value="<?php echo $row['sgpa_1'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_2" value="<?php echo $row['sgpa_2'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_3" value="<?php echo $row['sgpa_3'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_4" value="<?php echo $row['sgpa_4'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_5" value="<?php echo $row['sgpa_5'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_6" value="<?php echo $row['sgpa_6'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_7" value="<?php echo $row['sgpa_7'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_8" value="<?php echo $row['sgpa_8'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_9" value="<?php echo $row['sgpa_9'] ?>" size="5" /></td>
                        <td><input type="text" name="sgpa_10" value="<?php echo $row['sgpa_10'] ?>" size="5" /></td>
                    </tr>
                    <tr>
                        <td>CGPA</td>
                        <td><input type="text" name="cgpa_1" value="<?php echo $row['cgpa_1'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_2" value="<?php echo $row['cgpa_2'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_3" value="<?php echo $row['cgpa_3'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_4" value="<?php echo $row['cgpa_4'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_5" value="<?php echo $row['cgpa_5'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_6" value="<?php echo $row['cgpa_6'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_7" value="<?php echo $row['cgpa_7'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_8" value="<?php echo $row['cgpa_8'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_9" value="<?php echo $row['cgpa_9'] ?>" size="5" /></td>
                        <td><input type="text" name="cgpa_10" value="<?php echo $row['cgpa_10'] ?>" size="5" /></td>
                       
                    </tr>
                    <tr>
                        <td>No. Of Backlogs</td>
                        <td><input type="text" name="backlog_1" value="<?php echo $row['back_1'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_2" value="<?php echo $row['back_2'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_3" value="<?php echo $row['back_3'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_4" value="<?php echo $row['back_4'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_5" value="<?php echo $row['back_5'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_6" value="<?php echo $row['back_6'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_7" value="<?php echo $row['back_7'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_8" value="<?php echo $row['back_8'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_9" value="<?php echo $row['back_9'] ?>" size="5" /></td>
                        <td><input type="text" name="backlog_10" value="<?php echo $row['back_10'] ?>" size="5" /></td>
                    </tr>
                    
                </table>
                </td>
        </tr>
        <tr>
           <td colspan="6" align="left" bgcolor="#237648"><font color="#FFFFFF">Declaration</font></td>
        </tr>
        <tr>
            <td colspan="6">
                The information furnished above is true to the best of my knowledge and I agree with the rules and regulation 
                of Training and Placement, KiiT University, Bhubaneshwar
            </td>
        </tr>
        <tr>
        <td colspan="6" align="left" bgcolor="#003399"><font color="#FFFFFF">Final</font></td>
        </tr>
        <tr>
            <td colspan="6" align="center">
                <input type="submit" value="SUBMIT FOR VERIFICATION" name="btn_update_verification" />
            </td>
        </tr>
       </table>
</form>    
    <?php
}
$content=ob_get_contents();
ob_end_clean();
$pageTitle = "TNP || Student Data";
include'template1.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
    echo $_SESSION['ErrMsg'];
    unset ($_SESSION['ErrMsg']);
}
?>