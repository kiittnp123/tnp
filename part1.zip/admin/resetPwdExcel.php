<?php
include_once 'protectedAdmin.php';
error_reporting(0);
include '../db.php';
include_once '../inc/conf.php';
$query=$_SESSION['query'];
$res=mysql_query($query);
include_once '../excel/Classes/PHPExcel.php';
$phpExcel = new PHPExcel();
$phpExcel->createSheet();
$phpExcel->getActiveSheet()->setCellValue("A1","Serial Number");
$phpExcel->getActiveSheet()->setCellValue("B1","Roll Number");
$phpExcel->getActiveSheet()->setCellValue("C1","Name");
$phpExcel->getActiveSheet()->setCellValue("D1","Stream");
$phpExcel->getActiveSheet()->setCellValue("E1","Branch");
$phpExcel->getActiveSheet()->setCellValue("F1","Login Id");
$phpExcel->getActiveSheet()->setCellValue("G1","Password");

$t=2;
$slno=1;
while ($row= mysql_fetch_array($res)){
    
    $phpExcel->getActiveSheet()->setCellValue("A".$t,$slno);
    $phpExcel->getActiveSheet()->setCellValue("B".$t,$row['roll_no']);
    $phpExcel->getActiveSheet()->setCellValue("C".$t,$row['name']);
    $phpExcel->getActiveSheet()->setCellValue("D".$t,$row['stream']);
    $phpExcel->getActiveSheet()->setCellValue("E".$t,$row['branch']);
    $phpExcel->getActiveSheet()->setCellValue("F".$t,$row['email']);
    $phpExcel->getActiveSheet()->setCellValue("G".$t,$row['password']);
        $t++;
	$slno++;
}

$excelWriter = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
//$excelWriter->save("StudentPasswordData.xls");
header('Content-type:application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="StudentPasswordData.xls"');
$excelWriter->save('php://output');

?>