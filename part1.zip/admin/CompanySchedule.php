<?php
//session_start();
ob_start();
include'../db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';
?>
<script type="text/javascript">
function validateCompanySchedule(c)
{
	if(c.companyname.value=='Select')
	{
		alert("Please select a Company"); 
		return false;
	}
	if(c.date.value=='Date')
	{
		alert("Date cant be left blank"); 
		
		return false;
	}
	if(c.month.value=='Month')
	{
		alert("Month cant be left blank"); 
		
		return false;
	}
	if(c.year.value=='Year')
	{
		alert("Year cant be left blank"); 
		
		return false;
	}
}
</script>    
<?php
if(isset($_POST['btnsubmit']) && !empty($_POST['btnsubmit']) && $_POST['btnsubmit']=='Submit')
{
        
	//$cid=$_POST['cname'];
	$visitdate=mysql_real_escape_string($_POST['visit_date']);
        $ageLimit=mysql_real_escape_string($_POST['age_limit']);
        $enddate=mysql_real_escape_string($_POST['end_date']);
	$requirement=mysql_real_escape_string($_POST['requirement']);
	$package=mysql_real_escape_string($_POST['package']);
        $profile=mysql_real_escape_string($_POST['profile']);
        $procedure=mysql_real_escape_string($_POST['procedure']);
        //echo $procedure;
	$eligibility=mysql_real_escape_string($_POST['eligibility']);
        $totalStu=mysql_real_escape_string($_POST['total_stu']);
        $type=mysql_real_escape_string($_POST['type']);
        if($type=='ON CAMPUS')
            $collegeName="KIIT UNIVERSITY";
        else
            $collegeName=mysql_real_escape_string($_POST['college_name']);
	$Academic_year=mysql_real_escape_string($_POST['txtyear']);
	
	$cid=mysql_real_escape_string($_POST['companyname']);
	
$insschedule="insert into tbl_company_schedule(company_id,date_visit,intake,package,eligibility,academic_year,age_limit,date_end,
              drive_type,college_name,profile,round_list,total_stu) 
              values('$cid','$visitdate','$requirement','$package','$eligibility','$Academic_year','$ageLimit','$enddate','$type','$collegeName',
                  '$profile','$procedure','$totalStu'); ";
$res=mysql_query("$insschedule");
//echo $insschedule;
    if($res)
   {
	   $_SESSION['ErrMsg']="<script>alert('The Data Scheduled Properly..')</script>";
       
   }else{
   $_SESSION['ErrMsg']="<script>alert('Some Problem occurred. Please try again later.')</script>";
   }
	
}
    
?>
<form method="post" action="" onsubmit="return validateCompanySchedule(this)">
<table align="center" bgcolor="#E5E5E5" width="500">
<tr>
<td colspan="2" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>Company Schedule</b></font></td>
</tr>
<tr>
<td>Company Name:</td><td><select name="companyname" id="companyname">
        <option>Select</option>
<?php
	$sql="select company_name,company_id from tbl_company";
	$res=mysql_query("$sql");
	 while($data=mysql_fetch_array($res))
	{
		echo'<option value="'.$data['company_id'].'">'.$data['company_name'].'</option>';
	}
	
	 ?>
     </select></td>
</tr>
<tr>
<td>Start Date of Schedule:</td>
<td><script type="text/javascript">DateInput('visit_date', true, 'YYYY-MM-DD')</script></td>
</tr>
<tr>
<td>End Date Of Schedule:</td>
<td><script type="text/javascript">DateInput('end_date', true, 'YYYY-MM-DD')</script></td>
</tr>
<tr>
<td>Number Of Requirements:</td>
<td><input type="text" name="requirement"  onkeypress="return isNumberKey(event)" /></td>
</tr>
<tr>
<td>Offered Package(in lacs per annum):</td>
<td><input type="text" name="package"  onkeypress="return isNumberKey(event)" /></td>
</tr>
<tr>
<td>Offered Profile:</td>
<td><input type="text" name="profile" /></td>
</tr>

<tr>
<td>Selection Procedure(Please hit enter after every round)</td>
<td><textarea name="procedure" cols="30" rows="15"></textarea></td>
</tr>
<tr>
<td>Age Limit</td>
<td><input type="text" name="age_limit"  onkeypress="return isNumberKey(event)" /></td>
</tr>

<tr>
<td>Eligibility:</td>
<td><input type="text" name="eligibility" /></td>
</tr>
<tr>
    <td>Total number of eligible students</td>
    <td><input type="text" name="total_stu" /></td>
</tr>
<tr>
    <td>Type of Campus Drive</td>
    <td><select name="type">
            <option>ON CAMPUS</option>
            <option>OFF CAMPUS</option>
            <option>POOL CAMPUS</option>
        </select></td>
</tr>
<tr>
    <td>College Name(If OFF or POOL Campus)</td>
    <td><input type="text" name="college_name" /></td>
</tr>
<tr>
<td>Academic Year:</td>
<td>
    <select name="txtyear">
        <option>2011-2012</option>
        <option>2012-2013</option>
        <option>2013-2014</option>
        <option>2014-2015</option>
        <option>2015-2016</option>
        <option>2016-2017</option>
        
        
    </select></td>
</tr>
<tr>
<td colspan="2" align="center" bgcolor="#000033"><input type="submit" name="btnsubmit" value="Submit" />
                               <input type="reset" name="btnreset" value="Reset" /></td>
</tr>
</table>
</form>

<?php       	
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}

?>