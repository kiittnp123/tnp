<?php
ob_start();
include'../../NOCVerification/db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
if(isset($_POST['btn_setting']) && $_POST['btn_setting']=="Change Settings"){
    if(isset($_POST['registration']) && $_POST['registration']!="Select" ){
        $value=$_POST['registration'];
        $settingUpdateQuery="Update tbl_setting set value='$value',status='Active' where type='registration'";
        $resUpdateQuery=mysql_query($settingUpdateQuery);
        if($resUpdateQuery){
            $_SESSION['ErrMsg']="<script>alert('Setting Successfully Changed')</script>";
        }else{
            $_SESSION['ErrMsg']="<script>alert('Some error occurred. Please try once again.')</script>";
        }
    }
}
$query="select * from tbl_setting where type='registration' and status='Active'";
$res=  mysql_query($query);
$row=  mysql_fetch_array($res);
?>
<form method="post" action="">
<table align="center" bgcolor="#DFDFDF" width="900" cellspacing="5" cellpadding="5">
    <tr>
        <td colspan="3" align="center"><h1>NOC Administrator Settings</h1></td>
    </tr>
    <tr>
        <td>Setting Name</td>
        <td>Current Status</td>
        <td>New/Change to Status</td>
    </tr>
    <tr>
        <td>Registration Process for students</td>
        <td><?php echo $row['value']?></td>
        <td>Change to <select name='registration'>
                <option>Select</option>
                <option>ON</option>
                <option>OFF</option>
            </select></td>
    </tr>
    <tr>
        <td colspan="3"><input type="submit" name='btn_setting' value="Change Settings" /></td>
    </tr>
    <tr>
        <td colspan="3" align="right"><a href="../../../NOCVerification/index.php" target="_blank">Move to NOC Verification</a></td>
    </tr>
</table>  
</form>
<?php
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>