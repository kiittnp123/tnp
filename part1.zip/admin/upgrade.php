<?php
ob_start();
include_once 'protectedAdmin.php';
include_once '../inc/conf.php';
include '../db.php';
if(isset($_POST['btnsave']) && !empty($_POST['btnsave']))
{
    
        if(!empty($_POST['content'])){
        $content=mysql_real_escape_string(nl2br($_POST['content']));
	$query="update tbl_homepage set content='$content'";
        $res=mysql_query($query);
        $id=mysql_insert_id($con);
        $_SESSION['ErrMsg']="<script>alert('Data Updated successfully')</script>";
        }
	if((isset($_FILES['img1']['name']) && !empty($_FILES['img1']['name']))){
            
            if( ($_FILES['img1']['type'] == 'image/png' || $_FILES['img1']['type'] == 'image/jpeg' || $_FILES['img1']['type'] == 'image/gif')){
            $arr=explode(".", $_FILES['img1']['name']);
            $ext=end($arr);
            $destination1="images/home1.".$ext;
            $res1=move_uploaded_file($_FILES['img1']['tmp_name'], "../user/".$destination1);
            $query="update tbl_homepage set image1='$destination1'";
            $res=mysql_query($query);
            $_SESSION['ErrMsg']="<script>alert('Data Updated successfully')</script>";
	}else{
            $_SESSION['ErrMsg']="<script>alert('The changes to Image-1 were not done the files uploaded is not an image file.Please upload only .jpg,.png or .gif file extensions')</script>";
        }}
        if((isset($_FILES['img2']['name']) && !empty($_FILES['img2']['name']))){
            if(($_FILES['img2']['type'] == 'image/png' || $_FILES['img2']['type'] == 'image/jpeg' || $_FILES['img2']['type'] == 'image/gif')){
            $arr=explode(".", $_FILES['img2']['name']);
            $ext=end($arr);
            $destination2="images/home2.".$ext;
            $res2=move_uploaded_file($_FILES['img2']['tmp_name'], "../user/".$destination2);
            $query="update tbl_homepage set image2='$destination2'";
            $res=mysql_query($query);
            $_SESSION['ErrMsg']="<script>alert('Data Updated successfully')</script>";
	}else{
            $_SESSION['ErrMsg']="<script>alert('The changes to Image-2 were not done as files uploaded is not an image file.Please upload only .jpg,.png or .gif file extensions')</script>";
        }}
        if((isset($_FILES['img3']['name']) && !empty($_FILES['img3']['name']))){
            if( ($_FILES['img3']['type'] == 'image/png' || $_FILES['img3']['type'] == 'image/jpeg' || $_FILES['img3']['type'] == 'image/gif')){
            $arr=explode(".", $_FILES['img3']['name']);
            $ext=end($arr);
            $destination3="images/home3.".$ext;
            $res3=move_uploaded_file($_FILES['img3']['tmp_name'], "../user/".$destination3);
            $query="update tbl_homepage set image3='$destination3'";
            $res=mysql_query($query);
            $_SESSION['ErrMsg']="<script>alert('Data Updated successfully')</script>";
	}else{
            $_SESSION['ErrMsg']="<script>alert('The changes to Image-3 were not done as files uploaded is not an image file.Please upload only .jpg,.png or .gif file extensions')</script>";
        }}
}
?>
<form method="post" action="" enctype="multipart/form-data">
<table align="center">
<tr bgcolor="#000033">
<td colspan="2" align="center"><b style="color:#FFF; font-weight:bold">EDIT YOUR IMAGES AND CONTENT</b></td>
</tr>
<tr><td>Upload Image1 :</td><td><input type="file" name="img1" /></td></tr>
<tr><td>Upload Image2 :</td><td><input type="file" name="img2" /></td></tr>
<tr><td>Upload Image3 :</td><td><input type="file" name="img3" /></td></tr>
<tr><td>Your Content :</td><td><textarea name="content" rows="20" cols="50"></textarea></td></tr>
<tr><td colspan="2" align="center" valign="top"><input type="submit" name="btnsave" value="SAVE"/>
                       <input type="reset" value="RESET"/></td></tr>
</table>
</form>
<?php
$content=ob_get_contents();
ob_end_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>