<?php
//session_start();
ob_start();
include '../db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';
?>
<script type="text/javascript">
function numbers()
{
	var num=document.frmhr.txtmob;
	if(isNaN(num.value))
	{
		alert("Please enter number only");
                num.value='';
		return false;	
	}
}
function validation()
{
	if(document.frmhr.txtname.value=='')
	{
		alert("Please enter the name"); 
		document.frmhr.txtname.focus();
		return false;
	}
	if(document.frmhr.txtposn.value=='')
	{
		alert("Please enter the position"); 
		document.frmhr.txtposn.focus();
		return false;
	}
	if(document.frmhr.txtemail.value=='')
	{
		alert("Please enter the email id"); 
		document.frmhr.txtemail.focus();
		return false;
	}
	
}
</script>
<?php
if(isset($_POST['btnsave']) && !empty($_POST['btnsave']) && $_POST['btnsave']=='SAVE')
{
//$cname=$_SESSION['cname'];
$hrid=mysql_real_escape_string($_POST['txthrid']);
$name=mysql_real_escape_string($_POST['txtname']);
$posn=mysql_real_escape_string($_POST['txtposn']);
$mobile=mysql_real_escape_string($_POST['txtmob']);
$email=mysql_real_escape_string($_POST['txtemail']);
$add=mysql_real_escape_string($_POST['txtadd']);
$companyname=mysql_real_escape_string($_POST['companyname']);
$status=mysql_real_escape_string($_POST['ddlstatus']);

$insert="insert into tbl_hr(hr_id,name,position,mobile,email,address,company_id,status) values
('$hrid','$name','$posn','$mobile','$email','$add','$companyname','$status')";
$result=mysql_query($insert);
//echo $insert;
if($result)
{
	$_SESSION['ErrMsg']="<script>alert('Your data saved successfully.');</script>";
   
}
}
   

	$sql="select max(hr_id)+1 from tbl_hr";
	$res=mysql_query("$sql");
	$val=mysql_fetch_array($res);
	$maxid=$val[0];
	 ?>
<form name="frmhr" action="" method="post" onSubmit="return validation()">
<table align="center" bgcolor="#E5E5E5" width="600">
<tr>
<td colspan="2" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>ENTER YOUR DETAILS</b></font></td>
</tr>
<tr>
<td>HR Id:</td>
<td><input type="text" readonly name="txthrid" value="<?php echo $maxid ?>" /></td>
</tr>
<tr>
<td>Name:</td>
<td><input type="text" name="txtname" /></td>
</tr>
<tr>
<td>Position:</td>
<td><input type="text" name="txtposn" /></td>
</tr>
<tr>
<td>Mobile:</td>
<td><input type="text" name="txtmob" onBlur="return numbers()" /></td>
</tr>
<tr>
<td>Email:</td>
<td><input type="text" name="txtemail" /></td>
</tr>
<tr>
<td>Address:</td>
<td><textarea name="txtadd"></textarea></td>
</tr>
<tr>
<td>Company Name:</td>
<td><select name="companyname">
<?php
	$sql="select company_name,company_id from tbl_company";
	$res=mysql_query("$sql");
	 while($data=mysql_fetch_array($res))
	{
		echo'<option value="'.$data['company_id'].'">'.$data['company_name'].'</option>';
	}
	
	 ?>
     </select></td>
</tr>
<tr>
<td>Status:</td>
<td><select name="ddlstatus"><option>Active</option><option>Inactive</option></select></td>
</tr>

<tr>
<td colspan="2" align="center" bgcolor="#000033"><input type="submit" name="btnsave" value="SAVE" /><input type="reset" name="btnreset" value="RESET" /></td>
</tr>
</table>
</form>
<?php
 
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>