<?php
error_reporting(0);
include 'protectedAdmin.php';
include_once '../inc/conf.php';
if (isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg'])) {
    echo $_SESSION['ErrMsg'];
    unset($_SESSION['ErrMsg']);
}

ob_start();
include'../db.php';
?>
<script type="text/javascript">
    var lastYear = '';
    function academicYear(c) {
        //alert(c.value);
        //alert("c"+c.value);
        document.getElementById("c" + c.value).style.display = "block";
        document.getElementById("schedule_selected").value = "c" + c.value;
        document.getElementById("c" + lastYear).style.display = "none";
        lastYear = c.value;
    }
    function isValidSem(c) {
        var stream = document.getElementById("ddlstream");
        if (stream.value == 'B.Tech') {
            if (c.value == '9' || c.value == '10') {
                alert('The selected Semester does not belong to the selected stream');
                c.selectedIndex = 0;
                return false;
            }
        } else if (stream.value == 'M.Tech') {
            if (c.value == '9' || c.value == '10' || c.value == '7' || c.value == '8' || c.value == '5' || c.value == '6') {
                alert('The selected Semester does not belong to the selected stream');
                c.selectedIndex = 0;
                return false;
            }
        } else if (stream.value == 'MCA') {
            if (c.value == '9' || c.value == '10' || c.value == '7' || c.value == '8') {
                alert('The selected Semester does not belong to the selected stream');
                c.selectedIndex = 0;
                return false;
            }
        }
    }



    function setValidFields(c) {
        var stream = c.value;
        var graduation = document.getElementById("txtgrad");
        var graduationGap = document.getElementById("txtyrgpgrdpg");
        var branchDisplayArea = document.getElementById("branchList");
        if (stream == 'B.Tech' || stream == "Dual Degree-B.Tech + M.Tech" || stream == "Dual Degree-B.Tech + MBA") {
            graduation.value = "NA";
            graduation.disabled = "disabled";
            graduationGap.value = "NA";
            graduationGap.disabled = "disabled";
            branchDisplayArea.innerHTML = '<b>Branch</b><hr /><input type="checkbox" name="chkbranch[]" value="Computer Science Engg." />CSE<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Information Technology Engg." />IT<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Electronics & Electrical Engg." />EEE<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Electronics & Telecomm. Engg." />ETC<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Electrical Engg." />ELECT<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Electronics & Instrumentation Engg." />EI<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Mechanical Engg." />MECH<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Civil Engg." />CIVIL<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Automobile Engg." />AUTO';
        }
        else if (stream == 'M.Tech') {
            graduation.value = "";
            graduation.disabled = "";
            graduationGap.value = "";
            graduationGap.disabled = "";
            branchDisplayArea.innerHTML = '<b>Branch</b><hr /><input type="checkbox" name="chkbranch[]" value="Construction Engg. & Management" />Construction<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Structural Engg." />Structural<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Computer Science" />CSE<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Computer Science & Information Security" />CSIS<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Communication System Engg." />Communication<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Database Engg." />Database Engg<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Software Engg." />Software Engg<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="VLSI Design & Embedded System" />VLSI<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Power Electronics and Drives" />Power & Drives<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Power Engg. & Energy System" />Power & Energy<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Manufacturing Process & Systems" />Manufacturing<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Thermal Engg." />Thermal<br/>' +
		    '<input type="checkbox" name="chkbranch[]" value="RF & Microwave Engg." />RF & Microwave Engg.';
        }
        else if (stream == "MCA") {
            graduation.value = "";
            graduation.disabled = "";
            graduationGap.value = "";
            graduationGap.disabled = "";
            branchDisplayArea.innerHTML = '<b>Branch</b><hr /><input type="checkbox" name="chkbranch[]" value="MCA" />MCA';
        }
        
        else if (stream == 'Dual Degree B.Tech and M.Tech') {
            graduation.value = "";
            graduation.disabled = "";
            graduationGap.value = "";
            graduationGap.disabled = "";
            branchDisplayArea.innerHTML = '<b>Branch</b><hr /><input type="checkbox" name="chkbranch[]" value="Construction Engg. & Management" />Construction<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Structural Engg." />Structural<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Computer Science" />CSE<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Computer Science & Information Security" />CSIS<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Communication System Engg." />Communication<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Database Engg." />Database Engg<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Software Engg." />Software Engg<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="VLSI Design & Embedded System" />VLSI<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Power Electronics and Drives" />Power & Drives<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Power Engg. & Energy System" />Power & Energy<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Manufacturing Process & Systems" />Manufacturing<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Thermal Engg." />Thermal<br/>' +
		    '<input type="checkbox" name="chkbranch[]" value="RF & Microwave Engg." />RF & Microwave Engg.<br/>' +
		    '<input type="checkbox" name="chkbranch[]" value="Computer Science Engg." />CSE<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Information Technology Engg." />IT<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Electronics & Electrical Engg." />EEE<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Electronics & Telecomm. Engg." />ETC<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Electrical Engg." />ELECT<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Electronics & Instrumentation Engg." />EI<br />' +
                    '<input type="checkbox" name="chkbranch[]" value="Mechanical Engg." />MECH<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Civil Engg." />CIVIL<br/>' +
                    '<input type="checkbox" name="chkbranch[]" value="Automobile Engg." />AUTO';
        }
    }

    function formValidate(c) {
        //alert(c.dip_or_hsc.checked);
        var option = c.dip_or_hsc.checked;
        if (option == true) {
            if (c.txtdipl.value == '' || c.txt12th.value == '') {
                alert("Please fill both Diploma and HSC Criteria");
                return false;
            }
            else {
                return true;
            }
        }
        else {
            return true;
        }
    }
</script>
<form method="post" action="viewStudent.php" name="frmview" onSubmit="return formValidate(this)">
    <table align="center">
        <tr valign="top">
            <td colspan="8"><h2><font color="#000033">View Students</font></h2></td>
        </tr>
        <tr valign="top">
            <td>
                <b>Stream</b>
                <hr />
                <select name="ddlstream" id="ddlstream" onchange="return setValidFields(this)">
                    <option value="B.Tech">B.Tech</option>               
                    <option value="M.Tech">M.Tech</option>
                    <option value="MCA">MCA</option>
                    <option value="Dual Degree B.Tech and M.Tech">Dual Degree-B.Tech + M.Tech</option>
                    <option value="Dual Degree B.Tech and MBA">Dual Degree-B.Tech + MBA</option>
                </select><br /><br />
                <b>Status</b><hr />
                <input type="checkbox" name="status[]" value="Approved" checked="checked" />Approved<br />
                <input type="checkbox" name="status[]" value="Pending" />Pending<br />
                <input type="checkbox" name="status[]" value="Updated" />Updated<br />
                <input type="checkbox" name="status[]" value="Created" />Created<br />
            </td>
            <td id="branchList"><b>Branch</b><hr /><input type="checkbox" name="chkbranch[]" value="Computer Science Engg." />CSE<br/>
                <input type="checkbox" name="chkbranch[]" value="Information Technology Engg." />IT<br/>
                <input type="checkbox" name="chkbranch[]" value="Electronics & Electrical Engg." />EEE<br/>
                <input type="checkbox" name="chkbranch[]" value="Electronics & Telecomm. Engg." />ETC<br/>
                <input type="checkbox" name="chkbranch[]" value="Electrical Engg." />ELECT<br />
                <input type="checkbox" name="chkbranch[]" value="Electronics & Instrumentation Engg." />EI<br />
                <input type="checkbox" name="chkbranch[]" value="Mechanical Engg." />MECH<br/>
                <input type="checkbox" name="chkbranch[]" value="Civil Engg." />CIVIL<br/>
                <input type="checkbox" name="chkbranch[]" value="Automobile Engg." />AUTO</td>
            <td><b>Year</b><hr />
                <input type="checkbox" name="chkyear[]" value="2013" />2013<br/>
                <input type="checkbox" name="chkyear[]" value="2014" />2014<br/>
                <input type="checkbox" name="chkyear[]" value="2015" />2015<br/>
                <input type="checkbox" name="chkyear[]" value="2016" />2016<br/>
                <input type="checkbox" name="chkyear[]" value="2017" />2017<br/>
                <input type="checkbox" name="chkyear[]" value="2018" />2018<br/>
                <input type="checkbox" name="chkyear[]" value="2019" />2019<br />
                <input type="checkbox" name="chkyear[]" value="2020" />2020<br/>
                <input type="checkbox" name="chkyear[]" value="2021" />2021<br />
            </td>
            <td><b>Boarding</b><hr/><input type="checkbox" name="chkboarding[]" value="Hostel" />Hostel<br/>
                <input type="checkbox" name="chkboarding[]" value="Day Scholar" />Day Scholar</td>
            <td><b>Category</b><hr /><input type="checkbox" name="chkcat[]" value="General" />General<br/>
                <input type="checkbox" name="chkcat[]" value="OBC" />OBC<br/>
                <input type="checkbox" name="chkcat[]" value="Minority" />Minority<br/>
                <input type="checkbox" name="chkcat[]" value="GC" />GC<br/>
                <input type="checkbox" name="chkcat[]" value="PH" />PH<br/>
                <input type="checkbox" name="chkcat[]" value="SC" />SC<br/>
                <input type="checkbox" name="chkcat[]" value="ST" />ST<br />
                <input type="checkbox" name="chkcat[]" value="NRI" />NRI</td>
            <td><b>Gender</b><hr/><input type="checkbox" name="chkgen[]" value="Male" />Male<br/>
                <input type="checkbox" name="chkgen[]" value="Female" />Female</td> 
            <td><b>CGPA/Percentage</b><hr/>
                <table>
                    <tr><td>Current CGPA</td>
                        <td><input type="text" name="txtcurrent" style="width:50px" onkeypress="return isNumberKey(event)" />

                        </td></tr>
                    <tr><td>Current Backlogs</td>
                        <td><input type="text" name="txtbacklogs" style="width:50px" onkeypress="return isNumberKey(event)" />
                            Upto Semester <select name="txtcgpa" id="txtcgpa" onchange="return isValidSem(this)">
                                <option>1</option>
                                <option>2</option>
                                <option>3</option>
                                <option>4</option>
                                <option>5</option>
                                <option>6</option>
                                <option>7</option>
                                <option>8</option>
                                <option>9</option>
                                <option>10</option>
                            </select>
                        </td></tr>
                    <tr>
                        <td>As per Board<input type="radio" name="board" value="board" checked="checked" /></td>
                        <td>Total Appeared<input type="radio" name="board" value="total" /></td>
                    </tr>
                    <tr>
                        <td colspan="2"><input type="checkbox" name="dip_or_hsc" id="dip_or_hsc" value="ON" checked="checked"/>Consider either Diploma or Intermediate</td>
                    </tr>
                    <tr><td>Graduation</td><td><input type="text" name="txtgrad" id="txtgrad" style="width:50px" value="NA" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td></tr>
                    <tr><td>Diploma</td><td><input type="text" name="txtdipl" id="txtdipl" style="width:50px" onkeypress="return isNumberKey(event)" /></td></tr>
                    <tr><td>Intermediate</td><td><input type="text" name="txt12th" id="txt12th" style="width:50px" onkeypress="return isNumberKey(event)"   /></td></tr>
                    <tr><td>Matriculation</td><td><input type="text" name="txt10th" style="width:50px" onkeypress="return isNumberKey(event)"   /></td></tr>
                </table></td> 
            <td><b>Year Gaps</b><hr/>
                <table>
                    <tr><td>10<sup>th</sup> & 12<sup>th</sup></td><td><input type="text" name="txtyrgap1012" style="width:20px" onkeypress="return isNumberKey(event)"   /></td></tr>
                    <tr><td>10<sup>th</sup> & Diploma</td><td><input type="text" name="txtyrgap10dipl" style="width:20px" onkeypress="return isNumberKey(event)"   /></td></tr>
                    <tr><td>12<sup>th</sup> & Grad</td><td><input type="text" name="txtyrgap12grd" style="width:20px" onkeypress="return isNumberKey(event)"  /></td></tr>
                    <tr><td>Diploma & Grad</td><td><input type="text" name="txtyrgapdiplgrd" style="width:20px" onkeypress="return isNumberKey(event)"  /></td></tr>
                    <tr><td>Grad & PG</td><td><input type="text" name="txtyrgpgrdpg" id="txtyrgpgrdpg" style="width:20px"  value="NA" disabled="disabled" onkeypress="return isNumberKey(event)"   /></td></tr>
                    <tr><td colspan="2"><b>OR</b></td></tr>
                    <tr>
                        <td>All year Gaps</td><td><input type="text" name="txtyrgap" style="width:20px"  onkeypress="return isNumberKey(event)" /></td>
                    </tr>
                </table></td>                                                                        
        </tr>
        <tr>
            <td colspan="4">No. of Companies Placed :
                <select name="ddlcomp">
                    <option value="equal">Equal To</option>
                    <option value="lessequal">Less than Equal</option>
                    <option value="greaterequal">Greater than Equal</option>
                </select>
                <input type="text" name="txtcomp" style="width:50px" />
            </td>
            <td colspan="4">Maximum Package Offered :
                <select name="ddlpackage">
                    <option value="equal">Equal To</option>
                    <option value="lessequal">Less than Equal</option>
                    <option value="greaterequal">Greater than Equal</option>
                </select>
                <input type="text" name="txtpackage" style="width:50px" /></td>
        </tr>
        <tr>
            <td colspan="8" alugn="left"><input type="submit" name="btnsubmit" value="Submit" ></td>
        </tr>
    </table>
</form>
<form method="post" action="viewStudent.php" >
    <?php

    /* If submit button is clicked the following code gets executed */
    if (isset($_POST['btnsubmit']) && !empty($_POST['btnsubmit']) && $_POST['btnsubmit'] == 'Submit') {
        $condition = "";

        /* This piece of code holds the stream selected */
        $stream = $_POST['ddlstream'];
        $condition.="and stream='" . $stream . "' ";
        if ($stream == 'B.Tech')
            $file = "viewStudentExcel.php";
        else
            $file = "viewStudentExcelMCA.php";
        //echo $condition;

        if (isset($_POST['status']) && !empty($_POST['status'])) {
            $status = $_POST['status'];
            $status_list = "";
            $j = 0;
            while ($j < sizeof($status)) {
                if ($j == 0)
                    $status_list.="'" . $status[$j] . "'"; 
                else
                    $status_list.=",'" . $status[$j] . "'"; 
                $j++;
            }
            $condition.="and status IN(" . $status_list . ")"; 
        }

        /* This piece of code holds an array of branch selected */
        if (isset($_POST['chkbranch']) && !empty($_POST['chkbranch'])) {
            $branch = $_POST['chkbranch'];
            $branch_list = "";
            $j = 0;
            while ($j < sizeof($branch)) {
                if ($j == 0)
                    $branch_list.="'" . $branch[$j] . "'";
                else
                    $branch_list.=",'" . $branch[$j] . "'";
                $j++;
            }
            $condition.="and branch IN(" . $branch_list . ")";
        }

        /* This piece of code holds an array of year of passing selected */
        if (isset($_POST['chkyear']) && !empty($_POST['chkyear'])) {
            $year = $_POST['chkyear'];
            $year_list = "";
            $k = 0;
            while ($k < sizeof($year)) {
                if ($k == 0)
                    $year_list.="'" . $year[$k] . "'";
                else
                    $year_list.=",'" . $year[$k] . "'";
                $k++;
            }
            $condition.="and year_passout IN(" . $year_list . ")";
        }

        /* This piece of code holds an array of boarding selected */
        if (isset($_POST['chkboarding']) && !empty($_POST['chkboarding'])) {
            $boarding = $_POST['chkboarding'];
            $boarding_list = "";
            $l = 0;
            while ($l < sizeof($boarding)) {
                if ($l == 0)
                    $boarding_list.="'" . $boarding[$l] . "'";
                else
                    $boarding_list.=",'" . $boarding[$l] . "'";
                $l++;
            }
            $condition.="and boarding IN(" . $boarding_list . ")";
        }

        /* This piece of code holds an array of categeory selected */
        if (isset($_POST['chkcat']) && !empty($_POST['chkcat'])) {
            $category = $_POST['chkcat'];
            $category_list = "";
            $m = 0;
            while ($m < sizeof($category)) {
                if ($m == 0)
                    $category_list.="'" . $category[$m] . "'";
                else
                    $category_list.=",'" . $category[$m] . "'";
                $m++;
            }
            $condition.="and category IN(" . $category_list . ")";
        }

        /* This piece of code holds an array of gender selected */
        if (isset($_POST['chkgen']) && !empty($_POST['chkgen'])) {
            $gender = $_POST['chkgen'];
            $gender_list = "";
            $n = 0;
            while ($n < sizeof($gender)) {
                if ($n == 0)
                    $gender_list.="'" . $gender[$n] . "'";
                else
                    $gender_list.=",'" . $gender[$n] . "'";
                $n++;
            }
            $condition.="and gender IN(" . $gender_list . ")";
        }

        /* This piece of code holds an array of cgpa secured */
        if (isset($_POST['txtcurrent']) && !empty($_POST['txtcurrent'])) {
            $cgpa = $_POST['txtcurrent'];
            $cgpa_sem = 'cgpa_' . $_POST['txtcgpa'];
            $condition.=" and " . $cgpa_sem . " >= " . $cgpa;
        }
        if (isset($_POST['txtbacklogs']) && (!empty($_POST['txtbacklogs']) || $_POST['txtbacklogs'] == '0')) {
            $backLogLimit = $_POST['txtbacklogs'];
            $backSum = "(0 "; 
            for ($counter = 1; $counter <= $_POST['txtcgpa']; $counter++) {
                $backSum.="+ back_$counter"; 
            }
            $backSum.=" )"; 
            $condition.=" and $backSum <= $backLogLimit "; 
        }
        if ($_POST['board'] == 'board') {
            $type = 'board_total';
            $type1 = 'board_secure';
        } else {
            $type = 'total';
            $type1 = 'secure';
        }
        if (isset($_POST['txtgrad']) && !empty($_POST['txtgrad'])) {
            $cgpa_grad = $_POST['txtgrad'];
            $condition.=" and (gra_" . $type1 . " / gra_" . $type . ")*100 >= " . $cgpa_grad;
        }
        if (isset($_POST['dip_or_hsc']) && !empty($_POST['dip_or_hsc'])) {
            $cgpa_dipl = $_POST['txtdipl'];
            $cgpa_12 = $_POST['txt12th'];
            $condition.=" and ((hsc_" . $type1 . " / hsc_" . $type . ")*100 >= " . $cgpa_12 . " or (dip_" . $type1 . " / dip_" . $type . ")*100 >= " . $cgpa_dipl . ")";
        } else {
            if (isset($_POST['txtdipl']) && !empty($_POST['txtdipl'])) {
                $cgpa_dipl = $_POST['txtdipl'];
                $condition.=" and (dip_" . $type1 . " / dip_" . $type . ")*100 >= " . $cgpa_dipl;
            }
            if (isset($_POST['txt12th']) && !empty($_POST['txt12th'])) {
                $cgpa_12 = $_POST['txt12th'];
                $condition.=" and (hsc_" . $type1 . " / hsc_" . $type . ")*100 >= " . $cgpa_12;
            }
        }
        if (isset($_POST['txt10th']) && !empty($_POST['txt10th'])) {
            $cgpa_10 = $_POST['txt10th'];
            $condition.=" and (ssc_" . $type1 . " / ssc_" . $type . ")*100 >= " . $cgpa_10;
        }

        /* This piece of code holds an array of year gaps given */
        if (isset($_POST['txtyrgap']) && (!empty($_POST['txtyrgap']) || $_POST['txtyrgap'] == '0')) {
            $cumulativeYearGap = $_POST['txtyrgap'];
            $condition.="and ((gap_10_12 + gap_10_dip + gap_12_gra + gap_dip_gra + gap_gra_pg) <= $cumulativeYearGap)";
        } else {
            if (isset($_POST['txtyrgap1012']) && (!empty($_POST['txtyrgap1012']) || $_POST['txtyrgap1012'] == '0')) {
                $gap_10_12 = $_POST['txtyrgap1012'];
                $condition.=" and (gap_10_12 <= $gap_10_12)  ";
            }
            if (isset($_POST['txtyrgap10dipl']) && (!empty($_POST['txtyrgap10dipl']) || $_POST['txtyrgap10dipl'] == '0')) {
                $gap_10_dipl = $_POST['txtyrgap10dipl'];
                $condition.=" and (gap_10_dip <= $gap_10_dipl)  ";
            }
            if (isset($_POST['txtyrgap12grd']) && (!empty($_POST['txtyrgap12grd']) || $_POST['txtyrgap12grd'] == '0')) {
                $gap_12_grd = $_POST['txtyrgap12grd'];
                $condition.=" and ( gap_12_gra <= $gap_12_grd)  ";
            }
            if (isset($_POST['txtyrgapdiplgrd']) && (!empty($_POST['txtyrgapdiplgrd']) || $_POST['txtyrgapdiplgrd'] == '0')) {
                $gap_dipl_grd = $_POST['txtyrgapdiplgrd'];
                $condition.=" and (gap_dip_gra <= $gap_dipl_grd)";
            }
            if (isset($_POST['txtyrgpgrdpg']) && (!empty($_POST['txtyrgpgrdpg']) || $_POST['txtyrgpgrdpg'] == '0')) {
                $gap_grd_pg = $_POST['txtyrgpgrdpg'];
                $condition.=" and (gap_gra_pg <= $gap_grd_pg)";
            }
        }
        if (isset($_POST['txtcomp']) && (!empty($_POST['txtcomp']) || $_POST['txtcomp'] == '0')) {
            $operator = $_POST['ddlcomp'];
            $val = $_POST['txtcomp'];
            //echo $val;
            if ($operator == "greaterequal") {
                $condition.="and (select count(*) from tbl_company_student where tbl_company_student.student_id=tbl_student.student_id and status='Placed') >= '$val'";
            } else if ($operator == "lessequal") {
                $condition.="and (select count(*) from tbl_company_student where tbl_company_student.student_id=tbl_student.student_id and status='Placed') <= '$val'";
            } else if ($operator == "equal") {
                $condition.="and (select count(*) from tbl_company_student where tbl_company_student.student_id=tbl_student.student_id and status='Placed') = '$val'";
            }
        }
        if (isset($_POST['txtpackage']) && !empty($_POST['txtpackage'])) {
            $package = $_POST['txtpackage'];
            $opr = $_POST['ddlpackage'];
            if ($opr == "equal") {
                $condition.=" AND(SELECT max(package) FROM tbl_company_student, tbl_company_schedule WHERE tbl_company_student.student_id = tbl_student.student_id AND tbl_company_schedule.schedule_id = tbl_company_student.schedule_id AND status = 'Placed' )='$package'";
            } else if ($opr == "lessequal") {
                $condition.=" AND(SELECT max(package) FROM tbl_company_student, tbl_company_schedule WHERE tbl_company_student.student_id = tbl_student.student_id AND tbl_company_schedule.schedule_id = tbl_company_student.schedule_id AND status = 'Placed' ) <='$package'";
            } else if ($opr == "greaterequal") {
                $condition.=" AND(SELECT max(package) FROM tbl_company_student, tbl_company_schedule WHERE tbl_company_student.student_id = tbl_student.student_id AND tbl_company_schedule.schedule_id = tbl_company_student.schedule_id AND status = 'Placed' ) >='$package'";
            }
        }
        $query = "select * from tbl_student where 1 " . $condition;

//echo $query;
        $_SESSION['query'] = $query;
        $res = mysql_query("$query");
//$rows=mysql_num_rows($res);
        $table = '';
        if (mysql_num_rows($res) > 0) {
            $total = mysql_num_rows($res);
            $table.='
            <table width="100%" bgcolor="#DFDFDF" align="center">
            <tr bgcolor="#000099">
            <td style="word-wrap:break-word;"><input type="checkbox" id="allSelect" onclick="return allSet(' . $total . ')" /></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Roll No.</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Name</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Email id</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Mobile</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>DOB</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Branch</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Stream</b></font></td>
            <td align="center" style="word-wrap:break-word;"><font color="#FFFFFF"><b>Gender</b></font></td>
            </tr>';
            $i = 0;
            while ($data = mysql_fetch_array($res)) {
                $i++;
                $table.= '
                    <tr>
                        <td align="center" style="word-wrap:break-word;"><input type="checkbox" id="studentIdCheck' . $i . '" name="chkstudent[]" value="' . $data['student_id'] . '" id=sel /></td>
                        <td style="word-wrap:break-word;">' . $data['roll_no'] . '</td>
                        <td style="word-wrap:break-word;">' . $data['name'] . '</td>            
                        <td style="word-wrap:break-word;">' . $data['alt_email'] . '</td>
                        <td style="word-wrap:break-word;">' . $data['mobile'] . '</td>
                        <td style="word-wrap:break-word;">' . $data['dob'] . '</td>
                        <td style="word-wrap:break-word;">' . $data['branch'] . '</td>
                        <td style="word-wrap:break-word;">' . $data['stream'] . '</td>
                        <td style="word-wrap:break-word;">' . $data['gender'] . '</td>
                    </tr>';
            }
            echo $table;
            $_SESSION['pdfData'] = $table . "</table>";
            $fetchquery = "SELECT tcs.schedule_id, tc.company_name, academic_year FROM tbl_company tc, tbl_company_schedule tcs WHERE tc.company_id = tcs.company_id ORDER BY  `tcs`.`academic_year` ASC ";
            $yearQuery = "SELECT distinct(academic_year) as year FROM tbl_company_schedule tcs ORDER BY  `tcs`.`academic_year` ASC ";
            $yearRes = mysql_query($yearQuery);
//echo $fetchquery;
            $fetchcmpny = mysql_query("$fetchquery");
            echo "<tr><td colspan='9' align='center'>Add to recruitment Drive:
    Academic Year: <select name='aca_year' onchange='return academicYear(this)'>
                        <option>Select</option>";
            while ($yearRow = mysql_fetch_array($yearRes)) {
                echo "<option>" . $yearRow['year'] . "</option>";
            }
            echo "</select>
           <input type='hidden' name='schedule_selected' id='schedule_selected' value='' />
            <select id='c' style='display:none'>";
            $aca_year = "";
            while ($company = mysql_fetch_array($fetchcmpny)) {
                if ($company['academic_year'] != $aca_year) {
                    $aca_year = $company['academic_year'];
                    echo "</select>";
                    echo "<select name='c" . $aca_year . "' id='c" . $aca_year . "' style='display:none'>";
                }
                echo '<option value="' . $company[0] . '">' . $company[1] . '</option>';
            }
            echo " </select></td>
        <tr>
        <td colspan='9' align='center'><input type='submit' name='btnsave' value='SAVE' /></td>
</form>
<tr><td colspan='4' align='right'>
<form method='post' action='export.php'><input type='submit' name='btnpdf' value='Export to PDF'></form></td>";
//<td colspan='5' align='left'><form method='post' action='$file'><input type='submit' name='btnexl' value='Export to Excel'></form></td></tr>";
            ?>
			
            
            
          
<td colspan='5' align='left'>            
 <script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<input type="button" id='download' value="Export to Excel" onClick="javascript:download_report();">
<?php
require_once("excelwriter.class.php");

$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("S.No.",
             "STUDENT NAME",
			 "ROLL NO.",
			 "LATERAL ENTRY",
			 "BOARDING (HOSTEL/DAY SCHOLAR)",
			 "CATEGORY (GENERAL/SC/ST/MI/PH/GC)",
			 "GENDER (MALE/FEMALE)",
			 "STREAM",
			 "BRANCH",
			 "DOB (DD-MM-YYYY)",
			 "PERMANENT TELEPHONE NUMBER",
			 "STUDENT MOBILE NUMBER",
			 "E-MAIL ADDRESS",
			 "ALTERNATIVE MAIL ID",
			 "PRESENT ADDRESS",
			 "PERMANENT ADDRESS",
			 "FATHER'S NAME",
			 "FATHER'S MOBILE",
			 "FATHER'S EMAIL-ID",
			 "FATHER'S OCCUPATION",
			 "FATHER'S DESIG.",
			 "10TH BOARD",
			 "10TH STATE",
			 "10TH YOP (YYYY)",
             "DISTANCE_10",
			 "10TH %",
			 "10TH AGG %",
			 "12TH BOARD (COUNCIL/BOARD)",
			 "12TH STATE",
			 "12TH YOJ (YYYY)",
			 "12TH YOP (YYYY)",
			 "DISTANCE_12",
			 "12TH %",
			 "12TH AGG.",
			 "DIP. (BOARD/COUCIL)",
			 "DIP. STATE",
			 "DIP. YOJ (YYYY)",
			 "DIP. YOP (YYYY)",
			 "DISTANCE _DIPLOMA",
			 "DIP. %",
			 "DIP. AGG.",
			 "GRADU. (BOARD/COUCIL)",
			 "GRADU. STATE",
			 "GRADU. YOJ (YYYY)",
			 "GRADU. YOP (YYYY)",
			 "DISTANCE _GRADUATION",
			 "GRADU. STREAM",
			 "GRADU. HONS.",
			 "GRADU. %",
			 "GRADU. AGG.",
			 "SEM -1 (SGPA)",
			 "SEM -1 (CGPA)",
			 "SEM -2 (SGPA)",
			 "SEM -2 (CGPA)",
			 "SEM -3 (SGPA)",
			 "SEM -3 (CGPA)",
			 "SEM -4 (SGPA)",
			 "SEM -4 (CGPA)",
			 "SEM -5 (SGPA)",
			 "SEM -5 (CGPA)",
			 "SEM -6 (SGPA)",
			 "SEM -6 (CGPA)",
			 "SEM -7 (SGPA)",
			 "SEM -7 (CGPA)",
			 "SEM -8 (SGPA)",
			 "SEM -8 (CGPA)",
			 "SEM -9 (SGPA)",
			 "SEM -9 (CGPA)",
			 "SEM -10 (SGPA)",
			 "SEM -10 (CGPA)",
			 "NO OF BACK",
			 "10TH - 12TH",
			 "10TH - DIPLOMA",
			 "12TH - GRADUATION",
			 "DIPLOMA - GRADUATION",
			 "TOTAL YEAR GAP",
			 "REASON",
			 "HOBBY",
			 "PROJECT NAME",
			 "INSTITUTION/ORGANISATION",
			 "DURATION OF THE PROJECT",
			 "PROJECT GUIDE",
			 "PROJECT SUMMARY",
			 "STATUS",
			 "COMPANY 1",
			 "COMPANY 2",
			 "COMPANY 3",
			 "CERTIFICATION 1",
			 "CERTIFICATION 2",
			 "CERTIFICATION 3",
			 "CERTIFICATION 4",
			 "CERTIFICATION 5",
			 "CERTIFICATION 6",
			 "CERTIFICATION 7",
			 "CERTIFICATION 8",
			 "CERTIFICATION 9",
			 "CERTIFICATION 10",
			 "SSC SCHOOL NAME",
			 "HSC SCHOOL NAME",
			 "DIPLOMA SCHOOL NAME",
			 "GRADUATION SCHOOL NAME",
			 "PERMANENT ADDREES 1",
			 "PERMANENT ADDREES 2",
			 "PERMANENT ADDREES CITY",
			 "PERMANENT ADDREES STATE",
			 "PERMANENT ADDREES PIN",
			 "PRESENT ADDREES 1",
			 "PRESENT ADDREES 2",
			 "PRESENT ADDREES CITY",
			 "PRESENT ADDREES STATE",
			 "PRESENT ADDREES PIN");
$excel->writeLine($myArr);

$res = mysql_query($query);

if($res!=false)
{
	$i=1;
	while ($row = mysql_fetch_array($res)) {
		$dob = date("d-M-y", strtotime($row['dob']));//date of birth
/***********************
calculate 10th %
************************/
		if ($row['ssc_board_total'] != 0)
        $sscBoardPer = round(($row['ssc_board_secure'] / $row['ssc_board_total']) * 100, 2);
    else
        $sscBoardPer = 0;
    if ($row['ssc_total'] != 0)
        $sscPer = round(($row['ssc_secure'] / $row['ssc_total']) * 100, 2);
    else
        $sscPer = 0;
/***********************
calculate 12th %
************************/
		if ($row['hsc_board_total'] != 0)
        $hscBoardPer = round(($row[hsc_board_secure] / $row[hsc_board_total]) * 100, 2);
    else
        $hscBoardPer = 0;
    if ($row['hsc_total'] != 0)
        $hscPer = round(($row[hsc_secure] / $row[hsc_total]) * 100, 2);
    else
        $hscPer = 0;
/***********************

calculate graduation %
************************/
		if ($row['gra_board_total'] != 0)
        $graBoardPer = round(($row[gra_board_secure] / $row[gra_board_total]) * 100, 2);
    else
        $graBoardPer = 0;
    if ($row[gra_total] != 0)
        $graPer = round(($row[gra_secure] / $row[gra_total]) * 100, 2);
    else
        $graPer = 0;      
/***********************

calculate diploma %
************************/
		if ($row['dip_board_total'] != 0)
        $dipBoardPer = round(($row[dip_board_secure] / $row[dip_board_total]) * 100, 2);
    else
        $dipBoardPer = 0;
    if ($row[dip_total] != 0)
        $dipPer = round(($row[dip_secure] / $row[dip_total]) * 100, 2);
    else
        $dipPer = 0;

$totalBacks = $row[back_1] + $row[back_2] + $row[back_3] + $row[back_4] + $row[back_5] + $row[back_6] + $row[back_7] + $row[back_8] + $row[back9] + $row[back_10];//total no. of back

$totalYearGap = $row[gap_10_12] + $row[gap_10_dip] + $row[gap_12_gra] + $row[gap_dip_gra];//total year gap

$certList = explode("?", $row['certification']);//certification list
/*********************************
Select Company name
**********************************/
$companyQuery = "SELECT * FROM  `tbl_company_student` tcs, tbl_company_schedule tcsh, tbl_company tc
                       WHERE tcs.schedule_id = tcsh.schedule_id
                       AND tcsh.company_id = tc.company_id
                       AND tcs.status =  'Placed'
                       AND tcs.student_id=$row[student_id]";
    $companyRes = mysql_query("$companyQuery");
    
    while ($companyRow = mysql_fetch_array($companyRes)) {
		$company= $company.",".$companyRow['company_name'];
		}
		$company= explode(",",$company);
		$myArr=array($i,
		             $row['name'],
					 $row['roll_no'],
					 $row['lateral'],
					 $row['boarding'],
					 $row['category'],
					 $row['gender'],
					 $row['stream'],
					 $row['branch'],
					 $dob,
					 $row['mobile_perm'],
					 $row['mobile'],
					 $row['email'],
					 $row['alt_email'],
					 $row['corres_address'],
					 $row['permanent_address'],
					 $row['father_name'],
					 $row['father_mobile'],
					 $row['father_email'],
					 $row['father_org'],
					 $row['father_add'],
					 $row['ssc_board'],
					 $row['ssc_state'],
					 $row['ssc_yop'],
					 $row['ssc_distance'],
					 $sscBoardPer,
					 $sscPer,
					 $row['hsc_board'],
					 $row['hsc_state'],
					 $row['hsc_yoj'],
					 $row['hsc_yop'],
					 $row['hsc_distance'],
					 $hscBoardPer,
					 $hscPer,
					 $row['dip_board'],
					 $row['dip_state'],
					 $row['dip_yoj'],
					 $row['dip_yop'],
					 $row['dip_distance'],
					 $dipBoardPer,
					 $dipPer,
					 $row['gra_board'],
					 $row['gra_state'],
					 $row['gra_yoj'],
					 $row['gra_yop'],
					 $row['gra_distance'],
					 $row['gra_stream'],					 
					 $row['gra_honors'],					 
					 $graBoardPer,
					 $graPer,
					 $row['sgpa_1'],
					 $row['cgpa_1'],
					 $row['sgpa_2'],
					 $row['cgpa_2'],
					 $row['sgpa_3'],
					 $row['cgpa_3'],
					 $row['sgpa_4'],
					 $row['cgpa_4'],
					 $row['sgpa_5'],
					 $row['cgpa_5'],
					 $row['sgpa_6'],
					 $row['cgpa_6'],
					 $row['sgpa_7'],
					 $row['cgpa_7'],
					 $row['sgpa_8'],
					 $row['cgpa_8'],
					 $row['sgpa_9'],
					 $row['cgpa_9'],
					 $row['sgpa_10'],
					 $row['cgpa_10'],
					 $totalBacks,
					 $row['gap_10_12'],
					 $row['gap_10_dip'],
					 $row['gap_12_gra'],
					 $row['gap_dip_gra'],
					 $totalYearGap,
					 $row['gap_reason'],
					 $row['hobby'],
					 $row['pro_name'],
					 $row['pro_org'],
					 $row['pro_duration'],
					 $row['pro_guide'],
					 $row['pro_summary'],
					 $row['status'],
					 $company[1],
					 $company[2],
      				 $company[3],
					 $certList[0],
					 $certList[1],
					 $certList[2],
					 $certList[3],
					 $certList[4],
					 $certList[5],
					 $certList[6],
					 $certList[7],
					 $certList[8],
					 $certList[9],
					 $row['ssc_school'],
					 $row['hsc_school'],
					 $row['dip_school'],
					 $row['gra_school'],
					 $row['permanent_add_1'],
					 $row['permanent_add_2'],
					 $row['permanent_add_city'],
					 $row['permanent_add_state'],
					 $row['permanent_add_pin'],
					 $row['corres_add_1'],
					 $row['corres_add_2'],
					 $row['corres_add_city'],
					 $row['corres_add_state'],
					 $row['corres_add_pin'],
					 );
		$excel->writeLine($myArr);
		$i++;
	}
}
?>           
</td></tr>            
          
          
                     
			<?php
			echo "</table>";
        } else {
            $_SESSION['ErrMsg'] = "<script>alert('No Data Found. Please check your eligibility Criteria')</script>";
        }
    }

    if (isset($_POST['btnsave']) && !empty($_POST['btnsave']) && $_POST['btnsave'] == 'SAVE') {
        //echo "<script>alert('Mayank')</script>";
        if (isset($_POST['chkstudent']) && !empty($_POST['chkstudent'])) {
            $scheduleSelected = $_POST['schedule_selected'];
            $schedule_id = $_POST[$scheduleSelected];
            $i = 0;
            //echo "<script>alert(".$i.")</script>";
            while ($i < sizeof($_POST['chkstudent'])) {      // echo "<script>alert('".$i."')</script>";
                $student_id = $_POST['chkstudent'][$i];
                $i++;
                $insertquery = "insert into tbl_company_student(schedule_id,student_id,status) values ($schedule_id,$student_id,'Appeared')";
                //echo $insertquery;
                $insertstd = mysql_query($insertquery);
                if ($insertstd)
                    $_SESSION['ErrMsg'] = "<script>alert('Student registered for Recruitment Drive...')</script>";
                else
                    $_SESSION['ErrMsg'] = "<script>alert('The student is already added for the Drive. Terminating the process')</script>";
            }
            //header("location:viewStudent.php");
        }
    }

    $content = ob_get_contents();
    ob_clean();
    include'template.php';
    if (isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg'])) {
        echo $_SESSION['ErrMsg'];
        unset($_SESSION['ErrMsg']);
    }
    ?>