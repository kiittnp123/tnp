<?php
session_start();
if(!isset($_SESSION['userName']) || empty($_SESSION['userName']) || !isset($_SESSION['userType']) || empty($_SESSION['userType']) || ($_SESSION['userType']!='Admin-TNP' && $_SESSION['userType']!='Admin-VER' ))
    header("location:login.php");

?>
