<script language="javascript">
function download_report()
{
	window.location='report.xls';
}
</script>
<a id='download' href="javascript:void(0);" onClick="javascript:download_report();">Download Report</a>
<input type="button" id='download' value="download" onClick="javascript:download_report();">
<?php
require_once("excelwriter.class.php");

$excel=new ExcelWriter("report.xls");
if($excel==false)	
echo $excel->error;

$myArr=array("S.No.",
             "STUDENT NAME",
			 "ROLL NO.",
			 "LATERAL ENTRY",
			 "BOARDING (HOSTEL/DAY SCHOLAR)",
			 "CATEGORY (GENERAL/SC/ST/MI/PH/GC)",
			 "GENDER (MALE/FEMALE)",
			 "STREAM",
			 "BRANCH",
			 "DOB (DD-MM-YYYY)",
			 "PERMANENT TELEPHONE NUMBER",
			 "STUDENT MOBILE NUMBER",
			 "E-MAIL ADDRESS",
			 "ALTERNATIVE MAIL ID",
			 "PRESENT ADDRESS",
			 "PERMANENT ADDRESS",
			 "FATHER'S NAME",
			 "FATHER'S MOBILE",
			 "FATHER'S EMAIL-ID",
			 "FATHER'S OCCUPATION",
			 "FATHER'S DESIG.",
			 "10TH BOARD",
			 "10TH STATE",
			 "10TH YOP (YYYY)",
             "DISTANCE_10",
			 "10TH %",
			 "10TH AGG %",
			 "12TH BOARD (COUNCIL/BOARD)",
			 "12TH STATE",
			 "12TH YOJ (YYYY)",
			 "12TH YOP (YYYY)",
			 "DISTANCE_12",
			 "12TH %",
			 "12TH AGG.",
			 "DIP. (BOARD/COUCIL)",
			 "DIP. STATE",
			 "DIP. YOJ (YYYY)",
			 "DIP. YOP (YYYY)",
			 "DISTANCE _DIPLOMA",
			 "DIP. %",
			 "DIP. AGG.",
			 "SEM -1 (SGPA)",
			 "SEM -1 (CGPA)",
			 "SEM -2 (SGPA)",
			 "SEM -2 (CGPA)",
			 "SEM -3 (SGPA)",
			 "SEM -3 (CGPA)",
			 "SEM -4 (SGPA)",
			 "SEM -4 (CGPA)",
			 "SEM -5 (SGPA)",
			 "SEM -5 (CGPA)",
			 "SEM -6 (SGPA)",
			 "SEM -6 (CGPA)",
			 "SEM -7 (SGPA)",
			 "SEM -7 (CGPA)",
			 "SEM -8 (SGPA)",
			 "SEM -8 (CGPA)",
			 "SEM -9 (SGPA)",
			 "SEM -9 (CGPA)",
			 "SEM -10 (SGPA)",
			 "SEM -10 (CGPA)",
			 "NO OF BACK",
			 "10TH - 12TH",
			 "10TH - DIPLOMA",
			 "12TH - GRADUATION",
			 "DIPLOMA - GRADUATION",
			 "TOTAL YEAR GAP",
			 "REASON",
			 "HOBBY",
			 "PROJECT NAME",
			 "INSTITUTION/ORGANISATION",
			 "DURATION OF THE PROJECT",
			 "PROJECT GUIDE",
			 "PROJECT SUMMARY",
			 "STATUS",
			 "COMPANY 1",
			 "COMPANY 2",
			 "COMPANY 3",
			 "CERTIFICATION 1",
			 "CERTIFICATION 2",
			 "CERTIFICATION 3",
			 "CERTIFICATION 4",
			 "CERTIFICATION 5",
			 "CERTIFICATION 6",
			 "CERTIFICATION 7",
			 "CERTIFICATION 8",
			 "CERTIFICATION 9",
			 "CERTIFICATION 10",
			 "SSC SCHOOL NAME",
			 "HSC SCHOOL NAME",
			 "DIPLOMA SCHOOL NAME",
			 "GRADUATION SCHOOL NAME",
			 "PERMANENT ADDREES 1",
			 "PERMANENT ADDREES 2",
			 "PERMANENT ADDREES CITY",
			 "PERMANENT ADDREES STATE",
			 "PERMANENT ADDREES PIN",
			 "PRESENT ADDREES 1",
			 "PRESENT ADDREES 2",
			 "PRESENT ADDREES CITY",
			 "PRESENT ADDREES STATE",
			 "PRESENT ADDREES PIN");
$excel->writeLine($myArr);

$db_name="kiittnp_tnp_ilabs";
$server="localhost";
$user="kiittnp_tnpmis";
$password="ilabs@123$";
$con=mysql_connect($server,$user,$password);
mysql_select_db($db_name);

$query="SELECT * FROM `tbl_student` WHERE `year_passout`='2014'";
$res = mysql_query($query);

if($res!=false)
{
	$i=1;
	while ($row = mysql_fetch_array($res)) {
		$dob = date("d-M-y", strtotime($row['dob']));//date of birth
/***********************
calculate 10th %
************************/
		if ($row['ssc_board_total'] != 0)
        $sscBoardPer = round(($row['ssc_board_secure'] / $row['ssc_board_total']) * 100, 2);
    else
        $sscBoardPer = 0;
    if ($row['ssc_total'] != 0)
        $sscPer = round(($row['ssc_secure'] / $row['ssc_total']) * 100, 2);
    else
        $sscPer = 0;
/***********************
calculate 12th %
************************/
		if ($row['hsc_board_total'] != 0)
        $hscBoardPer = round(($row[hsc_board_secure] / $row[hsc_board_total]) * 100, 2);
    else
        $hscBoardPer = 0;
    if ($row['hsc_total'] != 0)
        $hscPer = round(($row[hsc_secure] / $row[hsc_total]) * 100, 2);
    else
        $hscPer = 0;
/***********************
calculate diploma %
************************/
		if ($row['dip_board_total'] != 0)
        $dipBoardPer = round(($row[dip_board_secure] / $row[dip_board_total]) * 100, 2);
    else
        $dipBoardPer = 0;
    if ($row[dip_total] != 0)
        $dipPer = round(($row[dip_secure] / $row[dip_total]) * 100, 2);
    else
        $dipPer = 0;

$totalBacks = $row[back_1] + $row[back_2] + $row[back_3] + $row[back_4] + $row[back_5] + $row[back_6] + $row[back_7] + $row[back_8] + $row[back9] + $row[back_10];//total no. of back

$totalYearGap = $row[gap_10_12] + $row[gap_10_dip] + $row[gap_12_gra] + $row[gap_dip_gra];//total year gap

$certList = explode("?", $row['certification']);//certification list
/*********************************
Select Company name
**********************************/
$companyQuery = "SELECT * FROM  `tbl_company_student` tcs, tbl_company_schedule tcsh, tbl_company tc
                       WHERE tcs.schedule_id = tcsh.schedule_id
                       AND tcsh.company_id = tc.company_id
                       AND tcs.status =  'Placed'
                       AND tcs.student_id=$row[student_id]";
    $companyRes = mysql_query("$companyQuery");
    
    while ($companyRow = mysql_fetch_array($companyRes)) {
		$company= $company.",".$companyRow['company_name'];
		}
		$company= explode(",",$company);
		$myArr=array($i,
		             $row['name'],
					 $row['roll_no'],
					 $row['lateral'],
					 $row['boarding'],
					 $row['category'],
					 $row['gender'],
					 $row['stream'],
					 $row['branch'],
					 $dob,
					 $row['mobile_perm'],
					 $row['mobile'],
					 $row['email'],
					 $row['alt_email'],
					 $row['corres_address'],
					 $row['permanent_address'],
					 $row['father_name'],
					 $row['father_mobile'],
					 $row['father_email'],
					 $row['father_org'],
					 $row['father_add'],
					 $row['ssc_board'],
					 $row['ssc_state'],
					 $row['ssc_yop'],
					 $row['ssc_distance'],
					 $sscBoardPer,
					 $sscPer,
					 $row['hsc_board'],
					 $row['hsc_state'],
					 $row['hsc_yoj'],
					 $row['hsc_yop'],
					 $row['hsc_distance'],
					 $hscBoardPer,
					 $hscPer,
					 $row['dip_board'],
					 $row['dip_state'],
					 $row['dip_yoj'],
					 $row['dip_yop'],
					 $row['dip_distance'],
					 $dipBoardPer,
					 $dipPer,
					 $row['sgpa_1'],
					 $row['cgpa_1'],
					 $row['sgpa_2'],
					 $row['cgpa_2'],
					 $row['sgpa_3'],
					 $row['cgpa_3'],
					 $row['sgpa_4'],
					 $row['cgpa_4'],
					 $row['sgpa_5'],
					 $row['cgpa_5'],
					 $row['sgpa_6'],
					 $row['cgpa_6'],
					 $row['sgpa_7'],
					 $row['cgpa_7'],
					 $row['sgpa_8'],
					 $row['cgpa_8'],
					 $row['sgpa_9'],
					 $row['cgpa_9'],
					 $row['sgpa_10'],
					 $row['cgpa_10'],
					 $totalBacks,
					 $row['gap_10_12'],
					 $row['gap_10_dip'],
					 $row['gap_12_gra'],
					 $row['gap_dip_gra'],
					 $totalYearGap,
					 $row['gap_reason'],
					 $row['hobby'],
					 $row['pro_name'],
					 $row['pro_org'],
					 $row['pro_duration'],
					 $row['pro_guide'],
					 $row['pro_summary'],
					 $row['status'],
					 $company[1],
					 $company[2],
      				 $company[3],
					 $certList[0],
					 $certList[1],
					 $certList[2],
					 $certList[3],
					 $certList[4],
					 $certList[5],
					 $certList[6],
					 $certList[7],
					 $certList[8],
					 $certList[9],
					 $row['ssc_school'],
					 $row['hsc_school'],
					 $row['dip_school'],
					 $row['gra_school'],
					 $row['permanent_add_1'],
					 $row['permanent_add_2'],
					 $row['permanent_add_city'],
					 $row['permanent_add_state'],
					 $row['permanent_add_pin'],
					 $row['corres_add_1'],
					 $row['corres_add_2'],
					 $row['corres_add_city'],
					 $row['corres_add_state'],
					 $row['corres_add_pin'],
					 );
		$excel->writeLine($myArr);
		$i++;
	}
}
?>