<?php 
session_start();
include_once '../db.php';
include_once '../inc/conf.php';
ob_start();
if(isset($_POST['btnlogin']) && !empty($_POST['btnlogin'])){
	$_SESSION['userType']=mysql_real_escape_string($_POST['userType']);
        
	$uid= mysql_real_escape_string($_POST['txtid']);
        $pwd= mysql_real_escape_string($_POST['txtpwd']);
        
        $query="select user_id,user_type,name from tbl_admin where user_id='$uid' and password='$pwd' and user_type='$_SESSION[userType]'";
        //echo $query;
	$res=mysql_query($query);
        if(mysql_num_rows($res) == 1)
	{
		$data=mysql_fetch_array($res);
            $_SESSION['userName']=$data[0];
			$_SESSION['userFullName']=$data[2];
            if($_SESSION['userType']=="Admin-TNP" || $_SESSION['userType']=="Admin-VER") header("location:index.php");
            if($_SESSION['userType']=="Admin-NOC") header("location:../noc/indexNoc.php");
            if($_SESSION['userType']=="Admin-CES") header("location:indexCes.php");
			if($_SESSION['userType']=="Admin-FIN"){ 
                $receiptQuery="select value from tbl_setting where type='mr_number' and status='Active'";
                $res=  mysql_query($receiptQuery);
                //echo mysql_num_rows($res);
                if(mysql_num_rows($res)==1){
                    $row=  mysql_fetch_array($res);
                    $_SESSION['mrNumber']=$row[0];
                }else{
                    //echo mysql_num_rows($res);
                    $_SESSION['mrNumber']='Not Set';
                }
                header("location:../finance/index.php");
                }
	}
	else{
        $_SESSION['errMsg']="<script>alert('Error while Login. Please check your username and password');</script>";
        }
    }
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body background="../img/Brown-Striped-Packaging-l.jpg">
    <form method="post" name="loginfrm" action="login.php">
<center><img src="../img/kiitlogo.png" /></center>
<table align="center"  bgcolor="#E2E2E2" style="border-style:ridge">
<tr>
<td align="center">User Type:</td>
<td><select name="userType">
        <option value="Admin-TNP">Admin</option>
    <option value="Admin-NOC">TPO</option>
    <option value="Admin-CES">Admin CS</option>
    <option value="Admin-VER">Admin Verification</option>
	<option value="Admin-FIN">Admin Finance</option>
</select></td>
</tr>
<tr>
<td width="100" height="70" align="center">User Id:</td><td width="204"><input type="text" name="txtid" /></td>
</tr>
<tr>
<td height="70" align="center">Password:</td><td><input type="password" name="txtpwd" /></td>
</tr>
<tr>
<td height="90" colspan="2" align="center"><input type="submit" name="btnlogin" value="Login" />
                                            <input type="reset" name="btnreset" value="Reset" /></td>
</tr>
</table>
</form>
</body>
</html>
<?php
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>