<?php
ob_start();
include 'protectedAdmin.php';
include_once '../inc/conf.php';
$selectStream="";
?>
<script type="text/javascript">
function display(c)
{
	//alert("swopna");
  if(c.value == "1")
  {
     document.getElementById('form1').style.display='block';
     document.getElementById('form2').style.display='none';
	 
  }
   else if(c.value == "2")
   {
	 document.getElementById("form1").style.display='none';
     document.getElementById("form2").style.display='block';
   } 
}
function isempty()
{
	if(document.form1.rollno.value=='')
	{
		alert("Please enter the roll no"); 
		document.form1.rollno.focus();
		return false;
	}
        if(document.form1.stream.value=='Select')
	{
		alert("Please select a stream"); 
		return false;
	}
        if(document.form1.passout_year.value=='Select')
	{
		alert("Please select the passout year of the student"); 
		return false;
	}
        return true;
	
}

function isblank()
{
	if(document.form2.srollno.value=='')
	{
		alert("Please enter the starting roll no"); 
		document.form2.srollno.focus();
		return false;
	}
	if(document.form2.erollno.value=='')
	{
		alert("Please enter the ending roll no"); 
		document.form2.erollno.focus();
		return false;
	}
        if(document.form2.stream.value=='')
	{
		alert("Please select a stream"); 
		return false;
	}
        if(document.form2.passout_year.value=='')
	{
		alert("Please select the passout year of the student"); 
		return false;
	}
        return true;
}

function setValidStream(c,d){
    var xmlhttp;
	//alert(c.value+d);
if (c.value=='Select')
  { 
  document.getElementById(d).innerHTML="Please select a Stream";
  return;
  }
if (window.XMLHttpRequest)
  {// code for IE7+, Firefox, Chrome, Opera, Safari
  xmlhttp=new XMLHttpRequest();
  }
else
  {// code for IE6, IE5
  xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
  }
xmlhttp.onreadystatechange=function()
  {
  if (xmlhttp.readyState==4 && xmlhttp.status==200)
    {
    document.getElementById(d).innerHTML="<select name='branch'>"+xmlhttp.responseText+"</select>";
    }
  }
xmlhttp.open("GET","../inc/branchList.php?id="+c.value,true);
xmlhttp.send();
}

</script>
<form action="addStudent.php" method="get" name="addstd" id="form3">
<table align="center">
<tr>
<td><input id="one" type="radio" name="rdbtn1"  value="1" onclick="display(this)" />Insert One Candidate</td>
<td><input id="two" type="radio" name="rdbtn1"  value="2" onclick="display(this)" />Insert Multiple Candidates</td>
</tr>
</table>
</form>

<form id='form1' style="display:none" name="form1" onsubmit="return isempty()">
<table align="center" bgcolor="#E8E8E8" width='600'>
<tr>
<td width='200'>Enter Roll no.</td>
<td width='400'><input type="text" name="rollno" onkeypress="return isNumberKey(event)" /></td>
</tr>
<tr>
    <td width='200'>Select Stream</td>
    <td width='400'><select name="stream" onchange="setValidStream(this,'branchPlaceHolder');">
        <option>Select</option>
                              <option value="B.Tech">B.Tech</option>               
                              <option value="M.Tech">M.Tech</option>
                              <option value="MCA">MCA</option>
                              <option value="Dual Degree B.Tech and M.Tech">Dual Degree-B.Tech + M.Tech</option>
                              <option value="Dual Degree B.Tech and MBA">Dual Degree-B.Tech + MBA</option>
                     </select></td>
</tr>
<tr>
    <td width='200'>Select Branch</td>
    <td id='branchPlaceHolder'  width='400'></td>
</tr>
<tr>
<td width='200'>Select Joining year</td>
<td width='400'><select name="year_join">
        <option>Select</option>
<?php include '../inc/yearList.php'; ?>
    </select></td>
</tr>
<tr>
<td width='200'>Select Passout year</td>
<td width='400'><select name="passout_year">
        <option>Select</option>
<?php include '../inc/yearList.php'; ?>
    </select></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnsubmit1" value="Submit" />
<input type="reset" name="btnreset1" value="Reset" /></td>
</tr>
</table>

</form>

<form id='form2' style="display:none" name="form2" onsubmit="return isblank()">

<table align="center" bgcolor="#E8E8E8">
<tr>
<td>Enter Starting Rollno.</td> <td><input type="text" name="srollno" onkeypress="return isNumberKey(event)" /></td>
</tr>
<tr>
<td>Enter Ending Rollno.</td> <td><input type="text" name="erollno" onkeypress="return isNumberKey(event)" /></td>
</tr>
    <tr>
        <td>Select Stream</td><td><select name="stream" onchange="setValidStream(this,'branchPlaceHolder1')">
        <option>Select</option>
                              <option value="B.Tech">B.Tech</option>               
                              <option value="M.Tech">M.Tech</option>
                              <option value="MCA">MCA</option>
                              <option value="Dual Degree B.Tech and M.Tech">Dual Degree-B.Tech + M.Tech</option>
                              <option value="Dual Degree B.Tech and MBA">Dual Degree-B.Tech + MBA</option>
                     </select></td>
</tr>
<tr>
    <td width='200'>Select Branch</td>
    <td id='branchPlaceHolder1' width='400'></td>
</tr>
<tr>
<td width='200'>Select Joining year</td>
<td width='400'><select name="year_join">
        <option>Select</option>
<?php include '../inc/yearList.php'; ?>
    </select></td>
</tr>
<tr>
<td>Select Passout year</td>
<td><select name="passout_year">
        <option>Select</option>
<?php include '../inc/yearList.php'; ?>
    </select></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnsubmit2" value="Submit" />
                               <input type="reset" name="btnreset2" value="Reset" /></td>
</tr>
</table>

</form>
<?php

include'../db.php';
if(isset($_GET['btnsubmit1']) && !empty($_GET['btnsubmit1']))
	{
		$roll1=  mysql_real_escape_string($_GET['rollno']);
		$email="@kiit.ac.in";
		$pwd=rand(1000,9000);
                $stream=mysql_real_escape_string($_GET['stream']);
                
                $year=mysql_real_escape_string($_GET['passout_year']);
                $branch=mysql_real_escape_string($_GET['branch']);
                $yearJoin=mysql_real_escape_string($_GET['year_join']);
$sql1="insert into tbl_student(roll_no,email,status,password,stream,year_passout,branch,year_join) values('$roll1','$roll1$email','Created','$pwd','$stream',$year,'$branch',$yearJoin)";
$res=mysql_query("$sql1");

if($res)
{
  $body='Dear Candidate,\r\nYour profile with the KIIT-TNP Management Portal has been created. Your credentials are provided below:\r\nUser id : '.$roll1.$email.'\r\n password: '.$pwd.'\r\n\r\nYou can now login to your profile from kiittnp.in\r\nPlease complete your profile as soon as possible so as to help in the smooth running of the Training and Placement process.\r\nBest Regards,\r\nTraining and Placement Officer\r\nKIIT-University';
  $body.="\r\n\r\n\r\n\r\nNote: Please do not reply back to this mail. Replies to this mail goes to an unmonitored mail box. For any further communication, please feel free to drop a mail at placement@kiit.ac.in and training@kiit.ac.in";
  mail($roll1.$email,'Profile Created KIIT-TNP',$body,'from: contact@kiittnp.in');
  $_SESSION['ErrMsg']="<script>alert('Rollno inserted !!')</script>";
  
}
else
{
  $_SESSION['ErrMsg']="<script>alert('Rollno already exists !!')</script>";
  
}
}
	
 if(isset($_GET['btnsubmit2']) && !empty($_GET['btnsubmit2']))
	{
		$srollno=mysql_real_escape_string($_GET["srollno"]);
                $erollno=mysql_real_escape_string($_GET["erollno"]);
                $email="@kiit.ac.in";
                $stream=mysql_real_escape_string($_GET['stream']);
                $year=mysql_real_escape_string($_GET['passout_year']);
                $branch=mysql_real_escape_string($_GET['branch']);
                $yearJoin=mysql_real_escape_string($_GET['year_join']);
                if($srollno<=$erollno){
		for($i=$srollno;$i<=$erollno;$i++)
		{
			$pwd=rand(1000,9000);
			$sql2="insert into tbl_student(roll_no,email,status,password,stream,year_passout,branch,year_join) values('$i','$i$email','Created','$pwd','$stream',$year,'$branch',$yearJoin)";
			$res2=mysql_query("$sql2");
                        if($res2)
                            {
                                 $_SESSION['ErrMsg']="<script>alert('Roll nos are inserted !!')</script>";
                                 $body='Dear Candidate,\r\nYour profile with the KIIT-TNP Management Portal has been created. Your credentials are provided below:\r\nUser id : '.$i.$email.'\r\n password: '.$pwd.'\r\n\r\nYou can now login to your profile from kiittnp.in\r\nPlease complete your profile as soon as possible so as to help in the smooth running of the Training and Placement process.\r\nBest Regards,\r\nTraining and Placement Officer\r\nKIIT-University';
                                 $body.="\r\n\r\n\r\n\r\nNote: Please do not reply back to this mail. Replies to this mail goes to an unmonitored mail box. For any further communication, please feel free to drop a mail at placement@kiit.ac.in and training@kiit.ac.in";
                                 mail($i.$email,'Profile Created KIIT-TNP',$body,'from: contact@kiittnp.in');
                            }
                        else
                            {
                                $_SESSION['ErrMsg']="<script>alert('Roll no".$i." already exists. Quitting the process')</script>";
                                break;          
                            }
		}
                }
                else{
                  $_SESSION['ErrMsg']="<script>alert('Starting Roll Number should be less than the ending roll number')</script>";  
                }
		//$rows2=mysql_affected_rows($res2);
        
	}
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>