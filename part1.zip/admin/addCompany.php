<?php
//session_start();
ob_start();
include 'protectedAdmin.php';
include '../db.php';
include_once '../inc/conf.php';
?>
<script language="javascript" type="text/javascript">
function validation()
{
	if(document.form1.txtcompname.value=='')
	{
		alert("Company name cant be left blank"); 
		document.form1.txtcompname.focus();
		return false;
	}
	if(document.form1.txtcompadd.value=='')
	{
		alert("Company address cant be left blank"); 
		document.form1.txtcompadd.focus();
		return false;
	}
        /*
	if(document.form1.imgupload.value=='')
	{
		alert("Please upload the company logo"); 
		document.form1.imgupload.focus();
		return false;
	}
        */
}
</script>
    <?php
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}

// this code will execute when save button is clicked .

if(isset($_POST['btnsave']) && !empty($_POST['btnsave']) && $_POST['btnsave']=='SAVE')
{
$compid=mysql_real_escape_string($_POST['txtcompid']);
$compname=mysql_real_escape_string($_POST['txtcompname']);
$add=mysql_real_escape_string($_POST['txtcompadd']);
$displayWall=mysql_real_escape_string($_POST['wall_display']);
$companyType=mysql_real_escape_string($_POST['comp_type']);
$insert="insert into tbl_company(company_id,company_name,company_address,company_logo,display,company_type) values('$compid','$compname','$add','','$displayWall','$companyType')";
$res=mysql_query("$insert");
if($res)
    $_SESSION['ErrMsg']="<script>alert('Your data saved successfully.');</script>";
else
    $_SESSION['ErrMsg']="<script>alert('Some Problem Occurred. Please try again');</script>";
if(isset($_FILES['imgupload']['name']) && !empty($_FILES['imgupload']['name'])){
if($_FILES['imgupload']['type'] == 'image/png' || $_FILES['imgupload']['type'] == 'image/jpeg')
      {
           $id=  mysql_insert_id($con);
           $arr=explode(".", $_FILES['imgupload']['name']);
           $ext=end($arr);
           $destination="../img/logo".$id.".".$ext;
           $res=move_uploaded_file($_FILES['imgupload']['tmp_name'], $destination);
              if($res){
                  $query = "UPDATE `tbl_company` SET `company_logo` = '$destination' WHERE `tbl_company`.`company_id` =$id";
                  $res=  mysql_query("$query");
      	          $_SESSION['ErrMsg']="<script>alert('Your data saved successfully.');</script>";
			          }
       }
		else
			   {
				   $_SESSION['ErrMsg']="<script>alert('please upload png or jpg type image file !!!')</script>";
			   }
} 
}
$selectid="select max(company_id)+1 from tbl_company";
$result=mysql_query($selectid,$con);
$data=mysql_fetch_array($result);
$maxid=$data[0];
?> 
<form name="form1" method="post"  enctype="multipart/form-data" id="form1" onSubmit="return validation()">
<table align="center" bgcolor="#E5E5E5" width="600">
<tr>
<td colspan="2" align="center" bgcolor="#000066"><font color="#FFFFFF"><b>ENTER COMPANY DETAILS</b></font></td>
</tr>
<tr>
<td>Company Id:</td>
<td><input type="text" name="txtcompid" value="<?php echo $maxid; ?>" readonly /></td>
</tr>
<tr>
<td>Company Name:</td>
<td><input type="text" name="txtcompname" /></td>
</tr>
<tr>
<td>Company Address:</td>
<td><textarea name="txtcompadd" rows="5" cols="20"></textarea></td>
</tr>
<tr>
<td>Company Logo:</td>
<td><input type="file" name="imgupload"><br></td>
</tr>
<tr>
<td>Company Type:</td>
<td><select name="comp_type">
        <option>IT</option>
        <option>CORE</option>
        <option>OTHERS</option>
        <option>ENGINEERING</option>
    </select></td>
</tr>
<tr>
<td>Display on Portal:</td>
<td><input type="radio" value="Block" name="wall_display" checked="checked"/>Yes &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
    <input type="radio" value="None" name="wall_display" />No</td>
</tr>

<tr>
<td colspan="2" align="center" bgcolor="#000066"><input type="submit" name="btnsave" value="SAVE" />
                                                <input type="reset" name="btnreset" value="RESET" /></td>
</tr>
</table>
</form>
</body>
</html>
 <?php
$content=ob_get_contents();
ob_clean();
include_once 'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>