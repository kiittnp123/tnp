<?php
//session_start();
include 'protectedAdmin.php';
include_once '../inc/conf.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}

ob_start();
include'../db.php';
?>
<form action='' method='post' onsubmit='return isEmpty(aca_year)'>
        <table align='center'>
        <tr>
        <td align='center' bgcolor='#000033'><font color='#FFFFFF'>Select recruitment Drive:</font>
<?php
$fetchquery="SELECT tcs.schedule_id, tc.company_name, academic_year FROM tbl_company tc, tbl_company_schedule tcs WHERE tc.company_id = tcs.company_id 
            ORDER BY  `tcs`.`academic_year` ASC ";
$yearQuery="SELECT distinct(academic_year) as year FROM tbl_company_schedule tcs ORDER BY  `tcs`.`academic_year` ASC ";
$yearRes=  mysql_query($yearQuery);
//echo $fetchquery;
$fetchcmpny=mysql_query("$fetchquery");
echo "
   <select name='aca_year' id='aca_year' onchange='return academicYear(this)'>
                        <option>Select</option>";
while($yearRow=  mysql_fetch_array($yearRes)){
    echo "<option>".$yearRow['year']."</option>";
}
       echo "</select>
           <input type='hidden' name='schedule_selected' id='schedule_selected' value='' />
            <select id='c' style='display:none'>";
$aca_year="";
while($company=mysql_fetch_array($fetchcmpny))
{
        if($company['academic_year']!=$aca_year){
            $aca_year=$company['academic_year'];
            echo "</select>";
            echo "<select name='c".$aca_year."' id='c".$aca_year."' style='display:none'>";
        }
	echo '<option value="'.$company[0].'">'.$company[1].'</option>';
        
}
?>
</select></td>
        </tr>
        <tr>
            <td align='center'><input type='Submit' name='btnsubmit' value='Submit'></td>
        </tr>
        </table>
</form>
<form method="post" action="">
<?php
if(isset($_POST['btnsubmit']) && !empty($_POST['btnsubmit']) && $_POST['btnsubmit'] == 'Submit')
{
	$scheduleSelected=mysql_real_escape_string($_POST['schedule_selected']);
	$schedule_id=$_POST[$scheduleSelected];
        echo "<input type='hidden' name='company_id' value='$schedule_id' />";
	$selstdquery="select * from 
                      tbl_student ts,tbl_company_student tcs,tbl_company tc,tbl_company_schedule tcsh
                      where 
                      tcs.schedule_id='$schedule_id' and 
                      tcs.student_id=ts.student_id and
                      tcs.schedule_id=tcsh.schedule_id and
                      tcsh.company_id=tc.company_id";
	//echo $selstdquery;
        $selstd=mysql_query($selstdquery);
        $total=  mysql_num_rows($selstd);
        if($total!=0){
        $i=0;
	$_SESSION['query']=$selstdquery;
	$table='';
	$table.='<table align="center" border="1" bgcolor="#DBDBDB" width="100%">
            <tr bgcolor="#000099" class="font">
            <td><input type="checkbox" id="allSelect" onclick="return allSet('.$total.')" /></td>
            <td>Student Name</td>
            <td>Roll No.</td>
            <td>Branch</td>
            <td>Stream</td>
            <td>Company</td>
            <td>Date of Visit</td>
            <td>Academic Year</td>
            <td>Status</td>
            </tr>';
		while($student=mysql_fetch_array($selstd))
                {
                    $i++;
                    $table.= '
		<tr>
        	<td><input type="checkbox" id="studentIdCheck'.$i.'" name="chkstudent[]" value="'. $student['student_id'].'"></td>
            <td>'.$student[1].'</td>
            <td>'.$student[0].'</td>
            <td>'. $student[14].'</td>
            <td>'. $student[18].'</td>
                <td>'. $student['company_name'].'</td>
                    <td>'. $student['date_visit'].'</td>
                        <td>'. $student['academic_year'].'</td>
            <td>'. $student[109].'</td>           
        </tr>';
	 }
	 echo $table;
     $_SESSION['pdfData']=$table."</table>";
	 ?> 
	<tr><td colspan="9" align="center">With Selected Rows 
                                            <select name="status">
                                                <option>Placed</option>
                                                <option>Appeared</option>
                                                <option>Remove</option>
                                            </select></td></tr>
	<tr><td colspan="9" align="center">
    <input type="submit" name="btnplaced" value="Set Status" /></td></tr>
</form>
    <tr><td colspan="4" align="right"><form action="export.php" method="post">
    <input type="submit" name="btnpdf" value="Export to PDF" />
    </form></td>
    <td colspan="5" align="left"><form action="placedstdExcel.php" method="post">
    <input type="submit" name="btnexcel" value="Export to Excel" />
    </form></td>
    </tr>
    </table>
<?php 
}
else{
    $_SESSION['errMsg']="<script>alert('No student has been selected to appear for this placement session. Please assign students to access this fucntionality');</script>";
}
}
if(isset($_POST['btnplaced']) && !empty($_POST['btnplaced']) && $_POST['btnplaced'] == 'Set Status')
{
	
	if(isset($_POST['chkstudent']) && !empty($_POST['chkstudent']))
	{	
		$scheduleId=mysql_real_escape_string($_POST['company_id']);
                $status=mysql_real_escape_string($_POST['status']);
                $i=0;
		while($i<sizeof($_POST['chkstudent']))
		{
			$student_id=$_POST['chkstudent'][$i];
			$i++;
                        if($status=='Remove')
                            $updatequery="delete from tbl_company_student where student_id='$student_id' and schedule_id='$scheduleId' ";
                        else
                            $updatequery="update tbl_company_student set status='$status' where student_id='$student_id' and schedule_id='$scheduleId' ";
                        $updateres=mysql_query($updatequery);
			//echo $updatequery;
			$_SESSION['errMsg']="<script>alert('Status of the Students are changed...')</script>";
	        
		}
	}else{
            $_SESSION['errMsg']="<script>alert('Atleast one student needs to be selected for completing the process')</script>";
        }
}

$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
?>