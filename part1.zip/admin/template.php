<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script src="../SpryAssets/SpryTabbedPanels.js" type="text/javascript"></script>
<link href="../SpryAssets/SpryTabbedPanels.css" rel="stylesheet" type="text/css" />
<link href="style.css" rel="stylesheet" type="text/css" />
<script src="../calendar/calendarDateInput.js" type="text/javascript">
</script>
<script type="text/javascript">
var lastYear='';
function academicYear(c){
    //alert(c.value);
    //alert(lastYear);
    document.getElementById("c"+c.value).style.display="block";
    document.getElementById("schedule_selected").value="c"+c.value;
    document.getElementById("c"+lastYear).style.display="none";
    
    
    lastYear=c.value;
}

function isNumberKey(evt)
       {
          var charCode = (evt.which) ? evt.which : event.keyCode;
          if (charCode != 46 && charCode > 31 
            && (charCode < 48 || charCode > 57)){
            alert("Invalid Character");
             return false;
            }

          return true;
       }
function isEmpty(c){
    if(c.value=='' || c.value=='Select'){
        alert('field cannot be left empty');
        c.focus();
        return false;
    }
}
</script>
<script type="text/javascript">
    function allSet(c){
    //alert(c);
    if(document.getElementById("allSelect").checked==true){
        for(var i=1;i<=c;i++)
            document.getElementById("studentIdCheck"+i).checked=true;
    }else{
        for(var i=1;i<=c;i++){
            document.getElementById("studentIdCheck"+i).checked=false;
        }
    }
    }
</script>
</head>

<body background="../img/background4.gif" style="background-repeat:repeat-x">
    <table align="center" >
  <tr>
 <td colspan="2"><img name="kiitlogo" src="../img/kiitlogo.png" /></td>
  </tr>
  <tr><td colspan="2">
          <table align="center">
         <tr>
             <td>
    <ul class="TabbedPanelsTabGroup">
   <?php if($_SESSION['userType']=="Admin-TNP"){ ?> 
      <li class="TabbedPanelsTab" tabindex="0"><a href="index.php">Homepage</a>
      <ul>
       <!-- <li><a href="viewMessages.php">View Messages</a></li> -->
       <li><a href="upgrade.php">Edit Homepage</a></li>
      </ul>
      </li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="viewStudent.php">View/Search</a></li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="javascript::void(0)">Manage Candidate</a>
      <ul>
        	<li><a href="addStudent.php">Add Candidate</a></li>
            <li><a href="resetPwd.php">Reset Password</a></li>
            <li><a href="verifyCandidate.php">Manage Candidate</a></li>
            <li><a href="resultUpdate.php">Result Update</a></li>
			
      </ul>
      </li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="#"><span>Manage Items</span></a>
      	<ul>
        	<li><a href="addNews.php?news=p">Publish News</a></li>
            <li><a href="addNotice.php?notice=p">Publish Notice</a></li>
            <li><a href="addNews.php?news=e">Update End Date-News</a></li>
            <li><a href="addNotice.php?notice=e">Update End Date-Notice</a></li>
            <li><a href="addNews.php?news=u">Delete News</a></li>
            <li><a href="addNotice.php?notice=u">Delete Notice</a></li>
            <li><a href="news.php">View News</a></li>
            <li><a href="notice.php">View Notice</a></li>
        </ul>
      </li> 
      <li class="TabbedPanelsTab" tabindex="0"><a href="#">Visiting Company</a>
      	<ul>
            <li><a href="manageCompany.php">Manage Company</a></li>
        	<li><a href="addCompany.php">Add Company</a></li>
            <li><a href="addHr.php">Add HR</a></li>
         </ul></li>   
      <li class="TabbedPanelsTab" tabindex="0"><a href="#">Manage Recruitments</a>
      <ul>
        	<li><a href="CompanySchedule.php">Add Company Schedule</a></li>
                <li><a href="viewRecruitment.php">Manage Company Schedule</a></li>
            <li><a href="placedStudent.php">Placed Students</a></li>
         </ul>
      
      </li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="#">Admin Settings</a>
      <ul>
          <li><a href="adminSettings.php">Manage Settings</a></li>
          <li><a href="nocSetting.php">NOC Settings</a></li>
          <li><a href="changePassword.php">Change Password</a></li>
                
         </ul>
      
      </li>
      <?php
   }elseif($_SESSION['userType']=="Admin-VER"){
      ?>
      <li class="TabbedPanelsTab" tabindex="0"><a href="index.php">Homepage</a>
      <ul>
       <li><a href="viewMessages.php">View Messages</a></li>
      </ul>
      </li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="javascript::void(0)">Manage Candidate</a>
      <ul>
            <li><a href="resetPwd.php">Reset Password</a></li>
            <li><a href="verifyCandidate.php">Manage Candidate</a></li>
            <li><a href="resultUpdate.php">Result Update</a></li>
			
      </ul>
      </li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="javascript::void(0)">News &amp; Notices</a>
      <ul>
            <li><a href="news.php">View News</a></li>
            <li><a href="notice.php">View Notices</a></li>
			
      </ul>
      </li>
      <li class="TabbedPanelsTab" tabindex="0"><a href="changePassword.php">Change Password</a></li>
      <?php
   }
      ?>
      
      <li class="TabbedPanelsTab" tabindex="0"><a href="logout.php">Logout</a></li>
      
    </ul>    
                  </td>
         </tr>
     </table>
 </td>
</tr>

<tr>
<td colspan="2" align="left"><?php echo $content ?></td>
</tr>
</table>
<script type="text/javascript">
var TabbedPanels1 = new Spry.Widget.TabbedPanels("TabbedPanels1");
</script>
</body>
</html>