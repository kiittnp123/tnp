<?php 
include 'protectedAdmin.php';
ob_start();
include'../db.php';
include_once '../inc/conf.php';
?>
<script type="text/javascript">
function numbers()
{
	var num=c.txtmob;
	if(isNaN(num.value))
	{
		alert("Please enter number only");
                num.value='';
		return false;	
	}
}
function validationHR(c)
{
	if(c.txtviewname.value=='')
	{
		alert("Please enter the name"); 
		return false;
	}
	if(c.txtviewposn.value=='')
	{
		alert("Please enter the position"); 
		return false;
	}
	if(c.txtviewemail.value=='')
	{
		alert("Please enter the email id"); 
		return false;
	}
        if(c.txtviewstatus.value!='Active' && c.txtviewstatus.value!='Inactive')
	{
		alert("Please enter the correct status. Valid values are 'Active' or 'Inactive' "); 
		return false;
	}
	
}
</script>
<script language="javascript" type="text/javascript">
function validationCompany(c)
{
	if(c.txtviewname.value=='')
	{
		alert("Company name cant be left blank"); 
		return false;
	}
	if(c.txtviewname.value=='')
	{
		alert("Company address cant be left blank"); 
		return false;
	}
}
</script>
<?php
if(isset($_POST['btn_hrupdate']) && !empty($_POST['btn_hrupdate']) && $_POST['btn_hrupdate']=='UPDATE')
{
	$hrid=mysql_real_escape_string($_POST['txtviewid']);
        $name=mysql_real_escape_string($_POST['txtviewname']);
        $posn=mysql_real_escape_string($_POST['txtviewposn']);
        $mobile=mysql_real_escape_string($_POST['txtviewmob']);
        $email=mysql_real_escape_string($_POST['txtviewemail']);
        $address=mysql_real_escape_string($_POST['txtviewadd']);
        $status=mysql_real_escape_string($_POST['txtviewstatus']);

$update="update tbl_hr set name='$name',position='$posn',mobile='$mobile',email='$email',address='$address' where hr_id='$hrid'";
$result=mysql_query($update);
if($result)
{
	$_SESSION['ErrMsg']="<script>alert('Data Updated Successfully')</script>";
}else{
        $_SESSION['ErrMsg']="<script>alert('Problem Occurred')</script>";
}
}
if(isset($_POST['btnupdate']) && !empty($_POST['btnupdate']) && $_POST['btnupdate']=='UPDATE')
 {
    $cmpid=mysql_real_escape_string($_POST['txtviewid']);
    $cmpname=mysql_real_escape_string($_POST['txtviewname']);
    $cmpadd=mysql_real_escape_string($_POST['txtviewadd']);
    $cmpType=mysql_real_escape_string($_POST['comp_type_change']);
    if($cmpType=="Select")
        $cmpType=mysql_real_escape_string($_POST['comp_type']);
    $wallDisplay=mysql_real_escape_string($_POST['wall_display_change']);
    if($wallDisplay=="Select")
        $wallDisplay=mysql_real_escape_string($_POST['wall_display']);

    $destination="";
    //var_dump($_FILES);
    if(isset($_FILES['imgupload']['name']) && !empty($_FILES['imgupload']['name'])){
        if($_FILES['imgupload']['type'] == 'image/png' || $_FILES['imgupload']['type'] == 'image/jpeg')
      {
           $arr=explode(".", $_FILES['imgupload']['name']);
           $ext=end($arr);
           $destination="../img/logo".$cmpid.".".$ext;
           $res=move_uploaded_file($_FILES['imgupload']['tmp_name'], $destination);
           echo $destination."Mayank";
       }
	else
    {
        $_SESSION['ErrMsg']="<script>alert('please upload png or jpg type image file !!!')</script>";
    }
} 
    $update="update tbl_company set company_name='$cmpname',company_address='$cmpadd',company_logo='$destination',display='$wallDisplay',
             company_type='$cmpType' where company_id='$cmpid'";
   // echo $update;
    $resupdate=mysql_query($update);
    if($resupdate)
	$_SESSION['ErrMsg']="<script>alert('You have successfully updated ur company details.')</script>";
  }
if(isset($_GET['task']) && !empty($_GET['task']) && ((isset($_GET['cid']) && !empty($_GET['cid'])) || (isset($_GET['hid']) && !empty($_GET['hid']))))
    {
    if(isset($_GET['cid']))
        $companyId=mysql_real_escape_string($_GET['cid']);
    
    if($_GET['task']=='update'){
        $select="select * from tbl_company where company_id=$companyId";
        $result=mysql_query("$select");
        $row=mysql_num_rows($result);
        if($row>0)
        {
          $data=mysql_fetch_array($result);
            ?>
    
<form name="cmpview2" method="post" action="manageCompany.php" id="cmpview2" onsubmit="return validationCompany(this)" enctype="multipart/form-data" >
        <table align="center" width="800" border="1" bgcolor="#CCCCCC">
        <tr>
        <td colspan="2" align="center" bgcolor="#000066"><font color="#FFFFFF"><b>YOUR COMPANY DETAILS</b></font></td>
        </tr>
        <tr>
        <td>Company Id:</td>
        <td><input type="text" name="txtviewid" value="<?php echo $data['company_id'] ?>" readonly></td>
        </tr>
        <tr>
        <td>Company Name:</td>
        <td><input type="text" name="txtviewname" value="<?php echo $data['company_name'] ?>"></td>
        </tr>
        <tr>
        <td>Company Address:</td>
        <td><textarea name="txtviewadd" rows="10" cols="30"><?php echo $data['company_address'] ?></textarea></td>
        </tr>
        <tr>
        <td>Company Logo:</td>
        <td><img src="<?php echo $data['company_logo'] ?>" height="200" width="200" /> Change to: <input type="file" name="imgupload"></td>
        </tr>
        <tr>
        <td>Company Type:</td>
        <td><input type="text" name="comp_type" value="<?php echo $data['company_type'] ?>" readonly /> Change TO : <select name="comp_type_change">
                <option>Select</option>
                <option>IT</option>
                <option>CORE</option>
                <option>OTHERS</option>
                <option>ENGINEERING</option>
            </select></td>  
        </tr>
        <tr>
        <td>Display on Portal:</td>
        <td><input type="text" name="wall_display" value="<?php echo $data['display'] ?>" readonly /> Change TO : <select name="wall_display_change">
                <option>Select</option>
                <option value="Block">Yes</option>
                <option value="None">No</option>
            </select></td>
        </tr>
        <tr>
        <td colspan="2" align="center" bgcolor="#000066"><input type="submit" name="btnupdate" value="UPDATE">
        </tr>
        </table>
        </form>
<?php
	}
	 else
	 {
		 $_SESSION['ErrMsg']="<script>alert('Sorry...No company found having this id.')</script>";
	 }
    }
    if($_GET['task']=='delete'){
        $checkValidQuery="select * from tbl_company_schedule where company_id=$companyId";
        $checkValidRes=  mysql_query($checkValidQuery);
        $validity=  mysql_num_rows($checkValidRes);
        if($validity==0){
            $deleteQuery="delete from tbl_company where company_id=$companyId";
            $deleteHrQuery="delete from tbl_hr where company_id=$companyId";
            $deleteRes=  mysql_query($deleteQuery);
            $deleteHrRes=  mysql_query($deleteHrQuery);
            if($deleteHrRes && $deleteRes)
                $_SESSION['ErrMsg']="<script>alert('Company Information and the related HR Information has been deleted')</script>";
            else
                $_SESSION['ErrMsg']="<script>alert('Could not complete the action')</script>";
        }else{
            $_SESSION['ErrMsg']="<script>alert('Cannot delete the company as there is placement data related to the company')</script>";
        }
    }
    if($_GET['task']=='hr'){
        $sqlsel="select name,position,mobile,email,address,company_name,hr_id from tbl_hr,tbl_company where tbl_company.company_id=tbl_hr.company_id and tbl_hr.company_id=$companyId";
        //echo $sqlsel;
        $_SESSION['query']=$sqlsel;
	$result=mysql_query($sqlsel);
        if(mysql_num_rows($result)>0){
	echo"<form method='get' action='manageCompanyExcel.php'>
                <table align='center' height='30' width='100%' bgcolor='#CCCCCC'>
                    <tr bgcolor='#000066'>
                        <td><font color='#FFFFFF'>Name</font></td>
                        <td><font color='#FFFFFF'>Position</font></td>
                        <td><font color='#FFFFFF'>Mobile</font></td>
                        <td><font color='#FFFFFF'>Email</font></td>
                        <td><font color='#FFFFFF'>Address</font></td>
                        <td><font color='#FFFFFF'>Company</font></td>
                        <td colspan='2'><font color='#FFFFFF'>Action</font></td>
                    </tr>";
	while($val=mysql_fetch_array($result))
	{ ?>
        	<tr>
                    <td> <?php echo $val[0]; ?></td>
                    <td> <?php echo $val[1]; ?></td>
                    <td> <?php echo $val[2]; ?></td>
                    <td> <?php echo $val[3]; ?></td>
                    <td> <?php echo $val[4]; ?></td>
                    <td> <?php echo $val[5]; ?></td>
                    <td><a href="manageCompany.php?task=delHr&hid=<?php echo $val[6]?>">Delete</a></td>
                    <td><a href="manageCompany.php?task=updHr&hid=<?php echo $val[6]?>">Update</a></td>
                </tr> 
	
	<?php
	 }
        echo "<tr>
                <td colspan='8' align='center'><input type='submit' name='btnexcel' value='Export To Excel'></td>
             </tr>
           </table>
         </form>";
        }else{
            $_SESSION['ErrMsg']="<script>alert('No HR Information Found')</script>";
        }
    }
    if($_GET['task']=='delHr'){
        $hrId=mysql_real_escape_string($_GET['hid']);
        $delHrQuery="delete from tbl_hr where hr_id=$hrId";
        $delHrRes=mysql_query($delHrQuery);
        if($delHrRes)
           $_SESSION['ErrMsg']="<script>alert('HR Information Deleted Successfully')</script>"; 
        else
            $_SESSION['ErrMsg']="<script>alert('Problem Occurred')</script>";
    }
    if($_GET['task']=='updHr'){
        $hrid=mysql_real_escape_string($_GET['hid']);
	$select="select * from tbl_hr,tbl_company where hr_id='$hrid' and tbl_hr.company_id=tbl_company.company_id";
        $result=mysql_query($select,$con);
        $row=mysql_num_rows($result);
        if($row>0)
            {
                $data=mysql_fetch_array($result);
	 ?>
                <form name="hrview2" id="hrview2" method="post" action="manageCompany.php" onsubmit="return validationHR(this)">
        <table align="center" border="1" width="500" bgcolor="#CCCCCC">
        <tr>
        <td colspan="2" align="center" bgcolor="#000033"><font color="#FFFFFF"><b>YOUR HR DETAILS</b></font></td>
        </tr>
        <tr>
        <td>Hr Id:</td>
        <td><input type="text" name="txtviewid" value="<?php echo $data['hr_id'] ?>" readonly></td>
        </tr>
        <tr>
        <td>Name:</td>
        <td><input type="text" name="txtviewname" value="<?php echo $data['name'] ?>"></td>
        </tr>
        <tr>
        <td>Position:</td>
        <td><input type="text" name="txtviewposn" value="<?php echo $data['position'] ?>"></td>
        </tr>
        <tr>
        <td>Mobile:</td>
        <td><input type="text" name="txtviewmob" value="<?php echo $data['mobile'] ?>" onblur="return numbers()"></td>
        </tr>
        <tr>
        <td>Email:</td>
        <td><input type="text" name="txtviewemail" value="<?php echo $data['email'] ?>"></td>
        </tr>
        <tr>
        <td>Address:</td>
        <td><textarea name="txtviewadd"><?php echo $data['address'] ?></textarea></td>
        </tr>
        <tr>
        <td>Company Name:</td>
        <td><input type="text" name="companyname" value="<?php echo $data['company_name'] ?>" readonly="readonly"></td>
        </tr>
        <tr>
        <td>Status:</td>
        <td><input type="text" name="txtviewstatus" value="<?php echo $data['status'] ?>"></td>
        </tr>
        <tr>
        <td colspan="2" align="center" bgcolor="#000033"><input type="submit" name="btn_hrupdate" value="UPDATE"></td>
        </tr>
        </table>
        </form>
     <?php }
          else
		  {
	 		 $_SESSION['ErrMsg']="<script>alert('Sorry...No record found having this id.')</script>";
	
		  }
   }
}else{
$sql="SELECT company_id,company_name FROM tbl_company ";
$res=mysql_query($sql);
if(mysql_num_rows($res)>0){
echo "<form method='get' action=''>
        <table width='600' bgcolor='#CCCCCC' align='center'>
        <tr bgcolor='#000066'>
            <td><font color='#FFFFFF'><b>Company Name</b></font></td>
            <td colspan=3><font color='#FFFFFF'><b>Action</b></font></td>
        </tr>" ;
while($data=mysql_fetch_array($res))
{ ?>
  <tr>
      <td><?php echo $data[1]; ?></td>
      <td><a href="?task=update&cid=<?php echo $data[0];?>">Update Details</a></td>
      <td><a href="?task=delete&cid=<?php echo $data[0];?>">Delete Details</a></td>
      <td><a href="?task=hr&cid=<?php echo $data[0];?>">View HR List</a></td>
  </tr>
   <?php 
}
echo "</table></form>";
}else{
    $_SESSION['ErrMsg']="<script>alert('No Company to display')</script>";
}
}
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>