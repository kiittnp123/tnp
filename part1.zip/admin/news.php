<?php
include_once '../db.php';
include_once '../inc/conf.php';
include_once 'protectedAdmin.php';
$sqlnews="SELECT * FROM tbl_news WHERE STATUS = 'Active' and curdate() between date_sub(start_date, interval 1 day) and end_date order by start_date desc";
$res=mysql_query("$sqlnews");
ob_start();
?>
<table width="800" cellspacing="10" cellpadding="10" style="font-family: trebuchet MS; font-size: 13px;text-align: justify;line-height: 1.5;">
    <tr>
        <td><h1>News and Events</h1></td>
    </tr>

        <?php
		
		$i=0;
		while($data=mysql_fetch_array($res))
		{ $i++;?>
                    <tr>
                        <td>
                            <fieldset <?php if($i%2==0) echo 'style="background-color: #D7D7D7;"'; else echo 'style="background-color: white;"'; ?>>
                             <h3><?php echo $data['heading']; ?></h3>
                          <p> <b>Date:  <?php echo $data['start_date'] ?></b></p>
                             <?php
                             if($data['news_img'] != '')
                             {
                             ?>
                             <img src="<?php echo $data['news_img'] ?>" alt="Image" width="125" height="125" align="left" style="padding: 10px;">
                            <?php
                             }
                            ?>
                    <p><br />
                       <?php echo $data['content'] ?></p>
                            </fieldset>
                        </td>
                    </tr>
        <?php
		}
		?>
</table>
<?php
$content = ob_get_contents();
$pageType="News";
ob_end_clean();
include_once 'template.php';
?>