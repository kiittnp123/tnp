<?php
ob_start();

include 'protectedAdmin.php';
include_once '../inc/conf.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}
include '../db.php';
?>
<script language="javascript" type="text/javascript">
function validation()
{
	if(document.frmpublish.txtheading.value=='')
	{
		alert("Heading cant be left blank"); 
		document.frmpublish.txtheading.focus();
		return false;
	}
	if(document.frmpublish.txtcontent.value=='')
	{
		alert("Content cant be left blank"); 
		document.frmpublish.txtcontent.focus();
		return false;
	}
	if(document.frmpublish.date.value=='Date' || document.frmpublish.enddate.value=='Date')
	{
		alert("Date cant be left blank"); 
		
		return false;
	}
	if(document.frmpublish.month.value=='Month' || document.frmpublish.endmonth.value=='Month')
	{
		alert("Month cant be left blank"); 
		
		return false;
	}
	if(document.frmpublish.year.value=='Year' || document.frmpublish.endyear.value=='Year')
	{
		alert("Year cant be left blank"); 
		
		return false;
	}
}
function validateDate(c){
    if(c.date.value=='Date')
	{
		alert("Date cant be left blank"); 
		
		return false;
	}
	if(c.month.value=='Month')
	{
		alert("Month cant be left blank"); 
		
		return false;
	}
	if(c.year.value=='Year')
	{
		alert("Year cant be left blank"); 
		
		return false;
	}
}
	</script>
<?php
$condition="";
if(isset($_POST['btnexpiry']) && !empty($_POST['btnexpiry']) && $_POST['btnexpiry']=='Update Date')
    {
    $id=mysql_real_escape_string($_POST['id']);
    $end_date=mysql_real_escape_string($_POST['expiry_date']);
    $query="update tbl_news set end_date='$end_date', status='Active' where news_id=$id";
    //echo $query;
    $res=  mysql_query($query);
    $_SESSION['errMsg']="<script>alert('Data Updated successfully')</script>";
    
    
}
/*If "publish news" button(publish sub-menu) is clicked then this code will be executed */
if(isset($_POST['btnpublish']) && !empty($_POST['btnpublish']) && $_POST['btnpublish']=='Publish News')
{
	$heading=mysql_real_escape_string($_POST['txtheading']);
	$content=nl2br(mysql_real_escape_string($_POST['txtcontent']));
	$start_date=mysql_real_escape_string($_POST['start_date']);
	$end_date=mysql_real_escape_string($_POST['end_date']);
	$status=mysql_real_escape_string($_POST['ddlstatus']);
        $query="insert into tbl_news(news_id,heading,content,start_date,end_date,status,news_img)  values(NULL,'$heading','$content','$start_date','$end_date','$status','');";
        $res=  mysql_query("$query");
        $id=  mysql_insert_id($con);
	if(isset($_FILES['imgupload']['name']) && !empty($_FILES['imgupload']['name'])){	
	if($_FILES['imgupload']['type'] == 'image/png' ||
               $_FILES['imgupload']['type'] == 'image/jpeg' || $_FILES['imgupload']['type'] == 'image/gif')
			   {
                $arr=explode(".", $_FILES['imgupload']['name']);
                $ext=end($arr);
                $destination="../img/news".$id.".".$ext;
	//			echo $destination;
              $res=move_uploaded_file($_FILES['imgupload']['tmp_name'], $destination);
              if($res){
                  $query = "UPDATE `tbl_news` SET `news_img` = '$destination' WHERE `tbl_news`.`news_id` =$id";
                  $res=  mysql_query("$query");
                 // echo 'successfully uploaded'; 
				       $_SESSION['errMsg']="<script>alert('News Submitted Successfully !!!')</script>";
	                   
			          }
					   
			   }
			   else
			   {
				   $_SESSION['errMsg']="<script>alert('please upload png or jpg type image file !!!')</script>";
	               
			   }
        }else{
            $_SESSION['errMsg']="<script>alert('News Submitted Successfully !!!')</script>";
        }
		
}
/*If "unpublish news" button(unpublish sub-menu) is clicked then this code will be executed */
if(isset($_POST['btnunpublish']) && !empty($_POST['btnunpublish']) && $_POST['btnunpublish']=='Delete News')
{
	$i=0;
        if(isset($_POST['chkbx'])){
	while($i<sizeof($_POST['chkbx']))
	   {
		if($i==0)
                    $condition.=$_POST['chkbx'][$i];
		else
                    $condition.=",".$_POST['chkbx'][$i];
                $imagePath=$_POST['image'.$_POST['chkbx'][$i]];
		if(!empty($imagePath))
                    unlink($imagePath);
                $i++;
		}
	$sqlupdate="delete from tbl_news where news_id IN (".$condition.")";
	//echo $sqlupdate;
	$update=mysql_query("$sqlupdate");
	$rows=mysql_affected_rows($con);
	$_SESSION['errMsg']="<script>alert('".$rows." News Deleted Successfully !!')</script>";
        }else{
            $_SESSION['errMsg']="<script>alert('Please select atleast one news to delete')</script>";
        }
}
if(isset($_POST['btnupdate']) && !empty($_POST['btnupdate']) && $_POST['btnupdate']=='Update News')
{
	$i=0;
        if(isset($_POST['updateid'])){
        $id=mysql_real_escape_string($_POST['updateid']);
	?>
    <form method="post" action="" onsubmit="return validateDate(this)">
        <input type="hidden" name="id" value="<?php echo $id ?>" />
        Select The new Expiry Date:
        <script type="text/javascript">DateInput('expiry_date', true, 'YYYY-MM-DD')</script>
        <br /><br />
                        <input type="submit" name="btnexpiry" value="Update Date"/>
    </form>
            
            <?php
	
        //echo $sqlupdate;
	//$update=mysql_query("$sqlupdate");
	
}else{
    $_SESSION['errMsg']="<script>alert('Please select a news to update')</script>";
}
}
/* If any of the sub menu links are clicked, then the following part of the code gets executed */
if(isset($_GET['news']) && !empty($_GET['news']))
{
	/* If any "Publish News" link is clicked then the following part of code gets executed */
	if($_GET['news']=="p")
	{ 
	$sql="select max(news_id)+1 from tbl_news";
	$res=mysql_query("$sql");
	while($data=mysql_fetch_array($res))
	{
	  $rol=$data[0];
	}
	?>    		
			<form name="frmpublish" id="frmpublish" method='post' onsubmit="return validation()" enctype="multipart/form-data">
            <table bgcolor="#E5E5E5" align="center" width="700">
			<tr>			
			<td width="530" colspan="4" align="center" bgcolor="#000033" valign="top"><font color="#FFFFFF"><b>ADD NEWS</b></font></td>
			</tr>
			<tr>			
            <td>News Id:</td>
			<td colspan="3"><input type="text" name="txtnid" value="<?php echo $rol ?>" readonly="readonly" style="width:200px" /></td>
			
            </tr>
			<tr>			
			<td>Headings:</td>
            <td colspan="3"><input type="text" name="txtheading" style="width:420px" /></td>
			</tr>
            <tr>
            <td>Content:</td>
            <td colspan="3"><textarea name="txtcontent" rows="5" cols="50"></textarea></td>
            </tr>
            <tr>           
            <td>Start Date:</td>
            <td><script type="text/javascript">DateInput('start_date', true, 'YYYY-MM-DD')</script></td>
              <td>End Date:</td>
            <td><script type="text/javascript">DateInput('end_date', true, 'YYYY-MM-DD')</script></td>          
            </tr>
            <tr>
            <td>Upload Image</td>
            <td colspan="3"><input type="file" name="imgupload" /></td>
            </tr>
            <tr>          
            <td>Status</td>
            <td colspan="3"><select name="ddlstatus">            				
                            <option>Active</option>
                            <option>Inactive</option></select></td>
            </tr>
            <tr>
            <td colspan="4" align="center"><input type="submit" name="btnpublish" value="Publish News" /></td>
            </tr>
			</table></form></td>
				
	<?php 	
	}
	/* If "Unpublish News" link is clicked then the following part of code gets executed */
	else if($_GET['news']=='u')
	{
			$sqlunpublish="select * from tbl_news ";
			//echo $sqlunpublish;
			$unpublishnews=mysql_query("$sqlunpublish");
			
			$rows=mysql_num_rows($unpublishnews);
			//echo $rows;
			if($rows>0)
			{
                            echo "<form name='unpublish' id='unpublish' method='post'>
                                <table border='1' align='center'  bgcolor='#E5E5E5' width='700'>
                                <tr bgcolor='#000033'>
                                    <td></td>
                                    <td align='center' width='100'><font color='#FFFFFF'><b>Heading</b></font></td>
                                    <td align='center'><font color='#FFFFFF'><b>Content</b></font></td>
                                </tr>";
			while($news2=mysql_fetch_array($unpublishnews))
                            {?>     <input type="hidden" name="image<?php echo $news2[0] ;?>" value="<?php echo $news2['news_img'] ;?>" />
				<tr>
                                    <td width="30" align="center"><input type="checkbox" name="chkbx[]" value="<?php echo $news2[0] ?>" /></td>
                                    <td><?php echo $news2[1]; ?></td>
                                    <td><?php echo $news2[2]; ?></td></tr>
			<?php }
                          echo "<tr>
                                    <td colspan='3' align='center'><input type='submit' name='btnunpublish' value='Delete News'/></td>
                               </tr>
                           </table>
                           </form>";
			}
			else
			{
				$_SESSION['errMsg']="<script>alert('No News Found !!!')</script>";
	 					
			}
	}
        else if($_GET['news']=='e')
            {
                        $sqlunpublish="select * from tbl_news";
			//echo $sqlunpublish;
			$unpublishnews=mysql_query("$sqlunpublish");
			
			$rows=mysql_num_rows($unpublishnews);
			//echo $rows;
			if($rows>0)
			{
                            echo "<form name='update' id='update' method='post'>
                            <table border='1' align='center'  bgcolor='#E5E5E5' width='700'>
                            <tr bgcolor='#000033'>
                            <td></td>
                            <td align='center' width='100'><font color='#FFFFFF'><b>Heading</b></font></td>
                            <td align='center'><font color='#FFFFFF'><b>Content</b></font></td>
                            </tr>";
			while($news2=mysql_fetch_array($unpublishnews))
			{ ?>
				<tr><td width="30" align="center"><input type="radio" name="updateid" value="<?php echo $news2[0] ?>" /></td>
                                    <td><?php echo $news2[1]; ?></td>
                                    <td><?php echo $news2[2]; ?></td>
                                </tr>
			<?php }
            echo "<tr>
                <td colspan='3' align='center'><input type='submit' name='btnupdate' value='Update News'/></td>
                </tr>
                </table>
                </form>";
			}
			else
			{
				$_SESSION['errMsg']="<script>alert('No News Found !!!')</script>";
	 					
			}
        }
	/* If any change in url is done forciblly the following part of code gets executed */
	else
	{
		echo "PAGE NOT FOUND.";
	}
}else
	{
		//echo "PAGE NOT FOUND.";
	}
	/* If page is loaded for the first time the following part of code gets executed */
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}

?>
