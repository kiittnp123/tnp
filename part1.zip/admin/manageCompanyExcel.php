<?php
session_start();
include'../db.php';
include_once '../inc/conf.php';
$query=$_SESSION['query'];
$res=  mysql_query($query);
include_once '../excel/Classes/PHPExcel.php';
$phpExcel = new PHPExcel();
$phpExcel->createSheet();
$phpExcel->getActiveSheet()->setCellValue("A1","Name");
$phpExcel->getActiveSheet()->setCellValue("B1","Position");
$phpExcel->getActiveSheet()->setCellValue("C1","Mobile");
$phpExcel->getActiveSheet()->setCellValue("D1","Email");
$phpExcel->getActiveSheet()->setCellValue("E1","Address");
$phpExcel->getActiveSheet()->setCellValue("F1","Company");
$t=2;
while ($row= mysql_fetch_array($res)){
    
    $phpExcel->getActiveSheet()->setCellValue("A".$t,$row[0]);
    $phpExcel->getActiveSheet()->setCellValue("B".$t,"$row[1]");
    $phpExcel->getActiveSheet()->setCellValue("C".$t,"$row[2]");
    $phpExcel->getActiveSheet()->setCellValue("D".$t,"$row[3]");
    $phpExcel->getActiveSheet()->setCellValue("E".$t,"$row[4]");
    $phpExcel->getActiveSheet()->setCellValue("F".$t,"$row[5]");
    $t++;
}

$excelWriter = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
//$excelWriter->save("HRdetails.xls");
header('Content-type:application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="HRdetails.xls"');
$excelWriter->save('php://output');

?>