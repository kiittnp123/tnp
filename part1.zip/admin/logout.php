<?php
session_start();
unset($_SESSION['userName']);
unset($_SESSION['userType']);
header("location:login.php");
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
?>
