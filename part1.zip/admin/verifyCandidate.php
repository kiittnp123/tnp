<?php
error_reporting(0);
ob_start();
include'../db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
if(isset($_POST['btn_action']) && !empty($_POST['btn_action']) && $_POST['btn_action']=='Perform Selected Action')
    {
    $selectedAction = mysql_real_escape_string($_POST['action']);
    $rollno=mysql_real_escape_string($_POST['roll_no']);
    if($selectedAction == 'Delete')
        {
        $verifySql="select * from tbl_company_student tcs, tbl_student ts where tcs.student_id=ts.student_id and ts.roll_no=$rollno ";
        //echo $verifySql;
        $verifyRes=  mysql_query($verifySql);
        //echo mysql_num_rows($verifyRes);
        if(mysql_num_rows($verifyRes)==0){
            $deleteSql="delete from tbl_student where roll_no=$rollno";
            $deleteRes=  mysql_query($deleteSql);
            if($deleteRes){
                $timeStamp=  date("d-M-Y G:i:s");
                $task=$_SESSION['userName']." deleted student with roll number $rollno";
                file_put_contents ( $_SESSION['userName'].date("d-M-Y").".txt" , $timeStamp." ".$task."\n", FILE_APPEND );
                $_SESSION['ErrMsg']="<script>alert('Student Data successfully deleted')</script>";
            }
            else
                $_SESSION['ErrMsg']="<script>alert('Some error was found')</script>";
        }else{
            //echo 'Mayank';
            $_SESSION['ErrMsg']="<script>alert('The roll number cannot be deleted as there are placement data related to the student')</script>";
        }
    }
    else if ($selectedAction == 'Update') 
        {
        $queryUpdate="";
        $status=$_POST['status'];
        $queryUpdate.="status = '$status',";
        if(isset($_POST['txtroll']) && !empty($_POST['txtroll']))
            $rollnoNew=mysql_real_escape_string($_POST['txtroll']);
        else 
            $rollnoNew=$rollno; 
        if(isset($_POST['name']) && !empty($_POST['name']))
            $queryUpdate.="name = '".mysql_real_escape_string($_POST[name])."', ";
        if($_POST['yearjoin'] != 'Select' ){
            $queryUpdate.="year_join = '".mysql_real_escape_string($_POST[yearjoin])."', ";
            $yearJoin=mysql_real_escape_string($_POST[yearjoin]);
        }  else {
            $yearJoin=$_POST['year_join'];
        }
        if($_POST['yearpass'] != 'Select' )
            $queryUpdate.="year_passout = '".mysql_real_escape_string($_POST[yearpass])."', ";
        if($_POST['boarding'] != 'Select' )
            $queryUpdate.="boarding = '".mysql_real_escape_string($_POST[boarding])."', ";
        if($_POST['category'] != 'Select' )
            $queryUpdate.="category = '".mysql_real_escape_string($_POST[category])."', ";
        if($_POST['gender'] != 'Select' )
            $queryUpdate.="gender = '".mysql_real_escape_string($_POST[gender])."', ";
        $curDate=date("Y-m-d");
        if($_POST['dob']!=$curDate)
            $queryUpdate.="dob = '".mysql_real_escape_string($_POST[dob])."', ";
        //$dob=$_POST['year']."-".$_POST['month']."-".$_POST['date'];
        if(isset($_POST['permanent_contact']) && !empty($_POST['permanent_contact']))
            $queryUpdate.="mobile_perm = '".mysql_real_escape_string($_POST[permanent_contact])."', ";
        if(isset($_POST['txtmobile']) && !empty($_POST['txtmobile']))
            $queryUpdate.="mobile = '".mysql_real_escape_string($_POST[txtmobile])."', ";
        if(isset($_POST['txtaltemail']) && !empty($_POST['txtaltemail']))
            $queryUpdate.="alt_email = '".mysql_real_escape_string($_POST[txtaltemail])."', ";
        if(isset($_POST['txtfhname']) && !empty($_POST['txtfhname']))
            $queryUpdate.="father_name = '".mysql_real_escape_string($_POST[txtfhname])."', ";
        if(isset($_POST['txtfhmobile']) && !empty($_POST['txtfhmobile']))
            $queryUpdate.="father_mobile = '".mysql_real_escape_string($_POST[txtfhmobile])."', ";
        if(isset($_POST['txtfemail']) && !empty($_POST['txtfemail']))
            $queryUpdate.="father_email = '".mysql_real_escape_string($_POST[txtfemail])."', ";
        if(isset($_POST['father_industry']) && !empty($_POST['father_industry']))
            $queryUpdate.="father_org = '".mysql_real_escape_string($_POST[father_industry])."', ";
        /*if(isset($_POST['father_post']) && !empty($_POST['father_post']))
            $queryUpdate.="father_add = '".mysql_real_escape_string($_POST[father_post])."', ";*/
		if(isset($_POST['father_post']) && !empty($_POST['father_post']))
            $queryUpdate.="father_add = '".mysql_real_escape_string($_POST[father_post])."', ";
		if(isset($_POST['father_add_1']) && !empty($_POST['father_add_1']))
            $queryUpdate.="father_add_1 = '".mysql_real_escape_string($_POST[father_add_1])."', ";	
		if(isset($_POST['father_add_2']) && !empty($_POST['father_add_2']))
            $queryUpdate.="father_add_2 = '".mysql_real_escape_string($_POST[father_add_2])."', ";
		if(isset($_POST['father_add_city']) && !empty($_POST['father_add_city']))
            $queryUpdate.="father_add_city = '".mysql_real_escape_string($_POST[father_add_city])."', ";
		if(isset($_POST['father_add_state']) && !empty($_POST['father_add_state']))
            $queryUpdate.="father_add_state = '".mysql_real_escape_string($_POST[father_add_state])."', ";
		if(isset($_POST['father_add_pin']) && !empty($_POST['father_add_pin']))
            $queryUpdate.="father_add_pin = '".mysql_real_escape_string($_POST[father_add_pin])."', ";
			
			
        /*if(isset($_POST['txtpermadd']) && !empty($_POST['txtpermadd']))
            $queryUpdate.="permanent_address = '".mysql_real_escape_string($_POST[txtpermadd])."', ";*/
		if(isset($_POST['txtpermadd']) && !empty($_POST['txtpermadd']))
            $queryUpdate.="permanent_address = '".mysql_real_escape_string($_POST[txtpermadd])."', ";
		if(isset($_POST['permanent_add_1']) && !empty($_POST['permanent_add_1']))
            $queryUpdate.="permanent_add_1 = '".mysql_real_escape_string($_POST[permanent_add_1])."', ";	
		if(isset($_POST['permanent_add_2']) && !empty($_POST['permanent_add_2']))
            $queryUpdate.="permanent_add_2 = '".mysql_real_escape_string($_POST[permanent_add_2])."', ";
		if(isset($_POST['permanent_add_city']) && !empty($_POST['permanent_add_city']))
            $queryUpdate.="permanent_add_city = '".mysql_real_escape_string($_POST[permanent_add_city])."', ";
		if(isset($_POST['permanent_add_state']) && !empty($_POST['permanent_add_state']))
            $queryUpdate.="permanent_add_state = '".mysql_real_escape_string($_POST[permanent_add_state])."', ";
		if(isset($_POST['permanent_add_pin']) && !empty($_POST['permanent_add_pin']))
            $queryUpdate.="permanent_add_pin = '".mysql_real_escape_string($_POST[permanent_add_pin])."', ";	
			
			
         /*if(isset($_POST['txtcorresadd']) && !empty($_POST['txtcorresadd']))
            $queryUpdate.="corres_address = '".mysql_real_escape_string($_POST[txtcorresadd])."', ";*/
		if(isset($_POST['txtcorresadd']) && !empty($_POST['txtcorresadd']))
            $queryUpdate.="corres_address = '".mysql_real_escape_string($_POST[txtcorresadd])."', ";
		if(isset($_POST['corres_add_1']) && !empty($_POST['corres_add_1']))
            $queryUpdate.="corres_add_1 = '".mysql_real_escape_string($_POST[corres_add_1])."', ";	
		if(isset($_POST['corres_add_2']) && !empty($_POST['corres_add_2']))
            $queryUpdate.="corres_add_2 = '".mysql_real_escape_string($_POST[corres_add_2])."', ";
		if(isset($_POST['corres_add_city']) && !empty($_POST['corres_add_city']))
            $queryUpdate.="corres_add_city = '".mysql_real_escape_string($_POST[corres_add_city])."', ";
		if(isset($_POST['corres_add_state']) && !empty($_POST['corres_add_state']))
            $queryUpdate.="corres_add_state = '".mysql_real_escape_string($_POST[corres_add_state])."', ";
		if(isset($_POST['corres_add_pin']) && !empty($_POST['corres_add_pin']))
            $queryUpdate.="corres_add_pin = '".mysql_real_escape_string($_POST[corres_add_pin])."', ";
			
         
        $destination='';
        $errFile='';
        //var_dump($_FILES['img']);
        if(isset($_FILES['img']['name']) && !empty($_FILES['img']['name'])){
	if($_FILES['img']['type'] == 'image/png' ||
           $_FILES['img']['type'] == 'image/jpeg' ||
           $_FILES['img']['type'] == 'image/gif') {
                   $std_id="select student_id from tbl_student where roll_no='$rollno'";
                   $res_id=mysql_query($std_id);
                   $data=mysql_fetch_array($res_id);
                   $id=$data[0];
                   $arr=explode(".", $_FILES['img']['name']);
                   $ext=end($arr);
                   $destination="../img/student".$id.".".$ext;
                   $res=move_uploaded_file($_FILES['img']['tmp_name'], $destination);
                   //var_dump($res);
                   $queryUpdate.="image = '$destination', ";
                   $errFile='';
            }else{
               $errFile="but the file type is not supported. Please upload only .jpg,.png or .gif file extensions";
            }
        }
         
        if((isset($_POST['ssc_done']) && !empty($_POST['ssc_done'])) ||
           (isset($_POST['hsc_done']) && !empty($_POST['hsc_done'])) ||
           (isset($_POST['dip_done']) && !empty($_POST['dip_done'])) ||
           (isset($_POST['gra_done']) && !empty($_POST['gra_done'])))
            {
            
        if(isset($_POST['ssc_done']) && !empty($_POST['ssc_done']) && $_POST['ssc_done']=='ssc')
            {
				$queryUpdate.="ssc_school = '".mysql_real_escape_string($_POST[ssc_school])."', ";
                $queryUpdate.="ssc_board = '".mysql_real_escape_string($_POST[ssc_board])."', ";
                if($_POST[ssc_state]!="Other")
                    $queryUpdate.="ssc_state = '".mysql_real_escape_string($_POST[ssc_state])."', ";
                else
                    $queryUpdate.="ssc_state = '".mysql_real_escape_string($_POST[ssc_state_other])."', ";
                $queryUpdate.="ssc_yop = $_POST[ssc_yop], ";
                $queryUpdate.="ssc_board_total = $_POST[ssc_board_total], ";
                $queryUpdate.="ssc_board_secure = $_POST[ssc_board_secured], ";
                $queryUpdate.="ssc_total = $_POST[ssc_total], ";
                $queryUpdate.="ssc_secure = $_POST[ssc_secured], ";
                $queryUpdate.="ssc_distance = '".mysql_real_escape_string($_POST[ssc_distance])."', ";
        }else
            {
                $queryUpdate.="ssc_school = 'NA', ";
				$queryUpdate.="ssc_board = 'NA', ";
                $queryUpdate.="ssc_state = 'NA', ";
                $queryUpdate.="ssc_yop = 0, ";
                $queryUpdate.="ssc_board_total = 0, ";
                $queryUpdate.="ssc_board_secure = 0, ";
                $queryUpdate.="ssc_total = 0, ";
                $queryUpdate.="ssc_secure = 0, ";
                $queryUpdate.="ssc_distance = 'NA', ";
        }
        if(isset($_POST['hsc_done']) && !empty($_POST['hsc_done']) && $_POST['hsc_done']=='hsc')
            {
                $queryUpdate.="hsc_school = '".mysql_real_escape_string($_POST[hsc_school])."', ";
			    $queryUpdate.="hsc_board = '".mysql_real_escape_string($_POST[hsc_board])."', ";
                if($_POST[hsc_state]!="Other")
                    $queryUpdate.="hsc_state = '".mysql_real_escape_string($_POST[hsc_state])."', ";
                else
                    $queryUpdate.="hsc_state = '".mysql_real_escape_string($_POST[hsc_state_other])."', ";
                $queryUpdate.="hsc_yop = $_POST[hsc_yop], ";
                $queryUpdate.="hsc_yoj = $_POST[hsc_yoj], ";
                $queryUpdate.="hsc_board_total = $_POST[hsc_board_total], ";
                $queryUpdate.="hsc_board_secure = $_POST[hsc_board_secured], ";
                $queryUpdate.="hsc_total = $_POST[hsc_total], ";
                $queryUpdate.="hsc_secure = $_POST[hsc_secured], ";
                $queryUpdate.="hsc_distance = '".mysql_real_escape_string($_POST[hsc_distance])."', ";
        }else
            {
                $queryUpdate.="hsc_school = 'NA', ";
				$queryUpdate.="hsc_board = 'NA', ";
                $queryUpdate.="hsc_state = 'NA', ";
                $queryUpdate.="hsc_yop = 0, ";
                $queryUpdate.="hsc_yoj = 0, ";
                $queryUpdate.="hsc_board_total = 0, ";
                $queryUpdate.="hsc_board_secure = 0, ";
                $queryUpdate.="hsc_total = 0, ";
                $queryUpdate.="hsc_secure = 0, ";
                $queryUpdate.="hsc_distance = 'NA', ";
        }
        if(isset($_POST['dip_done']) && !empty($_POST['dip_done']) && $_POST['dip_done']=='dip')
            {
                $queryUpdate.="dip_school = '".mysql_real_escape_string($_POST[dip_school])."', ";
				$queryUpdate.="dip_board = '".mysql_real_escape_string($_POST[dip_board])."', ";
                if($_POST[dip_state]!="Other")
                    $queryUpdate.="dip_state = '".mysql_real_escape_string($_POST[dip_state])."', ";
                else
                    $queryUpdate.="dip_state = '".mysql_real_escape_string($_POST[dip_state_other])."', ";
                $queryUpdate.="dip_yop = $_POST[dip_yop], ";
                $queryUpdate.="dip_yoj = $_POST[dip_yoj], ";
                $queryUpdate.="dip_board_total = $_POST[dip_board_total], ";
                $queryUpdate.="dip_board_secure = $_POST[dip_board_secured], ";
                $queryUpdate.="dip_total = $_POST[dip_total], ";
                $queryUpdate.="dip_secure = $_POST[dip_secured], ";
                $queryUpdate.="dip_distance = '".mysql_real_escape_string($_POST[dip_distance])."', ";
                
        }else
            {
                $queryUpdate.="dip_school = 'NA', ";
				$queryUpdate.="dip_board = 'NA', ";
                $queryUpdate.="dip_state = 'NA', ";
                $queryUpdate.="dip_yop = 0, ";
                $queryUpdate.="dip_yoj = 0, ";
                $queryUpdate.="dip_board_total = 0, ";
                $queryUpdate.="dip_board_secure = 0, ";
                $queryUpdate.="dip_total = 0, ";
                $queryUpdate.="dip_secure = 0, ";
                $queryUpdate.="dip_distance = 'NA', ";
                
        }
        if(isset($_POST['gra_done']) && !empty($_POST['gra_done']) && $_POST['gra_done']=='gra')
            {
                $queryUpdate.="gra_school = '".mysql_real_escape_string($_POST[gra_school])."', ";
				$queryUpdate.="gra_board = '".mysql_real_escape_string($_POST[gra_board])."', ";
                if($_POST[gra_state]!="Other")
                    $queryUpdate.="gra_state = '".mysql_real_escape_string($_POST[gra_state])."', ";
                else
                    $queryUpdate.="gra_state = '".mysql_real_escape_string($_POST[gra_state_other])."', ";
                $queryUpdate.="gra_yop = $_POST[gra_yop], ";
                $queryUpdate.="gra_yoj = $_POST[gra_yoj], ";
                $queryUpdate.="gra_board_total = $_POST[gra_board_total], ";
                $queryUpdate.="gra_board_secure = $_POST[gra_board_secured], ";
                $queryUpdate.="gra_total = $_POST[gra_total], ";
                $queryUpdate.="gra_secure = $_POST[gra_secured], ";
                $queryUpdate.="gra_distance = '".mysql_real_escape_string($_POST[gra_distance])."', ";
                $queryUpdate.="gra_stream = '".mysql_real_escape_string($_POST[gra_stream])."', ";
                $queryUpdate.="gra_honors = '".mysql_real_escape_string($_POST[gra_honours])."', ";
        }else
            {
                $queryUpdate.="gra_school = 'NA', ";
				$queryUpdate.="gra_board = 'NA', ";
                $queryUpdate.="gra_state = 'NA', ";
                $queryUpdate.="gra_yop = 0, ";
                $queryUpdate.="gra_yoj = 0, ";
                $queryUpdate.="gra_board_total = 0, ";
                $queryUpdate.="gra_board_secure = 0, ";
                $queryUpdate.="gra_total = 0, ";
                $queryUpdate.="gra_secure = 0, ";
                $queryUpdate.="gra_distance = 'NA', ";
                $queryUpdate.="gra_stream = 'NA', ";
                $queryUpdate.="gra_honors = 'NA', ";
        }
if(isset($_POST['ssc_done']) && $_POST['ssc_done']=='ssc' && isset($_POST['hsc_done']) && $_POST['hsc_done']=='hsc'){
 $gap_10_12 = $_POST['hsc_yoj'] - $_POST['ssc_yop'];
}else{
 $gap_10_12 = 0;
}
if(isset($_POST['ssc_done']) && $_POST['ssc_done']=='ssc' && isset($_POST['dip_done']) && $_POST['dip_done']=='dip'){
  $gap_10_dip = $_POST['dip_yoj'] - $_POST['ssc_yop'];
}else{
  $gap_10_dip = 0;
}
if(isset($_POST['hsc_done']) && $_POST['hsc_done']=='hsc' && isset($_POST['gra_done']) && $_POST['gra_done']=='gra'){
  $gap_12_gra = $_POST['gra_yoj'] - $_POST['hsc_yop'];
}else{
  if(isset($_POST['hsc_done']) && $_POST['hsc_done']=='hsc')
    $gap_12_gra = $yearJoin - $_POST['hsc_yop'];
  else
    $gap_12_gra = 0;
}
if(isset($_POST['dip_done']) && $_POST['dip_done']=='dip' && isset($_POST['gra_done']) && $_POST['gra_done']=='gra'){
  $gap_dip_gra = $_POST['gra_yoj'] - $_POST['dip_yop'];
}else{
  if(isset($_POST['dip_done']) && $_POST['dip_done']=='dip')
    $gap_dip_gra = $yearJoin - $_POST['dip_yop'];
  else
    $gap_dip_gra = 0;
}
if(isset($_POST['gra_done']) && $_POST['gra_done']=='gra'){
    $gap_gra_pg = $yearJoin - $_POST['gra_yop'];
}else{
    $gap_gra_pg = 0;
}
$queryUpdate.="gap_10_12=$gap_10_12, gap_10_dip=$gap_10_dip, gap_12_gra=$gap_12_gra, gap_dip_gra=$gap_dip_gra, gap_gra_pg=$gap_gra_pg,";
     }
     else
         {
       
             if(isset($_POST['ssc_school']) && !empty($_POST['ssc_school']))
                $queryUpdate.="ssc_school = '".mysql_real_escape_string($_POST[ssc_school])."', ";
			 if(isset($_POST['ssc_board']) && !empty($_POST['ssc_board']))
                $queryUpdate.="ssc_board = '".mysql_real_escape_string($_POST[ssc_board])."', ";
             if($_POST['ssc_state']!='Select'){
                 if($_POST[ssc_state]!="Other")
                    $queryUpdate.="ssc_state = '".mysql_real_escape_string($_POST[ssc_state])."', ";
                else
                    $queryUpdate.="ssc_state = '".mysql_real_escape_string($_POST[ssc_state_other])."', ";
             }
                //$queryUpdate.="ssc_state = '".mysql_real_escape_string($_POST[ssc_state])."', ";
             if($_POST['ssc_yop']!='Select')
                $queryUpdate.="ssc_yop = '$_POST[ssc_yop]', ";
             if(isset($_POST['ssc_board_total']) && !empty($_POST['ssc_board_total']))
                $queryUpdate.="ssc_board_total = '$_POST[ssc_board_total]', ";
             if(isset($_POST['ssc_board_secured']) && !empty($_POST['ssc_board_secured']))
                $queryUpdate.="ssc_board_secure = '$_POST[ssc_board_secured]', ";
             if(isset($_POST['ssc_total']) && !empty($_POST['ssc_total']))
                $queryUpdate.="ssc_total = '$_POST[ssc_total]', ";
             if(isset($_POST['ssc_secured']) && !empty($_POST['ssc_secured']))
                $queryUpdate.="ssc_secure = '$_POST[ssc_secured]', ";
             if($_POST['ssc_distance'] != 'Select')
                $queryUpdate.="ssc_distance = '$_POST[ssc_distance]', ";
             if(isset($_POST['ssc_board_per']) && !empty($_POST['ssc_board_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['ssc_board_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['ssc_board_per']*$factor;
                 $queryUpdate.="ssc_board_total = '$total', ssc_board_secure = '$obtained', ";
             }
             if(isset($_POST['ssc_per']) && !empty($_POST['ssc_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['ssc_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['ssc_per']*$factor;
                 $queryUpdate.="ssc_total = '$total', ssc_secure = '$obtained', ";
             }
             
             
			 if(isset($_POST['hsc_school']) && !empty($_POST['hsc_school']))
                $queryUpdate.="hsc_school = '".mysql_real_escape_string($_POST[hsc_school])."', ";
             if(isset($_POST['hsc_board']) && !empty($_POST['hsc_board']))
                $queryUpdate.="hsc_board = '".mysql_real_escape_string($_POST[hsc_board])."', ";
             if($_POST['hsc_state']!='Select'){
                 if($_POST[hsc_state]!="Other")
                    $queryUpdate.="hsc_state = '".mysql_real_escape_string($_POST[hsc_state])."', ";
                else
                    $queryUpdate.="hsc_state = '".mysql_real_escape_string($_POST[hsc_state_other])."', ";
             }
                //$queryUpdate.="hsc_state = '".mysql_real_escape_string($_POST[hsc_state])."', ";
             if($_POST['hsc_yoj']!='Select')
                $queryUpdate.="hsc_yoj = '$_POST[hsc_yoj]', ";
             if($_POST['hsc_yop']!='Select')
                $queryUpdate.="hsc_yop = '$_POST[hsc_yop]', ";
             if(isset($_POST['hsc_board_total']) && !empty($_POST['hsc_board_total']))
                $queryUpdate.="hsc_board_total = '$_POST[hsc_board_total]', ";
             if(isset($_POST['hsc_board_secured']) && !empty($_POST['hsc_board_secured']))
                $queryUpdate.="hsc_board_secure = '$_POST[hsc_board_secured]', ";
             if(isset($_POST['hsc_total']) && !empty($_POST['hsc_total']))
                $queryUpdate.="hsc_total = '$_POST[hsc_total]', ";
             if(isset($_POST['hsc_secured']) && !empty($_POST['hsc_secured']))
                $queryUpdate.="hsc_secure = '$_POST[hsc_secured]', ";
             if($_POST['hsc_distance'] != 'Select')
                $queryUpdate.="hsc_distance = '$_POST[hsc_distance]', ";
             if(isset($_POST['hsc_board_per']) && !empty($_POST['hsc_board_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['hsc_board_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['hsc_board_per']*$factor;
                 $queryUpdate.="hsc_board_total = '$total', hsc_board_secure = '$obtained', ";
             }
             if(isset($_POST['hsc_per']) && !empty($_POST['hsc_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['hsc_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['hsc_per']*$factor;
                 $queryUpdate.="hsc_total = '$total', hsc_secure = '$obtained', ";
             }
             
             
			 
			 if(isset($_POST['dip_school']) && !empty($_POST['dip_school']))
                $queryUpdate.="dip_school = '".mysql_real_escape_string($_POST[dip_school])."', ";       
             if(isset($_POST['dip_board']) && !empty($_POST['dip_board']))
                $queryUpdate.="dip_board = '".mysql_real_escape_string($_POST[dip_board])."', ";
             if($_POST['dip_state']!='Select'){
                 if($_POST[dip_state]!="Other")
                    $queryUpdate.="dip_state = '".mysql_real_escape_string($_POST[dip_state])."', ";
                else
                    $queryUpdate.="dip_state = '".mysql_real_escape_string($_POST[dip_state_other])."', ";
             }
                //$queryUpdate.="dip_state = '".mysql_real_escape_string($_POST[dip_state])."', ";
             if($_POST['dip_yoj']!='Select')
                $queryUpdate.="dip_yoj = '$_POST[dip_yoj]', ";
             if($_POST['dip_yop']!='Select')
                $queryUpdate.="dip_yop = '$_POST[dip_yop]', ";
             if(isset($_POST['dip_board_total']) && !empty($_POST['dip_board_total']))
                $queryUpdate.="dip_board_total = '$_POST[dip_board_total]', ";
             if(isset($_POST['dip_board_secured']) && !empty($_POST['dip_board_secured']))
                $queryUpdate.="dip_board_secure = '$_POST[dip_board_secured]', ";
             if(isset($_POST['dip_total']) && !empty($_POST['dip_total']))
                $queryUpdate.="dip_total = '$_POST[dip_total]', ";
             if(isset($_POST['dip_secured']) && !empty($_POST['dip_secured']))
                $queryUpdate.="dip_secure = '$_POST[dip_secured]', ";
             if($_POST['dip_distance'] != 'Select')
                $queryUpdate.="dip_distance = '$_POST[dip_distance]', ";
             if(isset($_POST['dip_board_per']) && !empty($_POST['dip_board_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['dip_board_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['dip_board_per']*$factor;
                 $queryUpdate.="dip_board_total = '$total', dip_board_secure = '$obtained', ";
             }
             if(isset($_POST['dip_per']) && !empty($_POST['dip_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['dip_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['dip_per']*$factor;
                 $queryUpdate.="dip_total = '$total', dip_secure = '$obtained', ";
             }
   
             
			 
			 if(isset($_POST['gra_school']) && !empty($_POST['gra_school']))
                $queryUpdate.="gra_school = '".mysql_real_escape_string($_POST[gra_school])."', ";
             if(isset($_POST['gra_board']) && !empty($_POST['gra_board']))
                $queryUpdate.="gra_board = '".mysql_real_escape_string($_POST[gra_board])."', ";
             if($_POST['gra_state']!='Select'){
                 if($_POST[gra_state]!="Other")
                    $queryUpdate.="gra_state = '".mysql_real_escape_string($_POST[gra_state])."', ";
                else
                    $queryUpdate.="gra_state = '".mysql_real_escape_string($_POST[gra_state_other])."', ";
             }
                //$queryUpdate.="gra_state = '".mysql_real_escape_string($_POST[gra_state])."', ";
             if($_POST['gra_yoj']!='Select')
                $queryUpdate.="gra_yoj = '$_POST[gra_yoj]', ";
             if($_POST['gra_yop']!='Select')
                $queryUpdate.="gra_yop = '$_POST[gra_yop]', ";
             if(isset($_POST['gra_stream']) && !empty($_POST['gra_stream']))
                $queryUpdate.="gra_stream = '".mysql_real_escape_string($_POST[gra_stream])."', ";
             if(isset($_POST['gra_honours']) && !empty($_POST['gra_honours']))
                $queryUpdate.="gra_honors = '".mysql_real_escape_string($_POST[gra_honours])."', ";
             if(isset($_POST['gra_board_total']) && !empty($_POST['gra_board_total']))
                $queryUpdate.="gra_board_total = '$_POST[gra_board_total]', ";
             if(isset($_POST['gra_board_secured']) && !empty($_POST['gra_board_secured']))
                $queryUpdate.="gra_board_secure = '$_POST[gra_board_secured]', ";
             if(isset($_POST['gra_total']) && !empty($_POST['gra_total']))
                $queryUpdate.="gra_total = '$_POST[gra_total]', ";
             if(isset($_POST['gra_secured']) && !empty($_POST['gra_secured']))
                $queryUpdate.="gra_secure = '$_POST[gra_secured]', ";
             if($_POST['gra_distance'] != 'Select')
                $queryUpdate.="gra_distance = '$_POST[gra_distance]', ";
             if(isset($_POST['gra_board_per']) && !empty($_POST['gra_board_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['gra_board_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['gra_board_per']*$factor;
                 $queryUpdate.="gra_board_total = '$total', gra_board_secure = '$obtained', ";
             }
             if(isset($_POST['gra_per']) && !empty($_POST['gra_per'])){
                 $factor=pow(10,(int)(strlen(substr(strrchr($_POST['gra_per'], "."), 1))));
                 $total=$factor*100;
                 $obtained=$_POST['gra_per']*$factor;
                 $queryUpdate.="gra_total = '$total', gra_secure = '$obtained', ";
             }
             
            
            if(isset($_POST['gap_10_12']) && (!empty($_POST['gap_10_12']) || $_POST['gap_10_12']=='0'))
                $queryUpdate.="gap_10_12 = '".mysql_real_escape_string($_POST[gap_10_12])."', ";
            if(isset($_POST['gap_10_dip']) && (!empty($_POST['gap_10_dip']) || $_POST['gap_10_dip']=='0'))
                $queryUpdate.="gap_10_dip = '".mysql_real_escape_string($_POST[gap_10_dip])."', ";
            if(isset($_POST['gap_12_gra']) && (!empty($_POST['gap_12_gra']) || $_POST['gap_12_gra']=='0'))
                $queryUpdate.="gap_12_gra = '".mysql_real_escape_string($_POST[gap_12_gra])."', ";
            if(isset($_POST['gap_dip_gra']) && (!empty($_POST['gap_dip_gra']) || $_POST['gap_dip_gra']=='0'))
                $queryUpdate.="gap_dip_gra = '".mysql_real_escape_string($_POST[gap_dip_gra])."', ";
            if(isset($_POST['gap_gra_pg']) && (!empty($_POST['gap_gra_pg']) || $_POST['gap_gra_pg']=='0'))
                $queryUpdate.="gap_gra_pg = '".mysql_real_escape_string($_POST[gap_gra_pg])."', ";
     }
        if($_POST['branch'] != 'Select'){
                $queryUpdate.="branch = '$_POST[branch]', ";
                $branch=mysql_real_escape_string($_POST['branch']);
        }else{
            $branch=mysql_real_escape_string($_POST['branch_status']);
        }
        if($_POST['stream'] != 'Select'){
                $queryUpdate.="stream = '$_POST[stream]', ";
                $stream = mysql_real_escape_string($_POST['stream']);
        }else{
            $stream=mysql_real_escape_string($_POST['stream_status']);
        }
        if($_POST['lateral_entry'] != 'Select'){
                $queryUpdate.="lateral = '$_POST[lateral_entry]', ";
                $lateralEntry = $_POST['lateral_entry'];
        }else{
            $lateralEntry = $_POST['lateral_status'];
        }
        if(isset($_POST['edit_current']) && !empty($_POST['edit_current'])){
            
        if($lateralEntry == 'yes'){
            $queryUpdate.="sgpa_1 = 0.00, ";
            $queryUpdate.="sgpa_2 = 0.00, ";
            $queryUpdate.="cgpa_1 = 0.00, ";
            $queryUpdate.="cgpa_2 = 0.00, ";
            $queryUpdate.="back_1 = 0, ";
            $queryUpdate.="back_2 = 0, ";
        }else{
            $queryUpdate.="sgpa_1 = '$_POST[sgpa_1]', ";
            $queryUpdate.="sgpa_2 = '$_POST[sgpa_2]', ";
            $queryUpdate.="cgpa_1 = '$_POST[cgpa_1]', ";
            $queryUpdate.="cgpa_2 = '$_POST[cgpa_2]', ";
            $queryUpdate.="back_1 = '$_POST[backlog_1]', ";
            $queryUpdate.="back_2 = '$_POST[backlog_2]', ";
        }
	$queryUpdate.="sgpa_3 = '$_POST[sgpa_3]', ";
        $queryUpdate.="sgpa_4 = '$_POST[sgpa_4]', ";
        $queryUpdate.="sgpa_5 = '$_POST[sgpa_5]', ";
        $queryUpdate.="sgpa_6 = '$_POST[sgpa_6]', ";
        $queryUpdate.="cgpa_3 = '$_POST[cgpa_3]', ";
        $queryUpdate.="cgpa_4 = '$_POST[cgpa_4]', ";
        $queryUpdate.="cgpa_5 = '$_POST[cgpa_5]', ";
        $queryUpdate.="cgpa_6 = '$_POST[cgpa_6]', ";
        $queryUpdate.="back_3 = '$_POST[backlog_3]', ";
        $queryUpdate.="back_4 = '$_POST[backlog_4]', ";
        $queryUpdate.="back_5 = '$_POST[backlog_5]', ";
        $queryUpdate.="back_6 = '$_POST[backlog_6]', ";
        if($stream == 'M.Tech' || $stream == 'MCA'){
            $queryUpdate.="sgpa_7 = 0.00, ";
            $queryUpdate.="sgpa_8 = 0.00, ";
            $queryUpdate.="sgpa_9 = 0.00, ";
            $queryUpdate.="sgpa_10 = 0.00, ";
            $queryUpdate.="cgpa_7 = 0.00, ";
            $queryUpdate.="cgpa_8 = 0.00, ";
            $queryUpdate.="cgpa_9 = 0.00, ";
            $queryUpdate.="cgpa_10 = 0.00, ";
            $queryUpdate.="back_7 = 0, ";
            $queryUpdate.="back_8 = 0, ";
            $queryUpdate.="back_9 = 0, ";
            $queryUpdate.="back_10 = 0, ";
        }else{
            $queryUpdate.="sgpa_7 = '$_POST[sgpa_7]', ";
            $queryUpdate.="sgpa_8 = '$_POST[sgpa_8]', ";
            $queryUpdate.="cgpa_7 = '$_POST[cgpa_7]', ";
            $queryUpdate.="cgpa_8 = '$_POST[cgpa_8]', ";
            $queryUpdate.="back_7 = '$_POST[backlog_7]', ";
            $queryUpdate.="back_8 = '$_POST[backlog_8]', ";
            
            if($stream == 'B.Tech'){
                $queryUpdate.="sgpa_9 = 0.00, ";
                $queryUpdate.="sgpa_10 = 0.00, ";
                $queryUpdate.="cgpa_9 = 0.00, ";
                $queryUpdate.="cgpa_10 = 0.00, ";
                $queryUpdate.="back_9 = 0, ";
                $queryUpdate.="back_10 = 0, ";
            }else{
                $queryUpdate.="sgpa_9 = '$_POST[sgpa_9]', ";
                $queryUpdate.="sgpa_10 = '$_POST[sgpa_10]', ";
                $queryUpdate.="cgpa_9 = '$_POST[cgpa_9]', ";
                $queryUpdate.="cgpa_10 = '$_POST[cgpa_10]', ";
                $queryUpdate.="back_9 = '$_POST[backlog_9]', ";
                $queryUpdate.="back_10 = '$_POST[backlog_10]', ";
            }
        }
        }
        
        if(isset($_POST['gap_reason']) && !empty($_POST['gap_reason']))
                $queryUpdate.="gap_reason = '".mysql_real_escape_string($_POST[gap_reason])."', ";
        if(isset($_POST['hobby']) && !empty($_POST['hobby']))
                $queryUpdate.="hobby = '".mysql_real_escape_string($_POST[hobby])."', ";
        if(isset($_POST['pro1_name']) && !empty($_POST['pro1_name']))
                $queryUpdate.="pro_name = '".mysql_real_escape_string($_POST[pro1_name])."', ";
        if(isset($_POST['pro1_dur']) && !empty($_POST['pro1_dur']))
                $queryUpdate.="pro_duration = '".mysql_real_escape_string($_POST[pro1_dur])."', ";
        if(isset($_POST['pro1_guide']) && !empty($_POST['pro1_guide']))
                $queryUpdate.="pro_guide = '".mysql_real_escape_string($_POST[pro1_guide])."', ";
        if(isset($_POST['pro1_sum']) && !empty($_POST['pro1_sum']))
                $queryUpdate.="pro_summary = '".mysql_real_escape_string($_POST[pro1_sum])."', ";
        if(isset($_POST['pro1_org']) && !empty($_POST['pro1_org']))
                $queryUpdate.="pro_org = '".mysql_real_escape_string($_POST[pro1_org])."', ";
        if($_POST['pref'] != 'Select')
                $queryUpdate.="preference = '".mysql_real_escape_string($_POST[pref])."', ";
        
        
        $certification="";
        for($counter=0;$counter<sizeof($_POST['cert']);$counter++){
            $certification.=mysql_real_escape_string($_POST['cert'][$counter]."?");
        }
        if($certification!="??????????")
            $queryUpdate.="certification = '$certification', ";
        
        $finalUpdateQuery="update tbl_student set ".$queryUpdate." roll_no=$rollnoNew where roll_no=$rollno";
        //echo $finalUpdateQuery;
        $finalUpdateRes=  mysql_query($finalUpdateQuery);
        $yearGapUpdateQuery="No year gap calculation done";
        if($finalUpdateRes){
            if($_POST['ssc_yop']!="Select" || ($_POST['hsc_yop'])!="Select" || ($_POST['hsc_yoj'])!="Select" || ($_POST['dip_yop'])!="Select" || ($_POST['dip_yoj'])!="Select" || ($_POST['gra_yop'])!="Select" || ($_POST['gra_yoj'])!="Select" || ($_POST['yearjoin'])!="Select"){
            $yearGapUpdateQuery="UPDATE `tbl_student` 
                                 SET
                                 `gap_10_12`=if(`ssc_board`!='NA' AND `hsc_board`!='NA',`hsc_yoj`-`ssc_yop`,0),
                                 `gap_10_dip`=if(`ssc_board`!='NA' AND `dip_board`!='NA',`dip_yoj`-`ssc_yop`,0),
                                 `gap_12_gra`=if(`hsc_board`!='NA' AND `gra_board`!='NA',`gra_yoj`-`hsc_yop`,if(`hsc_board`!='NA',`year_join`-`hsc_yop`,0)),
                                 `gap_dip_gra`=if(`dip_board`!='NA' AND `gra_board`!='NA',`gra_yoj`-`dip_yop`,if(`dip_board`!='NA',`year_join`-`dip_yop`,0)),
                                 `gap_gra_pg`=if(`gra_board`!='NA',`year_join`-`gra_yop`,0) 
                                 WHERE roll_no=$rollnoNew
                                 ";
            $yearGapUpdateRes=  mysql_query($yearGapUpdateQuery);
          }
        $timeStamp=  date("d-M-Y G:i:s");
        $task=$_SESSION['userName']." executed the query $finalUpdateQuery";
        file_put_contents ( $_SESSION['userName'].date("d-M-Y").".txt" , $timeStamp." ".$task."\n", FILE_APPEND );
        $_SESSION['ErrMsg']="<script>alert('Information has been updated ".$errFile."')</script>";
        }
        else
            $_SESSION['ErrMsg']="<script>alert('Error occurred. Please try again')</script>";
    }
}
?>
<form action="verifyCandidate.php" method="post">
<table align="center">
<tr>
<td>Enter Roll No:</td>
<td><input type="text" name="rollno" onkeypress="return isNumberKey(event)" ></td>
</tr>
<tr>
    <td colspan="2"> OR </td>
</tr>
<tr>
<td>Enter the Name of the Student</td>
<td><input type="text" name="stu_name"  /></td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnsubmit" value="Submit"></td>
</tr>
</table>
</form>
<?php
if(isset($_REQUEST['btnsubmit']) && !empty($_REQUEST['btnsubmit']) && $_REQUEST['btnsubmit']=='Submit')
{
        
	$rollno=  mysql_real_escape_string($_REQUEST['rollno']);
        $studentName=mysql_real_escape_string($_REQUEST['stu_name']);
        $querySelect="";
        if(!empty($rollno))
            $querySelect.="and roll_no like '%$rollno%'";
        if(!empty($studentName))
            $querySelect.="and name like '%$studentName%'";
        $sql="select * from tbl_student where 1 ".$querySelect;
        //echo $sql;
	$res=mysql_query($sql);
//	$rows=mysql_num_rows($res);
	 if(mysql_num_rows($res)==1)
	{
          $row=mysql_fetch_array($res);
          // calculation of percentage
          
          if($row['ssc_board_total']!=0)
            $sscBoardPer=round(($row['ssc_board_secure']/$row['ssc_board_total'])*100,2);          
        else
            $sscBoardPer=0;
        if($row['ssc_total']!=0)
            $sscPer=round(($row['ssc_secure']/$row['ssc_total'])*100,2);
        else
            $sscPer=0;
        
        if($row['hsc_board_total']!=0)
            $hscBoardPer=round(($row['hsc_board_secure']/$row['hsc_board_total'])*100,2);
        else
            $hscBoardPer=0;
        if($row['hsc_total']!=0)            
            $hscPer=round(($row['hsc_secure']/$row['hsc_total'])*100,2);
        else
            $hscPer=0;
        
        if($row['dip_board_total']!=0)
        $dipBoardPer=round(($row['dip_board_secure']/$row['dip_board_total'])*100,2);
        else
            $dipBoardPer=0;
        if($row['dip_total']!=0)
        $dipPer=round(($row['dip_secure']/$row['dip_total'])*100,2);
        else
            $dipPer=0;
        
        if($row['gra_board_total']!=0)
            $graBoardPer=round(($row['gra_board_secure']/$row['gra_board_total'])*100,2);
        else
            $graBoardPer=0;
        if($row['gra_total']!=0)
            $graPer=round(($row['gra_secure']/$row['gra_total'])*100,2);
        else
            $graPer=0;
          
          $completedQualification="";
            if($row['ssc_board'] != 'NA' && $row['hsc_board'] != 'NA'){
                $completedQualification.="SSC, HSC, ";
            }
            if($row['ssc_board'] != 'NA' && $row['dip_board'] != 'NA'){
                if(strpos($completedQualification, 'SSC' ) == true)
                    $completedQualification.="DIPLOMA, ";
                else
                    $completedQualification.="SSC, DIPLOMA, ";
            }
            if($row['gra_board'] != 'NA'){
                $completedQualification.="GRADUATION, ";
            }
?>
<script type="text/javascript">

function chkCorresAddress(id){
	if(document.getElementById(id).checked==true){
		document.getElementById("corres_add_1").value=document.getElementById("permanent_add_1").value;
		document.getElementById("corres_add_1").readOnly=true;
	    document.getElementById("corres_add_2").value=document.getElementById("permanent_add_2").value;
		document.getElementById("corres_add_2").readOnly=true;
		document.getElementById("corres_add_city").value=document.getElementById("permanent_add_city").value;
		document.getElementById("corres_add_city").readOnly=true;
		document.getElementById("corres_add_State").value=document.getElementById("permanent_add_State").value;
		document.getElementById("corres_add_State").readOnly=true;
		document.getElementById("corres_add_pin").value=document.getElementById("permanent_add_pin").value;	
		document.getElementById("corres_add_pin").readOnly=true;
		}
	else if(document.getElementById(id).checked==false){
		document.getElementById("corres_add_1").value="";
		document.getElementById("corres_add_1").readOnly=false;
	    document.getElementById("corres_add_2").value="";
		document.getElementById("corres_add_2").readOnly=false;
		document.getElementById("corres_add_city").value="";
		document.getElementById("corres_add_city").readOnly=false;
		document.getElementById("corres_add_State").readOnly="";
		document.getElementById("corres_add_State").readOnly=false;
		document.getElementById("corres_add_pin").value="";	
		document.getElementById("corres_add_pin").readOnly=false;
		}
	}

    
function isEditing(c){
    //alert(c.checked);
    if(c.checked == true){
        for(var i=1;i<=10;i++){
            document.getElementById("sgpa_"+i).disabled="";
            document.getElementById("cgpa_"+i).disabled="";
            document.getElementById("backlog_"+i).disabled="";
    }
    }else{
        for(var i=1;i<=10;i++){
            document.getElementById("sgpa_"+i).disabled="disabled";
            document.getElementById("cgpa_"+i).disabled="disabled";
            document.getElementById("backlog_"+i).disabled="disabled";
        }
    }
}

function infoDisplay(c){
    if(c.value=='Other Information'){
        document.getElementById("otherInfo").style.display='block';
        document.getElementById("personalInfo").style.display='none';
        document.getElementById("academicInfo").style.display='none';
        document.getElementById("placementInfo").style.display='none';
    }
    else if(c.value=='Certification Information'){
        document.getElementById("otherInfo").style.display='none';
        document.getElementById("personalInfo").style.display='none';
        document.getElementById("academicInfo").style.display='none';
        document.getElementById("placementInfo").style.display='block';
    }
    else if(c.value=='Personal Information'){
        document.getElementById("otherInfo").style.display='none';
        document.getElementById("personalInfo").style.display='block';
        document.getElementById("academicInfo").style.display='none';
        document.getElementById("placementInfo").style.display='none';
    }
    else if(c.value=='Academic Information'){
        document.getElementById("otherInfo").style.display='none';
        document.getElementById("personalInfo").style.display='none';
        document.getElementById("academicInfo").style.display='block';
        document.getElementById("placementInfo").style.display='none';
    }
        
}

function otherOptionNri(c){
    var enterOther=c.name+"_other";
    var obj=document.getElementById(enterOther);
    if(c.value=="Other"){
        obj.innerHTML="Change to <input type='text' name='"+enterOther+"' />";
    }else{
        obj.innerHTML="";
    }
}

function getConfirmation(){
    var submitChange=window.confirm("Do you wish to make the changes permanent to the database?");
    return submitChange;
}

function setValidStream(c, d) {
        var xmlhttp;
        if (c.value == 'Select')
        {
            document.getElementById(d).innerHTML = "Please select a Stream";
            return;
        }
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                document.getElementById(d).innerHTML = "<select name='branch'>" + xmlhttp.responseText + "</select>";
            }
        }
        xmlhttp.open("GET", "../inc/branchList.php?id=" + c.value, true);
        xmlhttp.send();
    }
</script>
<style>
    span.dropt { background: #ffeedd;}
    span.dropt:hover {text-decoration: none; background: #ffffff; z-index: 6; }
    span.dropt span {position: absolute; left: -9999px;margin: 20px 0 0 0px; padding: 3px 3px 3px 3px; border-color:black; border-width:1px; z-index: 6;}
    span.dropt:hover span {left: 2%; background: #ffffff;} 
    span.dropt span {position: absolute; left: -9999px;margin: 4px 0 0 0px; padding: 3px 3px 3px 3px; border-color:black; border-width:1px;}
    span.dropt:hover span {margin: 20px 0 0 170px; background: #ffffff; z-index:6;} 
</style>

<form method="post" action="" enctype="multipart/form-data" onsubmit="return getConfirmation()">
            <input type="hidden" name="roll_no" value="<?php echo $rollno; ?>" />
            <input type="hidden" name="ssc_council" value="<?php echo $row['ssc_board'] ?>" />
            <input type="hidden" name="hsc_council" value="<?php echo $row['hsc_board'] ?>" />
            <input type="hidden" name="dip_council" value="<?php echo $row['dip_board'] ?>" />
            <input type="hidden" name="gra_council" value="<?php echo $row['gra_board'] ?>" />
            <input type="hidden" name="lateral_status" value="<?php echo $row['lateral'] ?>" />
            <input type="hidden" name="stream_status" value="<?php echo $row['stream'] ?>" />
            <input type="hidden" name="branch_status" value="<?php echo $row['branch'] ?>" />
            <input type="hidden" name="year_join" value="<?php echo $row['year_join'] ?>" />
            <table align="center" width="1000" border="0" style="display: block">
                <tr>
                    <td>Select Information to be Displayed:</td>
                    <td><select name="info_type" id="infoType" onchange="return infoDisplay(this);">
    <option>Personal Information</option>
    <option>Academic Information</option>
    <option>Other Information</option>
    <option>Certification Information</option>
</select></td>
                </tr>
                <tr>
                    <td>Select an Action</td>
                    <td><input type="radio" name="action" value="Update" checked="checked" /> Update
                        <input type="radio" name="action" value="Delete" /> Delete</td>
                </tr>
                <tr>
                    <td>Select the Status</td>
                    <td><span class="dropt"><input type="radio" name="status" value="Pending" checked="checked" />Pending<span style="width:500px;"><b>Pending</b> status implies that the data pertaining to the student has not yet been verified by any of the T&P Officials</span></span>
                        <span class="dropt"> <input type="radio" name="status" value="Updated" />Updated<span style="width:500px;"><b>Updated</b> status implies that the data pertaining to the student has been correctly updated by a T&P Official, but all the documents were not produced in original and hence, the data could not be verified</span></span>
                        <span class="dropt"><input type="radio" name="status" value="Approved" />Approved<span style="width:500px;"><b>Approved</b> status implies that the data pertaining to the student has been correctly updated as well as verified against original documents by a T&P Official</span></span>
                        <span class="dropt"><input type="radio" name="status" value="Created" />Created<span style="width:500px;"><b>Created</b> status implies that the student has not yet registered(entered his information) with the T&P portal</span></span></td>
                </tr>
                <tr>
                    <td colspan="2"><input type="submit" name="btn_action" value="Perform Selected Action" /></td>
                </tr>
            </table>
 
      <table align="center" width="1000" border="0" id="personalInfo" style="display: block">
        <tr>
        <td colspan="3" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Personal Detail</font></td>
        </tr>
         <tr>
            <td>Rollno:</td>
            <td  align="left"><?php echo $row['roll_no'] ?> </td>
            <td  align="left">Change to <input type="text" name="txtroll" value="" size="25"  onkeypress="return isNumberKey(event)"   /></td>
        </tr>
        <tr>
            <td>Current Profile Status</td>
            <td  align="left"><?php echo $row['status'] ?> </td>
            <td  align="left">&nbsp;</td>
        </tr>
        <tr>
            <td>Name:</td>
            <td><?php echo $row['name'] ?></td>
            <td>Change to <input type="text" name="name" size="25" value=""    /></td>
        </tr>
        <tr>
            <td>Stream:</td>
            <td><?php $selectStream=$row['stream']; echo $row['stream']; ?></td>
            <td width='400'>Change To<select name="stream" onchange="setValidStream(this, 'branchPlaceHolder');">
                    <option><?php echo $row['stream'];?></option>
                    <option value="B.Tech">B.Tech</option>               
                    <option value="M.Tech">M.Tech</option>
                    <option value="MCA">MCA</option>
                    <option value="Dual Degree B.Tech and M.Tech">Dual Degree-B.Tech + M.Tech</option>
                    <option value="Dual Degree B.Tech and MBA">Dual Degree-B.Tech + MBA</option>
                </select></td>
        </tr>
        <tr>
            <td width='200'>Select Branch</td>
            <td><?php echo $row['branch'] ?></td>
            <td id='branchPlaceHolder'  width='400'>Change To<select name='branch'><option><?php echo $row['branch'] ?></option></select></td>
        </tr>
        <tr>
            <td>Lateral Entry:</td>
            <td><?php echo $row['lateral'] ?></td>
            <td>Change to <select name="lateral_entry" >
                    <option>Select</option>			
                                    <option>yes</option>
                                    <option>no</option>
                       </select></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><?php echo $row['year_join'] ?></td>
            <td>Change to  <select name="yearjoin" >
                                    <option>Select</option>
                                    <?php include '../inc/yearList.php';?></select></td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><?php echo $row['year_passout'] ?></td>
            <td>Change to
                <select name="yearpass">
                                    <option>Select</option>
                                    <?php include '../inc/yearList.php';?></select>
            </td>
        </tr>
        <tr>
            <td>Boarding:</td>
            <td><?php echo $row['boarding'] ?></td>
            <td>Change to 
            <select name="boarding">
                                    <option>Select</option>
                                    <option>Hostel</option>
                                    <option>Day Scholar</option>
                                </select></td>
        </tr>
        <tr>
            <td>Category</td>
            <td><?php echo $row['category'] ?></td>
            <td> Change to  <select name="category">
                                    <option>Select</option>
                                    <option>General</option>
                                    <option>OBC</option>
                                    <option>Minority</option>
                                    <option>PH</option>
                                    <option>SC</option>
                                    <option>ST</option>
                                    <option>GC</option>
                                    <option>NRI</option>
                </select></td>
        </tr>
        <tr>
            <td>Gender</td>
            <td><?php echo $row['gender'] ?></td>
            <td>Change to <select name="gender">
                                    <option>Select</option>
                                    <option>Male</option>
                                    <option>Female</option></select></td>           
        </tr>
        <tr>
            <td>DoB</td>
            <td><?php echo date("d-M-y",strtotime($row['dob'])) ?></td>
            <td>Change to <script type="text/javascript">DateInput('dob', true, 'YYYY-MM-DD')</script></td>
        </tr>
        <tr>
            <td>Permanent Contact Number</td>
            <td><?php echo $row['mobile_perm'] ?></td>
            <td>Change to <input type="text" name="permanent_contact" size="25" value=""  onkeypress="return isNumberKey(event)"  /></td>
        </tr>
        <!--<tr>
            <td>Photo</td>
            <td><img src="<?php echo $row['image']; ?>" height="90" width="110" /></td>
            <td><input type="file" name="img" /></td>
        </tr>-->
        <tr>
            <td align="left">Mobile Number(Self)</td>
            <td><?php echo $row['mobile'] ?></td>
            <td>Change to <input type="text" name="txtmobile" size="25" value=""   onkeypress="return isNumberKey(event)"  /></td>
        </tr>
        <tr>
            <td>e-Mail ID (Self)</td>
            <td><?php echo $row['alt_email'] ?></td>
            <td>Change to <input type="text" name="txtaltemail" size="25" value=""  /></td>
        </tr>
        <tr>
            <td align="left">Father's Name:</td>
            <td><?php echo $row['father_name'] ?></td>
            <td>Change to <input type="text" name="txtfhname" size="25" value=""   /></td>
        </tr>
        <tr>
            <td align="left">Father's Mobile Number</td>
            <td><?php echo $row['father_mobile'] ?></td>
            <td>Change to <input type="text" name="txtfhmobile" size="25" value=""   onkeypress="return isNumberKey(event)"  /></td>
        </tr>
        <tr>
            <td>Father's e-Mail ID</td>
            <td><?php echo $row['father_email'] ?></td>
            <td>Change to <input type="text" name="txtfemail" size="25" value=""  /></td>
        </tr>
        <tr valign="middle">
            <td align="left" valign="top">Occupation with:</td>
            <td><?php echo $row['father_org'] ?></td>
            <td>Change to <input type="text" name="father_industry" size="25" value=""  /></td>
        </tr>
        <tr valign="middle">
            <td><b><u>Designation & Address</u></b></td>
        </tr>
        <?php
        if($row['father_add']!=""){
			?>
			<tr>
                <td>Designation Address</td>
                <td><?php echo $row['father_add'] ?></td>
                <td>Change to <textarea name="father_post" cols="38" rows="8"></textarea></td>
            </tr>
			<?php
			}else{
				?>
			<tr>
            <td>Line 1</td>
            <td><?php echo $row['father_add_1'] ?></td>
            <td>Change to <input type="text" name="father_add_1"></td>
        </tr>
        <tr>
            <td>Line 2</td>
            <td><?php echo $row['father_add_2'] ?></td>
            <td>Change to <input type="text" name="father_add_2"></td>
        </tr>
        <tr>
            <td>City</td>
            <td><?php echo $row['father_add_city'] ?></td>
            <td>Change to <input type="text" name="father_add_city"></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['father_add_state'] ?></td>
            <td>Change to <input type="text" name="father_add_state"></td>
        </tr>
        <tr>
            <td>Pin</td>
            <td><?php echo $row['father_add_pin'] ?></td>
            <td>Change to <input type="text" name="father_add_pin"></td>
        </tr>
			<?php
				
				}
		?>
        <!---->
        
        
        <tr valign="middle">
            <td align="left"><b><u>Permanent Address</u></b></td>
        </tr>
        <?php
        if($row['permanent_address']!=""){
			?>
			<tr>
                <td>Designation Address</td>
                <td><?php echo $row['permanent_address'] ?></td>
                <td>Change to <textarea name="txtpermadd" cols="38" rows="8"></textarea></td>
            </tr>
			<?php
			}else{
				?>
			<tr>
            <td>Line 1</td>
            <td><?php echo $row['permanent_add_1'] ?></td>
            <td>Change to <input type="text" name="permanent_add_1" id="permanent_add_1"></td>
        </tr>
        <tr>
            <td>Line 2</td>
            <td><?php echo $row['permanent_add_2'] ?></td>
            <td>Change to <input type="text" name="permanent_add_2" id="permanent_add_2"></td>
        </tr>
        <tr>
            <td>City</td>
            <td><?php echo $row['permanent_add_city'] ?></td>
            <td>Change to <input type="text" name="permanent_add_city" id="permanent_add_city"></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['permanent_add_state'] ?></td>
            <td>Change to <input type="text" name="permanent_add_state" id="permanent_add_State"></td>
        </tr>
        <tr>
            <td>Pin</td>
            <td><?php echo $row['permanent_add_pin'] ?></td>
            <td>Change to <input type="text" name="permanent_add_pin" id="permanent_add_pin"></td>
        </tr>
			<?php
				
				}
		?>
        <!---->
        
        
        <tr valign="middle">
            <td align="left"><b><u>Correspondence Address</u></b></td>
        </tr>
        
        <?php
        if($row['corres_address']!=""){
			?>
			<tr>
                <td>Designation Address</td>
                <td><?php echo $row['corres_address'] ?></td>
                <td>Change to <textarea name="txtcorresadd" cols="38" rows="8"></textarea></td>
            </tr>
			<?php
			}else{
				?>
            <tr align="center">
            <td colspan="3"><input type="checkbox" id="chkField" onchange="chkCorresAddress(this.id)">Same as Permanent Address</td>
            </tr>
			<tr>
            <td>Line 1</td>
            <td><?php echo $row['corres_add_1'] ?></td>
            <td>Change to <input type="text" name="corres_add_1" id="corres_add_1"></td>
        </tr>
        <tr>
            <td>Line 2</td>
            <td><?php echo $row['corres_add_2'] ?></td>
            <td>Change to <input type="text" name="corres_add_2" id="corres_add_2"></td>
        </tr>
        <tr>
            <td>City</td>
            <td><?php echo $row['corres_add_city'] ?></td>
            <td>Change to <input type="text" name="corres_add_city" id="corres_add_city"></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['corres_add_state'] ?></td>
            <td>Change to <input type="text" name="corres_add_state" id="corres_add_State"></td>
        </tr>
        <tr>
            <td>Pin</td>
            <td><?php echo $row['corres_add_pin'] ?></td>
            <td>Change to <input type="text" name="corres_add_pin" id="corres_add_pin"></td>
        </tr>
			<?php
				
				}
		?>
        <!---->
        
        
        </table>
        <table align="center" width="1000" border="0" id="academicInfo"  style="display: none">           
        <tr>
        <td colspan="3" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Academic Detail</font></td>
        </tr>
        <tr>
            <td>
                Completed Academic Qualifications
            </td>
            <td>
                <?php echo $completedQualification; ?>
            </td>
            <td>
                Change to
                <input type="checkbox" value="ssc" name="ssc_done" onclick="alert('Please make sure to update the corresponding Academic Details as well otherwise, it would result into inconsistency')"/>10<sup>th</sup>
                <input type="checkbox" value="hsc" name="hsc_done" onclick="alert('Please make sure to update the corresponding Academic Details as well otherwise, it would result into inconsistency')"/>12<sup>th</sup>
                <input type="checkbox" value="dip" name="dip_done" onclick="alert('Please make sure to update the corresponding Academic Details as well otherwise, it would result into inconsistency')"/>Diploma
                <input type="checkbox" value="gra" name="gra_done" onclick="alert('Please make sure to update the corresponding Academic Details as well otherwise, it would result into inconsistency')"/>Graduation
            </td>
        </tr>
        <tr>
        <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">10<sup>th</sup> (SSC)</font></td>
        </tr>
        <tr>
            <td>School Name</td>
            <td><?php echo $row['ssc_school'] ?></td>
            <td>Change to <input type="text" name="ssc_school" value=""  /></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><?php echo $row['ssc_board'] ?></td>
            <td>Change to <input type="text" name="ssc_board" value=""  /></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['ssc_state'] ?></td>
            <td>Change to <select name="ssc_state" onchange="otherOptionNri(this);"><?php include '../inc/stateList.php'; ?></select><br />
                <span id="ssc_state_other"></span></td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><?php echo $row['ssc_yop'] ?></td>
            <td>Change to <select name="ssc_yop" >
                            <option>Select</option>
                            <?php include '../inc/yearList.php';?>
                        </select></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><?php echo $row['ssc_distance'] ?></td>
            <td>Change to <select name="ssc_distance">
                    <option>Select</option>
                    <option>Yes</option>
                    <option>No</option>
                    <option>Improvement</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="3">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['ssc_board_secure']." / ";echo $row['ssc_board_total'] ?></td>
            <td>Change to<br /> Total Marks<input type="text" name="ssc_board_total" value="" size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="ssc_board_secured" value="" size="5"  onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['ssc_board_secure']/$row['ssc_board_total'])*100, 2); ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="ssc_board_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>
        <tr>
            <td colspan="3">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['ssc_secure']." / ";echo $row['ssc_total'] ?></td>
            <td>Change to <br />Total Marks<input type="text" name="ssc_total" value=""  size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="ssc_secured" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['ssc_secure']/$row['ssc_total'])*100, 2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="ssc_per" value="" size="5" onkeypress="return isNumberKey(event)" /> </td>
        </tr>        
        <tr>
        <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">12<sup>th</sup> (HSC)</font></td>
        </tr>
        <tr>
            <td>School/College Name</td>
            <td><?php echo $row['hsc_school'] ?></td>
            <td>Change to <input type="text" name="hsc_school" value=""  /></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><?php echo $row['hsc_board'] ?></td>
            <td>Change to <input type="text" name="hsc_board" value=""  /></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['hsc_state'] ?></td>
            <td>Change to <select name="hsc_state"  onchange="otherOptionNri(this);"><?php include '../inc/stateList.php'; ?></select><br />
                <span id="hsc_state_other"></span></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><?php echo $row['hsc_yoj'] ?></td>
            <td>Change to <select name="hsc_yoj">
                    <option>Select</option>
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
        </tr>
        <tr>
            <td>Year of Passing</td>
            <td><?php echo $row['hsc_yop'] ?></td>
            <td>Change to <select name="hsc_yop">
                    <option>Select</option>
                            <?php include '../inc/yearList.php';?>
                        </select></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><?php echo $row['hsc_distance'] ?></td>
            <td>Change to <select name="hsc_distance">
                    <option>Select</option>
                    <option>Yes</option>
                    <option>No</option>
                    <option>Improvement</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="3">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['hsc_board_secure']." / ";echo $row['hsc_board_total'] ?></td>
            <td>Change to <br />Total Marks<input type="text" name="hsc_board_total" value="" size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="hsc_board_secured" value="" size="5"  onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['hsc_board_secure']/$row['hsc_board_total'])*100, 2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="hsc_board_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>         
        <tr>
            <td colspan="3">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['hsc_secure']." / ";echo $row['hsc_total'] ?></td>
            <td>Change to<br /> Total Marks<input type="text" name="hsc_total" value=""  size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="hsc_secured" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['hsc_secure']/ $row['hsc_total'])*100,2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="hsc_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>         
        <tr>
        <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">Diploma</font></td>
        </tr>
        <tr>
            <td>School/College Name</td>
            <td><?php echo $row['dip_school'] ?></td>
            <td>Change to <input type="text" name="dip_school" value=""  /></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><?php echo $row['dip_board'] ?></td>
            <td>Change to <input type="text" name="dip_board" value=""  /></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['dip_state'] ?></td>
            <td>Change to <select name="dip_state"  onchange="otherOptionNri(this);"><?php include '../inc/stateList.php'; ?></select><br />
                <span id="dip_state_other"></span></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><?php echo $row['dip_yoj'] ?></td>
            <td>Change to <select name="dip_yoj">
                    <option>Select</option>
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
        </tr>
        
        <tr>
            <td>Year of Passing</td>
            <td><?php echo $row['dip_yop'] ?></td>
            <td>Change to <select name="dip_yop">
                    <option>Select</option>
                            <?php include '../inc/yearList.php';?>
                        </select></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><?php echo $row['dip_distance'] ?></td>
            <td>Change to <select name="dip_distance">
                    <option>Select</option>
                    <option>Yes</option>
                    <option>No</option>
                    <option>Improvement</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="3">As per Board / Council:</td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['dip_board_secure']." / ";echo $row['dip_board_total'] ?></td>
            <td>Change to<br /> Total Marks<input type="text" name="dip_board_total" value="" size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="dip_board_secured" value="" size="5"  onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['dip_board_secure']/$row['dip_board_total'])*100,2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="dip_board_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>          
        <tr>
            <td colspan="3">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['dip_secure']." / ";echo $row['dip_total'] ?></td>
            <td>Change to <br />Total Marks<input type="text" name="dip_total" value=""  size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="dip_secured" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['dip_secure']/$row['dip_total'])*100,2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="dip_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>        
        <tr>
        <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">Graduation</font></td>
        </tr>
        <tr>
            <td>School/College Name</td>
            <td><?php echo $row['gra_school'] ?></td>
            <td>Change to <input type="text" name="gra_school" value=""  /></td>
        </tr>
        <tr>
            <td>Board / Council</td>
            <td><?php echo $row['gra_board'] ?></td>
            <td>Change to <input type="text" name="gra_board" value=""  /></td>
        </tr>
        <tr>
            <td>State</td>
            <td><?php echo $row['gra_state'] ?></td>
            <td>Change to <select name="gra_state"  onchange="otherOptionNri(this);"><?php include '../inc/stateList.php'; ?></select><br />
                <span id="gra_state_other"></span></td>
        </tr>
        <tr>
            <td>Year of Joining</td>
            <td><?php echo $row['gra_yoj'] ?></td>
            <td>Change to <select name="gra_yoj">
                    <option>Select</option>
                            <?php include '../inc/yearList.php';?>
                        </select>
            </td>
        </tr>
        
        <tr>
            <td>Year of Passing</td>
            <td><?php echo $row['gra_yop'] ?></td>
            <td>Change to <select name="gra_yop">
                    <option>Select</option>
                           <?php include '../inc/yearList.php';?>
                        </select></td>
        </tr>
        <tr>
            <td>Passed from a Distance Course</td>
            <td><?php echo $row['gra_distance'] ?></td>
            <td>Change to <select name="gra_distance">
                    <option>Select</option>
                    <option>Yes</option>
                    <option>No</option>
                    <option>Improvement</option>
                </select>
            </td>
        </tr>
        <tr>
            <td>Stream:</td>
            <td><?php echo $row['gra_stream'] ?></td>
            <td>Change to <input type="text" name="gra_stream" value=""   /></td>
        </tr>
        <tr>
            <td>Honours:</td>
            <td><?php echo $row['gra_honors'] ?></td>
            <td>Change to <input type="text" name="gra_honours" value=""  /></td>
        </tr>
        <tr>
            <td colspan="3">As per Board / Council:</td>
        </tr>
        <tr>
           <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['gra_board_secure']." / ";echo $row['gra_board_total'] ?></td>
            <td>Change to <br />Total Marks<input type="text" name="gra_board_total" value="" size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="gra_board_secured" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['gra_board_secure']/$row['gra_board_total'])*100,2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="gra_board_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr> 
        <tr>
            <td colspan="3">
                All the subjects appeared(including optional & extra optional):
            </td>
        </tr>
        <tr>
            <td>Marks Secured / Total Marks</td>
            <td><?php echo $row['gra_secure']." / ";echo $row['gra_total'] ?></td>
            <td>Change to <br />Total Marks<input type="text" name="gra_total" value=""  size="5" onkeypress="return isNumberKey(event)" /> 
                Marks Secured<input type="text" name="gra_secured" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
        </tr>
        <tr>
            <td>Percentage</td>
            <td><?php echo round(($row['gra_secure']/$row['gra_total'])*100,2) ?></td>
            <td>Change to &nbsp;&nbsp;<input type="text" name="gra_per" value="" size="5" onkeypress="return isNumberKey(event)"  /></td>
        </tr>        
        <tr>
           <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">Current Course(B.Tech / MCA / M.Tech)</font></td>
        </tr>
        <tr>
            <td colspan="3">
                <input type="checkbox" name="edit_current" value="Edit" onchange="return isEditing(this)"/>Enable editing
                <table>
                    <tr>
                        <td>Semester</td>
                        <td>1<sup>st</sup></td>
                        <td>2<sup>nd</sup></td>
                        <td>3<sup>rd</sup></td>
                        <td>4<sup>th</sup></td>
                        <td>5<sup>th</sup></td>
                        <td>6<sup>th</sup></td>
                        <td>7<sup>th</sup></td>
                        <td>8<sup>th</sup></td>
                        <td>9<sup>th</sup></td>
                        <td>10<sup>th</sup></td>
                    </tr>
                    <tr>
                        <td>SGPA</td>
                        <td><input type="text" name="sgpa_1" id="sgpa_1" value="<?php echo $row['sgpa_1'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_2" id="sgpa_2" value="<?php echo $row['sgpa_2'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_3" id="sgpa_3" value="<?php echo $row['sgpa_3'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_4" id="sgpa_4" value="<?php echo $row['sgpa_4'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_5" id="sgpa_5" value="<?php echo $row['sgpa_5'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_6" id="sgpa_6" value="<?php echo $row['sgpa_6'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_7" id="sgpa_7" value="<?php echo $row['sgpa_7'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_8" id="sgpa_8" value="<?php echo $row['sgpa_8'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_9" id="sgpa_9" value="<?php echo $row['sgpa_9'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="sgpa_10" id="sgpa_10" value="<?php echo $row['sgpa_10'] ?>" size="5"  disabled="disabled"  onkeypress="return isNumberKey(event)" /></td>
                    </tr>
                    <tr>
                        <td>CGPA</td>
                        <td><input type="text" name="cgpa_1" id="cgpa_1" value="<?php echo $row['cgpa_1'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_2" id="cgpa_2" value="<?php echo $row['cgpa_2'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_3" id="cgpa_3" value="<?php echo $row['cgpa_3'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_4" id="cgpa_4" value="<?php echo $row['cgpa_4'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_5" id="cgpa_5" value="<?php echo $row['cgpa_5'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_6" id="cgpa_6" value="<?php echo $row['cgpa_6'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_7" id="cgpa_7" value="<?php echo $row['cgpa_7'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_8" id="cgpa_8" value="<?php echo $row['cgpa_8'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_9" id="cgpa_9" value="<?php echo $row['cgpa_9'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="cgpa_10" id="cgpa_10" value="<?php echo $row['cgpa_10'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                    </tr>
                    <tr>
                        <td>No. Of Backlogs</td>
                        <td><input type="text" name="backlog_1" id="backlog_1" value="<?php echo $row['back_1'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_2" id="backlog_2" value="<?php echo $row['back_2'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_3" id="backlog_3" value="<?php echo $row['back_3'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_4" id="backlog_4" value="<?php echo $row['back_4'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_5" id="backlog_5" value="<?php echo $row['back_5'] ?>" size="5" disabled="disabled"  onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_6" id="backlog_6" value="<?php echo $row['back_6'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_7" id="backlog_7" value="<?php echo $row['back_7'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_8" id="backlog_8" value="<?php echo $row['back_8'] ?>" size="5"  disabled="disabled" onkeypress="return isNumberKey(event)"  /></td>
                        <td><input type="text" name="backlog_9" id="backlog_9" value="<?php echo $row['back_9'] ?>" size="5"  disabled="disabled"  onkeypress="return isNumberKey(event)" /></td>
                        <td><input type="text" name="backlog_10" id="backlog_10" value="<?php echo $row['back_10'] ?>" size="5" disabled="disabled"   onkeypress="return isNumberKey(event)" /></td>
                    </tr>      
                </table>
                </td>
         </tr>
         <tr>
           <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">Year Gap</font></td>
        </tr>
        <tr>
                        <td> No. of year gaps between 10<sup>th</sup> and 12<sup>th</sup>:</td>
                        <td><?php echo $row['gap_10_12'] ?></td>
                        <td>Change to <input type="text" name="gap_10_12" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between 10<sup>th</sup> and Diploma:</td>
                        <td><?php echo $row['gap_10_dip'] ?></td>
                        <td>Change to <input type="text" name="gap_10_dip" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between 12<sup>th</sup> and Graduation:</td>
                        <td><?php echo $row['gap_12_gra'] ?></td>
                        <td>Change to <input type="text" name="gap_12_gra" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between Diploma and Graduation:</td>
                        <td><?php echo $row['gap_dip_gra'] ?></td>
                        <td>Change to <input type="text" name="gap_dip_gra" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
                    </tr>
                    <tr>
                        <td>No. of year gaps between Graduation and PG(MCA & M.Tech):</td>
                        <td><?php echo $row['gap_gra_pg'] ?></td>
                        <td>Change to <input type="text" name="gap_gra_pg" value=""  size="5" onkeypress="return isNumberKey(event)" /></td>
                    </tr>
        <tr valign="middle">
                        <td>Reason</td>
                        <td><?php echo $row['gap_reason']; ?></td>
                        <td>Change to <br /><textarea name="gap_reason" rows="4" cols="40"  ></textarea></td>
                    </tr>
        </table>
        <table align="center" border="0" id="otherInfo" style="display: none;">
            <tr>
        <td colspan="3" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Other Detail</font></td>
        </tr>
        <tr>
           <td colspan="3" align="left" bgcolor="#237648" width="1000"><font color="#FFFFFF">Hobby</font></td>
        </tr>
        <tr valign="middle">
            <td>Hobbies</td>
            <td><?php echo $row['hobby'];  ?></td>
            <td>Change to <br /><textarea name="hobby" rows="4" cols="40"  ></textarea></td>
        </tr>
        <tr>
           <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">Project / Summer Training(Please mention all informal & formal Projects)</font></td>
        </tr>
        
                    <tr>
                        <td>Project Name</td>
                        <td><?php echo $row['pro_name']?></td>
                        <td>Change to <input type="text" name="pro1_name" value=""   /></td>
                    </tr>
                    <tr>
                        <td>Institution / Organization</td>
                        <td><?php echo $row['pro_org']?></td>
                        <td>Change to <input type="text" name="pro1_org" value=""   /></td>
                    </tr>
                    <tr>
                        <td>Duration of the Project</td>
                        <td><?php echo $row['pro_duration']?></td>
                        <td>Change to <input type="text" name="pro1_dur" value=""   /></td>
                    </tr>
                    <tr>
                        <td>Project Guide(s)</td>
                        <td><?php echo $row['pro_guide']?></td>
                        <td>Change to <input type="text" name="pro1_guide" value=""   /></td>
                    </tr>
                    <tr valign="middle">
                        <td>Project Summary</td>
                        <td><?php echo $row['pro_summary']?></td>
                        <td>Change to <br /><textarea name="pro1_sum" rows="4" cols="40"  ></textarea></td>
                    </tr>
                    
        <tr>
           <td colspan="3" align="left" bgcolor="#237648"><font color="#FFFFFF">Order of Preference</font></td>
        </tr>
        <tr>
            <td>You would give higher preference to</td>
            <td><?php echo $row['preference']; ?></td>
            <td>Change to <select name="pref">
                            <option>Select</option>
                            <option>Job</option>
                            <option>Higher Studies</option>
                        </select></td>
        </tr>
       </table>
            <?php 
            $certList=  explode("?", $row['certification']);
            $certDetail="";
            for($val=0;$val<sizeof($certList);$val++){
                if(!empty($certList[$val]))
                    $certDetail.=$certList[$val]."<br />";
            }
            ?>
       <table align="center" width="1000" border="0" id="placementInfo"  style="display: none">
           <tr>
        <td colspan="3" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Certification Detail</font></td>
        </tr>
        <tr width="1000">
            <td width="200">Certifications Done: </td>
            <td width="400"><?php echo $certDetail;?></td>
            <td width="400">Change To (Please enter the list of Certifications Done)<br />
                1. <input type="text" name="cert[]" /><br />
            2. <input type="text" name="cert[]" /><br />
            3. <input type="text" name="cert[]" /><br />
            4. <input type="text" name="cert[]" /><br />
            5. <input type="text" name="cert[]" /><br />
            6. <input type="text" name="cert[]" /><br />
            7. <input type="text" name="cert[]" /><br />
            8. <input type="text" name="cert[]" /><br />
            9. <input type="text" name="cert[]" /><br />
            10. <input type="text" name="cert[]" /><br /></td>
        </tr>
       </table>
</form>
            
            <?php 
	}
        elseif(mysql_num_rows($res)>1){
            ?>
       <table align="center" width="1000" border="0" >
        <tr>
        <td colspan="7" align="left" bgcolor="#003399"  width="1000"><font color="#FFFFFF">Student List as per the entered criteria</font></td>
        </tr>
        <tr>
            <td>Roll No</td>
            <td>Name</td>
            <td>Gender</td>
            <td>Stream</td>
            <td>Branch</td>
            <td>Joining Year</td>
            <td>Passout year</td>
        </tr>
        <?php
        while($row=mysql_fetch_array($res)){
        ?>
        <tr>
            <td><a href="verifyCandidate.php?btnsubmit=Submit&rollno=<?php echo $row['roll_no']?>&stu_name="><?php echo $row['roll_no']?></a></td>
            <td><?php echo $row['name']?></td>
            <td><?php echo $row['gender']?></td>
            <td><?php echo $row['stream']?></td>
            <td><?php echo $row['branch']?></td>
            <td><?php echo $row['year_join']?></td>
            <td><?php echo $row['year_passout']?></td>
        </tr>
        <?php } ?>
        </table>    
            <?php
        }
        else {
            $_SESSION['ErrMsg']="<script>alert('This roll number does not exist !!!')</script>";
	 
	}
}

?>

<?php
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>