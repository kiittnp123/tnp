<?php
include'../db.php';
include_once 'protectedAdmin.php';
include_once '../inc/conf.php';
$query=$_SESSION['query'];
$res=  mysql_query($query);
include_once '../excel/Classes/PHPExcel.php';
$phpExcel = new PHPExcel();
$phpExcel->createSheet();
$phpExcel->getActiveSheet()->setCellValue("A1","Company Name");
$phpExcel->getActiveSheet()->setCellValue("B1","Date Of Visit");
$phpExcel->getActiveSheet()->setCellValue("C1","Intake");
$phpExcel->getActiveSheet()->setCellValue("D1","Package");
$phpExcel->getActiveSheet()->setCellValue("E1","Eligibility");
$phpExcel->getActiveSheet()->setCellValue("F1","Academic Year");
$t=2;
while ($row= mysql_fetch_array($res)){
    
    $phpExcel->getActiveSheet()->setCellValue("A".$t,"$row[0]");
    $phpExcel->getActiveSheet()->setCellValue("B".$t,"$row[3]");
    $phpExcel->getActiveSheet()->setCellValue("C".$t,"$row[4]");
	$phpExcel->getActiveSheet()->setCellValue("D".$t,"$row[5]");
    $phpExcel->getActiveSheet()->setCellValue("E".$t,"$row[6]");
    $phpExcel->getActiveSheet()->setCellValue("F".$t,"$row[7]");
    $t++;
}

$excelWriter = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
//$excelWriter->save("schedule.xls");
header('Content-type:application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="schedule.xls"');
$excelWriter->save('php://output');

?>