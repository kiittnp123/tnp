<?php
ob_start();
include 'protectedAdmin.php';
include'../db.php';
include_once '../inc/conf.php';
?>
<script language="javascript" type="text/javascript">
    function validateDate(c){
    if(c.date.value=='Date')
	{
		alert("Date cant be left blank"); 
		
		return false;
	}
	if(c.month.value=='Month')
	{
		alert("Month cant be left blank"); 
		
		return false;
	}
	if(c.year.value=='Year')
	{
		alert("Year cant be left blank"); 
		
		return false;
	}
}
function validation()
{
	if(document.frmpublish.txtheading.value=='')
	{
		alert("Heading cant be left blank"); 
		document.frmpublish.txtheading.focus();
		return false;
	}
	if(document.frmpublish.txtcontent.value=='')
	{
		alert("Content cant be left blank"); 
		document.frmpublish.txtcontent.focus();
		return false;
	}
	if(document.frmpublish.date.value=='Date' || document.frmpublish.enddate.value=='Date')
	{
		alert("Date cant be left blank"); 
		
		return false;
	}
	if(document.frmpublish.month.value=='Month' || document.frmpublish.endmonth.value=='Month')
	{
		alert("Month cant be left blank"); 
		
		return false;
	}
	if(document.frmpublish.year.value=='Year' || document.frmpublish.endyear.value=='Year')
	{
		alert("Year cant be left blank"); 
		
		return false;
	}
}
	
</script>
    
</head>
<?php
$condition="";

if(isset($_POST['btnexpiry']) && !empty($_POST['btnexpiry']) && $_POST['btnexpiry']=='Update Status')
    {
    $id=mysql_real_escape_string($_POST['id']);
    $end_date=mysql_real_escape_string($_POST['expiry_date']);
    $status=$_POST['ddlstatus'];
    $query="update tbl_notice set end_date='$end_date',status='$status' where notice_id=$id";
    //echo $query;
    $res=  mysql_query($query);
    $_SESSION['errMsg']="<script>alert('Date Updated successfully')</script>";
    
    
}
/*If "Publish Notice" Link(publish sub-menu) is clicked then this code will be executed */

if(isset($_POST['btnpublish']) && !empty($_POST['btnpublish']) && $_POST['btnpublish']=='Publish Notice')
{
	$heading=mysql_real_escape_string($_POST['txtheading']);
	$content=nl2br(mysql_real_escape_string($_POST['txtcontent']));
	$start_date=mysql_real_escape_string($_POST['date']);
	$end_date=mysql_real_escape_string($_POST['enddate']);
	$status=mysql_real_escape_string($_POST['ddlstatus']);
        $query="insert into tbl_notice(notice_id,heading,content,start_date,end_date,status,notice_file) values(NULL,'$heading','$content','$start_date','$end_date','$status','');";
        $res=mysql_query("$query");
	$id=mysql_insert_id($con);
        //var_dump($_FILES);
	if(isset($_FILES['flupload']['name']) && !empty($_FILES['flupload']['name'])){
	if($_FILES['flupload']['type'] == 'application/pdf' ||
           $_FILES['flupload']['type'] == 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' || 
           $_FILES['flupload']['type'] == 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' || 
           $_FILES['flupload']['type'] == 'application/vnd.ms-excel' || 
           $_FILES['flupload']['type'] == 'application/vnd.ms-powerpoint' || 
           $_FILES['flupload']['type'] == 'application/msword' || 
           $_FILES['flupload']['type'] == 'image/png' ||
           $_FILES['flupload']['type'] == 'image/jpeg')
			   {
                $arr=explode(".", $_FILES['flupload']['name']);
                $ext=end($arr);
                $destination="../img/notice".$id.".".$ext;
				$res=move_uploaded_file($_FILES['flupload']['tmp_name'], $destination);
              if($res){
                  $query = "UPDATE `tbl_notice` SET `notice_file` = '$destination' WHERE `tbl_notice`.`notice_id` =$id";
                  $res=  mysql_query("$query");
                 // echo 'successfully uploaded'; 
				       $_SESSION['errMsg']="<script>alert('Notice Submitted Successfully !!!')</script>";
	                   
                      }
			   }
			   else
			   {
                                   $delNoticeQuery="delete from tbl_notice where notice_id=$id";
                                   $delNoticeRes=  mysql_query($delNoticeQuery);
				   $_SESSION['errMsg']="<script>alert('The notice content cannot be uploaded as the file format was wrong.Please upload only .pdf,.xls,.xlsx,.docx,.ppt file types')</script>";
	                   
			   }
        }else{
            $_SESSION['errMsg']="<script>alert('Notice Submitted Successfully !!!')</script>";
        }
	}

/*If "Unpublish Notice" button(unpublish sub-menu) is clicked then this code will be executed */
if(isset($_POST['btnunpublish']) && !empty($_POST['btnunpublish']) && $_POST['btnunpublish']=='Delete Notice')
{
	$i=0;
        $condition="";
        if(isset($_POST['chkbx'])){
	while($i<sizeof($_POST['chkbx']))
		{
			if($i==0)
                            $condition.=$_POST['chkbx'][$i];
			else
                            $condition.=",".$_POST['chkbx'][$i];
                        $imagePath=$_POST['image'.$_POST['chkbx'][$i]];
                        if(!empty($imagePath))
                            unlink($imagePath);
			$i++;
		}
	$sqlupdate="delete from tbl_notice where notice_id IN (".$condition.")";
        //echo $sqlupdate;
	$update=mysql_query("$sqlupdate");
	$rows=mysql_affected_rows($con);
	$_SESSION['errMsg']="<script>alert('".$rows." Notice Deleted Successfully !!')</script>";
        }else{
            $_SESSION['errMsg']="<script>alert('Please select atleast one notice to delete')</script>";
        }
                 }
if(isset($_POST['btnupdate']) && !empty($_POST['btnupdate']) && $_POST['btnupdate']=='Update Notice')
{
	$i=0;
        if(isset($_POST['updateid'])){
        $id=mysql_real_escape_string($_POST['updateid']);
?>
    <form method="post" action="" onsubmit="return validateDate(this)">
        <input type="hidden" name="id" value="<?php echo $id ?>" />
        Select The new Expiry Date:
        <script type="text/javascript">DateInput('expiry_date', true, 'YYYY-MM-DD')</script><br /><br />
        Select The new Status: <select name="ddlstatus">
                            <option>Protected</option>
                            <option>Open to All</option></select><br /><br />
                        <input type="submit" name="btnexpiry" value="Update Status"/>
    </form>
            
<?php
        }else{
            $_SESSION['errMsg']="<script>alert('Please select a notice to update')</script>";
        }
}
/* If any of the sub-menu links are clicked, then the following part of the code gets executed */
if(isset($_GET['notice']) && !empty($_GET['notice']))
{
	/* If any "Publish Notice" link is clicked then the following part of code gets executed */
	if($_GET['notice']=="p")
	{ 
		$sql="select max(notice_id)+1 from tbl_notice";
		$res=mysql_query("$sql");
		while($data=mysql_fetch_array($res))
		{
		  $rol=$data[0];
		}
	?>    				
            <form name="frmpublish" id="frmpublish" method="post" onsubmit="return validation()"  enctype="multipart/form-data">
            <table bgcolor="#E5E5E5" align="center" width="700">
			<tr>			
			<td width="530" colspan="4" align="center" bgcolor="#000033" valign="top"><font color="#FFFFFF"><b>ADD NOTICE</b></font></td>
			</tr>
			<tr>			
            <td>Notice Id:</td>
			<td colspan="3"><input type="text" name="txtnid" value="<?php echo $rol ?>" readonly="readonly" style="width:420px"/></td>
			</tr>
			<tr>			
			<td>Headings:</td>
            <td colspan="3"><input type="text" name="txtheading" style="width:420px"/></td>
			</tr>
            <tr>
            <td>Content:</td>
            <td colspan="3"><textarea name="txtcontent" rows="5" cols="50"></textarea></td>
            </tr>
            <tr>           
            <td>Start Date:</td>
            <td>
            		<script type="text/javascript">DateInput('date', true, 'YYYY-MM-DD')</script></td>
                 <td>End Date:</td>
            <td>
            	<script type="text/javascript">DateInput('enddate', true, 'YYYY-MM-DD')</script>
            </td>  
            </tr>
             <tr>
            <td>Upload File</td>
            <td><input type="file" name="flupload" /></td>
            </tr>
            <tr>          
            <td>Status</td>
            <td><select name="ddlstatus">
                            <option>Protected</option>
                            <option>Open to All</option></select></td>
            </tr>
            <tr>
            <td colspan="4" align="center"><input type="submit" name="btnpublish" value="Publish Notice" /></td>
            </tr>
			</table></form>
				
	<?php 	
	}
	/* If "Unpublish News" link is clicked then the following part of code gets executed */
	else if($_GET['notice']=='u')
	{
			$sqlunpublish="select * from tbl_notice";
			$unpublishnotice=mysql_query("$sqlunpublish");
                        $rows=mysql_num_rows($unpublishnotice);
			//echo $rows;
			if($rows){
			echo "<form name='unpublish' id='unpublish' method='post'>
                            <table border='1' align='center'  bgcolor='#E5E5E5' width='700'>
                                <tr bgcolor='#000033'>
                                    <td></td>
                                    <td align='center' width='100'><font color='#FFFFFF'><b>Heading</b></font></td>
                                    <td align='center'><font color='#FFFFFF'><b>Content</b></font></td>
                                </tr>";
			while($notice2=mysql_fetch_array($unpublishnotice))
			{ ?>  <input type="hidden" name="image<?php echo $notice2[0] ;?>" value="<?php echo $notice2['notice_file'] ;?>" />
                            <tr>
                                <td width="30" align="center"><input type="checkbox" name="chkbx[]" value="<?php echo $notice2[0] ?>" /></td>
                                <td><?php echo $notice2[1]; ?></td>
                                <td><?php echo $notice2[2]; ?></td>
                             </tr>
			<?php }		        
                            echo "<tr>
                                    <td colspan='3' align='center'><input type='submit' name='btnunpublish' value='Delete Notice'/></td>
                                 </tr>
                              </table></form>";
                        }else
			{
				$_SESSION['errMsg']="<script>alert('No Notice Found !!!')</script>";
	 				
			}	
	}
        else if($_GET['notice']=='e')
            {
                        $sqlunpublish="select * from tbl_notice";
			//echo $sqlunpublish;
			$unpublishnews=mysql_query("$sqlunpublish");
			
			$rows=mysql_num_rows($unpublishnews);
			//echo $rows;
			if($rows)
			{
                            echo "<form name='update' id='update' method='post'>
                            <table border='1' align='center'  bgcolor='#E5E5E5' width='700'>
                            <tr bgcolor='#000033'>
                            <td></td>
                            <td align='center' width='100'><font color='#FFFFFF'><b>Heading</b></font></td>
                            <td align='center'><font color='#FFFFFF'><b>Content</b></font></td>
                            </tr>";
			while($news2=mysql_fetch_array($unpublishnews))
			{ ?>
				<tr><td width="30" align="center"><input type="radio" name="updateid" value="<?php echo $news2[0] ?>" /></td>
                	<td><?php echo $news2[1]; ?></td>
                    <td><?php echo $news2[2]; ?></td></tr>
			<?php }
            echo "<tr>
                <td colspan='3' align='center'><input type='submit' name='btnupdate' value='Update Notice'/></td>
                </tr>
                </table>
                </form>";
			}
			else
			{
				$_SESSION['errMsg']="<script>alert('No Notice Found !!!')</script>";
	 				
			}
        }
	/* If any change in url is done forciblly the following part of code gets executed */
	else
	{
		echo "PAGE NOT FOUND.";
	}
}else
	{
		//echo "PAGE NOT FOUND.";
	}


$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['errMsg']) && !empty($_SESSION['errMsg']))
{
	echo $_SESSION['errMsg'];
	unset ($_SESSION['errMsg']);
}

?>
