<?php
include 'protectedAdmin.php';
include_once '../db.php';
include_once '../inc/conf.php';
ob_start();
?>
<!--
<table align="center" bgcolor="#DFDFDF" width="900">
    <tr>
        <td colspan="4" align="center"><h1>Messages / Feedbacks</h1></td>
    </tr>
    <tr bgcolor="#000099">
        <td style="color: #FFFFFF">Name</td>
        <td style="color: #FFFFFF">Mobile</td>
        <td style="color: #FFFFFF">E-Mail</td>
        <td style="color: #FFFFFF">Message</td>
    </tr>
    <?php
    /*
    $msgQuery = "select * from tbl_feedback order by feedback_date desc limit 0,5";
    $msgRes = mysql_query($msgQuery);
    $evenRow = 0;
    while ($msgRow = mysql_fetch_array($msgRes)) {
        ?>
        <tr <?php if ($evenRow % 2 == 0) {echo "bgcolor='white'";} ?>>
            <td style="word-wrap:break-word;"><?php echo $msgRow['name'] ?></td>
            <td style="word-wrap:break-word;"><?php echo $msgRow['mobile'] ?></td>
            <td style="word-wrap:break-word;"><?php echo $msgRow['email'] ?></td>
            <td style="word-wrap:break-word;"><?php echo $msgRow['message'] ?></td>
        </tr>
        <?php
        $evenRow++;
    }
     */
    ?>
</table>-->
<span>Welcome</span> 
<?php
$content = ob_get_contents();
ob_clean();
include'template.php';
?>