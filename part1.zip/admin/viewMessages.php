<?php
include 'protectedAdmin.php';
include_once '../inc/conf.php';
include_once '../db.php';
ob_start();
if(isset($_POST['message_date'])){
    $dateMessage=$_POST['message_date'];
?>
<table align="center" bgcolor="#DFDFDF" width="900" cellspacing="5" cellpadding="5">
    <tr>
        <td colspan="4" align="center"><h1>Messages / Feedbacks</h1></td>
    </tr>
    <tr bgcolor="#000099">
        <td style="color: #FFFFFF">Name</td>
        <td style="color: #FFFFFF">Mobile</td>
        <td style="color: #FFFFFF">E-Mail</td>
        <td style="color: #FFFFFF">Message</td>
    </tr>
<?php
$msgQuery="select * from tbl_feedback where feedback_date='$dateMessage' ";
$msgRes=  mysql_query($msgQuery);
if(mysql_num_rows($msgRes)>0){
    $evenRow=0;
while($msgRow=  mysql_fetch_array($msgRes)){
    ?>
        <tr <?php if($evenRow%2 == 0){echo "bgcolor='white'";}?>>
        <td style="word-wrap:break-word;"><?php echo $msgRow['name'] ?></td>
        <td style="word-wrap:break-word;"><?php echo $msgRow['mobile'] ?></td>
        <td style="word-wrap:break-word;"><?php echo $msgRow['email'] ?></td>
        <td style="word-wrap:break-word;"><?php echo $msgRow['message'] ?></td>
        </tr>
     <?php
     $evenRow++;
}
}else{
    ?>
        <tr>
        <td style="word-wrap:break-word;" colspan="4">No messages found for the date selection</td>
    </tr> 
     <?php
}

?>
</table>
<?php
}else{
    ?>
<form method="post" action="">
<table align="center" bgcolor="#DFDFDF" width="900" cellspacing="5" cellpadding="5">
    <tr>
        <td align="center">Select the Date</td>
        <td><script type="text/javascript">DateInput('message_date', true, 'YYYY-MM-DD');</script></td>
    </tr>
    <tr>
        <td colspan="2"><input type="submit" value="View Messages" /></td>
    </tr>
</table>
</form>
     <?php
}
$content=ob_get_contents();
ob_clean();
include'template.php';
?>