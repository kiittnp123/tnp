<?php
//session_start();
include 'protectedAdmin.php';
include_once '../inc/conf.php';
ob_start();
include'../db.php';
?>
<script type="text/javascript">
function validateFormData(c){
    if(c.txtyear.value=='Select'){
        alert('Please select an academic year');
        return false;
    }
}
</script>    
<?php
if(isset($_POST['btnupdate']) && !empty($_POST['btnupdate']) && $_POST['btnupdate']=='UPDATE')
{
 $scheduleId=mysql_real_escape_string($_POST['txt_schedule_id']);
 if($_POST['date']!='Date' && $_POST['month']!='Month' && $_POST['year']!='Year')
    $datevisit=mysql_real_escape_string($_POST['year'])."-".mysql_real_escape_string($_POST['month'])."-".mysql_real_escape_string($_POST['date']);
 else
    $datevisit=mysql_real_escape_string($_POST['txtdate']);
 if($_POST['end_date']!='Date' && $_POST['end_month']!='Month' && $_POST['end_year']!='Year')
    $endDate=mysql_real_escape_string($_POST['end_year'])."-".mysql_real_escape_string($_POST['end_month'])."-".mysql_real_escape_string($_POST['end_date']);
 else
    $endDate=mysql_real_escape_string($_POST['txtenddate']);
 $intake=mysql_real_escape_string($_POST['txtintake']);
 $package=mysql_real_escape_string($_POST['txtpackage']);
 $eligibility=mysql_real_escape_string($_POST['txteligiblty']);
 if($_POST['txtyear']!='Select')
    $academic_year=mysql_real_escape_string($_POST['txtyear']);
 else
     $academic_year=mysql_real_escape_string($_POST['txtyearold']);
 $profile=mysql_real_escape_string($_POST['txtprofile']);
 $ageLimit=mysql_real_escape_string($_POST['age_limit']);
 $totalStu=mysql_real_escape_string($_POST['total_stu']);
 $procedure=mysql_real_escape_string($_POST['procedure']);
 if($_POST['type_change']=="Select")
     $driveType=mysql_real_escape_string($_POST['type']);
 else
     $driveType=mysql_real_escape_string($_POST['type_change']);
 $college=mysql_real_escape_string($_POST['college']);
  $sqlupdate="update tbl_company_schedule 
                set 
                date_visit='$datevisit',intake='$intake',package='$package',eligibility='$eligibility',academic_year='$academic_year',
                    age_limit=$ageLimit,date_end='$endDate',drive_type='$driveType',college_name='$college',profile='$profile',
                        round_list='$procedure',total_stu=$totalStu
                where schedule_id=$scheduleId";
  //echo $sqlupdate;
 $result=mysql_query($sqlupdate);
 if($result)
 {
	  $_SESSION['ErrMsg']="<script>alert('Updated..')</script>";
      
 }  else {
          $_SESSION['ErrMsg']="<script>alert('Problem Occurred')</script>";
 }
}

if(isset($_GET['task']) && !empty($_GET['task']) && isset($_GET['schid']) && !empty($_GET['schid']))
    {
    $scheduleId=mysql_real_escape_string($_GET['schid']);
    if($_GET['task']=='del')
        {
        $queryCheck="select * from tbl_company_student where schedule_id=$scheduleId";
        $resCheck=  mysql_query($queryCheck);
        if(mysql_num_rows($resCheck)==0){
            $queryDel="delete from tbl_company_schedule where schedule_id=$scheduleId";
            //echo $queryDel;
            $resDel=  mysql_query($queryDel);
            if($resDel)
                $_SESSION['ErrMsg']="<script>alert('The schedule has been deleted.')</script>";
            else
                $_SESSION['ErrMsg']="<script>alert('Some problem occurred.')</script>";
                
        }else{
            $_SESSION['ErrMsg']="<script>alert('The schedule cannot be delted as it has placement data related to it.')</script>";
        }
        
    }
    elseif ($_GET['task']=='upd') 
        {
        $sql="SELECT tbl_company.company_name, tbl_company_schedule.date_visit, tbl_company_schedule.intake, tbl_company_schedule.package, 
                    tbl_company_schedule.eligibility, tbl_company_schedule.academic_year, tbl_company.company_id, schedule_id, 
                    tbl_company_schedule.date_end, tbl_company_schedule.profile, tbl_company_schedule.age_limit, tbl_company_schedule.drive_type, 
                    tbl_company_schedule.college_name, tbl_company_schedule.round_list, tbl_company_schedule.total_stu
                    FROM tbl_company, tbl_company_schedule
                    WHERE tbl_company.company_id = tbl_company_schedule.company_id
                    AND tbl_company_schedule.schedule_id =$scheduleId";
        $res=mysql_query("$sql");
        //echo $sql;
        
?>
<form method="post" action="viewRecruitment.php">
    
<table align="center" bgcolor="#CCCCCC"  style="width:800px;">

<?php while($data=mysql_fetch_array($res))
 { ?>
    <input type="hidden" name="txt_schedule_id" value="<?php echo $data[7] ?>">
    <tr><td>Company Name</td><td><input type="text" name="txtname" value="<?php echo $data[0] ?>" readonly="readOnly"></td></tr>
     <tr><td>Company Id</td><td><input type="text" name="txtid" value="<?php echo $data[6] ?>" readonly="readOnly"></td></tr>
     <tr><td>Date of Visit</td>
         <td><input type="text" name="txtdate" value="<?php echo $data[1] ?>" readonly /> Change to 
         <select name="date">
            			<option value="Date">Date</option>
                        <option value="01">1</option>
                        <option value="02">2</option>
                        <option value="03">3</option>
                        <option value="04">4</option>
                        <option value="05">5</option>
                        <option value="06">6</option>
                        <option value="07">7</option>
                        <option value="08">8</option>
                        <option value="09">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option></select>
           		<select name="month">
                		<option value="Month">Month</option>
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">Aug</option>
                        <option value="09">Sept</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option></select>
                <select name="year">
                		<option value="Year">Year</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2017</option>
                        <option value="2020">2018</option>
                        </select></td></tr>
     <tr><td>Date of Visit End</td>
         <td><input type="text" name="txtenddate" value="<?php echo $data[8] ?>" readonly /> Change to 
         <select name="end_date">
            			<option value="Date">Date</option>
                        <option value="01">1</option>
                        <option value="02">2</option>
                        <option value="03">3</option>
                        <option value="04">4</option>
                        <option value="05">5</option>
                        <option value="06">6</option>
                        <option value="07">7</option>
                        <option value="08">8</option>
                        <option value="09">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option></select>
           		<select name="end_month">
                		<option value="Month">Month</option>
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">Aug</option>
                        <option value="09">Sept</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option></select>
                <select name="end_year">
                		<option value="Year">Year</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2017</option>
                        <option value="2020">2018</option>
                        </select></td></tr>
     <tr><td>Intake</td><td><input type="text" name="txtintake" value="<?php echo $data[2] ?>"></td></tr>
     <tr><td>Package Offered</td><td><input type="text" name="txtpackage" value="<?php echo $data[3] ?>"></td></tr>
     <tr><td>Profile Offered</td><td><input type="text" name="txtprofile" value="<?php echo $data[9] ?>"></td></tr>
     <tr><td>Eligibility</td><td><textarea name="txteligiblty" rows="10" cols="30"><?php echo $data[4] ?></textarea></td></tr>
     <tr><td>Age Limit</td><td><input type="text" name="age_limit" value="<?php echo $data[10] ?>"></td></tr>
     <tr><td>Total Eligible Students</td><td><input type="text" name="total_stu" value="<?php echo $data[14] ?>"></td></tr>
     <tr><td>Selection Procedure</td><td><textarea  name="procedure"  rows="10" cols="30"><?php echo $data[13] ?></textarea></td></tr>
     <tr><td>Type of Campus Drive</td><td><input type="text" name="type" value="<?php echo $data[11] ?>" readonly />
             Change to <select name="type_change">
            <option>Select</option>
            <option>ON CAMPUS</option>
            <option>OFF CAMPUS</option>
            <option>POOL CAMPUS</option>
        </select></td></tr>
     <tr><td>College Name(If OFF or POOL Campus)</td><td><input type="text" name="college" value="<?php echo $data[12] ?>"></td></tr>
     <tr><td>Academic Year</td><td><input type="text" name="txtyearold" value="<?php echo $data[5] ?>" readonly /> 
             Change to <select name="txtyear">
                 <option>Select</option>
        <option>2011-2012</option>
        <option>2012-2013</option>
        <option>2013-2014</option>
        <option>2014-2015</option>
        <option>2015-2016</option>
        <option>2016-2017</option>
        
        
    </select></td></tr>
	 
 <?php } ?>
  <tr>
  <td colspan="2" align="center"><input type="submit" name="btnupdate" value="UPDATE"></td>
  </tr>
 </table>
 </form>
<?php
    }
    
}else
    {
?>
<form method="post" action="viewRecruitment.php" id="form1" onsubmit="return validateFormData(this)">
    <table align='center'>
        <tr>
        <td align='center' bgcolor='#000033'><font color='#FFFFFF'>Select Academic Year:</font>
    <select name="txtyear" id="txtyear" >
        <option>Select</option>
        <option>2011-2012</option>
        <option>2012-2013</option>
        <option>2013-2014</option>
        <option>2014-2015</option>
        <option>2015-2016</option>
        <option>2016-2017</option>
    </select>
        </td>
        </tr>
        <tr>
            <td><input type="submit" value="Submit" name="btn_year" /></td>
        </tr>
    </table>
</form>    
<?php
}
if(isset($_POST['btn_year']) && !empty($_POST['btn_year']) && $_POST['btn_year']=='Submit')
    {
    $aca_year=mysql_real_escape_string($_POST['txtyear']);
    $sql="SELECT 
            tbl_company.company_name, tbl_company_schedule.* 
          FROM 
            tbl_company_schedule, tbl_company  
          where 
            tbl_company.company_id=tbl_company_schedule.company_id and  
            tbl_company_schedule.academic_year='$aca_year'";
$_SESSION['query']=$sql;
$res=mysql_query($sql);
?>
<form action="scheduleExcel.php">

<?php
if(mysql_num_rows($res)!=0)
{
    ?>
    <table align="center" bgcolor="#E5E5E5" width=70%>
<tr bgcolor="#000033">
    <td><font color="#FFFFFF">Company Name</font></td>
    <td><font color="#FFFFFF">Date of Visit</font></td>
    <td><font color="#FFFFFF">Intake</font></td>
    <td><font color="#FFFFFF">Package</font></td>
    <td><font color="#FFFFFF">Eligibility</font></td>
    <td><font color="#FFFFFF">Academic Year</font></td>
    <td><font color="#FFFFFF">Action</font></td>
</tr>
    <?php
    while($data=mysql_fetch_array($res))
    {
?>
    
<tr>
<td><?php echo $data['company_name'] ?></td>
<td><?php echo $data['date_visit'] ?></td>
<td><?php echo $data['intake'] ?></td>
<td><?php echo $data['package'] ?></td>
<td><?php echo $data['eligibility'] ?></td>
<td><?php echo $data['academic_year'] ?></td>
<td><a href="?task=del&schid=<?php echo $data['schedule_id'] ?>">Delete</a>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<a href="?task=upd&schid=<?php echo $data['schedule_id'] ?>">Update</a></td>
</tr>
<?php
    }
echo "<tr bgcolor='#000033'><td colspan='7' align='center'><input type='submit' name='btnexcel' value='Export To Excel'></td></tr></table></form>";
} else{
    $_SESSION['ErrMsg']="<script>alert('No recruitment has been scheduled for the selected Academic Year')</script>";
}

}
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>