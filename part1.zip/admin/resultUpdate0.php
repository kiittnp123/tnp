<?php
ob_start();
include 'protectedAdmin.php';
include_once '../inc/conf.php';
//$selectStream = "";
?>
<script type="text/javascript">
    function isempty()
    {
        if (document.resultform.stream.value == 'Select')
        {
            alert("Please select a stream");
            return false;
        }
        if (document.resultform.passout_year.value == 'Select')
        {
            alert("Please select the passout year of the student");
            return false;
        }
        return true;

    }

   function setValidStream(c, d) {
        var xmlhttp;
        if (c.value == 'Select')
        {
            document.getElementById(d).innerHTML = "Please select a Stream";
            return;
        }
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                document.getElementById(d).innerHTML = "<select name='branch'>" + xmlhttp.responseText + "</select>";
            }
        }
        xmlhttp.open("GET", "../inc/branchList.php?id=" + c.value, true);
        xmlhttp.send();
    }

var checkflag = "false";
function enableText(field) {
	//alert("");
  if (checkflag == "false") {
    for (i = 0; i < field.length; i++) {
      field[i].disabled = false;
    }
    checkflag = "true";
    //return "Uncheck All";
  } else {
    for (i = 0; i < field.length; i++) {
      field[i].disabled = true;
    }
    checkflag = "false";
    //return "Check All";
  }
  
  
}

function disableCheck(id){
var inputs = document.getElementsByTagName("input");
if(document.getElementById(id).checked==true){
for (var i = 0; i < inputs.length; i++){
    if (inputs[i].type == "checkbox"){
        inputs[i].disabled = true;
		document.getElementById(id).disabled=false;
               }
         }
    }else if(document.getElementById(id).checked==false){
	     for (var i = 0; i < inputs.length; i++){
		  if (inputs[i].type == "checkbox"){
			  inputs[i].disabled = false;
			  //document.getElementById(id).disabled=false;
               }
         }
	
		}
}

</script>
<form method="post" id='resultform' name="resultform" onsubmit="return isempty()">
    <table align="center" bgcolor="#E8E8E8" width='600'>
        <tr>
            <td width='200'>Select Stream</td>
            <td width='400'><select name="stream" onchange="setValidStream(this, 'branchPlaceHolder');">
                    <option>Select</option>
                    <option value="B.Tech">B.Tech</option>               
                    <option value="M.Tech">M.Tech</option>
                    <option value="MCA">MCA</option>
                    <option value="Dual Digree B.Tech and M.Tech">Dual Degree-B.Tech + M.Tech</option>
                    <option value="Dual Degree-B.Tech + MBA">Dual Degree-B.Tech + MBA</option>
                </select></td>
        </tr>
        <tr>
            <td width='200'>Select Branch</td>
            <td id='branchPlaceHolder'  width='400'></td>
        </tr>
        <tr>
            <td width='200'>Select Passout year</td>
            <td width='400'>
                <select name="passout_year">
                    <option>Select</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>2016</option>
                    <option>2017</option>
                    <option>2018</option>
                    <option>2019</option>
                    <option>2020</option>
                    <option>2021</option>
                    <option>2022</option>
                    <option>2023</option>
                    <option>2024</option>
                    <option>2025</option>
                </select>
            </td>
        </tr>
        <tr>
            <td colspan="2" align="center"><input type="submit" name="btnsubmit1" value="Submit" />
                <input type="reset" name="btnreset1" value="Reset" /></td>
        </tr>
    </table>

</form>
<style>
#resultTb thead{
	display:block;
}
#resultTb tbody{
	display:block;
	height:600px;
	overflow:auto;
}
#resultTb th:nth-child(2){
width:4.1%;
}
#resultTb th:nth-child(3){
width:18.3%;
}
#resultTb th:nth-child(4){
width:2.6%;
}
#resultTb th:nth-child(7){
width:2.6%;
}
#resultTb th:nth-child(10){
width:2.6%;
}
#resultTb th:nth-child(13){
width:2.6%;
}
#resultTb th:nth-child(16){
width:2.6%;
}
#resultTb th:nth-child(19){
width:2.6%;
}
#resultTb th:nth-child(22){
width:2.6%;
}
#resultTb th:nth-child(25){
width:2.6%;
}
#resultTb th:nth-child(28){
width:2.6%;
}
#resultTb th:nth-child(31){
width:2.6%;
}
#resultTb th:nth-child(5){
width:2.5%;
}
#resultTb th:nth-child(8){
width:2.6%;
}
#resultTb th:nth-child(11){
width:2.5%;
}
#resultTb th:nth-child(14){
width:2.5%;
}
#resultTb th:nth-child(17){
width:2.5%;
}
#resultTb th:nth-child(20){
width:2.5%;
}
#resultTb th:nth-child(23){
width:2.5%;
}
#resultTb th:nth-child(26){
width:2.5%;
}
#resultTb th:nth-child(29){
width:2.5%;
}
#resultTb th:nth-child(32){
width:2.5%;
}
</style>
<?php
include'../db.php';
if(isset($_POST['btnsubmit1'])){
	$stream = $_POST['stream'];
	//echo  $_POST['year_join'];
	$passoutYear = $_POST['passout_year'];
	$branch = $_POST['branch'];
	
	$query="SELECT `roll_no`, `name`, `sgpa_1`, `sgpa_2`, `sgpa_3`, `sgpa_4`, `sgpa_5`, `sgpa_6`, `sgpa_7`, `sgpa_8`, `sgpa_9`, `sgpa_10`, `cgpa_1`, `cgpa_2`, `cgpa_3`, `cgpa_4`, `cgpa_5`, `cgpa_6`, `cgpa_7`, `cgpa_8`, `cgpa_9`, `cgpa_10`, `back_1`, `back_2`, `back_3`, `back_4`, `back_5`, `back_6`, `back_7`, `back_8`, `back_9`, `back_10`,`branch` FROM `tbl_student` WHERE `year_passout`='$passoutYear' AND `branch`='$branch' AND `stream`='$stream'";
	
	$result=mysql_query($query);
	
	if($result){
		if(mysql_num_rows($result)>0){
			$i=1;
			//$j=1;$k=1;$l=1;$m=1;$n=1;$o=1;$p=1;$q=1;$r=1;$s=1;
			?>
            <form method="post" id="updateResultForm">
			<table border="1" id="resultTb">
			<caption style="font-size: 20px;"><?php echo $branch ."(".$stream.")";?></caption>
			<thead>
            <th>Sl No.</th>
            <th>Roll No.</th>
            <th>Name</th>
            <th>Sem1 SGPA<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)"></th>
            <th>Sem1 CGPA<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem1 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
            <th>Sem2 SGPA<input type='checkbox' id='chkall2' onChange="enableText(this.form.sem2);disableCheck(this.id)"></th>
            <th>Sem2 CGPA<!--<input type='checkbox' id='chkall2' onChange="enableText(this.form.sem2);disableCheck(this.id)">--></th>            
			<th>Sem2 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem3 SGPA<input type='checkbox' id='chkall3' onChange="enableText(this.form.sem3);disableCheck(this.id)"></th>
            <th>Sem3 CGPA<!--<input type='checkbox' id='chkall3' onChange="enableText(this.form.sem3);disableCheck(this.id)">--></th>            
			<th>Sem3 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem4 SGPA<input type='checkbox' id='chkall4' onChange="enableText(this.form.sem4);disableCheck(this.id)"></th>
            <th>Sem4 CGPA<!--<input type='checkbox' id='chkall4' onChange="enableText(this.form.sem4);disableCheck(this.id)">--></th>            
			<th>Sem4 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem5 SGPA<input type='checkbox' id='chkall5' onChange="enableText(this.form.sem5);disableCheck(this.id)"></th>
            <th>Sem5 CGPA<!--<input type='checkbox' id='chkall5' onChange="enableText(this.form.sem5);disableCheck(this.id)">--></th>            
			<th>Sem5 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem6 SGPA<input type='checkbox' id='chkall6' onChange="enableText(this.form.sem6);disableCheck(this.id)"></th>
            <th>Sem6 CGPA<!--<input type='checkbox' id='chkall6' onChange="enableText(this.form.sem6);disableCheck(this.id)">--></th>            
			<th>Sem6 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem7 SGPA<input type='checkbox' id='chkall7' onChange="enableText(this.form.sem7);disableCheck(this.id)"></th>
            <th>Sem7 CGPA<!--<input type='checkbox' id='chkall7' onChange="enableText(this.form.sem7);disableCheck(this.id)">--></th>            
			<th>Sem7 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem8 SGPA<input type='checkbox' id='chkall8' onChange="enableText(this.form.sem8);disableCheck(this.id)"></th>
            <th>Sem8 CGPA<!--<input type='checkbox' id='chkall8' onChange="enableText(this.form.sem8);disableCheck(this.id)">--></th>            
			<th>Sem8 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem9 SGPA<input type='checkbox' id='chkall9' onChange="enableText(this.form.sem9);disableCheck(this.id)"></th>
            <th>Sem9 CGPA<!--<input type='checkbox' id='chkall9' onChange="enableText(this.form.sem9);disableCheck(this.id)">--></th>            
			<th>Sem9 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>			
			<th>Sem10 SGPA<input type='checkbox' id='chkall10' onChange="enableText(this.form.sem10);disableCheck(this.id)"></th>
            <th>Sem10 CGPA<!--<input type='checkbox' id='chkall10' onChange="enableText(this.form.sem10);disableCheck(this.id)">--></th>			
			<th>Sem10 BACK<!--<input type='checkbox' id='chkall1' onChange="enableText(this.form.sem1);disableCheck(this.id)">--></th>
			</thead>
			<?php
			while($row=mysql_fetch_array($result)){
				?>
				<tr>
                    <td><?php echo $i++;?></td>
                    <td><input type="text" name="roll[]" value="<?php echo $row[0];?>" readonly size="9" style="background-color:transparent;border:none"></td>
                    <td><input type="text" name="name[]" value="<?php echo $row[1];?>" readonly size="62" style="background-color:transparent;border:none"></td>
                    <td><input type="text" id="sem1" name="sem1Sgpa[]" value="<?php echo $row[2];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem1" name="sem1Cgpa[]" value="<?php echo $row[12];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem1" name="sem1Back[]" value="<?php echo $row[22];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem2" name="sem2Sgpa[]" value="<?php echo $row[3];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem2" name="sem2Cgpa[]" value="<?php echo $row[13];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem2" name="sem2Back[]" value="<?php echo $row[23];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem3" name="sem3Sgpa[]" value="<?php echo $row[4];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem3" name="sem3Cgpa[]" value="<?php echo $row[14];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem3" name="sem3Back[]" value="<?php echo $row[24];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem4" name="sem4Sgpa[]" value="<?php echo $row[5];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem4" name="sem4Cgpa[]" value="<?php echo $row[15];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem4" name="sem4Back[]" value="<?php echo $row[25];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem5" name="sem5Sgpa[]" value="<?php echo $row[6];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem5" name="sem5Cgpa[]" value="<?php echo $row[16];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem5" name="sem5Back[]" value="<?php echo $row[26];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem6" name="sem6Sgpa[]" value="<?php echo $row[7];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem6" name="sem6Cgpa[]" value="<?php echo $row[17];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem6" name="sem6Back[]" value="<?php echo $row[27];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem7" name="sem7Sgpa[]" value="<?php echo $row[8];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem7" name="sem7Cgpa[]" value="<?php echo $row[18];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem7" name="sem7Back[]" value="<?php echo $row[28];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem8" name="sem8Sgpa[]" value="<?php echo $row[9];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem8" name="sem8Cgpa[]" value="<?php echo $row[19];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem8" name="sem8Back[]" value="<?php echo $row[29];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem9" name="sem9Sgpa[]" value="<?php echo $row[10];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem9" name="sem9Cgpa[]" value="<?php echo $row[20];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem9" name="sem9Back[]" value="<?php echo $row[30];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem10" name="sem10Sgpa[]" value="<?php echo $row[11];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
                    <td><input type="text" id="sem10" name="sem10Cgpa[]" value="<?php echo $row[21];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
					<td><input type="text" id="sem10" name="sem10Back[]" value="<?php echo $row[31];?>" size="3" disabled style="background-color:transparent;border:thin transparent solid"></td>
				</tr>
				<?php
				}
				?>
                  <tr align="center">
                      <td colspan="33">
                          <input type="submit" name="updateResult" value="Update">
                      &nbsp;&nbsp;
                          <!--<input type="reset" name="reset" value="reset">-->
                      </td>
                  </tr>
				  </table>
                  </form>
				<?php
			}else{
				echo "No Record Found !!!";
				}
		}
	}
	
	
	
/*if(isset($_POST['updateResult'])){
	//$count = count($_POST['sem1']);
	$countRoll = count($_POST['roll']);
	
	
	
	
	
	
	for($i=0; $i < $countRoll; $i++)
  {    
    
	  echo $roll = $_POST['roll'][$i];
	  echo "<br/>".$sem1=$_POST['sem1'][$i];
   
  }
	}	*/
	if(isset($_POST['updateResult']) && isset($_POST['sem1Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){ 
		$semester1Sgpa=$_POST['sem1Sgpa'][$i];
		$semester1Cgpa=$_POST['sem1Cgpa'][$i];
		$semester1Back=$_POST['sem1Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa1Query="UPDATE `tbl_student` SET `sgpa_1`='$semester1Sgpa',`cgpa_1`='$semester1Cgpa',`back_1`='$semester1Back' where `roll_no`='$roll'";
		$sgpa1Result=mysql_query($sgpa1Query);
		}if($sgpa1Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 1 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem2Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester2Sgpa=$_POST['sem2Sgpa'][$i];
		$semester2Cgpa=$_POST['sem2Cgpa'][$i];
		$semester2Back=$_POST['sem2Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa2Query="UPDATE `tbl_student` SET `sgpa_2`='$semester2Sgpa',`cgpa_2`='$semester2Cgpa',`back_2`='$semester2Back' where `roll_no`='$roll'";
		$sgpa2Result=mysql_query($sgpa2Query);
		}if($sgpa2Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 2 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem3Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester3Sgpa=$_POST['sem3Sgpa'][$i];
		$semester3Cgpa=$_POST['sem3Cgpa'][$i];
		$semester3Back=$_POST['sem3Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa3Query="UPDATE `tbl_student` SET `sgpa_3`='$semester3Sgpa',`cgpa_3`='$semester3Cgpa',`back_3`='$semester3Back' where `roll_no`='$roll'";
		$sgpa3Result=mysql_query($sgpa3Query);
		}if($sgpa3Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 3 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem4Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester4Sgpa=$_POST['sem4Sgpa'][$i];
		$semester4Cgpa=$_POST['sem4Cgpa'][$i];
		$semester4Back=$_POST['sem4Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa4Query="UPDATE `tbl_student` SET `sgpa_4`='$semester4Sgpa',`cgpa_4`='$semester4Cgpa',`back_4`='$semester4Back' where `roll_no`='$roll'";
		$sgpa4Result=mysql_query($sgpa4Query);
		}if($sgpa4Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 4 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem5Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester5Sgpa=$_POST['sem5Sgpa'][$i];
		$semester5Cgpa=$_POST['sem5Cgpa'][$i];
		$semester5Back=$_POST['sem5Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa5Query="UPDATE `tbl_student` SET `sgpa_5`='$semester5Sgpa',`cgpa_5`='$semester5Cgpa',`back_5`='$semester5Back' where `roll_no`='$roll'";
		$sgpa5Result=mysql_query($sgpa5Query);
		}if($sgpa5Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 5 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem6Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester6Sgpa=$_POST['sem6Sgpa'][$i];
		$semester6Cgpa=$_POST['sem6Cgpa'][$i];
		$semester6Back=$_POST['sem6Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa6Query="UPDATE `tbl_student` SET `sgpa_6`='$semester6Sgpa',`cgpa_6`='$semester6Cgpa',`back_6`='$semester6Back' where `roll_no`='$roll'";
		$sgpa6Result=mysql_query($sgpa6Query);
		}if($sgpa6Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 6 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem7Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester7Sgpa=$_POST['sem7Sgpa'][$i];
		$semester7Cgpa=$_POST['sem7Cgpa'][$i];
		$semester7Back=$_POST['sem7Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa7Query="UPDATE `tbl_student` SET `sgpa_7`='$semester7Sgpa',`cgpa_7`='$semester7Cgpa',`back_7`='$semester7Back' where `roll_no`='$roll'";
		$sgpa7Result=mysql_query($sgpa7Query);
		}if($sgpa7Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 7 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem8Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester8Sgpa=$_POST['sem8Sgpa'][$i];
		$semester8Cgpa=$_POST['sem8Cgpa'][$i];
		$semester8Back=$_POST['sem8Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa8Query="UPDATE `tbl_student` SET `sgpa_8`='$semester8Sgpa',`cgpa_8`='$semester8Cgpa',`back_8`='$semester8Back' where `roll_no`='$roll'";
		$sgpa8Result=mysql_query($sgpa8Query);
		}if($sgpa8Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 8 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem9Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester9Sgpa=$_POST['sem9Sgpa'][$i];
		$semester9Cgpa=$_POST['sem9Cgpa'][$i];
		$semester9Back=$_POST['sem9Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa9Query="UPDATE `tbl_student` SET `sgpa_9`='$semester9Sgpa',`cgpa_9`='$semester9Cgpa',`back_9`='$semester9Back' where `roll_no`='$roll'";
		$sgpa9Result=mysql_query($sgpa9Query);
		}if($sgpa9Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 9 !!!");
            </script>
			<?php
			}
	}if(isset($_POST['updateResult']) && isset($_POST['sem10Sgpa'])){
		$countRoll = count($_POST['roll']);
		for($i=0; $i < $countRoll; $i++){
		$semester10Sgpa=$_POST['sem10Sgpa'][$i];
		$semester10Cgpa=$_POST['sem10Cgpa'][$i];
		$semester10Back=$_POST['sem10Back'][$i];
		$roll=$_POST['roll'][$i];
		$sgpa10Query="UPDATE `tbl_student` SET `sgpa_10`='$semester10Sgpa',`cgpa_10`='$semester10Cgpa',`back_10`='$semester10Back' where `roll_no`='$roll'";
		$sgpa10Result=mysql_query($sgpa10Query);
		}if($sgpa10Result){
			?>
			<script>
            alert("Result Updated Successfully For Semester 10 !!!");
            </script>
			<?php
			}
	}
?>
<?php
$content = ob_get_contents();
ob_clean();
include'template.php';
if (isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg'])) {
    echo $_SESSION['ErrMsg'];
    unset($_SESSION['ErrMsg']);
}
?>