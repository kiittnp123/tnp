<?php

session_start();
include'../db.php';
include_once '../inc/conf.php';
error_reporting(0);
$query = $_SESSION['query'];
//echo $query;
$res = mysql_query($query);
include_once '../excel/Classes/PHPExcel.php';
$phpExcel = new PHPExcel();
$phpExcel->createSheet();
/*
  $phpExcel->getActiveSheet()->setCellValue("A2","Student Name");
  $phpExcel->getActiveSheet()->setCellValue("B2","Roll No");
  $phpExcel->getActiveSheet()->setCellValue("C2","Branch");
  $phpExcel->getActiveSheet()->setCellValue("D2","Stream");
  $phpExcel->getActiveSheet()->setCellValue("E2","Company Name");
  $phpExcel->getActiveSheet()->setCellValue("F2","Date of Visit");
  $phpExcel->getActiveSheet()->setCellValue("G2","Academic Year");
  $phpExcel->getActiveSheet()->setCellValue("H2","Status");

  $t=3;
  while ($row= mysql_fetch_array($res)){

  $phpExcel->getActiveSheet()->setCellValue("A".$t,"$row[name]");
  $phpExcel->getActiveSheet()->setCellValue("B".$t,"$row[roll_no]");
  $phpExcel->getActiveSheet()->setCellValue("C".$t,"$row[branch]");
  $phpExcel->getActiveSheet()->setCellValue("D".$t,"$row[stream]");
  $phpExcel->getActiveSheet()->setCellValue("E".$t,"$row[company_name]");
  $phpExcel->getActiveSheet()->setCellValue("F".$t,"$row[date_visit]");
  $phpExcel->getActiveSheet()->setCellValue("G".$t,"$row[academic_year]");
  $phpExcel->getActiveSheet()->setCellValue("H".$t,"$row[status]");
  $t++;
  }
 */
$phpExcel->getActiveSheet()->setCellValue("A1", "SL NO");
$phpExcel->getActiveSheet()->setCellValue("B1", "STUDENTS Name");
$phpExcel->getActiveSheet()->setCellValue("C1", "ROLL NO");
$phpExcel->getActiveSheet()->setCellValue("D1", "LATERAL ENTRY");
$phpExcel->getActiveSheet()->setCellValue("E1", "BOARDING (HOSTEL/DAY SCHOLAR)");
$phpExcel->getActiveSheet()->setCellValue("F1", "CATEGORY (GENERAL/SC/ST/MI/PH/GC)");
$phpExcel->getActiveSheet()->setCellValue("G1", "GENDER (MALE/FEMALE)");
$phpExcel->getActiveSheet()->setCellValue("H1", "STREAM");
$phpExcel->getActiveSheet()->setCellValue("I1", "BRANCH");
$phpExcel->getActiveSheet()->setCellValue("J1", "DOB (DD-MM-YYYY)");

$phpExcel->getActiveSheet()->setCellValue("K1", "PERMANENT TELEPHONE NUMBER");
$phpExcel->getActiveSheet()->setCellValue("L1", "LOCAL MOBILE NUMBER");
$phpExcel->getActiveSheet()->setCellValue("M1", "E-MAIL ADDRESS(SMALL LETTER)");
$phpExcel->getActiveSheet()->setCellValue("N1", "ALTERNATIVE MAIL ID");
$phpExcel->getActiveSheet()->setCellValue("O1", "PRESENT ADDRESS");
$phpExcel->getActiveSheet()->setCellValue("P1", "PERMANENT ADDRESS");

$phpExcel->getActiveSheet()->setCellValue("Q1", "SEM -1 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("R1", "SEM -1 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("S1", "SEM -2 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("T1", "SEM -2 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("U1", "SEM -3 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("V1", "SEM -3 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("W1", "SEM -4 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("X1", "SEM -4 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("Y1", "SEM -5 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("Z1", "SEM -5 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AA1", "SEM -6 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AB1", "SEM -6 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AC1", "SEM -7 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AD1", "SEM -7 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AE1", "SEM -8 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AF1", "SEM -8 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AG1", "SEM -9 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AH1", "SEM -9 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AI1", "SEM -10 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AJ1", "SEM -10 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AK1", "NO OF BACK");

$phpExcel->getActiveSheet()->setCellValue("AL1", "TOTAL YEAR GAP");
$phpExcel->getActiveSheet()->setCellValue("AM1", "REASON");
$phpExcel->getActiveSheet()->setCellValue("AN1", "STATUS");

$phpExcel->getActiveSheet()->setCellValue("AO1", "CERTIFICATION LIST");

$phpExcel->getActiveSheet()->setCellValue("AP1", "COMPANY NAME");
$phpExcel->getActiveSheet()->setCellValue("AQ1", "DATE OF VISIT");
$phpExcel->getActiveSheet()->setCellValue("AR1", "PLACED STATUS");

$t = 2;
$slno = 1;
while ($row = mysql_fetch_array($res)) {

    $phpExcel->getActiveSheet()->setCellValue("A" . $t, "$slno");
    $phpExcel->getActiveSheet()->setCellValue("B" . $t, "$row[name]");
    $phpExcel->getActiveSheet()->setCellValue("C" . $t, "$row[roll_no]");
    $phpExcel->getActiveSheet()->setCellValue("D" . $t, "$row[lateral]");
    $phpExcel->getActiveSheet()->setCellValue("E" . $t, "$row[boarding]");
    $phpExcel->getActiveSheet()->setCellValue("F" . $t, "$row[category]");
    $phpExcel->getActiveSheet()->setCellValue("G" . $t, "$row[gender]");
    $phpExcel->getActiveSheet()->setCellValue("H" . $t, "$row[stream]");
    $phpExcel->getActiveSheet()->setCellValue("I" . $t, "$row[branch]");
    $dob = date("d-M-y", strtotime($row['dob']));
    $phpExcel->getActiveSheet()->setCellValue("J" . $t, $dob);
    $phpExcel->getActiveSheet()->setCellValue("K" . $t, "$row[mobile_perm]");
    $phpExcel->getActiveSheet()->setCellValue("L" . $t, "$row[mobile]");
    $phpExcel->getActiveSheet()->setCellValue("M" . $t, "$row[email]");
    $phpExcel->getActiveSheet()->setCellValue("N" . $t, "$row[alt_email]");
    $phpExcel->getActiveSheet()->setCellValue("O" . $t, "$row[corres_address]");
    $phpExcel->getActiveSheet()->setCellValue("P" . $t, "$row[permanent_address]");

    $phpExcel->getActiveSheet()->setCellValue("Q" . $t, "$row[sgpa_1]");
    $phpExcel->getActiveSheet()->setCellValue("R" . $t, "$row[cgpa_1]");
    $phpExcel->getActiveSheet()->setCellValue("S" . $t, "$row[sgpa_2]");
    $phpExcel->getActiveSheet()->setCellValue("T" . $t, "$row[cgpa_2]");
    $phpExcel->getActiveSheet()->setCellValue("U" . $t, "$row[sgpa_3]");
    $phpExcel->getActiveSheet()->setCellValue("V" . $t, "$row[cgpa_3]");
    $phpExcel->getActiveSheet()->setCellValue("W" . $t, "$row[sgpa_4]");
    $phpExcel->getActiveSheet()->setCellValue("X" . $t, "$row[cgpa_4]");
    $phpExcel->getActiveSheet()->setCellValue("Y" . $t, "$row[sgpa_5]");
    $phpExcel->getActiveSheet()->setCellValue("Z" . $t, "$row[cgpa_5]");
    $phpExcel->getActiveSheet()->setCellValue("AA" . $t, "$row[sgpa_6]");
    $phpExcel->getActiveSheet()->setCellValue("AB" . $t, "$row[cgpa_6]");
    $phpExcel->getActiveSheet()->setCellValue("AC" . $t, "$row[sgpa_7]");
    $phpExcel->getActiveSheet()->setCellValue("AD" . $t, "$row[cgpa_7]");
    $phpExcel->getActiveSheet()->setCellValue("AE" . $t, "$row[sgpa_8]");
    $phpExcel->getActiveSheet()->setCellValue("AF" . $t, "$row[cgpa_8]");
    $phpExcel->getActiveSheet()->setCellValue("AG" . $t, "$row[sgpa_9]");
    $phpExcel->getActiveSheet()->setCellValue("AH" . $t, "$row[cgpa_9]");
    $phpExcel->getActiveSheet()->setCellValue("AI" . $t, "$row[sgpa_10]");
    $phpExcel->getActiveSheet()->setCellValue("AJ" . $t, "$row[cgpa_10]");

    $totalBacks = $row[back_1] + $row[back_2] + $row[back_3] + $row[back_4] + $row[back_5] + $row[back_6] + $row[back_7] + $row[back_8] + $row[back9] + $row[back_10];
    $phpExcel->getActiveSheet()->setCellValue("AK" . $t, $totalBacks);

    $totalYearGap = $row['gap_10_12'] + $row['gap_10_dip'] + $row['gap_12_gra'] + $row['gap_dip_gra'] + $row['gap_gra_pg'];
    $phpExcel->getActiveSheet()->setCellValue("AL" . $t, $totalYearGap);
    $phpExcel->getActiveSheet()->setCellValue("AM" . $t, $row['reason']);

    $phpExcel->getActiveSheet()->setCellValue("AN" . $t, "$row[31]");

    $certList = str_replace("?", ",", $row['certification']);
    $phpExcel->getActiveSheet()->setCellValue("AO" . $t, $certList);

    $phpExcel->getActiveSheet()->setCellValue("AP" . $t, $row['company_name']);
    $phpExcel->getActiveSheet()->setCellValue("AQ" . $t, $row['date_visit']);
    $phpExcel->getActiveSheet()->setCellValue("AR" . $t, $row[109]);

    $t++;
    $slno++;
}
$excelWriter = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
//$excelWriter->save("placedStudent.xls");
header('Content-type:application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="placedStudent.xls"');
$excelWriter->save('php://output');
?>