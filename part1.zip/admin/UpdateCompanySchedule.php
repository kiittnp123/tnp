<?php
//session_start();
ob_start();
include'../db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';

echo "<form action='' method='post'>
        <table align='center'>
        <tr>
        <td align='center' bgcolor='#000033'><font color='#FFFFFF'>Select recruitment Drive:</font>";

$fetchquery="SELECT tcs.schedule_id, tc.company_name, academic_year FROM tbl_company tc, tbl_company_schedule tcs WHERE tc.company_id = tcs.company_id ORDER BY  `tcs`.`academic_year` ASC ";
$yearQuery="SELECT distinct(academic_year) as year FROM tbl_company_schedule tcs ORDER BY  `tcs`.`academic_year` ASC ";
$yearRes=  mysql_query($yearQuery);
//echo $fetchquery;
$fetchcmpny=mysql_query("$fetchquery");
echo "
   <select name='aca_year' onchange='return academicYear(this)'>
                        <option>Select</option>";
while($yearRow=  mysql_fetch_array($yearRes)){
    echo "<option>".$yearRow['year']."</option>";
}
       echo "</select>
           <input type='hidden' name='schedule_selected' id='schedule_selected' value='' />
            <select id='c' style='display:none'>";
$aca_year="";
while($company=mysql_fetch_array($fetchcmpny))
{
        if($company['academic_year']!=$aca_year){
            $aca_year=$company['academic_year'];
            echo "</select>";
            echo "<select name='c".$aca_year."' id='c".$aca_year."' style='display:none'>";
        }
	echo '<option value="'.$company[0].'">'.$company[1].'</option>';
        
}
echo " </select></td>
        </tr>
        <tr>
            <td align='center'><input type='Submit' name='btnsubmit' value='Submit'></td>
        </tr>
        </table>";

if(isset($_POST['btnsubmit']) && !empty($_POST['btnsubmit']) && $_POST['btnsubmit']=='Submit')
{
	$scheduleSelected=mysql_real_escape_string($_POST['schedule_selected']);
	$schedule_id=mysql_real_escape_string($_POST[$scheduleSelected]);
	//echo $cname;
        $sql="select 
                tbl_company.company_name,tbl_company_schedule.date_visit,tbl_company_schedule.intake,tbl_company_schedule.package,
                tbl_company_schedule.eligibility,tbl_company_schedule.academic_year,tbl_company.company_id,schedule_id
                from 
                tbl_company inner join tbl_company_schedule on tbl_company.company_id=tbl_company_schedule.company_id where tbl_company_schedule.schedule_id=$schedule_id";
        $res=mysql_query($sql);
        //echo $sql;
?>
<form method="post" action="">
    
<table align="center" bgcolor="#CCCCCC"  style="width:600px;">

<?php while($data=mysql_fetch_array($res))
 { ?>
    <input type="hidden" name="txt_schedule_id" value="<?php echo $data[7] ?>">
    <tr><td>Company Name</td><td><input type="text" name="txtname" value="<?php echo $data[0] ?>" readonly="readOnly"></td></tr>
     <tr><td>Company Id</td><td><input type="text" name="txtid" value="<?php echo $data[6] ?>" readonly="readOnly"></td></tr>
     <tr><td>Date of Visit</td><td><input type="text" name="txtdate" value="<?php echo $data[1] ?>"> Change to 
         <select name="date">
            			<option value="Date">Date</option>
                        <option value="01">1</option>
                        <option value="02">2</option>
                        <option value="03">3</option>
                        <option value="04">4</option>
                        <option value="05">5</option>
                        <option value="06">6</option>
                        <option value="07">7</option>
                        <option value="08">8</option>
                        <option value="09">9</option>
                        <option value="10">10</option>
                        <option value="11">11</option>
                        <option value="12">12</option>
                        <option value="13">13</option>
                        <option value="14">14</option>
                        <option value="15">15</option>
                        <option value="16">16</option>
                        <option value="17">17</option>
                        <option value="18">18</option>
                        <option value="19">19</option>
                        <option value="20">20</option>
                        <option value="21">21</option>
                        <option value="22">22</option>
                        <option value="23">23</option>
                        <option value="24">24</option>
                        <option value="25">25</option>
                        <option value="26">26</option>
                        <option value="27">27</option>
                        <option value="28">28</option>
                        <option value="29">29</option>
                        <option value="30">30</option>
                        <option value="31">31</option></select>
           		<select name="month">
                		<option value="Month">Month</option>
                        <option value="01">Jan</option>
                        <option value="02">Feb</option>
                        <option value="03">Mar</option>
                        <option value="04">Apr</option>
                        <option value="05">May</option>
                        <option value="06">June</option>
                        <option value="07">July</option>
                        <option value="08">Aug</option>
                        <option value="09">Sept</option>
                        <option value="10">Oct</option>
                        <option value="11">Nov</option>
                        <option value="12">Dec</option></select>
                <select name="year">
                		<option value="Year">Year</option>
                        <option value="2013">2013</option>
                        <option value="2014">2014</option>
                        <option value="2015">2015</option>
                        <option value="2016">2016</option>
                        <option value="2017">2017</option>
                        <option value="2018">2018</option>
                        <option value="2019">2017</option>
                        <option value="2020">2018</option>
                        </select></td></tr>
     <tr><td>Intake</td><td><input type="text" name="txtintake" value="<?php echo $data[2] ?>"></td></tr>
     <tr><td>Package</td><td><input type="text" name="txtpackage" value="<?php echo $data[3] ?>"></td></tr>
     <tr><td>Eligibility</td><td><input type="text" name="txteligiblty" value="<?php echo $data[4] ?>"></td></tr>
     <tr><td>Academic Year</td><td><input type="text" name="txtyearold" value="<?php echo $data[5] ?>"> 
             Change to <select name="txtyear">
                 <option>Select</option>
        <option>2011-2012</option>
        <option>2012-2013</option>
        <option>2013-2014</option>
        <option>2014-2015</option>
        <option>2015-2016</option>
        <option>2016-2017</option>
        
        
    </select></td></tr>
	 
 <?php } ?>
  <tr>
  <td colspan="2" align="center"><input type="submit" name="btnupdate" value="UPDATE"></td>
  </tr>
 </table>
 </form>
<?php }
if(isset($_POST['btnupdate']) && !empty($_POST['btnupdate']) && $_POST['btnupdate']=='UPDATE')
{
 $scheduleId=mysql_real_escape_string($_POST['txt_schedule_id']);
 if($_POST['date']!='Date' && $_POST['month']!='Month' && $_POST['year']!='Year')
    $datevisit=mysql_real_escape_string($_POST['year'])."-".mysql_real_escape_string($_POST['month'])."-".mysql_real_escape_string($_POST['date']);
 else
    $datevisit=mysql_real_escape_string($_POST['txtdate']);
 $intake=mysql_real_escape_string($_POST['txtintake']);
 $package=mysql_real_escape_string($_POST['txtpackage']);
 $eligibility=mysql_real_escape_string($_POST['txteligiblty']);
 if($_POST['txtyear']!='Select')
    $academic_year=mysql_real_escape_string($_POST['txtyear']);
 else
     $academic_year=mysql_real_escape_string($_POST['txtyearold']);
  $sqlupdate="update tbl_company_schedule 
                set 
                date_visit='$datevisit',intake='$intake',package='$package',eligibility='$eligibility',academic_year='$academic_year' 
                where schedule_id=$scheduleId";
  echo $sqlupdate;
 $result=mysql_query($sqlupdate);
 if($result)
 {
	  $_SESSION['ErrMsg']="<script>alert('Updated..')</script>";
      
 }  else {
          $_SESSION['ErrMsg']="<script>alert('Problem Occurred')</script>";
 }
}
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>