<?php
ob_start();
include 'protectedAdmin.php';
include_once '../inc/conf.php';
//$selectStream = "";
?>
<!DOCTYPE html>
<?php 
//error_reporting(0);
	include '../db.php';
	include 'Excel/reader.php';
    function uploadFile($fieldName, $fileType, $folderName, $name = "")
    {
        $flg = 0;
        $MaxID = "";
        $ext = "";
        $uploadfile = "";
        if (isset($fieldName) AND $fieldName['name'] != '')
        {
            $flg = 1;
            $allowed_filetypes = $fileType;
            $max_filesize = 1048576;
            $filename = $fieldName['name'];
            if ($name == "")
                $MaxID = time() . time() . rand(1, 100);
            else
                $MaxID = $name;
            $ext = substr($filename, strpos($filename, '.'), strlen($filename) - 1);
			if($ext==".xlsx")
				$ext=".xls";
            if (!in_array($ext, $allowed_filetypes))
                echo "<h1>The file you attempted to upload is not allowed...</h1>";
            else if (filesize($fieldName['tmp_name']) > $max_filesize)
                echo "<h1>The file you attempted to upload is too large...</h1>";
            else 
            {
                $uploadfile = $folderName . "/" . $MaxID . $ext;
                if (move_uploaded_file($fieldName['tmp_name'], $uploadfile) == FALSE)
                {
                    echo "<h1>Error in Uploading File...</h1>";
                    $MaxID = "";
                }
                else
                    $MaxID = $MaxID . $ext;
            }
        }
        return $MaxID;
    }
    if(isset($_POST['submit']))
	{
		$year_passout=$_POST['passout_year'];
		$stream=$_POST['stream'];
		$branch=$_POST['branch'];
		$semester=$_POST['semester'];

		
		if($_FILES['excelFile']['name']!="")
		{
			$fileName=uploadFile($_FILES['excelFile'],array(".xls",".xlsx"),"excel_file");
			$data = new Spreadsheet_Excel_Reader();
			$data->read('excel_file/'.$fileName);
			for($i=1;$i<=$data->sheets[0]['numRows'];$i++)
			{
				$roll=$data->sheets[0]['cells'][$i][1];
				$sgpa=$data->sheets[0]['cells'][$i][2];
				$cgpa=$data->sheets[0]['cells'][$i][3];
				$back=$data->sheets[0]['cells'][$i][4];
		
				if($semester=='1')
				{
					$query="UPDATE `tbl_student` SET `sgpa_1`='$sgpa',`cgpa_1`='$cgpa',`back_1`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='2')
				{
					$query="UPDATE `tbl_student` SET `sgpa_2`='$sgpa',`cgpa_2`='$cgpa',`back_2`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='3')
				{
					$query="UPDATE `tbl_student` SET `sgpa_3`='$sgpa',`cgpa_3`='$cgpa',`back_3`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='4')
				{
					$query="UPDATE `tbl_student` SET `sgpa_4`='$sgpa',`cgpa_4`='$cgpa',`back_4`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='5')
				{
					$query="UPDATE `tbl_student` SET `sgpa_5`='$sgpa',`cgpa_5`='$cgpa',`back_5`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='6')
				{
					$query="UPDATE `tbl_student` SET `sgpa_6`='$sgpa',`cgpa_6`='$cgpa',`back_6`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='7')
				{
					$query="UPDATE `tbl_student` SET `sgpa_7`='$sgpa',`cgpa_7`='$cgpa',`back_7`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='8')
				{
					$query="UPDATE `tbl_student` SET `sgpa_8`='$sgpa',`cgpa_8`='$cgpa',`back_8`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='9')
				{
					$query="UPDATE `tbl_student` SET `sgpa_9`='$sgpa',`cgpa_9`='$cgpa',`back_9`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
				elseif($semester=='10')
				{
					$query="UPDATE `tbl_student` SET `sgpa_10`='$sgpa',`cgpa_10`='$cgpa',`back_10`='$back' WHERE `roll_no`='$roll'";
					$res=mysql_query($query);
				}
		
				/*$query="UPDATE `tbl_student` SET `sgpa_6`='$sgpa_6',`cgpa_6`='$cgpa_6',`back_6`='$back_6' WHERE `roll_no`='$roll'";
				$query1=mysql_query($query);*/
			}
			if($res)
			{
			?>
			<script>
			alert("<?php echo $_FILES['excelFile']['name']; ?> SUCCESSFULLY UPDATED");
			</script>
		<?php
		   }
		}
	}
?>
<style>

/*fieldset{width:400px;
         background:-moz-linear-gradient( center top, #E6E6E6 20%, #FFFFFF 70% );
         background:-webkit-linear-gradient( #E6E6E6 20%, #FFFFFF 70% );
		 box-shadow:10px 10px 8px #333333;z-index:1000px;border:hidden;border-radius:10px}
p{color:red}
button{}
button {
      -moz-box-shadow:inset 0px 1px 0px 0px #cae3fc;
      -webkit-box-shadow:inset 0px 1px 0px 0px #cae3fc;
      box-shadow:inset 0px 1px 0px 0px #cae3fc;
      background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #79bbff), color-stop(1, #4197ee) );
      background:-moz-linear-gradient( center top, #79bbff 5%, #4197ee 100% );
      filter:progid:DXImageTransform.Microsoft.gradient(startColorstr='#79bbff', endColorstr='#4197ee');
      background-color:#79bbff;
     -moz-border-radius:6px;
     -webkit-border-radius:6px;
     border-radius:6px;
     border:1px solid #469df5;
     display:inline-block;
     color:#ffffff;
     font-family:arial;
     font-size:14px;
     font-weight:bold;
     padding:5px 14px;
     text-decoration:none;
     text-shadow:1px 1px 0px #287ace;
    cursor:pointer;
}
button:hover {
     background:-webkit-gradient( linear, left top, left bottom, color-stop(0.05, #4197ee), color-stop(1, #79bbff) );
     background:-moz-linear-gradient( center top, #4197ee 5%, #79bbff 100% );
     
}
 button:active {
   position:relative;
   top:1px;
}

 .input-large {
    padding: 6px;
    font-size: 13px;
    border: 1px solid #d5d5d5;
    color: #333;
    border-radius: 4px 4px 4px 4px !important;
 }*/
</style>
<script>
function setValidStream(c, d) {
        var xmlhttp;
        if (c.value == 'Select')
        {
            document.getElementById(d).innerHTML = "Please select a Stream";
            return;
        }
        if (window.XMLHttpRequest)
        {// code for IE7+, Firefox, Chrome, Opera, Safari
            xmlhttp = new XMLHttpRequest();
        }
        else
        {// code for IE6, IE5
            xmlhttp = new ActiveXObject("Microsoft.XMLHTTP");
        }
        xmlhttp.onreadystatechange = function()
        {
            if (xmlhttp.readyState == 4 && xmlhttp.status == 200)
            {
                document.getElementById(d).innerHTML = "<select name='branch'>" + xmlhttp.responseText + "</select>";
            }
        }
        xmlhttp.open("GET", "../inc/branchList.php?id=" + c.value, true);
        xmlhttp.send();
    }

</script>

	<body>    
				<!--<br/><font face='forte' size='6' color='#8a0000'>Upload Student Results </font>
				<br/><fieldset>
				
				<label><p>*Upload only .xls File Type*</p></label>
				<form method="post" name="upload_excel" enctype="multipart/form-data">
					
						        
								<input type="file" name="excelFile" class="input-large"><br/><br/>
							
							<button type="submit" id="submit" name="submit">Upload</button>
							
				</form>
				</fieldset><br/><br/><br/>-->
<form method="post" name="upload_excel" enctype="multipart/form-data">			
<table align="center" bgcolor="#E8E8E8" width='600'>
	<!--<tr>
		<td width='200'>
			Select Passout Year
		</td width='400'>
		<td>
			<select name="passout_year">
                    <option>Select</option>
                    <option>2014</option>
                    <option>2015</option>
                    <option>2016</option>
                    <option>2017</option>
                    <option>2018</option>
                    <option>2019</option>
                    <option>2020</option>
                    <option>2021</option>
                    <option>2022</option>
                    <option>2023</option>
                    <option>2024</option>
                    <option>2025</option>
            </select>
		</td>
	</tr>
	<tr>
		<td width='200'>
			Select Stream
		</td>
		<td width='400'>
			<select name="stream" onchange="setValidStream(this, 'branchPlaceHolder');">
                    <option>Select</option>
                    <option value="B.Tech">B.Tech</option>               
                    <option value="M.Tech">M.Tech</option>
                    <option value="MCA">MCA</option>
                    <option value="Dual Degree-B.Tech + M.Tech">Dual Degree-B.Tech + M.Tech</option>
                    <option value="Dual Degree-B.Tech + MBA">Dual Degree-B.Tech + MBA</option>
            </select>
		</td>
	</tr>
	<tr>
        <td width='200'>
			Select Branch
		</td>
        <td id='branchPlaceHolder' width='400'>
			
		</td>
    </tr>-->
	<tr>
		<td width='200'>
			Select Semester
		</td>
		<td width='400'>
			<select name="semester">
                    <option>Select</option>
                    <option value="1">1st</option>
                    <option value="2">2nd</option>
                    <option value="3">3rd</option>
                    <option value="4">4th</option>
                    <option value="5">5th</option>
                    <option value="6">6th</option>
                    <option value="7">7th</option>
                    <option value="8">8th</option>
                    <option value="9">9th</option>
                    <option value="10">10th</option>
            </select>
		</td>
	</tr>
	<tr>
        <td width='200'>
			Upload only .xls File Type
		</td>
        <td width='400'>
			<input type="file" name="excelFile" class="input-large">
		</td>
    </tr>
	<tr>
        <td align="center" colspan="2">
			<input type="submit" name="submit" value="Update">
		</td>
    </tr>
</table>
</form>
    <!-- Footer
    ================================================== -->
    
	</body>
</html>
<?php
$content = ob_get_contents();
ob_clean();
include'template.php';
if (isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg'])) {
    echo $_SESSION['ErrMsg'];
    unset($_SESSION['ErrMsg']);
}
?>



