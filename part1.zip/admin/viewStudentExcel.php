<?php
flush();
ini_set('max_execution_time', 1200); 
ini_set("memory_limit","120000M");

include_once 'protectedAdmin.php';
include_once '../inc/conf.php';
error_reporting(1);
include '../db.php';
$query = $_SESSION['query'];
//$query="SELECT * FROM `tbl_student` WHERE `year_passout`='2015' limit 1764";
$res = mysql_query("$query");
include_once '../excel/Classes/PHPExcel.php';
//include_once '../excel/Classes/PHPExcel/IOFactory.php';
$phpExcel = new PHPExcel();
$phpExcel->createSheet();
$phpExcel->getActiveSheet()->setCellValue("A1", "SL NO");
$phpExcel->getActiveSheet()->setCellValue("B1", "STUDENTS Name");
$phpExcel->getActiveSheet()->setCellValue("C1", "ROLL NO");
$phpExcel->getActiveSheet()->setCellValue("D1", "LATERAL ENTRY");
$phpExcel->getActiveSheet()->setCellValue("E1", "BOARDING (HOSTEL/DAY SCHOLAR)");
$phpExcel->getActiveSheet()->setCellValue("F1", "CATEGORY (GENERAL/SC/ST/MI/PH/GC)");
$phpExcel->getActiveSheet()->setCellValue("G1", "GENDER (MALE/FEMALE)");
$phpExcel->getActiveSheet()->setCellValue("H1", "STREAM");
$phpExcel->getActiveSheet()->setCellValue("I1", "BRANCH");
$phpExcel->getActiveSheet()->setCellValue("J1", "DOB (DD-MM-YYYY)");
$phpExcel->getActiveSheet()->setCellValue("BP1", "HOBBIES");
$phpExcel->getActiveSheet()->setCellValue("BV1", "FORM VERIFIED");

$phpExcel->getActiveSheet()->setCellValue("K1", "PERMANENT TELEPHONE NUMBER");
$phpExcel->getActiveSheet()->setCellValue("L1", "STUDENT MOBILE NUMBER");
$phpExcel->getActiveSheet()->setCellValue("M1", "E-MAIL ADDRESS");
$phpExcel->getActiveSheet()->setCellValue("N1", "ALTERNATIVE MAIL ID");
$phpExcel->getActiveSheet()->setCellValue("O1", "PRESENT ADDRESS");
$phpExcel->getActiveSheet()->setCellValue("P1", "PERMANENT ADDRESS");

$phpExcel->getActiveSheet()->setCellValue("Q1", "FATHER'S NAME");
$phpExcel->getActiveSheet()->setCellValue("R1", "FATHER'S MOBILE");
$phpExcel->getActiveSheet()->setCellValue("S1", "FATHER'S EMAIL-ID");
$phpExcel->getActiveSheet()->setCellValue("T1", "FATHER'S OCCUPATION");
$phpExcel->getActiveSheet()->setCellValue("U1", "FATHER'S DESIG.");

$phpExcel->getActiveSheet()->setCellValue("V1", "10TH BOARD");
$phpExcel->getActiveSheet()->setCellValue("W1", "10TH STATE");
$phpExcel->getActiveSheet()->setCellValue("X1", "10TH YOP (YYYY)");
$phpExcel->getActiveSheet()->setCellValue("Y1", "DISTANCE_10");
$phpExcel->getActiveSheet()->setCellValue("Z1", "10TH %");
$phpExcel->getActiveSheet()->setCellValue("AA1", "10TH AGG %");

$phpExcel->getActiveSheet()->setCellValue("AB1", "12TH BOARD (COUNCIL/BOARD)");
$phpExcel->getActiveSheet()->setCellValue("AC1", "12TH STATE");
$phpExcel->getActiveSheet()->setCellValue("AD1", "12TH YOJ (YYYY)");
$phpExcel->getActiveSheet()->setCellValue("AE1", "12TH YOP (YYYY)");
$phpExcel->getActiveSheet()->setCellValue("AF1", "DISTANCE_12");
$phpExcel->getActiveSheet()->setCellValue("AG1", "12TH %");
$phpExcel->getActiveSheet()->setCellValue("AH1", "12TH AGG.");

$phpExcel->getActiveSheet()->setCellValue("AI1", "DIP. (BOARD/COUCIL)");
$phpExcel->getActiveSheet()->setCellValue("AJ1", "DIP. STATE");
$phpExcel->getActiveSheet()->setCellValue("AK1", "DIP. YOJ (YYYY)");
$phpExcel->getActiveSheet()->setCellValue("AL1", "DIP. YOP (YYYY)");
$phpExcel->getActiveSheet()->setCellValue("AM1", "DISTANCE _DIPLOMA");
$phpExcel->getActiveSheet()->setCellValue("AN1", "DIP. %");
$phpExcel->getActiveSheet()->setCellValue("AO1", "DIP. AGG.");

$phpExcel->getActiveSheet()->setCellValue("AP1", "SEM -1 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AQ1", "SEM -1 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AR1", "SEM -2 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AS1", "SEM -2 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AT1", "SEM -3 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AU1", "SEM -3 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AV1", "SEM -4 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AW1", "SEM -4 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AX1", "SEM -5 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("AY1", "SEM -5 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("AZ1", "SEM -6 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("BA1", "SEM -6 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("BB1", "SEM -7 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("BC1", "SEM -7 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("BD1", "SEM -8 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("BE1", "SEM -8 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("BF1", "SEM -9 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("BG1", "SEM -9 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("BH1", "SEM -10 (SGPA)");
$phpExcel->getActiveSheet()->setCellValue("BI1", "SEM -10 (CGPA)");
$phpExcel->getActiveSheet()->setCellValue("BJ1", "NO OF BACK");

$phpExcel->getActiveSheet()->setCellValue("BK1", "10TH - 12TH");
$phpExcel->getActiveSheet()->setCellValue("BL1", "10TH - DIPLOMA");
$phpExcel->getActiveSheet()->setCellValue("BM1", "12TH - GRADUATION");
$phpExcel->getActiveSheet()->setCellValue("BN1", "DIPLOMA - GRADUATION");
$phpExcel->getActiveSheet()->setCellValue("BO1", "TOTAL YEAR GAP");
$phpExcel->getActiveSheet()->setCellValue("BP1", "REASON");
$phpExcel->getActiveSheet()->setCellValue("BQ1", "HOBBY");


$phpExcel->getActiveSheet()->setCellValue("BR1", "PROJECT NAME");
$phpExcel->getActiveSheet()->setCellValue("BS1", "INSTITUTION/ORGANISATION");
$phpExcel->getActiveSheet()->setCellValue("BT1", "DURATION OF THE PROJECT");
$phpExcel->getActiveSheet()->setCellValue("BU1", "PROJECT GUIDE");
$phpExcel->getActiveSheet()->setCellValue("BV1", "PROJECT SUMMARY");

$phpExcel->getActiveSheet()->setCellValue("BW1", "STATUS");


$phpExcel->getActiveSheet()->setCellValue("BX1", "COMPANY 1");
$phpExcel->getActiveSheet()->setCellValue("BY1", "COMPANY 2");
$phpExcel->getActiveSheet()->setCellValue("BZ1", "COMPANY 3");

$phpExcel->getActiveSheet()->setCellValue("CA1", "CERTIFICATION 1");
$phpExcel->getActiveSheet()->setCellValue("CB1", "CERTIFICATION 2");
$phpExcel->getActiveSheet()->setCellValue("CC1", "CERTIFICATION 3");
$phpExcel->getActiveSheet()->setCellValue("CD1", "CERTIFICATION 4");
$phpExcel->getActiveSheet()->setCellValue("CE1", "CERTIFICATION 5");
$phpExcel->getActiveSheet()->setCellValue("CF1", "CERTIFICATION 6");
$phpExcel->getActiveSheet()->setCellValue("CG1", "CERTIFICATION 7");
$phpExcel->getActiveSheet()->setCellValue("CH1", "CERTIFICATION 8");
$phpExcel->getActiveSheet()->setCellValue("CI1", "CERTIFICATION 9");
$phpExcel->getActiveSheet()->setCellValue("CJ1", "CERTIFICATION 10");

$phpExcel->getActiveSheet()->setCellValue("CM1","SSC SCHOOL NAME");
$phpExcel->getActiveSheet()->setCellValue("CN1","HSC SCHOOL NAME");
$phpExcel->getActiveSheet()->setCellValue("CO1","DIPLOMA SCHOOL NAME");
$phpExcel->getActiveSheet()->setCellValue("CP1","GRADUATION SCHOOL NAME");

$phpExcel->getActiveSheet()->setCellValue("CQ1","PERMANENT ADDREES 1");
$phpExcel->getActiveSheet()->setCellValue("CR1","PERMANENT ADDREES 2");
$phpExcel->getActiveSheet()->setCellValue("CS1","PERMANENT ADDREES CITY");
$phpExcel->getActiveSheet()->setCellValue("CT1","PERMANENT ADDREES STATE");
$phpExcel->getActiveSheet()->setCellValue("CU1","PERMANENT ADDREES PIN");
$phpExcel->getActiveSheet()->setCellValue("CV1","PRESENT ADDREES 1");
$phpExcel->getActiveSheet()->setCellValue("CW1","PRESENT ADDREES 2");
$phpExcel->getActiveSheet()->setCellValue("CX1","PRESENT ADDREES CITY");
$phpExcel->getActiveSheet()->setCellValue("CY1","PRESENT ADDREES STATE");
$phpExcel->getActiveSheet()->setCellValue("CZ1","PRESENT ADDREES PIN");


$t = 2;
$slno = 1;
while ($row = mysql_fetch_array($res)) {
    $phpExcel->getActiveSheet()->setCellValue("A" . $t, "$slno");
    //$phpExcel->getActiveSheet()->setCellValue("B" . $t, "$row[name]");
    $phpExcel->getActiveSheet()->setCellValue("C" . $t, "$row[roll_no]");
    $phpExcel->getActiveSheet()->setCellValue("D" . $t, "$row[lateral]");
    $phpExcel->getActiveSheet()->setCellValue("E" . $t, "$row[boarding]");
    $phpExcel->getActiveSheet()->setCellValue("F" . $t, "$row[category]");
    $phpExcel->getActiveSheet()->setCellValue("G" . $t, "$row[gender]");
    $phpExcel->getActiveSheet()->setCellValue("H" . $t, "$row[stream]");
    $phpExcel->getActiveSheet()->setCellValue("I" . $t, "$row[branch]");
    $dob = date("d-M-y", strtotime($row['dob']));
    $phpExcel->getActiveSheet()->setCellValue("J" . $t, "$dob");
    $phpExcel->getActiveSheet()->setCellValue("K" . $t, "$row[mobile_perm]");
    $phpExcel->getActiveSheet()->setCellValue("L" . $t, "$row[mobile]");
    $phpExcel->getActiveSheet()->setCellValue("M" . $t, "$row[email]");
    $phpExcel->getActiveSheet()->setCellValue("N" . $t, "$row[alt_email]");
    $phpExcel->getActiveSheet()->setCellValue("O" . $t, "$row[corres_address]");
    $phpExcel->getActiveSheet()->setCellValue("P" . $t, "$row[permanent_address]");

    $phpExcel->getActiveSheet()->setCellValue("Q" . $t, "$row[father_name]");
    $phpExcel->getActiveSheet()->setCellValue("R" . $t, "$row[father_mobile]");
    $phpExcel->getActiveSheet()->setCellValue("S" . $t, "$row[father_email]");
    $phpExcel->getActiveSheet()->setCellValue("T" . $t, "$row[father_org]");
    $phpExcel->getActiveSheet()->setCellValue("U" . $t, "$row[father_add]");

    $phpExcel->getActiveSheet()->setCellValue("V" . $t, "$row[ssc_board]");
    $phpExcel->getActiveSheet()->setCellValue("W" . $t, "$row[ssc_state]");
    $phpExcel->getActiveSheet()->setCellValue("X" . $t, "$row[ssc_yop]");
    $phpExcel->getActiveSheet()->setCellValue("Y" . $t, "$row[ssc_distance]");
    if ($row['ssc_board_total'] != 0)
        $sscBoardPer = round(($row['ssc_board_secure'] / $row['ssc_board_total']) * 100, 2);
    else
        $sscBoardPer = 0;
    if ($row['ssc_total'] != 0)
        $sscPer = round(($row['ssc_secure'] / $row['ssc_total']) * 100, 2);
    else
        $sscPer = 0;
    $phpExcel->getActiveSheet()->setCellValue("Z" . $t, "$sscBoardPer");
    $phpExcel->getActiveSheet()->setCellValue("AA" . $t, "$sscPer");

    $phpExcel->getActiveSheet()->setCellValue("AB" . $t, "$row[hsc_board]");
    $phpExcel->getActiveSheet()->setCellValue("AC" . $t, "$row[hsc_state]");
    $phpExcel->getActiveSheet()->setCellValue("AD" . $t, "$row[hsc_yoj]");
    $phpExcel->getActiveSheet()->setCellValue("AE" . $t, "$row[hsc_yop]");
    $phpExcel->getActiveSheet()->setCellValue("AF" . $t, "$row[hsc_distance]");
    if ($row['hsc_board_total'] != 0)
        $hscBoardPer = round(($row[hsc_board_secure] / $row[hsc_board_total]) * 100, 2);
    else
        $hscBoardPer = 0;
    if ($row['hsc_total'] != 0)
        $hscPer = round(($row[hsc_secure] / $row[hsc_total]) * 100, 2);
    else
        $hscPer = 0;
    $phpExcel->getActiveSheet()->setCellValue("AG" . $t, "$hscBoardPer");
    $phpExcel->getActiveSheet()->setCellValue("AH" . $t, "$hscPer");

    $phpExcel->getActiveSheet()->setCellValue("AI" . $t, "$row[dip_board]");
    $phpExcel->getActiveSheet()->setCellValue("AJ" . $t, "$row[dip_state]");
    $phpExcel->getActiveSheet()->setCellValue("AK" . $t, "$row[dip_yoj]");
    $phpExcel->getActiveSheet()->setCellValue("AL" . $t, "$row[dip_yop]");
    $phpExcel->getActiveSheet()->setCellValue("AM" . $t, "$row[dip_distance]");
    if ($row['dip_board_total'] != 0)
        $dipBoardPer = round(($row[dip_board_secure] / $row[dip_board_total]) * 100, 2);
    else
        $dipBoardPer = 0;
    if ($row[dip_total] != 0)
        $dipPer = round(($row[dip_secure] / $row[dip_total]) * 100, 2);
    else
        $dipPer = 0;
    $phpExcel->getActiveSheet()->setCellValue("AN" . $t, "$dipBoardPer");
    $phpExcel->getActiveSheet()->setCellValue("AO" . $t, "$dipPer");

    $phpExcel->getActiveSheet()->setCellValue("AP" . $t, "$row[sgpa_1]");
    $phpExcel->getActiveSheet()->setCellValue("AQ" . $t, "$row[cgpa_1]");
    $phpExcel->getActiveSheet()->setCellValue("AR" . $t, "$row[sgpa_2]");
    $phpExcel->getActiveSheet()->setCellValue("AS" . $t, "$row[cgpa_2]");
    $phpExcel->getActiveSheet()->setCellValue("AT" . $t, "$row[sgpa_3]");
    $phpExcel->getActiveSheet()->setCellValue("AU" . $t, "$row[cgpa_3]");
    $phpExcel->getActiveSheet()->setCellValue("AV" . $t, "$row[sgpa_4]");
    $phpExcel->getActiveSheet()->setCellValue("AW" . $t, "$row[cgpa_4]");
    $phpExcel->getActiveSheet()->setCellValue("AX" . $t, "$row[sgpa_5]");
    $phpExcel->getActiveSheet()->setCellValue("AY" . $t, "$row[cgpa_5]");
    $phpExcel->getActiveSheet()->setCellValue("AZ" . $t, "$row[sgpa_6]");
    $phpExcel->getActiveSheet()->setCellValue("BA" . $t, "$row[cgpa_6]");
    $phpExcel->getActiveSheet()->setCellValue("BB" . $t, "$row[sgpa_7]");
    $phpExcel->getActiveSheet()->setCellValue("BC" . $t, "$row[cgpa_7]");
    $phpExcel->getActiveSheet()->setCellValue("BD" . $t, "$row[sgpa_8]");
    $phpExcel->getActiveSheet()->setCellValue("BE" . $t, "$row[cgpa_8]");
    $phpExcel->getActiveSheet()->setCellValue("BF" . $t, "$row[sgpa_9]");
    $phpExcel->getActiveSheet()->setCellValue("BG" . $t, "$row[cgpa_9]");
    $phpExcel->getActiveSheet()->setCellValue("BH" . $t, "$row[sgpa_10]");
    $phpExcel->getActiveSheet()->setCellValue("BI" . $t, "$row[cgpa_10]");

    $totalBacks = $row[back_1] + $row[back_2] + $row[back_3] + $row[back_4] + $row[back_5] + $row[back_6] + $row[back_7] + $row[back_8] + $row[back9] + $row[back_10];
    $phpExcel->getActiveSheet()->setCellValue("BJ" . $t, "$totalBacks");



    $phpExcel->getActiveSheet()->setCellValue("BK" . $t, "$row[gap_10_12]");
    $phpExcel->getActiveSheet()->setCellValue("BL" . $t, "$row[gap_10_dip]");
    $phpExcel->getActiveSheet()->setCellValue("BM" . $t, "$row[gap_12_gra]");
    $phpExcel->getActiveSheet()->setCellValue("BN" . $t, "$row[gap_dip_gra]");
    $totalYearGap = $row[gap_10_12] + $row[gap_10_dip] + $row[gap_12_gra] + $row[gap_dip_gra];
    $phpExcel->getActiveSheet()->setCellValue("BO" . $t, "$totalYearGap");
    $phpExcel->getActiveSheet()->setCellValue("BP" . $t, "$row[gap_reason]");

    $phpExcel->getActiveSheet()->setCellValue("BQ" . $t, "$row[hobby]");

    $phpExcel->getActiveSheet()->setCellValue("BR" . $t, "$row[pro_name]");
    $phpExcel->getActiveSheet()->setCellValue("BS" . $t, "$row[pro_duration]");
    $phpExcel->getActiveSheet()->setCellValue("BT" . $t, "$row[pro_org]");
    $phpExcel->getActiveSheet()->setCellValue("BU" . $t, "$row[pro_guide]");
    $phpExcel->getActiveSheet()->setCellValue("BV" . $t, "$row[pro_summary]");

    $phpExcel->getActiveSheet()->setCellValue("BW" . $t, "$row[status]");
	
	    $phpExcel->getActiveSheet()->setCellValue("CM".$t,"$row[ssc_school]");
		$phpExcel->getActiveSheet()->setCellValue("CN".$t,"$row[hsc_school]");
		$phpExcel->getActiveSheet()->setCellValue("CO".$t,"$row[dip_school]");
		$phpExcel->getActiveSheet()->setCellValue("CP".$t,"$row[gra_school]");

        $phpExcel->getActiveSheet()->setCellValue("CQ".$t,"$row[permanent_add_1]");
		$phpExcel->getActiveSheet()->setCellValue("CR".$t,"$row[permanent_add_2]");
		$phpExcel->getActiveSheet()->setCellValue("CS".$t,"$row[permanent_add_city]");
		$phpExcel->getActiveSheet()->setCellValue("CT".$t,"$row[permanent_add_state]");
		$phpExcel->getActiveSheet()->setCellValue("CU".$t,"$row[permanent_add_pin]");
		$phpExcel->getActiveSheet()->setCellValue("CV".$t,"$row[corres_add_1]");
		$phpExcel->getActiveSheet()->setCellValue("CW".$t,"$row[corres_add_2]");
		$phpExcel->getActiveSheet()->setCellValue("CX".$t,"$row[corres_add_city]");
		$phpExcel->getActiveSheet()->setCellValue("CY".$t,"$row[corres_add_state]");
		$phpExcel->getActiveSheet()->setCellValue("CZ".$t,"$row[corres_add_pin]");

    $companyQuery = "SELECT * 
                       FROM  `tbl_company_student` tcs, tbl_company_schedule tcsh, tbl_company tc
                       WHERE tcs.schedule_id = tcsh.schedule_id
                       AND tcsh.company_id = tc.company_id
                       AND tcs.status =  'Placed'
                       AND tcs.student_id=$row[student_id]";
    $companyRes = mysql_query("$companyQuery");
    $j = 0;
    while ($companyRow = mysql_fetch_array($companyRes)) {
        if ($j == 0)
            $r = "BX";
        if ($j == 1)
            $r = "BY";
        if ($j == 2)
            $r = "BZ";
        $phpExcel->getActiveSheet()->setCellValue($r . $t, "$companyRow[company_name]"); //COMPANY 1
        $j++;
    }
    $certList = explode("?", $row['certification']);
    $phpExcel->getActiveSheet()->setCellValue("CA" . $t, $certList[0]);
    $phpExcel->getActiveSheet()->setCellValue("CB" . $t, $certList[1]);
    $phpExcel->getActiveSheet()->setCellValue("CC" . $t, $certList[2]);
    $phpExcel->getActiveSheet()->setCellValue("CD" . $t, $certList[3]);
    $phpExcel->getActiveSheet()->setCellValue("CE" . $t, $certList[4]);
    $phpExcel->getActiveSheet()->setCellValue("CF" . $t, $certList[5]);
    $phpExcel->getActiveSheet()->setCellValue("CG" . $t, $certList[6]);
    $phpExcel->getActiveSheet()->setCellValue("CH" . $t, $certList[7]);
    $phpExcel->getActiveSheet()->setCellValue("CI" . $t, $certList[8]);
    $phpExcel->getActiveSheet()->setCellValue("CJ" . $t, $certList[9]);

    $t++;
    $slno++;
}
$excelWriter = PHPExcel_IOFactory::createWriter($phpExcel, "Excel2007");
//$excelWriter->save("StudentData-UG.xls");
header('Content-type:application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="studentdata.xls"');
$excelWriter->save('php://output');
flush();
?>