<?php
ob_start();
include'../db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
if(isset($_POST['btnreset']) && !empty($_POST['btnreset']) && $_POST['btnreset']=='Reset Password')
{
 	$email=mysql_real_escape_string($_POST['email']);
	$pwd=mysql_real_escape_string($_POST['pwd']);
        if(!empty($pwd)){
	$update="update tbl_student set password='$pwd' where email='$email'";
	$res=mysql_query($update);
	if($res)
	{
		$_SESSION['ErrMsg']="<script>alert('Password changed..')</script>";
                $body='Dear Candidate,\r\nThe password for your profile with the KIIT-TNP Management Portal has been changed. Your new credentials are provided below:\r\nUser id : '.$email.'\r\n password: '.$pwd.'\r\n\r\nYou can now login to your profile from kiittnp.in\r\n\r\nBest Regards,\r\nTraining and Placement Officer\r\nKIIT-University';
                $body.="\r\n\r\n\r\n\r\nNote: Please do not reply back to this mail. Replies to this mail goes to an unmonitored mail box. For any further communication, please feel free to drop a mail at placement@kiit.ac.in and training@kiit.ac.in";
                mail($email,"TNP Student Account : Password Reset",$body,"from: contact@kiittnp.in" );    
	}
        }
        else{
            $_SESSION['ErrMsg']="<script>alert('Password cant be empty')</script>";
        }
}
if(isset($_POST['btn_pwd_download']) && !empty($_POST['btn_pwd_download']) && $_POST['btn_pwd_download']=='Download Data')
{
    $pwdQuery="select * from tbl_student where year_passout=".$_POST['radyear'];
    $_SESSION['query']=$pwdQuery;
    header("location:resetPwdExcel.php");
}
?>
<form action="resetPwd.php" method="post">
<table align="center">
<tr>
<td>Enter Roll No:</td>
<td><input type="text" name="rollno" onkeypress="return isNumberKey(event)" ></td>
<td align="center" style="background-color: #999;width:50px;">OR</td>
<td>Select Year to download the user-id and password<hr />  
                     <input type="radio" name="radyear" value="2013" checked="checked"/>2013
                     <input type="radio" name="radyear" value="2014" />2014
                     <input type="radio" name="radyear" value="2015" />2015
                     <input type="radio" name="radyear" value="2016" />2016
                     <input type="radio" name="radyear" value="2017" />2017
                     <input type="radio" name="radyear" value="2018" />2018
                     <input type="radio" name="radyear" value="2019" />2019
                     <input type="radio" name="radyear" value="2020" />2020
                     <input type="radio" name="radyear" value="2021" />2021
</td>
</tr>
<tr>
<td colspan="2" align="center"><input type="submit" name="btnsubmit" value="View Password"></td>
<td style="background-color: #999;width:50px;"></td>
<td align="center"><input type="submit" value="Download Data" name="btn_pwd_download" /></td>
</tr>
</table>
</form>
<?php
if(isset($_POST['btnsubmit']) && !empty($_POST['btnsubmit']) && $_POST['btnsubmit']=='View Password')
{
	$roll=$_POST['rollno'];
	$sql="select email,password from tbl_student where roll_no='$roll'";
	$res=mysql_query($sql);
	$rows=mysql_num_rows($res);
	 if($rows==1)
	{$data=mysql_fetch_array($res);
	?>
	<form method="post" action="">
    <table align="center" bgcolor="#C3C3C3">
	  	<tr><td>Email Id</td>
        <td><input type="text" name="email" value="<?php echo $data[0] ?>" readonly="readonly"></td></tr>
                <tr><td>Current Password</td><td><input type="text" name="pwd_old" value="<?php echo $data[1] ?>" readonly="readonly"></td>
        </tr>
        <tr><td>New Password</td><td><input type="text" name="pwd" ></td>
        </tr>
        <tr><td colspan="2" align="center"><input type="submit" name="btnreset" value="Reset Password"></td></tr>
	<?php 
    }
  else
  {
     $_SESSION['ErrMsg']="<script>alert('This roll number is not exist !!!')</script>";
	   }
}
?>
</table>
</form>
<?php


$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>