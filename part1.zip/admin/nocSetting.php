<?php
ob_start();
include'../../NOCVerification/db.php';
include 'protectedAdmin.php';
include_once '../inc/conf.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
if(isset($_POST['btn_setting']) && $_POST['btn_setting']=="Change Settings"){
    
    if(isset($_POST['registration']) && $_POST['registration']!="Select" ){
        $value=$_POST['registration'];
        $last_dt=$_POST['dob'];
        $last_tm=$_POST['time1'].$_POST['time2'];
        $settingUpdateQuery="Update tbl_setting set value='$value', last_dt='$last_dt' ,last_tm='$last_tm' ,status='Active' where type='registration'";
        $resUpdateQuery=mysql_query($settingUpdateQuery);
        if($resUpdateQuery){
            $_SESSION['ErrMsg']="<script>alert('Setting Successfully Changed')</script>";
        }else{
            $_SESSION['ErrMsg']="<script>alert('Some error occurred. Please try once again.')</script>";
        }
    }
}
$query="select * from tbl_setting where type='registration' and status='Active'";
$res=  mysql_query($query);
$row=  mysql_fetch_array($res);
?>
<script>
    function change_regStatus()
    {
        var reg_status1=document.getElementById("reg_status1").value;
        var reg_status=document.getElementById("reg_status").innerHTML;
        
        if(reg_status1=="ON")
        {
            document.getElementById("dt").style.display="block";
        }
//        else if(reg_status1=="OFF")
//        {
//            document.getElementById("dt").style.display="none";
//        }
        else if(reg_status=="ON")
        {
            document.getElementById("dt").style.display="block";
        }
        else if(reg_status=="OFF")
        {
            document.getElementById("dt").style.display="none";
        }
        else
        {
            document.getElementById("dt").style.display="none";
        }
    }
</script>
<body onload="change_regStatus()">
<form method="post" action="">
<table align="center" bgcolor="#DFDFDF" width="900" cellspacing="5" cellpadding="5">
    <tr>
        <td colspan="3" align="center"><h1>NOC Administrator Settings</h1></td>
    </tr>
    <tr>
        <td>Setting Name</td>
        <td>Current Status</td>
        <td>New/Change to Status</td>
    </tr>
    <tr>
        <td>Registration Process for students</td>
        <td><span  id='reg_status'><?php echo $row['value']?></span></td>
        <td>Change to 
            <select name="registration" id="reg_status1" onchange="change_regStatus();">
                <option>OFF</option>
                <option>ON</option>
            </select>
            <span id="dt" style="display: none">
                <script type="text/javascript">DateInput('dob', true, 'YYYY-MM-DD')</script>
                <input type="text" name="time1" size="2" value="<?php echo substr($row['last_tm'],0,2)?>"><select name="time2"><option>PM</option><option>AM</option></select>
            </span>
        </td>
    </tr>
    <tr>
        <td colspan="3"><input type="submit" name='btn_setting' value="Change Settings" /></td>
    </tr>
    <tr>
        <td colspan="3" align="right"><a href="../../../NOCVerification/index.php" target="_blank">Move to NOC Verification</a></td>
    </tr>
</table>  
</form>
</body>
<?php
$content=ob_get_contents();
ob_clean();
include'template.php';
if(isset($_SESSION['ErrMsg']) && !empty($_SESSION['ErrMsg']))
{
	echo $_SESSION['ErrMsg'];
	unset ($_SESSION['ErrMsg']);
}
?>